## Laboratório (CLAUDE.md 5.9)
- Instalado: **não** (pendência do laboratório abaixo). Cópia de tester `C:\MT5_RF_Lab`; conta demo (`$LAB_LOGIN`): a preencher.
- Família padrão: v1 (2026-09-29): E3_SL45, E3_SL75, E3_TPM, E3_TRAIL0, E1_S540, E1_S660, NEWS5, NEWS20.
- Último lote lido: nenhum.
- Candidatas e extras em quarentena: nenhuma.
- Alternativas aguardando OK: nenhuma.
- OK ALTERNATIVA pendente de conferência: nenhum.
- Notícias para o tester (`news.csv` + `campanha\lab\news\`): USD até 2026-10-30.

@@PENDENCIAS@@
| N | **Instalar o laboratório** (SETUP_VPS 6.7): `ops\lab_instalar.ps1`, logar uma conta DEMO RoboForex-Pro na cópia `C:\MT5_RF_Lab` com Salvar senha (nunca a 52012798), desligar nela o MCP interno e o Algo Trading, preencher `$LAB_LOGIN` no `ops\config.ps1` e rodar `ops\register_tasks.ps1 -SoLab`. Até lá a revalidação (5.8) fica sem o item 6 | Henrique | aberta |
| N | Notícias para a revalidação de jan/2027: o `news.csv` vai até 2026-10-30; completar outubro a dezembro de 2026 em `campanha\lab\news\` pelo calendário do MCP (USD, impacto alto, em GMT; CLAUDE.md 5.9) antes de 2027-01-02 | Claude | aberta |
@@HISTORICO@@
- 2026-09-30 — **Laboratório de testes no kit** (pedido do Henrique de 29/09: "não quero que recomende, quero que já faça os novos testes e me dê alternativas e soluções"). `ops\lab.ps1` roda backtests numa cópia separada (`C:\MT5_RF_Lab`, conta demo), só de sábado 04:30 a domingo 17:30 UTC, com a família padrão v1 (8 variantes), StepM de Romano-Wolf e quarentena de 2 trimestres fora da amostra; o agente lê o relatório e entrega alternativas e soluções (CLAUDE.md 5.8 item 6 e 5.9); aplicar continua sendo do Henrique (`OK ALTERNATIVA`). Validado na estação: parser igual ao da campanha, lote de teste de ponta a ponta com o MT5 real. Achado: o `news.csv` com o fuso do início do teste deixava 194 saídas da E3 50 min depois da notícia no inverno; corrigido no laboratório (hora do servidor por evento), o C22 teria DD 15,3% em vez de 20,3%. Desligado até a pendência do laboratório.
