# SETUP_VPS.md — roteiro de instalação do kit Sobrevivência no Hyonix HS-3

## Caminho rápido (scripts)

Três scripts automatizam boa parte deste roteiro. **O roteiro manual abaixo continua valendo** e é a referência sempre que um passo falhar ou for pulado.

1. **Na estação (aqui)** — gerar o pacote (varre segredos, confere obrigatórios, imprime o SHA256):
   ```powershell
   powershell -NoProfile -File C:\Users\Henri\Sobrevivencia\ops\empacotar_kit.ps1
   ```
2. **Copiar o zip para o VPS** por RDP com a unidade local montada (`\\tsclient\C`) e conferir o SHA256 dos dois lados (o próprio script imprime os comandos).
3. **No VPS** — extrair o kit e rodar o instalador num PowerShell **como Administrador**, logado com o **usuário do auto-logon**:
   ```powershell
   Expand-Archive -Path C:\Sobrevivencia_kit_<carimbo>.zip -DestinationPath C:\ -Force
   powershell -NoProfile -ExecutionPolicy Bypass -File C:\Sobrevivencia\ops\vps_bootstrap.ps1 -KitZip C:\Sobrevivencia_kit_<carimbo>.zip -InstalarMT5 -MT5Setup C:\roboforex5setup.exe
   ```
   Faz fuso UTC, energia, proteção de tela, Windows Update de sábado 03:00, ExecutionPolicy, Git, Claude Code, download do Autologon, o kit em `C:\Sobrevivencia` e o MT5 portátil em `C:\MT5_RoboForex` — e imprime no fim **o que continua manual**. Nesse texto final, os itens (h) e (j) estão desatualizados (STATE pendência 17): no lugar do (h) vale a seção 6 (6.0 a 6.4: especificação do XAUUSD, já conferida em 22/09; Concorde só com `Concorde_E13_A.set`, guardião com `SurvivalGuardian_G35.set`, perfil salvo); no lugar do (j), o ensaio 8.6 sem posições, já na ProCent real. `-DryRun` mostra tudo sem alterar nada; `-Reescrever` (apelido `-Force`) reaplica valores já corretos; `-ForcarMaquina` é outro parâmetro e serve **só** para furar a guarda de máquina. Sem `-MT5Setup`, baixe `roboforex5setup.exe` na área do cliente (seção 2) e repita com `-Etapas "4" -InstalarMT5 -MT5Setup <caminho>`.
   **VPS que já roda o kit** (o caso desde 22/09): rodar só a etapa 3 (`-KitZip <zip> -Etapas "3"`), que preserva `STATE.md`, `DIARIO.md`, `ALERTAS.md` e `INBOX.md`. Nesta atualização (decisão E1+E3 com a escada A/B), logo depois dela, copiar `STATE.md` e `INBOX.md` da estação por cima (seção 3, último parágrafo), antes da primeira acordada do agente.
4. **Depois de ativar o MCP no terminal (2.7) e de fazer o login do Claude (4.2)** — registrar o MCP:
   ```powershell
   powershell -NoProfile -File C:\Sobrevivencia\ops\registrar_mcp.ps1
   ```
   Ele pede a chave sem eco (também aceita `-Chave "<chave do terminal>"`), testa porta e chave, registra no escopo `user` e confere no fim. `-SoTestar` só diagnostica; `-Forcar` substitui um registro que esteja com a chave errada.

> **A chave do MCP do terminal (porta 22346) é diferente da do MetaEditor (22345), e a chave longa em hexadecimal de `config\assistant.ini` não serve — o servidor responde 401.**

Versão 2026-09-22. Alvo: VPS Windows Server (Hyonix HS-3, 4 vCPU / 8 GB), conta ProCent RoboForex (depósito 98,50 USD = 9.850 USC, login 52012798).
Tudo que roda no VPS: **um** terminal MT5 RoboForex que opera, em modo `/portable` (`C:\MT5_RoboForex`), mais a cópia só de tester do laboratório (`C:\MT5_RF_Lab`, conta demo, só no fim de semana; seção 6.7), os EAs (SurvivalGuardian + Concorde_RF, mais o RegimeLogger, que só registra o regime do ouro e não opera; seção 6.6), o heartbeat em PowerShell (sem LLM, a cada 10 min) e o Claude Code headless (Task Scheduler). O agente nunca envia ordens: só lê estado e escreve `control.txt` via `ops\cmd.ps1`.

Convenções: comandos PowerShell rodam num console **PowerShell 5.1 como o usuário do auto-logon** (não precisa ser Administrador, salvo onde indicado). Caminhos fixos: workspace `C:\Sobrevivencia`, terminal `C:\MT5_RoboForex`. Se mudar algum, ajuste **só** `C:\Sobrevivencia\ops\config.ps1`.

---

## 0. Antes de contratar

- Hyonix só oferece Windows. No pedido do HS-3, **confirmar**: Windows Server 2022 (ou 2019) Standard/Datacenter em inglês, disco NVMe, e que **backup/snapshot não vem incluso** (o kit faz backup próprio, item 12).
- **Datacenter: Amsterdam, Netherlands. Sistema: Windows Server 2022.** Decidido em 2026-09-22. O terminal RoboForex local conectou nos 17 logins registrados pelo ponto de acesso "Netherlands" (IP 188.72.232.121, Amsterdã, AS35415 Webzilla), e do Brasil nunca escolheu um ponto nas Américas. Estimativa: 1 a 3 ms de Amsterdã, 5 a 10 ms de Frankfurt ou Londres, 75 a 90 ms da costa leste dos EUA, cerca de 145 ms de Phoenix. Conferir depois do login no VPS (item 2.4).
- Anotar: IP, usuário (`Administrator`) e senha inicial. **Trocar a senha** no primeiro logon (mínimo 16 caracteres, gerada por gerenciador de senhas).

## 1. Primeiro acesso (RDP) e base do sistema

1. Conectar por RDP (`mstsc`), trocar a senha (`Ctrl+Alt+End` > Alterar senha).
2. **Fuso horário UTC** (os horários das tarefas agendadas são em hora local, e o kit registra tudo em UTC):
   ```powershell
   Set-TimeZone -Id UTC
   w32tm /resync
   Get-TimeZone      # deve mostrar UTC
   ```
3. Energia/tela (nunca dormir, nunca bloquear a sessão; o terminal é um programa gráfico):
   ```powershell
   powercfg /change standby-timeout-ac 0
   powercfg /change monitor-timeout-ac 0
   powercfg /change hibernate-timeout-ac 0
   ```
   Em `gpedit.msc` > Configuração do Usuário > Modelos Administrativos > Painel de Controle > Personalização: **Habilitar proteção de tela = Desabilitado**. (Sem isso o Windows pode bloquear a sessão e as tarefas "somente quando logado" continuam rodando, mas o terminal fica numa sessão bloqueada — funciona, só atrapalha a inspeção por RDP.)
4. **Windows Update em janela de fim de semana** (`gpedit.msc` > Configuração do Computador > Modelos Administrativos > Componentes do Windows > Windows Update):
   - "Configurar Atualizações Automáticas" = **Habilitado**, opção **4 – Baixar automaticamente e agendar a instalação**, dia **Sábado**, hora **03:00** (UTC = sábado de madrugada, mercado fechado).
   - "Não reiniciar automaticamente com usuários conectados" = **Desabilitado** (queremos que reinicie na janela; o auto-logon e a tarefa `Sobrevivencia-Terminal` sobem tudo de novo).
   - Depois de qualquer atualização, conferir na segunda-feira: `ops\status.ps1`.
5. **Auto-logon** (obrigatório: o terminal MT5 e o heartbeat rodam na sessão interativa):
   - Baixar Sysinternals Autologon: <https://learn.microsoft.com/sysinternals/downloads/autologon> (zip oficial da Microsoft).
   - Executar `Autologon64.exe`, informar usuário/domínio (`.` ou o nome do computador)/senha, **Enable**. A senha fica cifrada como LSA secret (não em texto puro no registro).
   - Testar: `Restart-Computer`; ao voltar, a área de trabalho deve abrir sozinha (veja pelo RDP).
6. Instalar **Git for Windows** (<https://git-scm.com/download/win>, opções padrão) — usado pelo Claude Code (ferramenta Bash) e para versionar o workspace.
7. Habilitar execução de scripts locais para o usuário:
   ```powershell
   Set-ExecutionPolicy -Scope CurrentUser RemoteSigned -Force
   ```
   (As tarefas agendadas usam `-ExecutionPolicy Bypass` de qualquer forma.)

## 2. Terminal MT5 RoboForex em `C:\MT5_RoboForex` (SEMPRE /portable)

1. Baixar o instalador oficial da RoboForex (área do cliente > Plataformas > MetaTrader 5, `roboforex5setup.exe`).
2. Executar o instalador, clicar em **Configurações** e mudar a pasta de instalação para `C:\MT5_RoboForex`. Concluir e **fechar** o terminal que abrir (ele abriu em modo normal, com dados em AppData — não queremos isso).
3. Criar o atalho portátil (fica na área de trabalho e é o único jeito de abrir o terminal à mão):
   ```powershell
   $s = (New-Object -ComObject WScript.Shell).CreateShortcut("$env:USERPROFILE\Desktop\MT5 RoboForex (portable).lnk")
   $s.TargetPath = 'C:\MT5_RoboForex\terminal64.exe'; $s.Arguments = '/portable'; $s.WorkingDirectory = 'C:\MT5_RoboForex'; $s.Save()
   ```
   Abrir por esse atalho. Conferir que apareceu `C:\MT5_RoboForex\MQL5\` (é a prova do modo portátil). **Regra: nunca abrir `terminal64.exe` sem `/portable`** — cria uma segunda pasta de dados em AppData e os EAs/arquivos "somem".
4. **Login na conta ProCent real**: Arquivo > Login na conta de negociação > login, senha e o servidor que veio no e-mail de abertura da conta > marcar **Salvar senha**. Pela reestruturação da RoboForex de 2020, contas ProCent MT5 ficam no servidor **`RoboForex-Pro`**, o mesmo da demo usada nos backtests; se o e-mail disser outro nome, vale o e-mail. Conferir no Diário a linha `'<login>': authorized on RoboForex-Pro through Netherlands (ping: N ms)`: **N deve ficar entre 1 e 3 ms**. Se passar de 20 ms, o datacenter não está perto do servidor; anotar a linha e avisar. Ferramentas > Opções > Servidor: manter "Ativar notícias" e o **Calendário Econômico** ligados (o Concorde lê o calendário nativo ao vivo).
5. **Market Watch** (Ctrl+M): botão direito > **Mostrar todos**, depois deixar visíveis pelo menos `XAUUSD, EURUSD, GBPUSD, USDJPY, AUDUSD, USDCAD, USDCHF` (+ o que o portfólio pedir; os símbolos ProCent aparecem sem sufixo — conferir nome exato e `Especificação` de XAUUSD: tamanho do contrato, volume mínimo/passo, alavancagem; anotar em `STATE.md`; critério obrigatório antes de anexar o Concorde na seção 6.0).
6. Ferramentas > Opções > **Expert Advisors**: marcar **Permitir negociação algorítmica**; desmarcar "Desabilitar ... quando a conta muda / o perfil muda"; **não** precisa de DLL nem WebRequest.
7. **MCP nativo do terminal** (build 6061+): Ferramentas > Opções > aba **MCP** (é uma aba própria, entre "AI Assistant" e "Community"; conferido na build 6204 em 22/09/2026). Marcar **"Enable internal server"**, conferir o campo **Address** = `http://127.0.0.1:22346/mcp` e copiar o campo **API Key** (42 caracteres, botão **Copy**; o botão **Generate** gera uma nova e invalida a anterior). **Clicar em OK**: enquanto o diálogo está aberto nada é aplicado e a porta continua fechada — foi exatamente o que travou a instalação de 22/09. A lista "Endpoint / API key" embaixo é para clientes MCP externos e não tem relação com o servidor interno. Atenção: a chave do terminal é **diferente** da do MetaEditor (porta 22345) e a de `config\assistant.ini` **não serve** (memória do projeto). Guardar a chave num gerenciador de senhas; ela entra só no `claude mcp add` (item 4.3). Só uma instância pode escutar 22346: como o VPS terá um único terminal, ele fica com a porta.
8. Ferramentas > Opções > Gráficos: "Máx. de barras no gráfico" = 100000 (o Concorde/E4 usa H1 de 4 pares).

## 3. Kit: copiar o workspace para `C:\Sobrevivencia`

Da máquina local (`C:\Users\Henri\Sobrevivencia`) para o VPS, por RDP com unidade local mapeada (mstsc > Recursos locais > Unidades) ou zip pela área de transferência:
```powershell
# no VPS, com a unidade local montada como \\tsclient\C
robocopy \\tsclient\C\Users\Henri\Sobrevivencia C:\Sobrevivencia /E /XD logs .git /XF config.local.ps1 notify.secret.ps1 *.ex5 *.log
Get-ChildItem C:\Sobrevivencia -Recurse | Unblock-File
```
Não copiar `ops\config.local.ps1` (é o override da máquina local: apontaria para AppData) nem `notify.secret.ps1` (recriar no VPS, item 9). Estrutura esperada:
```
C:\Sobrevivencia\
  CLAUDE.md  STATE.md  DIARIO.md  ALERTAS.md  INBOX.md  SETUP_VPS.md
  .claude\settings.json        (allowlist de ferramentas do agente)
  ops\      config.ps1 common.ps1 start.ini start_terminal.ps1 heartbeat.ps1 run_claude.ps1
            cmd.ps1 status.ps1 compile.ps1 register_tasks.ps1 notify.ps1
            (config.local.example.ps1 e notify.secret.example.ps1 sao modelos)
  prompts\  diario.md semanal.md incidente.md preabertura.md
  mql5\Experts\*.mq5   mql5\Include\*.mqh   mql5\Presets\*.set (presets do Concorde e do guardião, seção 6)
  campanha\  docs\  ops\logs\ (criada na primeira execução)
```
Conferir a configuração: `powershell -NoProfile -File C:\Sobrevivencia\ops\status.ps1` deve imprimir os caminhos `C:\Sobrevivencia` e `C:\MT5_RoboForex\terminal64.exe` (ainda sem status.json — normal).

Alternativa a este passo (e ao resto das seções 1 e 2): `ops\empacotar_kit.ps1` na estação + `ops\vps_bootstrap.ps1 -KitZip <zip>` no VPS (ver **Caminho rápido** no topo). A etapa 3 do bootstrap **preserva** `STATE.md`, `DIARIO.md`, `ALERTAS.md`, `INBOX.md` e os arquivos de segredo, guardando uma cópia `<arquivo>.antes_<carimbo>` — por isso ela é o jeito seguro de reaplicar um kit atualizado num VPS que já está rodando (um `Expand-Archive -Force` por cima apagaria o diário, os alertas e um `OK RESUME` pendente).

**Atualização de 2026-09-22 (decisão E1+E3 com a escada A/B) num VPS que já tem o kit.** O `STATE.md` e o `INBOX.md` que a etapa 3 preserva são os de um pacote anterior (escala "A DEFINIR" com referência rfconf2x e E2 e E4 no portfólio, ou o plano anterior com referência C11; sem as linhas `OK DEGRAU` e sem os presets A/B). O agente leria o CLAUDE.md novo junto com esse STATE.md antigo. Enquanto as tarefas do Claude não estiverem registradas (STATE pendência 13), o agente ainda não escreveu nada nesses arquivos, então é seguro copiar os da estação por cima, logo depois do bootstrap e antes da primeira acordada:
```powershell
Copy-Item \\tsclient\C\Users\Henri\Sobrevivencia\STATE.md, \\tsclient\C\Users\Henri\Sobrevivencia\INBOX.md C:\Sobrevivencia\ -Force
Select-String -Path C:\Sobrevivencia\STATE.md -Pattern 'Concorde_E13_A' -Quiet    # tem de imprimir True
```
O `<arquivo>.antes_<carimbo>` deixado pela etapa 3 fica de backup. Se o `INBOX.md` do VPS já tiver linhas escritas pelo Henrique depois do `---` (ex.: o `OK RESUME` do ensaio 8.6), copiá-las para o fim do novo. `DIARIO.md` e `ALERTAS.md` também trazem o formato antigo no cabeçalho (colunas de P&L de E2/E4, exemplo com magic 550555): se no VPS eles ainda não têm nenhuma entrada real, copiar os da estação do mesmo jeito; se já têm, trocar só o bloco de formato/exemplo do topo e manter as entradas. Depois que o agente começar a escrever no VPS, não copiar mais o STATE.md inteiro: incorporar à mão só as seções "Portfólio", "Guardião", "Backtests de referência" e "Pendências".

## 4. Claude Code

1. Instalar (instalador nativo, sem Node):
   ```powershell
   irm https://claude.ai/install.ps1 | iex
   claude --version
   ```
   Fechar e reabrir o console para o PATH atualizar. O binário fica em `%USERPROFILE%\.local\bin\claude.exe` (o `config.ps1` procura aí e no shim do npm).
2. **Login por assinatura** no navegador do próprio VPS: rodar `claude` num console dentro de `C:\Sobrevivencia`, aceitar a pasta como confiável, `/login`, concluir no navegador (Edge). Sair com `/exit`. Confirmar: `claude -p "responda OK" --permission-mode acceptEdits` imprime `OK`.
   - Se o VPS não tiver navegador utilizável, copiar a URL de login para o navegador local e colar o código de volta no console.
   - O token fica em `%USERPROFILE%\.claude\`. Quando expirar, `run_claude.ps1` detecta a mensagem de login no log, grava `ERRO auth` em `heartbeat.log` e anexa um pedido de relogin em `ALERTAS.md` (+ Telegram CRITICO, se configurado); a tarefa agendada ainda tenta 2 vezes em 15 min, então podem chegar até 3 avisos. Relogin: `claude auth login` (ou `claude` e depois `/login`).
   - Opcional, para não depender de relogin: `claude setup-token` gera um token de longa duração (assinatura); guardá-lo como variável de ambiente **do usuário** `CLAUDE_CODE_OAUTH_TOKEN` (fora do workspace, nunca em arquivo do kit) e testar o `claude -p` de novo.
3. Registrar o MCP do terminal (escopo `user`, vale para qualquer pasta). O jeito recomendado é o ajudante, que diagnostica porta fechada, chave errada (401) e recusa do CLI:
   ```powershell
   powershell -NoProfile -File C:\Sobrevivencia\ops\registrar_mcp.ps1        # pede a chave sem eco
   powershell -NoProfile -File C:\Sobrevivencia\ops\registrar_mcp.ps1 -Forcar # troca um registro com a chave errada
   ```
   À mão, o comando equivalente:
   ```powershell
   claude mcp add --transport http mt5-terminal http://127.0.0.1:22346/mcp --header "Authorization: Bearer <CHAVE_DO_TERMINAL>" --scope user
   claude mcp list      # mt5-terminal ... Connected
   ```
   O nome **tem de ser `mt5-terminal`**: a allowlist em `.claude\settings.json` usa `mcp__mt5-terminal__get_*`, `list_*`, `read_file`, `read_file_by_lines`, `search_*` e `find_*`, e **nega** todos os `trade_*`, `tester_*`, `chart_*` **e todas as ferramentas de escrita** (`write_file`, `write_binary_file`, `create_new_file`, `create_new_folder`, `replace_text_in_file`, `delete_file`, `send_web_request`). O agente escreve no freio pelo `ops\cmd.ps1`, nunca pelo MCP — não "conserte" a allowlist dando escrita a ele.
   A chave digitada nesse comando fica no histórico do PSReadLine (`%APPDATA%\Microsoft\Windows\PowerShell\PSReadLine\ConsoleHost_history.txt`): rodar antes `Set-PSReadLineOption -HistorySaveStyle SaveNothing` no mesmo console, ou apagar a linha do arquivo depois. Nunca colar a chave em INBOX.md, DIARIO.md ou num prompt.
4. Testar o headless com o prompt real, sem esperar o agendamento:
   ```powershell
   powershell -NoProfile -File C:\Sobrevivencia\ops\run_claude.ps1 -Modo diario -DryRun   # mostra o comando
   powershell -NoProfile -File C:\Sobrevivencia\ops\run_claude.ps1 -Modo diario           # executa (até 45 min)
   ```
   Saída em `C:\Sobrevivencia\ops\logs\claude_diario_<data>.log`; o agente deve ter escrito em `DIARIO.md`.

## 5. Compilar os EAs no terminal do VPS

```powershell
powershell -NoProfile -File C:\Sobrevivencia\ops\compile.ps1
```
Copia `mql5\Include\*.mqh` para `C:\MT5_RoboForex\MQL5\Include\` e `mql5\Experts\*.mq5` para `...\MQL5\Experts\` (menos `*_original.mq5`), compila cada um com `metaeditor64.exe /compile /log /portable` e imprime `Result: N errors, M warnings`. Critério de sucesso: 0 erros **e** `.ex5` atualizado (o exit code do MetaEditor não é confiável). Se o terminal estiver aberto, atualizar a lista do Navegador (botão direito > Atualizar).

**Com os EAs já operando, compilar só o que mudou:** `compile.ps1 -Filtro <Nome>.mq5` (ex.: `-Filtro RegimeLogger.mq5`, seção 6.6). Sem o filtro o script recompila também o Concorde_RF e o SurvivalGuardian, e o terminal recarrega (deinit/init) todo EA em execução cujo `.ex5` foi regravado: o Concorde rebaseia o stop diário no meio do dia (CLAUDE.md, seção 3, camada 1) e o guardião passa de novo pelo aquecimento. Recompilar tudo só com o mercado fechado.

**news.csv**: o Concorde com `News_Source=0 (AUTO)` usa o **calendário nativo** ao vivo e o CSV só no tester. Ainda assim, copie `news.csv` (da máquina local: `%APPDATA%\MetaQuotes\Terminal\Common\Files\news.csv`) para:
- `%APPDATA%\MetaQuotes\Terminal\Common\Files\news.csv` no VPS (pasta `FILE_COMMON`; existe mesmo em modo portátil), e
- `C:\MT5_RoboForex\MQL5\Files\news.csv` (para o caso de `News_CsvCommonFolder=false`).

Validação ao vivo: no diário do Expert, após o init do Concorde, a linha `FILTRO NOTÍCIAS Concorde: fonte=CALENDARIO ... eventos=N` com N > 0. Se N = 0, o calendário está desligado (item 2.4) ou a RoboForex não o serve — nesse caso mudar `News_Source` para CSV e manter `news.csv` atualizado (cobre até dez/2026).

## 6. Anexar os EAs e salvar o perfil

Portfólio decidido pela campanha (`campanha\RESULTADOS.md`, seção 5): **Concorde_RF só com E1+E3, degrau A** (preset `Concorde_E13_A.set`: E1 0,4% e E3 1,2% por perna, stops diários 8% / 6%) e **SurvivalGuardian com os limites G35** (preset `SurvivalGuardian_G35.set`). O degrau B (`Concorde_E13_B.set` + `SurvivalGuardian_G45.set`) só entra pela seção 6.5. Os presets ficam em `C:\Sobrevivencia\mql5\Presets\`. Ordem obrigatória: 6.0 (concluída em 22/09) -> 6.1 -> 6.2 -> 6.3 -> 6.4. O ensaio HALT/RESUME sem posições (8.6) vem antes do 6.3, enquanto não há posição aberta. O RegimeLogger (6.6, registrador que não opera) entra depois do 6.4, a qualquer momento, e só depois de o CLAUDE.md, os prompts e o STATE.md do VPS conhecerem ele.

### 6.0 Checagem PRÉVIA obrigatória: especificação do XAUUSD na ProCent

**CONCLUÍDA em 2026-09-22** (Henrique, no VPS; registrada em STATE.md, seção "Especificação do XAUUSD"): contrato 100 XAU, dígitos 2, stops level 0, volume mínimo 0,01 e passo 0,01, margem ~436 por lote (alavancagem 1:1000), filling FOK/IOC, execução a mercado, swap long -60 / short +19 pontos (triplo na quarta), sessão 01:05-23:55 hora do servidor (UTC+3 = 22:05-20:55 UTC; as pendentes da E1 às 00:00 GMT caem dentro dela), sem negociação no sábado e no domingo. A margem de ~436 por lote com saldo 9.850 prova que o valor do tick é o padrão (1,00 na moeda da conta por lote para cada 0,01): a conta cent se comporta numericamente como a conta de 10.000 do backtest. Falta só o spread na abertura de Londres (item 2, opcional). O procedimento abaixo fica como referência, para repetir se a corretora mudar a especificação.

Sem esta checagem o Concorde **não** é anexado. Motivo: os backtests rodaram na conta Pro (demo, em USD, contrato de 100 onças) com depósito 10.000; a ProCent tem 9.850 USC. O EA dimensiona o lote pelo risco em % do saldo, usando o valor do tick que a corretora informa. Os percentuais só batem com o backtest se **0,01 lote na ProCent render, em USC, o mesmo número que 0,01 lote rende em USD na Pro**.

1. Market Watch (Ctrl+M) > XAUUSD > botão direito > **Especificação**. Anotar em `STATE.md` (pendência 6): moeda da conta (Caixa de Ferramentas > Negociação, ou `currency` do status.json), **Tamanho do contrato**, Dígitos, **Tamanho do tick**, **Valor do tick** (se a janela mostrar), Moeda de lucro, Moeda da margem, **Volume mínimo**, **Volume máximo**, **Passo de volume**, margem/alavancagem de metais e as **Sessões** de negociação.
2. Anotar também o **spread** do XAUUSD (coluna Spread do Market Watch) num dia útil entre 08:00 e 10:00 UTC (abertura de Londres, a hora da E3). É a referência de spread do critério de custo de execução (CLAUDE.md 5.6).
3. Comparar com o esperado:

| Campo | Backtest (RoboForex-Pro demo, conta em USD) | Esperado na ProCent para o dimensionamento bater |
|---|---|---|
| Dígitos / tamanho do tick | 2 / 0,01 | 2 / 0,01 |
| Tamanho do contrato | 100 onças (1 lote = 100 onças) | **1 lote-cent = 1 onça real.** A janela mostra 100 se a conta aparece em "USD" (como no status.json; as unidades são centavos) ou 1 se a conta aparece em "USC" (o lucro em USD é convertido x100). Os dois casos batem; quem decide é a linha de baixo |
| Valor do tick de 0,01 em 1 lote | 1,00 USD | **1,00 na moeda da conta (= 1 USC)** |
| 0,01 lote, tick de 0,01 | 0,01 USD | **0,01 USC** |
| 0,01 lote, movimento de 1 USD no ouro | 1,00 USD | **1,00 USC** (= 0,01 USD real) |
| Volume mínimo / passo | 0,01 / 0,01 | **0,01 / 0,01** |
| Volume máximo | — | pelo menos 1 lote (o maior lote do C23, degrau B, foi 0,62; no C22, degrau A, 0,24) |
| Sessão | aberta às 00:00 GMT (02:00 ou 03:00 do servidor) | aberta às 00:00 GMT: é quando a E1 coloca as pendentes do range noturno (na validação V1 a sessão fechava nessa hora e a E1 não operou) |
| Alavancagem | 1:1000 | anotar. Com 1:100 ou mais, 4 pernas típicas (0,20 lote, nocional ~86.000 USC com o ouro a ~4.300) pedem menos de 10% da conta em margem. Abaixo de 1:100, avisar antes de anexar |

Se a janela não mostrar "Valor do tick", calcular: valor do tick por lote = tamanho do contrato x 0,01, em USD; se a moeda da conta for USC, multiplicar por 100. Tem de dar 1,00 na moeda da conta.

Exemplo com o saldo de hoje (9.850), para conferir que o lote sai igual ao do backtest de 10.000 (lote = risco / (distância do SL em ticks x valor do tick), arredondado para baixo no passo 0,01):
- E1 no degrau A, 0,4% por perna = 39,40 USC. SL típico da E1: 15,38 USD (mediana do C19) = 1.538 ticks. Lote = 39,40 / (1.538 x 1,00) = 0,026 -> **0,02**. Perda no SL = 0,02 x 1.538 x 1,00 = 30,76 USC (0,31% da conta). No backtest com 10.000: 40 / 1.538 = 0,026 -> 0,02. Igual.
- E3 no degrau A, 1,2% por perna = 118,20 USC. SL típico da E3: 33,45 USD = 3.345 ticks. Lote = 118,20 / 3.345 = 0,035 -> **0,03**. Perda no SL = 100,35 USC (1,02%). Backtest: 120 / 3.345 = 0,036 -> 0,03. Igual.

**Não bateu = NÃO anexar o Concorde e avisar o Claude** (texto livre no INBOX.md ou direto na estação), com os valores anotados. O guardião continua no ar. Os dois erros que importam:
- Valor do tick de 100 USC por lote (conta em USC com contrato de 100 onças, isto é, 1 lote-cent = 100 onças reais): o EA calcularia 0,0005 lote, o arredondamento daria zero e ele subiria para o **lote mínimo de 0,01**. Cada perna da E1 perderia 0,01 x 1.538 x 100 = **1.538 USC (15,6% da conta)** no SL, e a E1 abre 2 pernas: ~31% num único trade. Na E3, 3.345 USC (34%) por perna. HALT ou morte no primeiro trade perdedor.
- Valor do tick de 0,01 por lote, ou volume mínimo/passo diferente de 0,01: o risco em % pode até bater, mas o lote, a granularidade e os limites de volume não são os do backtest. O Claude refaz a conta antes de qualquer anexo.

### 6.1 Copiar os presets para o terminal

```powershell
# presets do plano anterior (obsoletos): se vieram de um pacote antigo, apagar antes de copiar
Remove-Item C:\Sobrevivencia\mql5\Presets\Concorde_E13_x100.set, C:\Sobrevivencia\mql5\Presets\Concorde_E13_x150s.set -ErrorAction SilentlyContinue
Remove-Item C:\MT5_RoboForex\MQL5\Presets\Concorde_E13_x100.set, C:\MT5_RoboForex\MQL5\Presets\Concorde_E13_x150s.set -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force C:\MT5_RoboForex\MQL5\Presets | Out-Null
Copy-Item C:\Sobrevivencia\mql5\Presets\*.set C:\MT5_RoboForex\MQL5\Presets\ -Force
Get-ChildItem C:\MT5_RoboForex\MQL5\Presets\*.set | Select-Object Name, Length
```
Devem aparecer 4 arquivos: `Concorde_E13_A.set`, `Concorde_E13_B.set`, `SurvivalGuardian_G35.set` e `SurvivalGuardian_G45.set` (UTF-16, abrem no Bloco de Notas). O `Expand-Archive` e a etapa 3 do bootstrap copiam por cima sem apagar nada, por isso os dois presets obsoletos podem ter ficado no VPS: as duas linhas `Remove-Item` acima resolvem. A janela de inputs do EA abre `MQL5\Presets\` ao clicar em **Carregar**.

### 6.2 SurvivalGuardian (G35)

1. O guardião já está no gráfico **EURUSD H1** desde 22/09, com os defaults, que são os valores do G35. Para conferir, ou se for anexar de novo: no gráfico do guardião, F7 (propriedades do Expert) > aba **Parâmetros** > **Carregar** > `SurvivalGuardian_G35.set` > conferir `Inp_DiarioMaxPerdaPct=10`, `Inp_DD_ReduzPct=20`, `Inp_DD_ReduzHisterese=10`, `Inp_DD_HaltPct=35` e `Inp_ResetEstado=false` > aba **Comum**: "Permitir negociação algorítmica" marcado > **OK**. Recarregar os inputs não perde o estado (HWM, HALT e last_seq ficam nas GVs `SURV_*` e no `state.txt`).
2. Conferir: `guardian.log` (mostrado por `ops\status.ps1`) com a linha `SurvivalGuardian v1.10 iniciado: ... | lock diario 10.0% ... | DD reduz 20.0% (hist 10.0%, escala 0.50) | DD halt 35.0% ...`, e o status.json com `limit_daily_loss_pct` 10, `limit_dd_reduce_pct` 20, `limit_dd_hysteresis_pct` 10 e `limit_dd_halt_pct` 35.

### 6.3 Concorde_RF (E1+E3, degrau A), só depois do 6.0 aprovado (aprovado em 22/09)

1. Abrir gráfico **XAUUSD M15** > arrastar **Concorde_RF** (versão com `SurvivalGuard.mqh`) do Navegador.
2. Aba **Comum**: marcar "Permitir negociação algorítmica".
3. Aba **Parâmetros** > **Carregar** > `Concorde_E13_A.set`. Conferir na lista, antes do OK: `Estrategia1_Ativada=true`, `Estrategia2_Ativada=false`, `Estrategia3_Ativada=true`, `Estrategia4_Ativada=false`, `E1_RiscoPorPernaPct=0.4`, `E3_RiscoPorPernaPct=1.2`, `Concorde_StopDiarioGlobalPct=8.0`, `E3_StopDiarioPercent=6.0`, sufixos vazios (`E1_Simbolo`, `E2_Simbolo`, `E3_SufixoSimbolo`, `E4_SymbolSuffix`), `News_Enable=true` e `Panel_Mostrar=true`. Os demais inputs ficam como vieram do preset (são os do backtest C22). **OK**.
4. Botão **Algo Trading** (barra de ferramentas) **ligado**. Na aba **Experts** do Diário, na ordem em que o EA imprime:
   - `E1 | Saída GMT0 >= 10:00 | Trail=PERIOD_M15 | TPs min=3.0R | Lote: RISCO 0.40%/perna (v9) | Conta hedge recomendada.`
   - `E4 par 1 ativo: EURUSD ...` até `E4 iniciada com 4 par(es).` É normal mesmo com a E4 desligada: o EA prepara os indicadores dos pares, e o `Estrategia4_Ativada=false` bloqueia toda entrada nova.
   - `FILTRO NOTÍCIAS Concorde: fonte=CALENDÁRIO nativo | ... | eventos=N` com N > 0.
   - `Concorde EA inicializado: E1+E2(off)+E3+E4 | fuso GMT+3 (auto/DST) | stopGlobal=sim 8.0% | capPernas=4 | E3 ATR=1` (GMT+2 depois do fim do horário de verão europeu, no fim de outubro).
   - `SURV: Concorde v3.04 integrado ao SurvivalGuard | ...`

   **Atenção ao texto da linha de init** (conferido no fonte `mql5\Experts\Concorde_RF.mq5`, `OnInit`): o EA só marca `(off)` na E2. A E4 aparece como `+E4` mesmo desligada, e E1/E3 não mostram estado. A linha **não** prova que a E4 está desligada. O painel do gráfico fica **desligado** (`Panel_Mostrar=false`, decisão do Henrique em 2026-09-23 para execução mais leve; os presets já saem assim), então a prova é: (1) a janela de parâmetros do EA (F7 > Parâmetros: `Estrategia2_Ativada=false`, `Estrategia4_Ativada=false`, `E1_RiscoPorPernaPct=0.4`, `E3_RiscoPorPernaPct=1.2`); (2) o snapshot do perfil depois do `ops\save_profile.ps1`: `Select-String -Path C:\Sobrevivencia\ops\profile\sobrevivencia\*.chr -Pattern 'Estrategia2_Ativada=false','Estrategia4_Ativada=false','E3_RiscoPorPernaPct=1.2'` tem de achar as três. O risco da E3 não aparece no diário do Expert (a linha "E2 lote: RISCO ..." que sai na inicialização é da E2, desligada). Se algum dos três não bater: remover o EA e repetir o item 3.
5. Conferir que `C:\MT5_RoboForex\MQL5\Files\survival\status.json` está sendo atualizado: `powershell -NoProfile -File C:\Sobrevivencia\ops\status.ps1`.
6. Na primeira madrugada (00:00 GMT) a E1 coloca as pendentes do range noturno. Na manhã seguinte, conferir no Diário que não houve `market closed` nem `invalid volume` da E1 e que as ordens têm magic 202512. Qualquer posição ou ordem com magic 202605122 (E2) ou 550555 (E4) é preset errado: o Claude manda HALT (CLAUDE.md 9.3).
7. Anotar em `STATE.md`, seção Conta, a linha "Início ao vivo do Concorde" com a data/hora UTC do anexo. Os critérios de subida (CLAUDE.md 5.6) contam dali; HALTs de ensaio anteriores não contam.

### 6.4 Salvar o perfil

1. **Salvar o perfil**: Arquivo > Perfis > **Salvar como...** > `sobrevivencia`. O nome importa: `ops\start.ini` (passado como `/config:` por `start_terminal.ps1`) carrega `ProfileLast=sobrevivencia` e religa `AllowLiveTrading=1` / `Enabled=1` a cada arranque. Depois de um reinício via `ops\start_terminal.ps1 -Restart`, confirmar que os gráficos do perfil voltaram com os EAs (guardião e Concorde; depois do 6.6, também o RegimeLogger no XAUUSD D1) e o botão Algo Trading ligado (o `SurvivalGuardian` também restaura as GVs `SURV_*` persistidas e o `survival\state.txt`).
2. **Guardar a cópia do perfil no kit**: `powershell -NoProfile -File C:\Sobrevivencia\ops\save_profile.ps1`. O `start_terminal.ps1` restaura essa cópia (`ops\profile\sobrevivencia\`) antes de cada arranque, para que um perfil salvo sem o gráfico do guardião (fechado por engano) não se perpetue. **Repetir o `save_profile.ps1` depois de qualquer mudança nos gráficos ou inputs feita por RDP** (ex.: `OK LIMITES`, troca de preset); senão o próximo reinício volta ao snapshot anterior. Opcional: salvar o gráfico do guardião como template `guardian.tpl` (botão direito > Templates > Salvar); o script também o copia para `ops\templates\`.

### 6.5 Degrau B (só com `OK DEGRAU B` no INBOX)

Depois que o Claude recomendar em ALERTAS.md e o Henrique escrever a linha `AAAA-MM-DD OK DEGRAU B` no INBOX, no fim de semana, por RDP (CLAUDE.md 5.6). Antes, conferir que o alerta de subida continua aberto: se ele tem uma linha `Estado: FECHADO ... NÃO aplicar`, algum critério voltou a falhar e o degrau não deve ser aplicado.
1. Gráfico XAUUSD M15 > F7 no Concorde > **Parâmetros** > **Carregar** > `Concorde_E13_B.set` > conferir `E1_RiscoPorPernaPct=0.4`, `E3_RiscoPorPernaPct=1.8`, `Concorde_StopDiarioGlobalPct=12.0`, `E3_StopDiarioPercent=9.0`, `Estrategia2_Ativada=false` e `Estrategia4_Ativada=false` > **OK**. Diário: `stopGlobal=sim 12.0%` (a linha da E1 continua `Lote: RISCO 0.40%/perna`, igual à do degrau A); painel: E3 "Risco: 1.8%/p".
2. Gráfico do guardião > F7 > **Parâmetros** > **Carregar** > `SurvivalGuardian_G45.set` > conferir `Inp_DiarioMaxPerdaPct=15`, `Inp_DD_ReduzPct=25`, `Inp_DD_ReduzHisterese=12` e `Inp_DD_HaltPct=45` > **OK**. status.json: `limit_daily_loss_pct` 15, `limit_dd_reduce_pct` 25, `limit_dd_hysteresis_pct` 12, `limit_dd_halt_pct` 45.
3. Os dois presets vão sempre juntos. No fim, Arquivo > Perfis > **Salvar como...** > `sobrevivencia` e `ops\save_profile.ps1`: o `start_terminal.ps1` restaura esse snapshot em todo arranque, e sem ele o próximo reinício (RESUME, heartbeat, reboot) volta ao preset anterior.

**Descida para o degrau A** (com `AAAA-MM-DD OK DEGRAU A` no INBOX, que cobre o Concorde e o guardião; CLAUDE.md 5.6):
1. Antes de tudo, ler o `dd_pct` (`ops\status.ps1`). Com `dd_pct` >= 30%: trocar **só o Concorde** e manter o G45 até o DD cair abaixo de 30%. O guardião reavalia os limites em cerca de 15 s: carregar o G35 com DD >= 35% dispara HALT na hora e fecha tudo no fundo do DD (o RESUME não resolve enquanto o DD continuar >= 35%), e entre 30% e 35% não sobra margem. Com `dd_pct` < 30%: as duas trocas. Entre 20% e 30%, o G35 põe a escala em 0,5 (se ela estiver em AUTO) até o DD ficar abaixo de 10%. A troca do guardião adiada por DD >= 30% não precisa de linha nova: vale a mesma `OK DEGRAU A`, quando o Claude avisar (linha de "Estado" no alerta da descida) que o DD caiu abaixo de 30%.
2. Concorde: F7 > **Parâmetros** > **Carregar** > `Concorde_E13_A.set` > conferir `E1_RiscoPorPernaPct=0.4`, `E3_RiscoPorPernaPct=1.2`, `Concorde_StopDiarioGlobalPct=8.0`, `E3_StopDiarioPercent=6.0`, `Estrategia2_Ativada=false` e `Estrategia4_Ativada=false` > **OK**. Diário: `stopGlobal=sim 8.0%`; E3 1,2% conferido nos parâmetros e no snapshot do perfil (o painel fica desligado).
3. Guardião (se for a vez dele): F7 > **Parâmetros** > **Carregar** > `SurvivalGuardian_G35.set` > **OK**. status.json: `limit_daily_loss_pct` 10, `limit_dd_reduce_pct` 20, `limit_dd_hysteresis_pct` 10, `limit_dd_halt_pct` 35.
4. Arquivo > Perfis > **Salvar como...** > `sobrevivencia` e `ops\save_profile.ps1`.
O `RISK_SCALE AUTO` que desfaz um 0,67 manual é do Claude, na acordada de fim de semana, depois de conferir a troca.

### 6.6 RegimeLogger (registrador do regime do ouro, não opera)

Terceiro EA do kit, aprovado pelo Henrique em 23/09 (STATE pendência 21). Grava uma linha por dia do servidor em `C:\MT5_RoboForex\MQL5\Files\survival\regime.csv`: amplitude diária `amplitude_pct` ((máxima - mínima) / fechamento da barra D1, em %), `atr14_pct`, `vol20_pct` (mediana de 20 dias da amplitude) e métricas das janelas da E1 e da E3. Serve para o Claude acompanhar a volatilidade do ouro (alerta abaixo de 1,40% e recomendação de redução abaixo de 1,20%, CLAUDE.md 5.7) e guardar dados para as revalidações trimestrais (CLAUDE.md 5.8). Não envia ordens, não tem magic, não tem preset e não registra spread nem ticks. Não mexe nos outros gráficos: pode ser instalado em qualquer dia, sem zerar posições.

**Ordem obrigatória: regras primeiro, gráfico depois.** Com o CLAUDE.md antigo, um gráfico com um EA que não consta em STATE.md é "EA desconhecido" e o agente manda HALT.
1. Levar o kit novo ao VPS pela etapa 3 do bootstrap (`vps_bootstrap.ps1 -KitZip <zip> -Etapas "3"`, que atualiza CLAUDE.md, prompts, docs, SETUP_VPS, `ops\` e `mql5\` e preserva STATE.md, DIARIO.md, ALERTAS.md e INBOX.md). Conferir: `Select-String C:\Sobrevivencia\CLAUDE.md -Pattern '5.7 Regime do ouro' -Quiet` e `Test-Path C:\Sobrevivencia\mql5\Experts\RegimeLogger.mq5` imprimem `True`.
2. STATE.md do VPS: ele tem edições ao vivo, então **não** copiar o da estação por cima. Incorporar à mão, a partir do da estação: a linha do RegimeLogger na tabela "Portfólio planejado", o complemento "0,5 FIXO (regime)" na linha "risk_scale esperado do guardião", a seção inteira "Regime do ouro" e a pendência 21. Conferir: `Select-String C:\Sobrevivencia\STATE.md -Pattern 'RegimeLogger' -Quiet` imprime `True`.
3. Compilar **só** ele (seção 5): `powershell -NoProfile -File C:\Sobrevivencia\ops\compile.ps1 -Filtro RegimeLogger.mq5`. Esperado: `OK  RegimeLogger.mq5  Result: 0 errors, ...  ex5_atualizado=True`. Sem o `-Filtro` o Concorde e o guardião seriam recompilados e recarregados.
4. No terminal: Navegador (Ctrl+N) > Expert Advisors > botão direito > **Atualizar**. Arquivo > **Novo gráfico** > XAUUSD, período **D1**.
5. Arrastar **RegimeLogger** para esse gráfico. Aba **Comum**: "Permitir negociação algorítmica" marcado, como nos outros dois EAs (o fonte não tem nenhuma função de ordem: sem `Trade.mqh`, `CTrade` ou `OrderSend`; e um EA sem permissão de trade no terminal cairia na linha "EA sem permissão de trade" da seção 6 do CLAUDE.md, que manda reiniciar o terminal) e "Permitir importação de DLL" desmarcado. Aba **Parâmetros**: os padrões do fonte, **sem preset**. **OK**.
6. Conferir na aba **Experts** do Diário `RegimeLogger v1.10 iniciado (NAO OPERA): simbolo XAUUSD, arquivo MQL5\Files\survival\regime.csv, ...`, depois `arquivo survival\regime.csv criado com cabecalho; backfill de 180 dias.` e `gravados N dia(s) de ... a ...`, sem linha `RegimeLogger ERRO`. Com o mercado aberto, em ~1 min aparece `RegimeLogger: offset real do servidor (3 h) confere com a regra.` (2 h no inverno europeu); com o mercado fechado essa checagem espera a abertura. Uma linha `RegimeLogger AVISO: offset pela regra ... diverge do real` (só sai depois de ~1 h seguida de mercado aberto) merece aviso ao Claude (as colunas das janelas da E1 e da E3 ficariam deslocadas). Uma linha `RegimeLogger AVISO <data>: ... historico incompleto ...` durante o backfill não é erro: o M1 daquele dia não carregou em ~10 min e o dia fica só com as colunas de amplitude (cada dia assim atrasa o backfill em ~10 min). `dia <data> pulado: barra D1 residual (feriado)` também é normal. E o `regime.csv` com o backfill:
   ```powershell
   Get-Content C:\MT5_RoboForex\MQL5\Files\survival\regime.csv -TotalCount 3   # cabeçalho + primeiras linhas do backfill
   Get-Content C:\MT5_RoboForex\MQL5\Files\survival\regime.csv -Tail 5         # últimos dias
   ```
   Cabeçalho `data_servidor;abertura;maxima;minima;fechamento;amplitude_usd;amplitude_pct;atr14_pct;vol20_pct;...;gerado_em`, ~180 linhas de backfill, a última do último dia do servidor já fechado (a linha de um dia é gravada ~2 min depois da meia-noite do servidor; no fim de semana, a de sexta) e o `vol20_pct` plausível (em set/2026, ~2,0% a 2,4%). Arquivo ausente ou vazio: ver o erro no Diário, remover o EA do gráfico (não há risco: ele não opera) e avisar o Claude na estação.
7. Salvar o perfil: Arquivo > Perfis > **Salvar como...** > `sobrevivencia` e `powershell -NoProfile -File C:\Sobrevivencia\ops\save_profile.ps1`. Conferir que o snapshot tem o gráfico dele: `Select-String C:\Sobrevivencia\ops\profile\sobrevivencia\*.chr -Pattern 'RegimeLogger' -List` mostra um `.chr`. Sem isso o próximo arranque do terminal (heartbeat, RESUME, reboot) volta sem o gráfico.
8. Não é preciso anotar nada no STATE.md: na primeira acordada que vir o gráfico, o `regime.csv` e o snapshot, o agente preenche a linha "RegimeLogger instalado" e fecha a pendência 21 (CLAUDE.md 5.7). Se quiser testar o arranque, `ops\start_terminal.ps1 -Restart` só com o mercado fechado (o reinício também recarrega o Concorde) e conferir os três gráficos.

Operação: no HALT o guardião fecha todos os outros gráficos, inclusive o do RegimeLogger; ele volta com o perfil no próximo arranque. `regime.csv` parado há mais de 2 dias úteis, ou o gráfico dele ausente fora de HALT, é ATENCAO para o agente, nunca HALT nem reinício do terminal (CLAUDE.md, seção 6). Para reanexar, repetir os itens 4, 5 e 7.

### 6.7 Laboratório de testes (cópia de tester, conta demo)

O laboratório (`ops\lab.ps1`, CLAUDE.md 5.9) roda os backtests da revalidação trimestral e os pedidos do Claude numa **cópia separada** do terminal, logada numa conta **demo**, só de sábado 04:30 a domingo 17:30 UTC. O agente não roda o tester: só lê os relatórios e escreve pedidos numa fila. Instalar uma vez, em qualquer dia (não mexe no terminal ao vivo nem nas posições):
1. `powershell -NoProfile -ExecutionPolicy Bypass -File C:\Sobrevivencia\ops\lab_instalar.ps1`. Copia só os programas do terminal ao vivo para `C:\MT5_RF_Lab` (sem config, contas, perfis, MQL5, bases ou logs), mais `servers.dat` e o `Concorde_RF.ex5`. Exige 20 GB livres. Nunca use `C:\RF_bt` no VPS (o `vps_bootstrap.ps1` aborta se existir).
2. Abrir **a cópia**: `C:\MT5_RF_Lab\terminal64.exe /portable`. Arquivo > Abrir uma conta > RoboForex-Pro > **conta demo**, marcando Salvar senha. **Nunca** logar a conta real 52012798 nela: um tester na mesma conta derrubou a sessão ao vivo 3 vezes na Axi. O `lab.ps1` recusa rodar se a cópia estiver em outra conta que não a `$LAB_LOGIN`.
3. Na cópia: Ferramentas > Opções > **MCP** > desmarcar "Enable internal server" > OK (a porta 22346 é do terminal ao vivo; o lab aborta se a cópia abrir o MCP). Ferramentas > Opções > **Expert Advisors** > desmarcar "Permitir negociação algorítmica" > OK. Nenhum gráfico com EA. Arquivo > Sair.
4. Em `C:\Sobrevivencia\ops\config.ps1`, trocar `$LAB_LOGIN = 0` pelo número da conta demo (sem o número, o laboratório fica desligado).
5. `powershell -NoProfile -ExecutionPolicy Bypass -File C:\Sobrevivencia\ops\register_tasks.ps1 -SoLab` (registra só a tarefa `Sobrevivencia-Lab`, a cada 30 min).
6. Conferir: `powershell -NoProfile -ExecutionPolicy Bypass -File C:\Sobrevivencia\ops\lab.ps1` mostra "copia: ok" e "executor: parado". O primeiro sábado roda a sonda (1 semana, alguns minutos) e, se o último trimestre ainda não tem lote, o lote trimestral (algumas horas; o relatório sai em `campanha\lab\lotes\<id>\relatorio.md` e o Claude é chamado para ler).

Demo expirada (a sonda de sábado falha por autorização): abrir uma demo nova na cópia (passo 2) e atualizar `$LAB_LOGIN`. Para aplicar uma alternativa aprovada (`OK ALTERNATIVA`): `ops\lab.ps1 -Acao conferir -Proposta <arquivo.set>`, depois carregar o `.set` no gráfico XAUUSD M15 no fim de semana, salvar o perfil e rodar `ops\save_profile.ps1`.

## 7. Tarefas agendadas

```powershell
powershell -NoProfile -File C:\Sobrevivencia\ops\register_tasks.ps1
powershell -NoProfile -File C:\Sobrevivencia\ops\register_tasks.ps1 -List
```
Registra, como o usuário atual e **somente com sessão aberta** (auto-logon garante isso):

| Tarefa | Gatilho (hora local = UTC) | Script |
|---|---|---|
| Sobrevivencia-Heartbeat | a cada 10 min | `heartbeat.ps1` |
| Sobrevivencia-Diario | seg–sex 22:30 (depois do fechamento do dia-servidor, 21:00 ou 22:00 UTC conforme o horário de verão) | `run_claude.ps1 -Modo diario` |
| Sobrevivencia-Semanal | sáb 12:00 | `run_claude.ps1 -Modo semanal` |
| Sobrevivencia-PreAbertura | dom 18:00 | `run_claude.ps1 -Modo preabertura` |
| Sobrevivencia-Terminal | ao logon (+1 min) | `start_terminal.ps1 -SoIniciar` |
| Sobrevivencia-Lab | a cada 30 min (o executor só roda sáb 04:30 a dom 17:30; sem "iniciar assim que possível") | `lab.ps1 -Acao agendado` |

Os horários são os do CLAUDE.md (seção 1). O terminal e o `run_claude` de incidente são criados **fora do job da tarefa** (WMI, `Start-Detached` em `common.ps1`): dentro dele o Task Scheduler os mataria ao estourar o limite de tempo da tarefa (5 min Terminal, 8 min Heartbeat) e a tarefa ficaria "Running" até eles morrerem.

Opcional `-RunWhetherLoggedOn` (pede a senha) faz **só** as três tarefas do Claude rodarem sem sessão; Heartbeat e Terminal continuam interativas porque sobem o terminal gráfico. Remover tudo: `register_tasks.ps1 -Unregister`. O script avisa se o fuso não for UTC.

Além disso, colocar o atalho portátil também em `shell:startup` (Win+R > `shell:startup`) é redundante com a tarefa `Sobrevivencia-Terminal` — usar **uma** das duas (recomendado: a tarefa, porque passa por `start_terminal.ps1` e registra no `ops.log`).

## 8. CHECKLIST de validação (na ordem)

1. `Get-TimeZone` = UTC; `Get-Process terminal64 | Select Path` = `C:\MT5_RoboForex\terminal64.exe` (uma única instância do terminal ao vivo; fora do fim de semana nenhum processo de `C:\MT5_RF_Lab`).
2. `ops\status.ps1`: `status.json` com idade < 60 s, `connected: sim`, `state OK`, equity = saldo ProCent.
3. `ops\cmd.ps1 -Cmd PING` → `ACK seq=N cmd=PING result=OK` em poucos segundos (prova o caminho control.txt → guardião → status.json).
4. `ops\heartbeat.ps1 -Eco` imprime uma linha `... | acao=ok`; após 20 min, `ops\logs\heartbeat.log` tem ≥ 2 linhas escritas pela tarefa agendada (`register_tasks.ps1 -List` mostra `LastTaskResult 0`).
5. `ops\run_claude.ps1 -Modo diario` termina com `exit=0` no `ops.log` e `DIARIO.md` ganhou uma entrada com a data de hoje.
6. **Ensaio HALT/RESUME na ProCent, sem posições abertas** (custo zero; o terminal já está na conta real desde 22/09). Fazer antes do 6.3 (STATE pendência 5): itens 1 a 4 e 6 agora; o item 5 precisa de uma entrada do Concorde e fica para depois do 6.3.
   1. `ops\cmd.ps1 -Cmd HALT` → ACK; o Diário mostra o guardião em HALT e `status.ps1` mostra `state HALT` (sem posições, não há o que fechar). Com o Concorde já anexado e `Inp_FecharGraficosNoHalt=true`, o gráfico dele também seria fechado (só o do guardião fica): é o esperado.
   2. Se o heartbeat já estiver agendado (seção 7), esperar um ciclo: `heartbeat.log` deve registrar `acao=INCIDENTE` (uma vez) e `ALERTAS.md` a linha de incidente; `ops\logs\claude_incidente_*.log` aparece. Esse alerta recebe depois a linha `Estado: FECHADO em <data> (ensaio 8.6)`. HALTs de ensaio anteriores ao anexo do Concorde não contam no critério 4 de subida (CLAUDE.md 5.6).
   3. Reiniciar o terminal (`start_terminal.ps1 -Restart`): o HALT **tem de sobreviver** ao restart (GV forçada a disco + `state.txt`). Repetir com um kill forçado, **pelo caminho** (`Get-Process terminal64 | Where-Object Path -eq 'C:\MT5_RoboForex\terminal64.exe' | Stop-Process -Force`; nunca `-Name` sozinho, que mataria também a cópia do laboratório): o HALT também tem de voltar (`guardian.log`: "estado lido de survival\state.txt").
   4. Escrever em `INBOX.md` a linha `AAAA-MM-DD OK RESUME` (data igual ou posterior à da linha `HALT ATIVADO` do guardian.log, que está no horário do servidor, GMT+2/+3: um HALT depois das 21:00 ou 22:00 UTC já tem a data do dia seguinte) e rodar `ops\cmd.ps1 -Cmd RESUME` → ACK, `state OK`. Sem a linha, com data anterior ao HALT, dentro de um bloco ``` ou já usada por um RESUME anterior, o script recusa — é a trava humana. Cada linha vale para **um** RESUME (registro em `ops\logs\resume_consumido.txt`). O RESUME **não** altera a escala de risco: se havia `RISK_SCALE 0.5` manual, continua 0,5. Depois do RESUME o gráfico do Concorde ainda está fechado (item 1): `start_terminal.ps1 -Restart` recoloca os dois gráficos pelo perfil do kit; conferir. Ao vivo, o Claude só envia o RESUME na acordada de fim de semana (CLAUDE.md, regra 5); para RESUME imediato o Henrique roda o `cmd.ps1` ele mesmo por RDP.
   5. `ops\cmd.ps1 -Cmd RISK_SCALE -Arg 0.5` → conferir no Diário do Concorde que o lote caiu pela metade na próxima entrada; `-Cmd RISK_SCALE -Arg AUTO` devolve o controle à regra de DD (`-Arg 1` fixaria 1,0 manual).
   6. `ops\cmd.ps1 -Cmd LOCK_TODAY` / `-Cmd UNLOCK_TODAY` e `-Cmd SET_HWM -Arg <equity atual>`.
7. Desligar o terminal à mão (Arquivo > Sair) e esperar 10–20 min: o heartbeat deve subi-lo de novo (`acao=START_TERMINAL`), já com o perfil e o AutoTrading do `start.ini`. **Esperar mais 15 min e conferir que o terminal continua vivo** (`Get-Process terminal64`) e que `register_tasks.ps1 -List` mostra a tarefa Heartbeat em `Ready`, não `Running`: prova que o terminal nasceu fora do job da tarefa (senão o Task Scheduler o mataria aos 8 min). `ops\start_terminal.ps1` sem parâmetros também reinicia sozinho um terminal vivo cujo `status.json` esteja stale (> 180 s) ou com `connected=false`; `-Restart` força; `-SoIniciar` nunca reinicia.
8. Reiniciar o VPS: em até 3 min o auto-logon + `Sobrevivencia-Terminal` devem deixar o terminal aberto com o perfil `sobrevivencia`, os EAs do perfil ativos (guardião e Concorde; depois do 6.6, também o RegimeLogger) e `status.json` fresco; o `guardian.log` deve mostrar o estado restaurado (HALT/lock/HWM/last_seq iguais aos de antes) e o `heartbeat.log` uma linha com `acao=POS_REBOOT`. Repetir o teste com um HALT ativo: ele tem de voltar ativo.
9. Telegram (se configurado): `ops\notify.ps1 -Nivel CRITICO -Titulo teste -Corpo ola` chega no celular (INFO nunca envia; ATENCAO envia 1x/dia por título; CRITICO e AGUARDANDO_OK sempre).

O terminal já está na **ProCent real** (login 52012798) desde 22/09. Com tudo verde: conferir em `STATE.md` a linha solta `Equity inicial: 9850` (já registrada; o heartbeat e o `status.ps1` leem esse valor para o alarme de 50%, 4.925 USC; a linha da tabela "Depósito inicial" não é lida) e definir `$EXPECTED_LOGIN = 52012798` no `ops\config.ps1` do VPS (ou no `config.local.ps1` de lá), para ligar a checagem de conta certa do heartbeat (STATE pendência 18).

## 9. Notificações (Telegram, opcional mas recomendado)

`ops\notify.ps1 -Nivel <INFO|ATENCAO|CRITICO|AGUARDANDO_OK> -Titulo "..." -Corpo "..."` sempre anexa em `ALERTAS.md` e aplica a política do CLAUDE.md (INFO nunca envia; ATENCAO no máximo 1x por dia por título; CRITICO e AGUARDANDO OK sempre). Para receber no celular: criar um bot no @BotFather, mandar `/start` para ele, ler o `chat_id` em `https://api.telegram.org/bot<TOKEN>/getUpdates` e guardar as credenciais **fora do workspace**, como variáveis de ambiente do usuário do auto-logon (preferido):
```powershell
[Environment]::SetEnvironmentVariable('SURV_TELEGRAM_TOKEN','123456789:AAAA...','User')
[Environment]::SetEnvironmentVariable('SURV_TELEGRAM_CHAT','987654321','User')
```
Alternativa: `C:\Sobrevivencia\ops\notify.secret.ps1` a partir de `notify.secret.example.ps1` (está no `.gitignore`). **Nunca** colar o token em prompts, DIARIO.md ou no chat.

## 10. Segurança

- **MCP só em 127.0.0.1** (padrão do terminal). Conferir: `netstat -ano | findstr 22346` deve mostrar `127.0.0.1:22346`, nunca `0.0.0.0`. Firewall do Windows: nenhuma regra de entrada para 22346/22345.
- **RDP**: senha forte; se a Hyonix oferecer firewall/ACL, restringir 3389 ao IP de casa (ou usar a VPN da Hyonix). Alternativa: trocar a porta do RDP e habilitar NLA (já padrão). Desativar a conta `Guest`.
- Sem plugins/EAs/indicadores de terceiros no terminal, sem "assistentes de trading" baixados (memória: ClawHavoc distribuiu 1.100+ skills maliciosas disfarçadas de bots).
- Claude Code: `.claude\settings.json` já bloqueia `bypassPermissions` (`disableBypassPermissionsMode`), nega ferramentas `trade_*`/`tester_*`/`chart_*` do MCP e comandos destrutivos (`shutdown`, `taskkill`, `format`), e a edição de `ops\*.cs`, `campanha\lab\lotes\` e `C:\MT5_RF_Lab\`. O laboratório roda o tester só na cópia separada, por script; o `lab.ps1` recusa ao agente tudo menos status e parar. **Não** usar `--dangerously-skip-permissions` em nenhuma tarefa.
- Segredos: chave do MCP só no `claude mcp add` (fica em `%USERPROFILE%\.claude.json`), token do Telegram só em `notify.secret.ps1`, senha da conta só no terminal (salva cifrada). Nada disso vai para o git nem para os logs.
- Contas: um único usuário local com auto-logon; `Administrator` só para instalação.

## 11. Operação e manutenção

- Consulta rápida: `ops\status.ps1`. Logs: `ops\logs\ops.log` (tudo que os scripts fizeram, inclusive cada comando enviado ao freio), `ops\logs\heartbeat.log` (uma linha a cada 10 min), `ops\logs\claude_<modo>_<ts>.log` (+ `.prompt.md` com o prompt renderizado).
- Limpeza mensal: apagar `ops\logs\claude_*` com mais de 60 dias, `C:\MT5_RoboForex\logs\*.log` e `MQL5\Logs\*.log` antigos (o terminal cresce ~50 MB/dia com EAs verbosos), os `survival\control.<data>.txt` rotacionados (o `survival\regime.csv` **não** se apaga nem se trunca: é o histórico diário do regime, pequeno, usado nas revalidações trimestrais) e, se passar de alguns MB, truncar `survival\guardian.log`, `ops\logs\ops.log` e `ops\logs\heartbeat.log` (nenhum deles rotaciona sozinho; o guardião só faz append). Tarefa do Henrique: o Claude não apaga nada. O laboratório limpa sozinho o cache do tester antes de cada run e os logs dos agentes de teste com mais de 30 dias; `C:\MT5_RF_Lab\bases` (ticks, ~2 GB) fica.
- **Backup semanal** do workspace (tarefa manual no sábado ou adicionar ao `semanal.md`): `Compress-Archive C:\Sobrevivencia -DestinationPath D:\backup\Sobrevivencia_$(Get-Date -f yyyyMMdd).zip` (se o VPS tiver D:; senão copiar pelo RDP para o disco D: da máquina local, autorizado pelo Henrique; **excluir `ops\notify.secret.ps1`** do zip, ou mantê-lo só como variáveis de ambiente, para o token não viajar no backup) — incluir `C:\MT5_RoboForex\MQL5\Files\survival\` e o perfil `C:\MT5_RoboForex\MQL5\Profiles\Charts\sobrevivencia\` (a cópia do kit em `ops\profile\` já vai no zip).
- Rotação do `control.txt`: `cmd.ps1` rotaciona sozinho acima de 5.000 linhas (com status fresco), renomeando para `control.<data>.txt`; acima de 10.000 linhas o guardião pararia de ler comandos novos (log "excede 10000 linhas", `control_overflow:true` no status). Nunca reescrever o arquivo por fora nem usar `>>` do PowerShell (grava UTF-16): só `cmd.ps1` ou, em emergência, `Add-Content -LiteralPath control.txt -Value 'SEQ|HALT|' -Encoding Ascii`.
- Atualização do terminal: o MT5 se atualiza sozinho; depois de um build novo, conferir MCP (item 2.7 — a chave pode ser mantida) e recompilar (`compile.ps1`) se o Diário reclamar de `.ex5` antigo.
- Relogin do Claude: quando `ALERTAS.md` pedir, RDP > console > `claude auth login` (ou `cd C:\Sobrevivencia` > `claude` > `/login`).

---

## Anexo A — contrato `status.json` / `control.txt` (o que os scripts esperam do SurvivalGuardian)

Pasta: `<dados do terminal>\MQL5\Files\survival\` (`$SURV_DIR`). Conferido em 22/09/2026 contra `mql5\Experts\SurvivalGuardian.mq5` (`BuildStatusJson`): os scripts leem estas chaves (e aceitam alguns sinônimos, ver `Read-SurvStatus` em `ops\common.ps1`):

```json
{
  "guardian_version": "...", "ts_server": "2026.09.22 13:00:05", "ts_local": "...",
  "login": 12345678, "server": "RoboForex-Pro", "currency": "USC",
  "connected": true,                                   // TERMINAL_CONNECTED
  "trade_allowed_terminal": true, "trade_allowed_account": true, "trade_allowed_expert": true,
  "balance": 10000.00, "credit": 0.00, "equity": 10012.50, "margin_level": 0.00,
  "hwm": 10050.00, "dd_pct": 0.37,                     // rebaixamento vs HWM, em %
  "day_start": 10000.00, "day_pnl_pct": 0.12,          // dia vs equity de abertura, em %
  "positions": 2, "orders": 0, "by_magic": {...},
  "halt": false, "daily_lock": false, "day_override": false,
  "risk_scale": 1.0000, "risk_scale_manual": false,
  "last_seq": 7, "last_cmd": "7|PING|", "last_cmd_result": "OK",
  "state": "OK",                                       // OK | RISCO_REDUZIDO | LOCK_DIARIO | HALT | DISCONNECTED
  "uptime_s": 3600, "cycle": 120, "poll_s": 5, "managed_magics": "ALL",
  "limit_daily_loss_pct": 10.0, "limit_dd_reduce_pct": 20.0, "limit_dd_hysteresis_pct": 10.0, "limit_dd_halt_pct": 35.0
}
```
- Gravado a cada `Inp_PollSegundos` (default 5 s) de forma atômica (`.tmp` + `FileMove`), `FILE_ANSI` sem BOM; o heartbeat considera **stale** acima de `$STATUS_STALE_SEC` = 180 s. O heartbeat detecta HALT pela chave booleana `halt` (o `state` vira `DISCONNECTED` quando o terminal cai, mesmo em HALT). `status.ps1` mostra as chaves não normalizadas na linha `outros`.
- `control.txt`: uma linha por comando, `SEQ|CMD|ARG`, CRLF, **ASCII sem BOM** (o guardião abre com `FILE_ANSI` + codepage UTF-8 e descarta NUL; ele mesmo cria o arquivo com uma linha de cabeçalho `#`, ignorada). O guardião processa só `SEQ > SURV_LAST_SEQ` (GV persistente + `state.txt`), uma vez por SEQ, executa e reflete `last_seq/last_cmd/last_cmd_result` no `status.json`. Comandos: `HALT`, `RESUME`, `RISK_SCALE <0.05–1.0|AUTO>`, `CLOSE_ALL`, `LOCK_TODAY`, `UNLOCK_TODAY`, `SET_HWM <valor>`, `PING`. Chaves novas no status (v1.10): `syncing` (conta carregando/aquecimento: estado `SYNC`, limites e comandos suspensos por 3 ciclos), `control_overflow`, `state_file_ok`, `retry_pending`, `guardian_chart`.
- `state.txt`: espelho `CHAVE=valor` das GVs `SURV_*` (HALT, DAILY_LOCK, HWM, LAST_SEQ, escala, tolerância do lock), gravado atomicamente a cada mudança e restaurado no OnInit. Não editar.
- `guardian.log`: texto, uma linha por evento (mostrado por `status.ps1`).

## Anexo B — suposições sobre o CLI do Claude a conferir na instalação

Verificado localmente com **Claude Code 2.1.260** (22/09/2026). No VPS, rodar `claude --help` e confirmar:

1. `-p/--print` aceita o prompt por **stdin** (o `run_claude.ps1` redireciona o arquivo renderizado para a entrada padrão; não passa o prompt na linha de comando). Teste: `Get-Content prompt.md | claude -p --permission-mode acceptEdits`.
2. `--permission-mode` aceita `acceptEdits` (usado), `dontAsk`, `plan`, `manual`, `auto`, `bypassPermissions` (proibido).
3. `--output-format text`, `--add-dir <pasta>` (várias), `--model <alias>` existem.
4. `--permission-prompts none` existe (2.1.x, escolhas `host`/`none`) e **é usado por padrão** (`$CLAUDE_EXTRA_ARGS` em `config.ps1`): ninguém responde prompts em `-p`, o que não está na allowlist é negado na hora. Se uma versão recusar a flag ("unknown option", exit 1 e alerta "Claude terminou com erro"), esvaziar `$CLAUDE_EXTRA_ARGS = @()`.
5. `claude mcp add --transport http <nome> <url> --header "Authorization: Bearer <chave>" --scope user` (sintaxe confirmada em 2.1.260).
6. Caminho do binário após o instalador nativo: `%USERPROFILE%\.local\bin\claude.exe` (o `Find-ClaudeCmd` procura aí, no PATH e em `%APPDATA%\npm\claude.cmd`). Se ficar em outro lugar, definir `$CLAUDE_CMD` em `ops\config.local.ps1`.
7. O CLI recusa execução aninhada quando a variável `CLAUDECODE` está definida; o `run_claude.ps1` a remove do ambiente antes de iniciar (relevante só se alguém chamar o script de dentro de uma sessão do Claude Code).
8. Mensagem de token expirado observada na 2.1.260: `Failed to authenticate. API Error: 401 OAuth access token has expired. Re-authenticate to continue.` (exit 1). O `run_claude.ps1` procura por "failed to authenticate", "re-authenticate", "not logged in", "/login", "api error: 401" etc. para pedir relogin em `ALERTAS.md`. Se o texto mudar numa versão nova, ajustar a regex no fim do script. Relogin: `claude auth login` num console do VPS (subcomandos confirmados em 2.1.260: `claude auth login|logout|status`; o token OAuth do CLI expira periodicamente — na máquina local ele já estava expirado em 22/09/2026). Alternativa durável: `claude setup-token` + variável de usuário `CLAUDE_CODE_OAUTH_TOKEN` (item 4.2).

## Anexo C — comandos rápidos

```powershell
cd C:\Sobrevivencia
powershell -NoProfile -File ops\status.ps1                       # estado geral
powershell -NoProfile -File ops\cmd.ps1 -Cmd PING                # eco do guardião
powershell -NoProfile -File ops\cmd.ps1 -Cmd HALT                # freio total (fecha tudo, trava)
powershell -NoProfile -File ops\cmd.ps1 -Cmd RESUME              # exige "OK RESUME" em INBOX.md
powershell -NoProfile -File ops\cmd.ps1 -Cmd RISK_SCALE -Arg 0.5
powershell -NoProfile -File ops\heartbeat.ps1 -Eco               # rodar o vigia à mão
powershell -NoProfile -File ops\run_claude.ps1 -Modo incidente -Motivo "teste manual"
powershell -NoProfile -File ops\start_terminal.ps1 -Restart
powershell -NoProfile -File ops\compile.ps1
powershell -NoProfile -File ops\register_tasks.ps1 -List
```
