# =====================================================================
#  config.ps1 - configuracao central do kit Sobrevivencia
#  Uso: todo script em ops\ faz  . "$PSScriptRoot\config.ps1"
#  Este arquivo NAO executa nada: so define variaveis.
#  Overrides locais (maquina do Henrique, testes): crie ops\config.local.ps1
#  (ignorado pelo git) redefinindo o que precisar - ele e carregado no fim.
#  Arquivo sem acentos de proposito: PowerShell 5.1 le .ps1 sem BOM como ANSI.
# =====================================================================

# --- Workspace (copia do kit no VPS) ---------------------------------
$WS        = 'C:\Sobrevivencia'
$LOG_DIR   = "$WS\ops\logs"     # mesmo caminho que CLAUDE.md e os prompts citam (ops\logs\heartbeat.log)
$PROMPTS_DIR = "$WS\prompts"

# --- Terminal MT5 RoboForex (instalacao dedicada, SEMPRE /portable) --
$MT5_DIR      = 'C:\MT5_RoboForex'
$MT5_EXE      = "$MT5_DIR\terminal64.exe"
$MT5_EDITOR   = "$MT5_DIR\metaeditor64.exe"
$MT5_PORTABLE = $true            # $false so na maquina local (dados em AppData)
$MT5_DATA     = $MT5_DIR         # modo /portable => pasta de dados = pasta do exe
$MT5_MQL5     = "$MT5_DATA\MQL5"
# Ini de arranque (perfil "sobrevivencia" + AutoTrading ligado), passado como /config:
# por start_terminal.ps1. Se o arquivo nao existir, o terminal sobe sem /config.
$MT5_START_INI = "$PSScriptRoot\start.ini"

# --- Arquivos do guardiao (SurvivalGuardian escreve/le aqui) ---------
$SURV_DIR     = "$MT5_DATA\MQL5\Files\survival"
$STATUS_FILE  = "$SURV_DIR\status.json"    # escrito pelo guardiao (a cada poll, 5 s)
$CONTROL_FILE = "$SURV_DIR\control.txt"    # linhas "SEQ|CMD|ARG" (so cmd.ps1 escreve)
$GUARDIAN_LOG = "$SURV_DIR\guardian.log"   # log humano do guardiao
$STATE_MIRROR_FILE = "$SURV_DIR\state.txt" # espelho do estado SURV_* (o guardiao restaura no OnInit)
# control.txt e SEMPRE ASCII sem BOM, CRLF (o guardiao le com FILE_ANSI + CP_UTF8 e descarta
# NUL; um arquivo UTF-16 nao seria interpretado). Nao ha opcao de codificacao.
# Rotacao pelo cmd.ps1 acima deste numero de linhas (o guardiao nao le alem de 10000):
$CONTROL_ROTATE_LINES = 5000

# --- Perfil de graficos (autocura do guardiao) -----------------------
# Copia integra do perfil "sobrevivencia" (graficos do guardiao e dos EAs) guardada no
# kit. start_terminal.ps1 a restaura ANTES de cada arranque, para que um perfil salvo
# sem o grafico do guardiao (fechado por engano, ChartClose de outro EA) nao se
# perpetue. Atualizar com ops\save_profile.ps1 depois de qualquer mudanca nos graficos.
$PROFILE_NAME    = 'sobrevivencia'
$PROFILE_SRC_DIR = "$WS\ops\profile\$PROFILE_NAME"                       # copia no kit
$PROFILE_DST_DIR = "$MT5_DATA\MQL5\Profiles\Charts\$PROFILE_NAME"         # onde o MT5 le
$PROFILE_RESTORE = $true                                                  # $false desliga a restauracao

# --- Conta esperada --------------------------------------------------
$EXPECTED_LOGIN = 52012798          # login da conta ProCent real (RoboForex-Pro); 0 = nao conferir (heartbeat gera incidente se divergir)

# --- Limites do heartbeat --------------------------------------------
$STATUS_STALE_SEC            = 180   # status.json mais velho que isto = stale
$HEARTBEAT_RESTART_AFTER_MIN = 10    # stale por mais que isto (terminal vivo) => reinicia
$RESTART_MIN_INTERVAL_MIN    = 30    # nao reiniciar de novo antes disto; se ainda stale => incidente
$DISCONNECTED_ALERT_MIN      = 10    # connected=false por mais que isto => incidente
$EQUITY_CRITICAL_FRAC        = 0.50  # equity <= 50% do inicial => incidente
$INCIDENT_COOLDOWN_MIN       = 60    # intervalo minimo entre chamadas de incidente ao Claude
$INITIAL_EQUITY              = 10000 # USC; usado se STATE.md nao informar "Equity inicial: N"
$MT5_BOOT_GRACE_SEC          = 300   # terminal com menos que isto de vida nao e julgado "doente" (status stale e normal no arranque)

# --- Claude Code headless --------------------------------------------
$CLAUDE_TIMEOUT_MIN     = 45
$CLAUDE_PERMISSION_MODE = 'acceptEdits'   # NUNCA bypassPermissions (regra do Henrique)
$CLAUDE_MODEL           = ''              # vazio = default da conta; ex.: 'sonnet'
# --permission-prompts none (existe desde 2.1.x; conferido em 2.1.260): ninguem responde
# prompts em -p, tudo que nao esta na allowlist e negado na hora. Se uma versao recusar a
# flag ("unknown option"), esvaziar: @()
$CLAUDE_EXTRA_ARGS      = @('--permission-prompts', 'none')
$CLAUDE_LOCK_WAIT_MIN   = 50              # incidente espera a acordada anterior soltar o lock ate isto (min)
# Pastas fora do workspace que o Claude precisa ler (status, logs do terminal):
$CLAUDE_ADD_DIRS        = @($SURV_DIR, "$MT5_DATA\MQL5\Logs", "$MT5_DATA\logs")

function Find-ClaudeCmd {
    # Prefere .exe/.cmd (Start-Process nao roda .ps1 direto). Ordem:
    # 1) o que estiver no PATH (troca claude.ps1 pelo claude.cmd vizinho)
    # 2) instalador nativo (irm https://claude.ai/install.ps1 | iex)
    # 3) shim do npm
    $cands = @()
    $gc = Get-Command claude -ErrorAction SilentlyContinue
    if ($gc) {
        $src = $null
        if ($gc.PSObject.Properties['Source']) { $src = $gc.Source }
        if (-not $src -and $gc.PSObject.Properties['Path']) { $src = $gc.Path }
        if ($src) {
            if ($src.ToLower().EndsWith('.ps1')) {
                $alt = [IO.Path]::ChangeExtension($src, '.cmd')
                if (Test-Path $alt) { $cands += $alt }
            } else {
                $cands += $src
            }
        }
    }
    $cands += "$env:USERPROFILE\.local\bin\claude.exe"
    $cands += "$env:APPDATA\npm\claude.cmd"
    $cands += "$env:LOCALAPPDATA\Programs\claude-code\claude.exe"
    foreach ($c in $cands) {
        if ($c -and (Test-Path $c)) { return (Resolve-Path $c).Path }
    }
    return $null
}
$CLAUDE_CMD = Find-ClaudeCmd

# --- Laboratorio de testes (ops\lab.ps1) ------------------------------
# Copia de tester SEPARADA do terminal ao vivo, logada numa conta DEMO RoboForex-Pro (nunca na conta real:
# um tester na mesma conta derrubou a sessao ao vivo 3x na Axi). Roda so com o ouro fechado (sab 04:30 a
# dom 17:30 UTC), um teste por vez, dentro de um Job Object com limite de memoria. Ver CLAUDE.md 5.9.
$LAB_DIR             = 'C:\MT5_RF_Lab'  # NAO usar C:\RF_bt (o vps_bootstrap.ps1 aborta se existir)
$LAB_LOGIN           = 0                # login da conta DEMO logada na copia; 0 = laboratorio desligado
$LAB_SERVER          = 'RoboForex-Pro'
$LAB_PORT            = 3500             # porta do agente de teste da copia
$LAB_MEM_LIMIT_MB    = 2500             # limite de memoria do job da copia (estouro = run INVALIDO, nunca o ao vivo); segmento de 6 meses ~1,7 GB
$LAB_RAM_FOLGA_MB    = 1000             # so inicia um run com RAM disponivel >= limite + folga
$LAB_RAM_MIN_MB      = 700              # aborta o run se a RAM disponivel cair abaixo disto
$LAB_CPUS            = 2                # nucleos que a copia pode usar (afinidade do job)
$LAB_DISCO_MIN_GB    = 15               # livre em C: para iniciar um run (aborta abaixo de 10)
$LAB_STATUS_MAX_SEC  = 60               # status.json do guardiao mais velho que isto = aborta o run
$LAB_RUN_TIMEOUT_MIN = 180              # timeout de um run
$LAB_SEGMENTO_MESES  = 6                # janela de 24 meses em segmentos (memoria do VPS de 8 GB); 0 = inteira

# --- Compilacao ------------------------------------------------------
$COMPILE_EXCLUDE = @('*_original.mq5')   # fontes de referencia que nao vao para o terminal

# --- Overrides locais (nao versionar) --------------------------------
# O arquivo local redefine as variaveis-base ($WS, $MT5_DIR, $MT5_PORTABLE,
# $MT5_DATA, $MT5_EDITOR, $CLAUDE_CMD, limites...). As derivadas sao
# recalculadas aqui, entao nao precisam ser repetidas no local.
if (Test-Path "$PSScriptRoot\config.local.ps1") {
    $editorPadrao = $MT5_EDITOR
    . "$PSScriptRoot\config.local.ps1"
    $LOG_DIR      = "$WS\ops\logs"
    $PROMPTS_DIR  = "$WS\prompts"
    $MT5_EXE      = "$MT5_DIR\terminal64.exe"
    if ($MT5_EDITOR -eq $editorPadrao) { $MT5_EDITOR = "$MT5_DIR\metaeditor64.exe" }
    if ($MT5_PORTABLE) { $MT5_DATA = $MT5_DIR }
    $MT5_MQL5     = "$MT5_DATA\MQL5"
    $SURV_DIR     = "$MT5_DATA\MQL5\Files\survival"
    $STATUS_FILE  = "$SURV_DIR\status.json"
    $CONTROL_FILE = "$SURV_DIR\control.txt"
    $GUARDIAN_LOG = "$SURV_DIR\guardian.log"
    $STATE_MIRROR_FILE = "$SURV_DIR\state.txt"
    $PROFILE_SRC_DIR = "$WS\ops\profile\$PROFILE_NAME"
    $PROFILE_DST_DIR = "$MT5_DATA\MQL5\Profiles\Charts\$PROFILE_NAME"
    $CLAUDE_ADD_DIRS = @($SURV_DIR, "$MT5_DATA\MQL5\Logs", "$MT5_DATA\logs")
}
