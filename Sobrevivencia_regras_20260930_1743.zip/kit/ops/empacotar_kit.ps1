# =====================================================================
#  empacotar_kit.ps1 - empacota o workspace Sobrevivencia para levar ao VPS
#
#  Uso:  powershell -NoProfile -File empacotar_kit.ps1
#        powershell -NoProfile -File empacotar_kit.ps1 -DryRun
#        powershell -NoProfile -File empacotar_kit.ps1 -Saida D:\backup
#        powershell -NoProfile -File empacotar_kit.ps1 -Force
#
#  Parametros:
#    -Saida <pasta>  pasta onde o zip e gravado (padrao: %USERPROFILE%\Downloads)
#    -DryRun         so LE e LISTA (o que entraria, o que ficaria de fora, a
#                    conferencia dos MQL5 e a varredura de segredos). Nao escreve nada.
#    -Force          segue mesmo com achado de segredo (o achado continua impresso).
#                    NAO cobre arquivo obrigatorio faltando: isso sempre aborta.
#
#  O que faz, nesta ordem:
#    1. Enumera o workspace e classifica cada arquivo (entra / regra de exclusao).
#    2. Confere a lista de arquivos OBRIGATORIOS (aborta se faltar algum).
#    3. Confere os arquivos MQL5 (Concorde_RF, SurvivalGuardian e RegimeLogger, .mq5
#       e .ex5) e se cada .ex5 e mais novo que o .mq5 (e que o SurvivalGuard.mqh: nos
#       dois EAs originais sempre; no RegimeLogger so se o fonte fizer #include dele).
#       Se nao for: AVISO EM VERMELHO "falta recompilar" - nao aborta, porque o zip
#       ainda serve para as fontes.
#    4. Varre os arquivos de TEXTO atras de segredos. Achado BLOQUEIO aborta
#       (a menos que -Force). Achado AVISO so aparece na lista.
#    5. Gera o zip, imprime tamanho / numero de arquivos / SHA256 e as instrucoes
#       de transferencia por RDP.
#
#  Dentro do zip tudo fica sob a pasta de topo "Sobrevivencia\", entao no VPS
#  basta  Expand-Archive -DestinationPath C:\  para nascer C:\Sobrevivencia.
#
#  Este script roda na MAQUINA LOCAL do Henrique e e SOMENTE LEITURA no workspace:
#  a unica escrita e o zip em -Saida. Nao mexe em servico, registro, agendador nem
#  no terminal MT5. Nao carrega config.ps1 de proposito (o $WS de la e C:\Sobrevivencia,
#  o caminho do VPS): a raiz aqui e sempre a pasta pai de ops\.
#
#  Sem acentos (PowerShell 5.1 le .ps1 sem BOM como ANSI). Sem && e sem ternario.
# =====================================================================
param(
    [string]$Saida = '',
    [switch]$Force,
    [switch]$DryRun
)
$ErrorActionPreference = 'Stop'

# --- Caminhos e constantes -------------------------------------------
$RAIZ      = Split-Path -Parent $PSScriptRoot
$NOME_RAIZ = Split-Path -Leaf $RAIZ            # pasta de topo dentro do zip
if (-not $Saida) { $Saida = Join-Path $env:USERPROFILE 'Downloads' }
$STAMP        = [DateTime]::UtcNow.ToString('yyyyMMdd_HHmm')   # carimbo UTC (padrao do kit)
$ZIP_NOME     = "Sobrevivencia_kit_$STAMP.zip"
$ZIP          = Join-Path $Saida $ZIP_NOME
$LIMITE_MB    = 20
$LIMITE_BYTES = $LIMITE_MB * 1MB

# Varredura de segredos: DENYLIST de binarios - tudo que NAO esta aqui e lido como
# texto. Era uma allowlist de extensoes, e entao o padrao para qualquer arquivo novo
# (.env, .pem, .key, .jsonl, .har, .reg, .sh, .js, .html) era "viaja sem ser lido".
$EXT_BINARIO = @('.ex5','.ex4','.dll','.exe','.zip','.7z','.gz','.rar','.png','.jpg',
                 '.jpeg','.gif','.ico','.bmp','.pdf','.mqd','.hst','.dat','.db',
                 '.sqlite','.pyc','.pyd','.so','.bin','.mp4','.ttf','.woff','.woff2')

# Arquivos que TEM de estar no zip (caminho relativo, minusculas)
$OBRIGATORIOS = @(
    'claude.md','state.md','diario.md','alertas.md','inbox.md','setup_vps.md',
    '.claude\settings.json',
    'ops\start.ini','ops\config.ps1','ops\common.ps1','ops\cmd.ps1','ops\status.ps1',
    'ops\heartbeat.ps1','ops\run_claude.ps1','ops\start_terminal.ps1','ops\compile.ps1',
    'ops\register_tasks.ps1','ops\notify.ps1','ops\save_profile.ps1','ops\empacotar_kit.ps1',
    'ops\vps_bootstrap.ps1','ops\registrar_mcp.ps1',
    # laboratorio de testes (CLAUDE.md 5.9, desde 2026-09-29): executor, nucleo C#, instalador da copia, prompt
    'ops\lab.ps1','ops\lab_core.cs','ops\lab_instalar.ps1','prompts\lab.md',
    # regras em modulos e calculos de passa/falha (CLAUDE.md secao 0, desde 2026-10)
    'ops\checar.ps1','regras\saude.md','regras\inbox.md','regras\incidente.md','regras\desempenho.md',
    'regras\degrau.md','regras\regime.md','regras\revalidacao.md','regras\laboratorio.md','regras\referencia.md',
    'ops\config.local.example.ps1','ops\notify.secret.example.ps1',
    'campanha\matriz.json','campanha\readme.md','campanha\resultados.md',
    # presets .set (UTF-16 LE com BOM) que o Henrique carrega na janela de inputs dos EAs
    # (SETUP_VPS secao 6): degraus A / B do Concorde e limites G35 / G45 do guardiao.
    # Os dois presets do Concorde do plano anterior foram apagados em 2026-09-22.
    'mql5\presets\concorde_e13_a.set','mql5\presets\concorde_e13_b.set',
    'mql5\presets\survivalguardian_g35.set','mql5\presets\survivalguardian_g45.set',
    'mql5\experts\survivalguardian.mq5',
    'mql5\experts\concorde_rf.mq5',
    'mql5\include\survivalguard.mqh',
    # RegimeLogger (registrador diario do regime do ouro, NAO opera, sem magic;
    # aprovado em 2026-09-23, CLAUDE.md 5.7). Fonte E binario obrigatorios: o pacote
    # so sai com o registrador ja compilado e conferido na estacao (copia portatil
    # C:\RF_bt). No VPS ele e recompilado sozinho por
    # ops\compile.ps1 -Filtro RegimeLogger.mq5 (SETUP_VPS 6.6).
    'mql5\experts\regimelogger.mq5',
    'mql5\experts\regimelogger.ex5'
)
# Os .ex5 do Concorde_RF e do SurvivalGuardian NAO sao obrigatorios: o .gitignore do
# kit ignora *.ex5 e o vps_bootstrap.ps1 trata a ausencia como normal, porque eles sao
# compilados NO VPS por ops\compile.ps1 (SETUP_VPS secao 5). Se estiverem aqui, entram
# no pacote e a conferencia de datas abaixo continua valendo. Excecao: o
# RegimeLogger.ex5, obrigatorio (acima).
# mql5\Presets\*.set: nenhuma regra de exclusao abaixo os pega (nao sao .log, .zip nem
# secret, e tem poucos KB); a varredura de segredos os le como texto UTF-16 pelo BOM.
# Grupos que precisam de pelo menos um arquivo (padrao relativo, minusculas)
$GRUPOS_OBRIGATORIOS = @(
    @{ Padrao = 'docs\*.md';      Rotulo = 'docs\*.md' },
    @{ Padrao = 'prompts\*.md';   Rotulo = 'prompts\*.md' },
    @{ Padrao = 'campanha\*.py';  Rotulo = 'campanha\*.py' },
    @{ Padrao = 'campanha\*.ps1'; Rotulo = 'campanha\*.ps1' },
    @{ Padrao = 'mql5\presets\*.set'; Rotulo = 'mql5\presets\*.set' }
)

# --- Utilidades -------------------------------------------------------
function Escrever([string]$Txt, [string]$Cor) {
    if ($Cor) { Write-Host $Txt -ForegroundColor $Cor } else { Write-Host $Txt }
}

function Formatar-Tamanho([long]$B) {
    if ($B -ge 1MB) { return ('{0:N1} MB' -f ($B / 1MB)) }
    if ($B -ge 1KB) { return ('{0:N1} KB' -f ($B / 1KB)) }
    return ("$B B")
}

function Ler-Texto([string]$Caminho) {
    # Le detectando BOM (UTF-16 LE / UTF-8). Sem BOM assume UTF-8: os padroes
    # procurados sao todos ASCII, entao um acento mal decodificado nao atrapalha.
    $bytes = $null
    try { $bytes = [IO.File]::ReadAllBytes($Caminho) } catch { return $null }
    if ($bytes.Length -eq 0) { return '' }
    if ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
        return [Text.Encoding]::Unicode.GetString($bytes, 2, $bytes.Length - 2)
    }
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        return [Text.Encoding]::UTF8.GetString($bytes, 3, $bytes.Length - 3)
    }
    if ($bytes.Length -ge 2 -and $bytes[1] -eq 0 -and $bytes[0] -ne 0) {
        return [Text.Encoding]::Unicode.GetString($bytes)
    }
    return [Text.Encoding]::UTF8.GetString($bytes)
}

# --- Regras de exclusao ----------------------------------------------
# Devolve o nome da regra que barrou o arquivo, ou $null se ele entra.
# A regra de TAMANHO fica por ultimo de proposito: assim a lista "excluido por
# tamanho" so mostra arquivo que de outro jeito entraria.
function Get-RegraExclusao {
    param([string]$Rel, [long]$Tamanho)
    $r    = $Rel.ToLower()
    $nome = Split-Path -Leaf $r

    # --- pedidas pelo Henrique ---
    if ($r.StartsWith('graphify-out\'))              { return 'graphify-out\' }
    if ($r.StartsWith('campanha\reports\'))          { return 'campanha\reports\' }
    if ($r.StartsWith('campanha\reports_ref\'))      { return 'campanha\reports_ref\' }
    if ($r.StartsWith('campanha\reports_sanidade\')) { return 'campanha\reports_sanidade\' }
    if ($r.StartsWith('campanha\trades\'))           { return 'campanha\trades\' }
    if ($r.StartsWith('campanha\inis\'))             { return 'campanha\inis\' }
    if ($r.StartsWith('ops\logs\'))                  { return 'ops\logs\' }
    # lotes e fila do laboratorio sao do VPS (um lote de teste da estacao nao pode entrar no registro de la)
    if ($r.StartsWith('campanha\lab\lotes\'))        { return 'campanha\lab\lotes\' }
    if ($r.StartsWith('campanha\lab\fila\'))         { return 'campanha\lab\fila\' }
    if ($r -eq 'ops\config.local.ps1')               { return 'ops\config.local.ps1' }
    if ($r -eq 'ops\notify.secret.ps1')              { return 'ops\notify.secret.ps1' }
    if ($nome -like '*.secret.ps1')                  { return '*.secret.ps1' }
    if ($nome -like '*.zip')                         { return '*.zip' }
    # campanha\*.log e, por seguranca, qualquer .log em qualquer pasta
    if ($nome -like '*.log')                         { return '*.log' }

    # --- extras (lixo que nao serve no VPS; nao estavam no pedido) ---
    if ($r.StartsWith('.git\'))                      { return '.git\ [extra]' }
    if ($r -like '*__pycache__\*')                   { return '__pycache__\ [extra]' }
    if ($nome -like '*.pyc')                         { return '*.pyc [extra]' }
    if ($r -eq '.claude\settings.local.json')        { return '.claude\settings.local.json [extra]' }

    if ($Tamanho -gt $LIMITE_BYTES)                  { return 'TAMANHO' }
    return $null
}

# --- Varredura de segredos -------------------------------------------
# Dois niveis, de proposito:
#   BLOQUEIO = padrao COM VALOR colado (Bearer <32 chars>, token=<valor>, chave
#              aleatoria de 32+). Aborta, a menos que -Force.
#   AVISO    = a palavra aparece, mas sem valor (prosa do CLAUDE.md, exemplo do
#              notify.secret.example.ps1, regex do run_claude.ps1). So lista.
# Sem essa separacao o script abortaria em toda execucao por causa da propria
# documentacao do kit, e o -Force viraria habito - que e o oposto do objetivo.

# Valores que o padrao pega mas que NAO sao segredo. Acrescente aqui se aparecer
# outro falso positivo recorrente (e diga por que, numa linha de comentario).
$IGNORAR_VALORES = @()

function Test-Benigno([string]$V, [string]$Linha) {
    foreach ($x in $IGNORAR_VALORES) {
        if ($V -eq $x) { return $true }
    }
    # Id da pasta de dados do MT5 em MetaQuotes\Terminal\<32 hex>: e um hash do
    # caminho de instalacao, aparece na documentacao do kit e nao da acesso a nada.
    if ($Linha -match ('(?i)MetaQuotes\\Terminal\\' + [regex]::Escape($V))) { return $true }
    return $false
}

function Test-Placeholder([string]$V) {
    if (-not $V) { return $true }
    if ($V -match '[<>]')   { return $true }   # <CHAVE_DO_TERMINAL>
    if ($V.Contains('...')) { return $true }   # 123456789:AAAA...
    if ($V.StartsWith('$')) { return $true }   # $env:SURV_TELEGRAM_TOKEN
    if ($V.Contains('%'))   { return $true }   # %USERPROFILE%
    if ($V -match '(?i)(AAAA|BBBB|XXXX|1234567|seu_|sua_|troque|exemplo|example|placeholder|changeme|dummy|fake|redacted|xxx)') { return $true }
    $d = ($V.ToCharArray() | Select-Object -Unique).Count
    if ($d -le 6)           { return $true }   # entropia baixa demais
    return $false
}

function Test-Aleatorio([string]$S) {
    # "parece chave" e nao "parece identificador": mcp__mt5-terminal__get_workspace_info
    # tem 38 chars e NAO pode disparar.
    if ($S.Length -lt 32)      { return $false }
    if ($S.Contains('__'))     { return $false }
    if ($S -cmatch '^[0-9]+$') { return $false }
    # Identificador de codigo (E3_ManageDynamicATRTakeProfitOnly) tem varias
    # sequencias longas de minusculas; chave aleatoria quase nunca tem duas.
    $runs = ([regex]::Matches($S, '[a-z]{5,}')).Count
    if ($runs -ge 2) { return $false }
    if ($S.Contains('_') -and $runs -ge 1) { return $false }
    $d = ($S.ToCharArray() | Select-Object -Unique).Count
    if (($S -cmatch '^[0-9a-f]+$') -or ($S -cmatch '^[0-9A-F]+$')) { return ($d -ge 8) }
    $temMin = ($S -cmatch '[a-z]')
    $temMai = ($S -cmatch '[A-Z]')
    $temNum = ($S -cmatch '[0-9]')
    if (-not ($temMin -and $temMai -and $temNum)) { return $false }
    return ($d -ge 12)
}

function Mascarar([string]$V) {
    if ($V.Length -le 10) { return ('*' * $V.Length) }
    return ('{0}{1}{2} ({3} chars)' -f $V.Substring(0,4), ('*' * 6), $V.Substring($V.Length - 4), $V.Length)
}

function New-Achado {
    param([string]$Rel, [int]$Linha, [string]$Nivel, [string]$Padrao, [string]$Valor, [string]$Texto)
    $t = $Texto.Trim()
    # Mascara o valor DENTRO da linha antes de guardar: quem imprime o achado imprime
    # tambem esta linha, que e o texto CRU do arquivo. Sem isto o script mascarava o
    # valor numa linha e o imprimia inteiro na seguinte - no console, no scrollback e
    # em qualquer Start-Transcript ou "> saida.txt".
    if ($Valor) { $t = $t -replace [regex]::Escape($Valor), (Mascarar $Valor) }
    if ($t.Length -gt 120) { $t = $t.Substring(0,120) + '...' }
    return (New-Object PSObject -Property @{
        Rel = $Rel; Linha = $Linha; Nivel = $Nivel; Padrao = $Padrao; Valor = $Valor; Texto = $t
    })
}

function Get-Achados {
    param([string]$Rel, [string]$Texto)
    $res = @()
    if (-not $Texto) { return $res }
    $linhas = $Texto -split "`r?`n"
    for ($i = 0; $i -lt $linhas.Count; $i++) {
        $l = $linhas[$i]
        if (-not $l) { continue }
        if ($l.Length -gt 4000) { $l = $l.Substring(0, 4000) }
        $n = $i + 1
        $bloqueou = $false

        # 1) Authorization: Bearer <chave>
        foreach ($m in [regex]::Matches($l, 'Bearer\s+([A-Za-z0-9\._\-~\+/=]{16,})')) {
            $v = $m.Groups[1].Value
            if ((-not (Test-Placeholder $v)) -and (-not (Test-Benigno $v $l))) {
                $res += (New-Achado $Rel $n 'BLOQUEIO' 'Bearer <chave>' $v $l)
                $bloqueou = $true
            }
        }
        # 2) palavra-chave seguida de = ou : e de um valor de 12+ chars com cara de
        #    chave (classe positiva: assim "chave = ROTULOS.get(rot)" e
        #    "$senha = [Runtime...]::PtrToStringBSTR($bstr)" nao disparam)
        foreach ($m in [regex]::Matches($l, '(?i)\b(pass(?:word|wd)?|senha|token|api[_\-]?key|apikey|secret|chave|bot_?token)\b\s*[:=]\s*["'']?([A-Za-z0-9._:/+=~\-]{12,})')) {
            $v = $m.Groups[2].Value
            if ((-not (Test-Placeholder $v)) -and (-not (Test-Benigno $v $l))) {
                $res += (New-Achado $Rel $n 'BLOQUEIO' ($m.Groups[1].Value + '=<valor>') $v $l)
                $bloqueou = $true
            }
        }
        # 3) token de bot do Telegram (123456789:AA...)
        foreach ($m in [regex]::Matches($l, '\b[0-9]{8,12}:[A-Za-z0-9_\-]{30,}')) {
            $v = $m.Value
            if ((-not (Test-Placeholder $v)) -and (-not (Test-Benigno $v $l))) {
                $res += (New-Achado $Rel $n 'BLOQUEIO' 'token Telegram' $v $l)
                $bloqueou = $true
            }
        }
        # 4) sequencia solta de 32+ em base64/hex com cara de chave
        foreach ($m in [regex]::Matches($l, '[A-Za-z0-9+/=_\-]{32,}')) {
            $v = $m.Value
            if ((Test-Aleatorio $v) -and (-not (Test-Placeholder $v)) -and (-not (Test-Benigno $v $l))) {
                $res += (New-Achado $Rel $n 'BLOQUEIO' 'sequencia 32+ base64/hex' $v $l)
                $bloqueou = $true
            }
        }
        # 5) a palavra aparece mas sem valor colado => so aviso
        if (-not $bloqueou) {
            if ($l -match '(?i)(Bearer |password|senha=|token)') {
                $res += (New-Achado $Rel $n 'AVISO' 'palavra sem valor' '' $l)
            }
        }
    }
    return $res
}

# =====================================================================
#  1. Enumeracao
# =====================================================================
if (-not (Test-Path -LiteralPath $RAIZ)) {
    Escrever "ERRO: raiz do workspace nao encontrada: $RAIZ" 'Red'
    exit 1
}
Escrever ''
Escrever '=====================================================================' 'Cyan'
Escrever ' empacotar_kit.ps1 - kit Sobrevivencia para o VPS' 'Cyan'
Escrever '=====================================================================' 'Cyan'
Escrever ("Raiz    : {0}" -f $RAIZ)
Escrever ("Saida   : {0}" -f $Saida)
Escrever ("Zip     : {0}" -f $ZIP_NOME)
Escrever ("Carimbo : {0} (UTC)" -f $STAMP)
if ($DryRun) { Escrever "Modo    : -DryRun (so leitura; nenhum arquivo sera escrito)" 'Yellow' }
if ($Force)  { Escrever "Modo    : -Force (achado de segredo nao aborta)" 'Yellow' }
Escrever ''

$incluir = @()
$excluir = @()
$todos   = @(Get-ChildItem -LiteralPath $RAIZ -Recurse -File -Force -ErrorAction SilentlyContinue)
foreach ($f in $todos) {
    $rel = $f.FullName.Substring($RAIZ.Length + 1)
    $reg = Get-RegraExclusao -Rel $rel -Tamanho $f.Length
    $o = New-Object PSObject -Property @{
        Rel = $rel; Full = $f.FullName; Tam = $f.Length; Ext = $f.Extension.ToLower()
        Mod = $f.LastWriteTimeUtc; Regra = $reg
    }
    if ($reg) { $excluir += $o } else { $incluir += $o }
}
$incluir = @($incluir | Sort-Object Rel)
$relsMin = @{}
foreach ($it in $incluir) { $relsMin[$it.Rel.ToLower()] = $true }

$tamTotal = 0
foreach ($it in $incluir) { $tamTotal += $it.Tam }

# =====================================================================
#  2. Obrigatorios
# =====================================================================
$faltando = @()
foreach ($ob in $OBRIGATORIOS) {
    if (-not $relsMin.ContainsKey($ob)) { $faltando += $ob }
}
foreach ($g in $GRUPOS_OBRIGATORIOS) {
    $achou = $false
    foreach ($k in $relsMin.Keys) {
        if ($k -like $g.Padrao) { $achou = $true; break }
    }
    if (-not $achou) { $faltando += ($g.Rotulo + '  (nenhum arquivo)') }
}
if ($faltando.Count -gt 0) {
    Escrever 'ABORTADO: arquivo(s) obrigatorio(s) fora do pacote:' 'Red'
    foreach ($x in $faltando) { Escrever ("  - {0}" -f $x) 'Red' }
    Escrever ''
    Escrever 'Sem eles o kit nao roda no VPS. Verifique se o arquivo existe na raiz do' 'Red'
    Escrever 'workspace e se nao esta caindo numa regra de exclusao. -Force NAO cobre isto.' 'Red'
    exit 1
}
Escrever ("[1/3] Obrigatorios: {0} arquivos e {1} grupos conferidos, todos presentes." -f $OBRIGATORIOS.Count, $GRUPOS_OBRIGATORIOS.Count) 'Green'

# =====================================================================
#  3. Conferencia dos MQL5 (fonte x binario)
# =====================================================================
# Mqh: 'sim' = compara o .ex5 tambem com o SurvivalGuard.mqh; 'auto' = so se o fonte
# tiver  #include <SurvivalGuard.mqh>  (o RegimeLogger nao opera e nao precisa dele).
$mqlPares = @(
    @{ Fonte = 'mql5\Experts\SurvivalGuardian.mq5'; Bin = 'mql5\Experts\SurvivalGuardian.ex5'; Mqh = 'sim' },
    @{ Fonte = 'mql5\Experts\Concorde_RF.mq5';      Bin = 'mql5\Experts\Concorde_RF.ex5';      Mqh = 'sim' },
    @{ Fonte = 'mql5\Experts\RegimeLogger.mq5';     Bin = 'mql5\Experts\RegimeLogger.ex5';     Mqh = 'auto' }
)
$incMqh  = 'mql5\Include\SurvivalGuard.mqh'
$mqhFull = Join-Path $RAIZ $incMqh
$mqhMod  = $null
if (Test-Path -LiteralPath $mqhFull) { $mqhMod = (Get-Item -LiteralPath $mqhFull).LastWriteTimeUtc }
$precisaRecompilar = @()
$ex5Ausentes = @()
foreach ($p in $mqlPares) {
    $fFonte = Join-Path $RAIZ $p.Fonte
    $fBin   = Join-Path $RAIZ $p.Bin
    if (-not (Test-Path -LiteralPath $fFonte)) { continue }
    if (-not (Test-Path -LiteralPath $fBin)) { $ex5Ausentes += $p.Bin; continue }
    $tFonte = (Get-Item -LiteralPath $fFonte).LastWriteTimeUtc
    $tBin   = (Get-Item -LiteralPath $fBin).LastWriteTimeUtc
    $usaMqh = $true
    if ($p.Mqh -eq 'auto') {
        try {
            $usaMqh = [bool](Select-String -LiteralPath $fFonte -Pattern '^\s*#include\s*[<"]SurvivalGuard\.mqh[>"]' -Quiet)
        } catch { $usaMqh = $true }
    }
    if ($tBin -lt $tFonte) {
        $precisaRecompilar += ("{0} e mais velho que o {1} ({2:yyyy-MM-dd HH:mm}Z vs {3:yyyy-MM-dd HH:mm}Z)" -f (Split-Path -Leaf $p.Bin), (Split-Path -Leaf $p.Fonte), $tBin, $tFonte)
    } elseif ($usaMqh -and $mqhMod -and $tBin -lt $mqhMod) {
        $precisaRecompilar += ("{0} e mais velho que o SurvivalGuard.mqh ({1:yyyy-MM-dd HH:mm}Z vs {2:yyyy-MM-dd HH:mm}Z) - o EA inclui esse .mqh" -f (Split-Path -Leaf $p.Bin), $tBin, $mqhMod)
    }
}
if ($ex5Ausentes.Count -gt 0) {
    Escrever ''
    Escrever ("AVISO: {0} arquivo(s) .ex5 nao estao no workspace:" -f $ex5Ausentes.Count) 'Yellow'
    foreach ($x in $ex5Ausentes) { Escrever ("  ! {0}" -f $x) 'Yellow' }
    Escrever '  Isto NAO e erro: o .gitignore ignora *.ex5 e eles sao compilados no VPS por' 'Yellow'
    Escrever '  ops\compile.ps1 (SETUP_VPS secao 5). Para leva-los no pacote, copie' 'Yellow'
    Escrever '  <Terminal>\MQL5\Experts\*.ex5 para mql5\Experts\ e empacote de novo.' 'Yellow'
    Escrever ''
}
if ($precisaRecompilar.Count -gt 0) {
    Escrever ''
    Escrever '*** FALTA RECOMPILAR ***' 'Red'
    foreach ($x in $precisaRecompilar) { Escrever ("  ! {0}" -f $x) 'Red' }
    Escrever '  O ops\compile.ps1 grava o .ex5 dentro da pasta do TERMINAL, nao aqui: rode-o e' 'Red'
    Escrever '  copie <Terminal>\MQL5\Experts\*.ex5 para mql5\Experts\ antes de empacotar de' 'Red'
    Escrever '  novo (ou apague os .ex5 daqui e deixe o VPS compilar). O zip sai assim mesmo -' 'Red'
    Escrever '  as fontes vao junto -, mas o .ex5 que viaja NAO corresponde ao .mq5.' 'Red'
    Escrever ''
} elseif ($ex5Ausentes.Count -eq 0) {
    Escrever ("[2/3] MQL5: {0} arquivos presentes, .ex5 mais novos que .mq5 (e que o .mqh, onde se aplica)." -f ($mqlPares.Count * 2)) 'Green'
} else {
    Escrever ("[2/3] MQL5: fontes presentes; {0} .ex5 ausente(s), a compilar no VPS." -f $ex5Ausentes.Count) 'Yellow'
}

# =====================================================================
#  4. Varredura de segredos
# =====================================================================
$achados  = @()
$lidos    = 0
$naoLidos = @()
foreach ($it in $incluir) {
    if ($EXT_BINARIO -contains $it.Ext) { $naoLidos += ("{0}  (binario)" -f $it.Rel); continue }
    if ($it.Tam -gt $LIMITE_BYTES) { $naoLidos += ("{0}  (acima de {1} MB)" -f $it.Rel, $LIMITE_MB); continue }
    $txt = Ler-Texto $it.Full
    if ($null -eq $txt) { continue }
    $lidos++
    $achados += (Get-Achados -Rel $it.Rel -Texto $txt)
}
$bloqueios = @($achados | Where-Object { $_.Nivel -eq 'BLOQUEIO' })
$avisos    = @($achados | Where-Object { $_.Nivel -eq 'AVISO' })

$corSeg = 'Green'
if ($bloqueios.Count -gt 0) { $corSeg = 'Red' }
Escrever ("[3/3] Segredos: {0} arquivos de texto varridos - {1} BLOQUEIO, {2} aviso(s)." -f $lidos, $bloqueios.Count, $avisos.Count) $corSeg
if ($naoLidos.Count -gt 0) {
    Escrever ("      {0} arquivo(s) entraram no pacote SEM varredura:" -f $naoLidos.Count) 'DarkYellow'
    foreach ($x in $naoLidos) { Escrever ("        {0}" -f $x) 'DarkGray' }
}

if ($avisos.Count -gt 0) {
    Escrever ''
    Escrever '  Avisos (a palavra aparece sem valor colado; nao impedem o pacote):' 'DarkYellow'
    $i = 0
    foreach ($a in $avisos) {
        $i++
        if ($i -gt 15) {
            Escrever ("    (+{0} outros)" -f ($avisos.Count - 15)) 'DarkYellow'
            break
        }
        Escrever ("    {0}:{1}  {2}" -f $a.Rel, $a.Linha, $a.Texto) 'DarkGray'
    }
}
if ($bloqueios.Count -gt 0) {
    Escrever ''
    Escrever 'POSSIVEL SEGREDO NO KIT:' 'Red'
    foreach ($b in $bloqueios) {
        Escrever ("  {0}:{1}  [{2}]  valor={3}" -f $b.Rel, $b.Linha, $b.Padrao, (Mascarar $b.Valor)) 'Red'
        Escrever ("      linha: {0}" -f $b.Texto) 'DarkGray'
    }
    Escrever ''
    if (-not $Force) {
        Escrever 'ABORTADO. Tire o segredo do arquivo (regra 2 do CLAUDE.md: chave, senha e' 'Red'
        Escrever 'token ficam FORA do workspace - Credential Manager ou variavel de ambiente do' 'Red'
        Escrever 'usuario) e rode de novo. Se for falso positivo, repita com -Force.' 'Red'
        exit 1
    }
    Escrever '-Force: seguindo mesmo assim. Confira cada linha acima antes de levar ao VPS.' 'Yellow'
}

# =====================================================================
#  5. Listagem
# =====================================================================
Escrever ''
Escrever ("ENTRAM: {0} arquivo(s), {1} (antes de compactar)" -f $incluir.Count, (Formatar-Tamanho $tamTotal)) 'Cyan'
if ($DryRun) {
    foreach ($it in $incluir) {
        Escrever ("  + {0,-52} {1,10}" -f $it.Rel, (Formatar-Tamanho $it.Tam))
    }
} else {
    $porPasta = $incluir | Group-Object { $p = $_.Rel.Split('\')[0]; if ($p -eq $_.Rel) { '(raiz)' } else { $p } } | Sort-Object Name
    foreach ($g in $porPasta) {
        $t = 0
        foreach ($x in $g.Group) { $t += $x.Tam }
        Escrever ("  + {0,-24} {1,4} arquivo(s)  {2,10}" -f $g.Name, $g.Count, (Formatar-Tamanho $t))
    }
}

Escrever ''
Escrever ("FICAM DE FORA: {0} arquivo(s)" -f $excluir.Count) 'Cyan'
$porRegra = $excluir | Group-Object Regra | Sort-Object Name
foreach ($g in $porRegra) {
    $t = 0
    foreach ($x in $g.Group) { $t += $x.Tam }
    Escrever ("  - {0,-38} {1,4} arquivo(s)  {2,10}" -f $g.Name, $g.Count, (Formatar-Tamanho $t))
}
$porTamanho = @($excluir | Where-Object { $_.Regra -eq 'TAMANHO' } | Sort-Object Tam -Descending)
if ($porTamanho.Count -gt 0) {
    Escrever ''
    Escrever ("  Excluidos por passarem de {0} MB:" -f $LIMITE_MB) 'Yellow'
    foreach ($x in $porTamanho) {
        Escrever ("    - {0,-52} {1,10}" -f $x.Rel, (Formatar-Tamanho $x.Tam)) 'Yellow'
    }
}

if ($DryRun) {
    Escrever ''
    Escrever '-DryRun: nada foi escrito. Rode sem -DryRun para gerar o zip.' 'Yellow'
    exit 0
}

# =====================================================================
#  6. Compactacao
# =====================================================================
if (-not (Test-Path -LiteralPath $Saida)) {
    New-Item -ItemType Directory -Path $Saida -Force | Out-Null
}
if (Test-Path -LiteralPath $ZIP) { Remove-Item -LiteralPath $ZIP -Force }

Add-Type -AssemblyName System.IO.Compression | Out-Null
Add-Type -AssemblyName System.IO.Compression.FileSystem | Out-Null

$zipObj = $null
try {
    $zipObj = [IO.Compression.ZipFile]::Open($ZIP, [IO.Compression.ZipArchiveMode]::Create)
    foreach ($it in $incluir) {
        $entrada = $NOME_RAIZ + '/' + $it.Rel.Replace('\', '/')
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zipObj, $it.Full, $entrada, [IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
} finally {
    if ($zipObj) { $zipObj.Dispose() }
}

# Conferencia: reabre o zip e conta as entradas
$nEntradas = 0
$leitura = $null
try {
    $leitura = [IO.Compression.ZipFile]::OpenRead($ZIP)
    $nEntradas = $leitura.Entries.Count
} finally {
    if ($leitura) { $leitura.Dispose() }
}
if ($nEntradas -ne $incluir.Count) {
    Escrever ("ERRO: o zip tem {0} entradas, esperava {1}." -f $nEntradas, $incluir.Count) 'Red'
    exit 1
}

$info = Get-Item -LiteralPath $ZIP
$sha  = (Get-FileHash -LiteralPath $ZIP -Algorithm SHA256).Hash

# Caminho do zip visto do VPS com a unidade local montada por RDP
$tsclient = $ZIP
if ($ZIP -match '^([A-Za-z]):\\(.*)$') {
    $tsclient = '\\tsclient\' + $Matches[1].ToUpper() + '\' + $Matches[2]
}
# Caminho do workspace desta maquina visto do VPS (para copiar STATE.md/INBOX.md)
$tsRaiz = $RAIZ
if ($RAIZ -match '^([A-Za-z]):\\(.*)$') {
    $tsRaiz = '\\tsclient\' + $Matches[1].ToUpper() + '\' + $Matches[2]
}
$pct = 100.0 * $info.Length / [Math]::Max(1, $tamTotal)

Escrever ''
Escrever '=====================================================================' 'Green'
Escrever ' PACOTE PRONTO' 'Green'
Escrever '=====================================================================' 'Green'
Escrever ("Arquivo   : {0}" -f $ZIP)
Escrever ("Tamanho   : {0} ({1:N0} bytes, {2:N1}% do original)" -f (Formatar-Tamanho $info.Length), $info.Length, $pct)
Escrever ("Arquivos  : {0}" -f $nEntradas)
Escrever ("SHA256    : {0}" -f $sha) 'Cyan'
if ($precisaRecompilar.Count -gt 0) {
    Escrever 'ATENCAO   : pacote gerado com .ex5 desatualizado (ver *** FALTA RECOMPILAR *** acima).' 'Red'
}
Escrever ''
Escrever '--- Levar para o VPS por RDP ---------------------------------------' 'Cyan'
Escrever ''
Escrever '1. Na MAQUINA LOCAL, antes de conectar: abra o mstsc, clique em "Mostrar'
Escrever '   opcoes" > aba "Recursos Locais" > secao "Dispositivos e recursos locais"'
Escrever '   > botao "Mais..." > marque a unidade  C:  > OK. Depois conecte no VPS.'
Escrever '   (Se ja estiver conectado, desconecte e reconecte: a unidade so e montada'
Escrever '    no inicio da sessao.)'
Escrever ''
Escrever '2. No VPS, num PowerShell, a unidade local aparece como \\tsclient\C.'
Escrever '   Copie o pacote e confira o SHA256:'
Escrever ''
Escrever ("   Copy-Item '{0}' 'C:\{1}' -Force" -f $tsclient, $ZIP_NOME) 'White'
Escrever ("   (Get-FileHash 'C:\{0}' -Algorithm SHA256).Hash" -f $ZIP_NOME) 'White'
Escrever ''
Escrever '   O hash impresso no VPS tem de ser IGUAL a este:'
Escrever ("   {0}" -f $sha) 'Cyan'
Escrever ''
Escrever '3. Ainda no VPS, extraia direto na raiz de C: (o zip ja tem a pasta de topo'
Escrever ("   '{0}\', entao nasce C:\{0}) e libere os arquivos (vieram da rede e o" -f $NOME_RAIZ)
Escrever '   Windows os marca como bloqueados):'
Escrever ''
Escrever ("   Expand-Archive -Path 'C:\{0}' -DestinationPath 'C:\' -Force" -f $ZIP_NOME) 'White'
Escrever ("   Get-ChildItem 'C:\{0}' -Recurse | Unblock-File" -f $NOME_RAIZ) 'White'
Escrever ("   Remove-Item 'C:\{0}'" -f $ZIP_NOME) 'White'
Escrever ''
Escrever '   ATENCAO: se o VPS JA estiver rodando, NAO extraia por cima assim: o' 'Yellow'
Escrever '   Expand-Archive -Force sobrescreve STATE.md, DIARIO.md, ALERTAS.md e INBOX.md' 'Yellow'
Escrever '   com as copias desta maquina (perde diario, alertas e um OK RESUME pendente).' 'Yellow'
Escrever '   Nesse caso use o bootstrap com -KitZip (ele preserva o estado e faz backup):' 'Yellow'
Escrever ("   powershell -NoProfile -ExecutionPolicy Bypass -File C:\{0}\ops\vps_bootstrap.ps1 -KitZip 'C:\{1}' -Etapas `"3`"" -f $NOME_RAIZ, $ZIP_NOME) 'White'
Escrever ''
Escrever '   Depois do -KitZip: o STATE.md e o INBOX.md preservados sao os do VPS. Se' 'Yellow'
Escrever '   este pacote traz uma decisao nova (ex.: a de 22/09, E1+E3) e o agente ainda' 'Yellow'
Escrever '   nao escreveu nada la (tarefas do Claude nao registradas), copie os desta' 'Yellow'
Escrever '   maquina por cima ANTES da primeira acordada (o .antes_<carimbo> fica de' 'Yellow'
Escrever '   backup) e confira; linhas do Henrique no INBOX do VPS vao para o fim do novo:' 'Yellow'
Escrever ("   Copy-Item '{0}\STATE.md','{0}\INBOX.md' 'C:\{1}\' -Force" -f $tsRaiz, $NOME_RAIZ) 'White'
Escrever ("   Select-String -Path 'C:\{0}\STATE.md' -Pattern 'Concorde_E13_A' -Quiet   # True" -f $NOME_RAIZ) 'White'
Escrever '   Com o agente ja escrevendo no VPS, nao copie: incorpore so as secoes novas' 'Yellow'
Escrever '   (SETUP_VPS.md, secao 3).' 'Yellow'
Escrever ''
Escrever '4. INSTALADOR (fuso UTC, energia, Windows Update de sabado, Git e Claude Code):'
Escrever '   abra o PowerShell COMO ADMINISTRADOR (Iniciar > digite PowerShell > botao'
Escrever '   direito > "Executar como administrador"), logado com o usuario do auto-logon, e rode:'
Escrever ''
Escrever ("   powershell -NoProfile -ExecutionPolicy Bypass -File C:\{0}\ops\vps_bootstrap.ps1" -f $NOME_RAIZ) 'White'
Escrever ''
Escrever '   No fim ele imprime a lista do que CONTINUA MANUAL (login do MT5, auto-logon,'
Escrever '   login do Claude e a chave do MCP). Para o passo do MCP existe o ajudante:'
Escrever ''
Escrever ("   powershell -NoProfile -File C:\{0}\ops\registrar_mcp.ps1" -f $NOME_RAIZ) 'White'
Escrever ''
Escrever '5. Confira a instalacao:'
Escrever ''
Escrever ("   powershell -NoProfile -File C:\{0}\ops\status.ps1" -f $NOME_RAIZ) 'White'
Escrever ''
Escrever '   Lembre que NAO viajam no pacote (recriar no VPS, ver SETUP_VPS.md):'
Escrever '     - ops\config.local.ps1   (override da maquina local; no VPS nao existe)'
Escrever '     - ops\notify.secret.ps1  (token do Telegram; prefira as variaveis de ambiente'
Escrever '       SURV_TELEGRAM_TOKEN / SURV_TELEGRAM_CHAT do usuario, item 9 do SETUP_VPS)'
Escrever '     - a chave do MCP do terminal (vai so no claude mcp add, item 4.3)'
Escrever ''
exit 0
