# =====================================================================
#  register_tasks.ps1 - registra/remove as tarefas do Task Scheduler
#  Uso:  register_tasks.ps1                       (registra, roda como o usuario atual, so logado)
#        register_tasks.ps1 -RunWhetherLoggedOn   (tarefas do Claude tambem sem sessao aberta; pede senha)
#        register_tasks.ps1 -Unregister           (remove todas)
#        register_tasks.ps1 -List                 (mostra estado)
#  Tarefas (horarios em HORA LOCAL do VPS => o VPS DEVE estar em UTC, ver SETUP_VPS.md):
#    Sobrevivencia-Heartbeat    a cada 10 min                heartbeat.ps1
#    Sobrevivencia-Diario       seg-sex 22:30                run_claude.ps1 -Modo diario
#                               (depois do fechamento do dia-servidor da RoboForex, que cai
#                                em 21:00 ou 22:00 UTC conforme o horario de verao)
#    Sobrevivencia-Semanal      sab 12:00                    run_claude.ps1 -Modo semanal
#    Sobrevivencia-PreAbertura  dom 18:00                    run_claude.ps1 -Modo preabertura
#    Sobrevivencia-Terminal     ao logon (+1 min)            start_terminal.ps1 -SoIniciar
#    Sobrevivencia-Lab          a cada 30 min                lab.ps1 -Acao agendado
#                               (fora da janela sab 04:30-dom 17:30 UTC so vigia; dentro, relanca o
#                                executor do laboratorio se nao houver um vivo; sem "iniciar
#                                assim que possivel", para nao disparar antes do terminal ao vivo)
#  register_tasks.ps1 -SoLab registra (ou atualiza) so a tarefa do laboratorio.
#  Os horarios sao os do CLAUDE.md (secao 1). Heartbeat e Terminal ficam SEMPRE "somente
#  quando logado" (Interactive): eles sobem o terminal64, que e um programa grafico e
#  precisa da sessao interativa do auto-logon.
#  -RunWhetherLoggedOn so afeta Diario/Semanal/PreAbertura (Claude nao precisa de GUI).
#  Processos longos (terminal64, run_claude de incidente) sao iniciados fora do job da
#  tarefa (Start-Detached): o ExecutionTimeLimit nao os mata e a tarefa volta a "Ready".
# =====================================================================
param(
    [switch]$Unregister,
    [switch]$RunWhetherLoggedOn,
    [switch]$List,
    [switch]$SoLab
)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\config.ps1"
. "$PSScriptRoot\common.ps1"
$ORIGEM = 'register_tasks'

$ps  = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$ops = $PSScriptRoot
$user = "$env:USERDOMAIN\$env:USERNAME"
$names = @('Sobrevivencia-Heartbeat', 'Sobrevivencia-Diario', 'Sobrevivencia-Semanal', 'Sobrevivencia-PreAbertura', 'Sobrevivencia-Terminal', 'Sobrevivencia-Lab')

if ($List) {
    foreach ($n in $names) {
        $t = Get-ScheduledTask -TaskName $n -ErrorAction SilentlyContinue
        if ($t) {
            $i = Get-ScheduledTaskInfo -TaskName $n
            Write-Host ("{0,-28} {1,-10} ultima={2} result={3} proxima={4}" -f $n, $t.State, $i.LastRunTime, $i.LastTaskResult, $i.NextRunTime)
        } else {
            Write-Host ("{0,-28} (nao registrada)" -f $n)
        }
    }
    exit 0
}

if ($Unregister) {
    foreach ($n in $names) {
        if (Get-ScheduledTask -TaskName $n -ErrorAction SilentlyContinue) {
            Unregister-ScheduledTask -TaskName $n -Confirm:$false
            Write-Host "removida: $n"
            Write-OpsLog "tarefa removida: $n" $ORIGEM
        }
    }
    exit 0
}

# --- Avisos de ambiente ----------------------------------------------
$tz = (Get-TimeZone).Id
if ($tz -ne 'UTC') {
    Write-Host "AVISO: fuso do sistema e '$tz', nao UTC. Os horarios abaixo serao interpretados em hora local."
    Write-Host "       No VPS rode:  Set-TimeZone -Id UTC   (ver SETUP_VPS.md)."
}
foreach ($s in @('heartbeat.ps1', 'run_claude.ps1', 'start_terminal.ps1')) {
    if (-not (Test-Path -LiteralPath (Join-Path $ops $s))) { Write-Host "ERRO: falta $ops\$s"; exit 1 }
}

$senha = $null
if ($RunWhetherLoggedOn) {
    Write-Host "Senha do usuario $user (necessaria para 'executar mesmo sem logon'):"
    $sec = Read-Host -AsSecureString
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
    $senha = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
}

function New-PsAction([string]$Script, [string]$Extra) {
    $arg = ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}\{1}" {2}' -f $ops, $Script, $Extra).Trim()
    return New-ScheduledTaskAction -Execute $ps -Argument $arg -WorkingDirectory $ops
}

function Register-One {
    param([string]$Name, [string]$Descricao, $Action, $Trigger, [int]$LimiteMin, [bool]$Retry, [bool]$SemLogon, [bool]$SemAtraso = $false)
    $settings = $null
    if ($SemAtraso) {
        $settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes $LimiteMin) `
            -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
    } elseif ($Retry) {
        $settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes $LimiteMin) `
            -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -RestartCount 2 -RestartInterval (New-TimeSpan -Minutes 15)
    } else {
        $settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes $LimiteMin) `
            -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
    }
    if (Get-ScheduledTask -TaskName $Name -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName $Name -Confirm:$false
    }
    if ($SemLogon -and $senha) {
        Register-ScheduledTask -TaskName $Name -Description $Descricao -Action $Action -Trigger $Trigger -Settings $settings `
            -User $user -Password $senha -RunLevel Limited | Out-Null
        Write-Host ("registrada: {0,-28} (executa mesmo sem logon)" -f $Name)
    } else {
        $principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
        Register-ScheduledTask -TaskName $Name -Description $Descricao -Action $Action -Trigger $Trigger -Settings $settings -Principal $principal | Out-Null
        Write-Host ("registrada: {0,-28} (somente com usuario logado)" -f $Name)
    }
    Write-OpsLog "tarefa registrada: $Name" $ORIGEM
}

# --- Laboratorio: a cada 30 min (so ele, com -SoLab) ------------------
function Register-Lab {
    if (-not (Test-Path -LiteralPath (Join-Path $ops 'lab.ps1'))) { Write-Host "ERRO: falta $ops\lab.ps1"; exit 1 }
    $trgLab = New-ScheduledTaskTrigger -Once -At ([DateTime]::Today) -RepetitionInterval (New-TimeSpan -Minutes 30) -RepetitionDuration (New-TimeSpan -Days 3650)
    # Interactive (o terminal64 da copia e grafico); o executor longo sai do job da tarefa (Start-Detached)
    Register-One -Name 'Sobrevivencia-Lab' -Descricao 'Laboratorio de testes (copia de tester, conta demo): so sab 04:30-dom 17:30 UTC' `
        -Action (New-PsAction 'lab.ps1' '-Acao agendado') -Trigger $trgLab -LimiteMin 5 -Retry $false -SemLogon $false -SemAtraso $true
}
if ($SoLab) { Register-Lab; exit 0 }

# --- Heartbeat: a cada 10 min, sem fim ------------------------------
$trgHb = New-ScheduledTaskTrigger -Once -At ([DateTime]::Today) -RepetitionInterval (New-TimeSpan -Minutes 10) -RepetitionDuration (New-TimeSpan -Days 3650)
Register-One -Name 'Sobrevivencia-Heartbeat' -Descricao 'Vigia sem LLM: terminal vivo, status.json fresco, anomalias -> incidente' `
    -Action (New-PsAction 'heartbeat.ps1' '') -Trigger $trgHb -LimiteMin 8 -Retry $false -SemLogon $false

# --- Claude: diario seg-sex 22:30, semanal sab 12:00, pre-abertura dom 18:00 (UTC) ---
$trgDia = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday, Tuesday, Wednesday, Thursday, Friday -At '22:30'
Register-One -Name 'Sobrevivencia-Diario' -Descricao 'Claude headless: revisao diaria (seg-sex 22:30 UTC)' `
    -Action (New-PsAction 'run_claude.ps1' '-Modo diario') -Trigger $trgDia -LimiteMin 60 -Retry $true -SemLogon $RunWhetherLoggedOn

$trgSem = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Saturday -At '12:00'
Register-One -Name 'Sobrevivencia-Semanal' -Descricao 'Claude headless: revisao semanal (sab 12:00 UTC)' `
    -Action (New-PsAction 'run_claude.ps1' '-Modo semanal') -Trigger $trgSem -LimiteMin 60 -Retry $true -SemLogon $RunWhetherLoggedOn

$trgPre = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Sunday -At '18:00'
Register-One -Name 'Sobrevivencia-PreAbertura' -Descricao 'Claude headless: pre-abertura da semana (dom 18:00 UTC)' `
    -Action (New-PsAction 'run_claude.ps1' '-Modo preabertura') -Trigger $trgPre -LimiteMin 60 -Retry $true -SemLogon $RunWhetherLoggedOn

Register-Lab

# --- Terminal ao logon -----------------------------------------------
$trgLogon = New-ScheduledTaskTrigger -AtLogOn -User $user
$trgLogon.Delay = 'PT1M'
# -SoIniciar: ao logon so falta subir; se o heartbeat ja subiu o terminal segundos antes,
# nao o reinicia por causa de um status.json ainda stale (de antes do reboot).
Register-One -Name 'Sobrevivencia-Terminal' -Descricao 'Sobe o terminal MT5 RoboForex (/portable) ao logon' `
    -Action (New-PsAction 'start_terminal.ps1' '-SoIniciar') -Trigger $trgLogon -LimiteMin 5 -Retry $false -SemLogon $false

$senha = $null
Write-Host ''
Write-Host 'Pronto. Conferir com: register_tasks.ps1 -List   e   schtasks /Query /TN Sobrevivencia-Heartbeat /V /FO LIST'
exit 0
