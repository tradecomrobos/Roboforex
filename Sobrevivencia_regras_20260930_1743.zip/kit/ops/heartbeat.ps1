# =====================================================================
#  heartbeat.ps1 - vigia SEM LLM, roda a cada 10 min pelo Task Scheduler
#  O que faz (nesta ordem):
#   1. terminal64 (da instalacao $MT5_EXE) rodando? senao -> start_terminal.ps1
#   1b. copia de tester do laboratorio ($LAB_DIR) rodando fora da janela ou sem o lab.ps1
#      vivo -> encerra so os processos da copia (pelo caminho) + CRITICO
#   2. le $SURV_DIR\status.json: idade (< $STATUS_STALE_SEC), connected, state, equity, dd
#   3. stale por > $HEARTBEAT_RESTART_AFTER_MIN com terminal vivo -> reinicia o terminal
#      (no maximo 1x a cada $RESTART_MIN_INTERVAL_MIN; se continuar stale -> incidente)
#   4. anomalias -> run_claude.ps1 -Modo incidente (assincrono, com cooldown
#      $INCIDENT_COOLDOWN_MIN via logs\last_incident.txt) + notify.ps1:
#        - HALT recem-detectado (state mudou para HALT desde o ultimo heartbeat)
#        - DISCONNECTED por > $DISCONNECTED_ALERT_MIN
#        - status stale mesmo apos reinicio do terminal
#        - equity <= $EQUITY_CRITICAL_FRAC x equity inicial (STATE.md ou config)
#        - login do status.json diferente de $EXPECTED_LOGIN (se configurado)
#        - posicao aberta com magic fora de $SURV_ALLOWED_MAGICS (by_magic do
#          status.json): 202605122 (E2) / 550555 (E4) = preset errado, outro = EA
#          desconhecido; o incidente leva ao HALT (CLAUDE.md 6 e 9.3)
#   5. escreve UMA linha em logs\heartbeat.log:
#        ts | equity | dd% | state | conn | idade_s | acao
#  NUNCA envia ordens. NUNCA escreve em control.txt. Saida sempre 0 (o Scheduler
#  nao deve tratar anomalia de mercado como falha da tarefa).
#  Estado entre execucoes (logs\): last_state.txt, stale_since.txt,
#  disconnected_since.txt, last_restart.txt, last_incident.txt, last_boot.txt
#  Reinicio do Windows: boot novo (Win32_OperatingSystem.LastBootUpTime != last_boot.txt)
#  -> registra, zera os carimbos de stale/desconectado e marca POS_REBOOT na linha.
#  Terminal e run_claude sao iniciados FORA do job da tarefa (Start-Detached em
#  common.ps1): senao o Task Scheduler os mataria ao estourar o limite de 8 min.
# =====================================================================
param([switch]$Eco)   # -Eco: imprime a linha do heartbeat no console (uso manual)
$ErrorActionPreference = 'Continue'
. "$PSScriptRoot\config.ps1"
. "$PSScriptRoot\common.ps1"
$ORIGEM = 'heartbeat'
Ensure-Dir $LOG_DIR
# Magics autorizados (CLAUDE.md 9.3: E1 202512, E3 202533 e 202534). Se o portfolio
# mudar, redefinir $SURV_ALLOWED_MAGICS em config.local.ps1; lista vazia desliga a checagem.
if ($null -eq $SURV_ALLOWED_MAGICS) { $SURV_ALLOWED_MAGICS = @(202512, 202533, 202534) }

$hbLog        = Join-Path $LOG_DIR 'heartbeat.log'
$fLastState   = Join-Path $LOG_DIR 'last_state.txt'
$fStaleSince  = Join-Path $LOG_DIR 'stale_since.txt'
$fDiscSince   = Join-Path $LOG_DIR 'disconnected_since.txt'
$fLastRestart = Join-Path $LOG_DIR 'last_restart.txt'
$fLastIncid   = Join-Path $LOG_DIR 'last_incident.txt'
$startScript  = Join-Path $PSScriptRoot 'start_terminal.ps1'
$runClaude    = Join-Path $PSScriptRoot 'run_claude.ps1'
$notify       = Join-Path $PSScriptRoot 'notify.ps1'
$psExe        = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"

$acoes = @()
$anomalias = @()
$now = [DateTime]::UtcNow

function Invoke-Incidente([string]$Motivo) {
    # Dispara o Claude em modo incidente respeitando o cooldown. Assincrono: o
    # heartbeat nao pode ficar preso 45 min (precisa continuar vigiando o terminal).
    $last = Read-StampFile $fLastIncid
    if ($last -and (($now - $last).TotalMinutes -lt $INCIDENT_COOLDOWN_MIN)) {
        $rest = [int]($INCIDENT_COOLDOWN_MIN - ($now - $last).TotalMinutes)
        Write-OpsLog "incidente em cooldown (faltam ${rest}min): $Motivo" $ORIGEM
        return "INCIDENTE_COOLDOWN"
    }
    Write-StampFile $fLastIncid $Motivo
    $motivoSafe = ($Motivo -replace '["\r\n]', ' ')
    try { & $notify -Titulo 'Incidente' -Mensagem $motivoSafe -Nivel 'CRITICO' | Out-Null } catch { }
    $a = ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -Modo incidente -Motivo "{1}"' -f $runClaude, $motivoSafe)
    # Fora do job da tarefa Heartbeat (limite 8 min): o run_claude pode levar 45 min.
    $newPid = Start-Detached -FilePath $psExe -Arguments $a -WorkingDirectory $PSScriptRoot
    if ($newPid -gt 0) {
        Write-OpsLog "incidente disparado (run_claude assincrono, PID $newPid): $motivoSafe" $ORIGEM
        return "INCIDENTE"
    }
    Write-OpsLog "ERRO ao disparar run_claude (nenhum processo criado): $motivoSafe" $ORIGEM
    return "INCIDENTE_FALHOU"
}

# --- 0. Reinicio do Windows? -----------------------------------------
$fLastBoot = Join-Path $LOG_DIR 'last_boot.txt'
$bootUtc = Get-SystemBootTimeUtc
if ($bootUtc) {
    $bootTxt = $bootUtc.ToString('yyyy-MM-dd HH:mm:ss')
    $prevBoot = ''
    if (Test-Path -LiteralPath $fLastBoot) { $prevBoot = (Get-Content -LiteralPath $fLastBoot -ErrorAction SilentlyContinue | Select-Object -First 1) }
    if (-not $prevBoot) { $prevBoot = '' }
    if ($prevBoot -ne $bootTxt) {
        [IO.File]::WriteAllText($fLastBoot, $bootTxt, (New-Object System.Text.UTF8Encoding($false)))
        if ($prevBoot) {
            Write-OpsLog ("Windows reiniciado (boot {0}Z, ha {1:N0} min); carimbos de stale/desconectado de antes do reinicio zerados" -f $bootTxt, ($now - $bootUtc).TotalMinutes) $ORIGEM
            Remove-StampFile $fStaleSince
            Remove-StampFile $fDiscSince
            $acoes += 'POS_REBOOT'
        }
    }
}

# --- 1. Terminal -----------------------------------------------------
$procs = @(Get-Mt5Process)
$startedNow = $false
if ($procs.Count -eq 0) {
    Write-OpsLog 'terminal ausente -> start_terminal.ps1' $ORIGEM
    try { & $startScript -SoIniciar | Out-Null } catch { Write-OpsLog "start_terminal falhou: $($_.Exception.Message)" $ORIGEM }
    $startedNow = $true
    $acoes += 'START_TERMINAL'
    $procs = @(Get-Mt5Process)
}
$termOk = ($procs.Count -gt 0)

# --- 1b. Laboratorio: copia de tester fora da janela ou sem o lab.ps1 vivo -> encerra ---------
# Rede de seguranca sem LLM (CLAUDE.md 5.9): processo da copia ($LAB_DIR) rodando fora da janela (sab 04:30 a
# dom 17:30 UTC) ou sem o lab.ps1 dono do lock (LiveUpdate relancou, lab.ps1 caiu, alguem abriu na mao) chega ao
# mercado aberto disputando RAM com o terminal ao vivo. Filtra pelo caminho do executavel (common.ps1).
try {
    $labP = @(Get-LabProcesses)
    if ($labP.Count -gt 0) {
        $labNaJanela = Test-LabJanela $now
        $labLock = Get-LabLockInfo
        if ((-not $labNaJanela -or -not $labLock) -and (Test-LabManutencao)) {
            Write-OpsLog 'copia do laboratorio aberta em manutencao (ops\logs\lab.manutencao, sem posicao aberta): nao encerrada' $ORIGEM
        } elseif (-not $labNaJanela -or -not $labLock) {
            $motLab = 'fora da janela do laboratorio'
            if ($labNaJanela) { $motLab = 'sem o lab.ps1 vivo (lock)' }
            $nLab = Stop-LabProcesses ("heartbeat: " + $motLab) $ORIGEM
            $acoes += 'LAB_ENCERRADO'
            try { & $notify -Titulo 'Laboratorio encerrado pelo heartbeat' -Corpo ("{0} processo(s) da copia de tester ({1}) encerrado(s): {2}." -f $nLab, $LAB_DIR, $motLab) -Nivel 'CRITICO' | Out-Null } catch { }
        }
    }
} catch {
    Write-OpsLog ("checagem do laboratorio falhou: {0}" -f $_.Exception.Message) $ORIGEM
}

# --- 2. Status -------------------------------------------------------
$st = Read-SurvStatus
$age = -1
if ($st) { $age = $st.AgeSec }
$stale = ((-not $st) -or ($age -gt $STATUS_STALE_SEC))

# --- 3. Stale -> reinicio --------------------------------------------
if ($stale) {
    $since = Read-StampFile $fStaleSince
    if (-not $since) { Write-StampFile $fStaleSince; $since = $now }
    $staleMin = ($now - $since).TotalMinutes
    if (-not $startedNow -and $termOk -and $staleMin -ge $HEARTBEAT_RESTART_AFTER_MIN) {
        $lastR = Read-StampFile $fLastRestart
        $upMin = Get-Mt5UptimeMin
        if ($upMin -ge 0 -and $upMin -lt $HEARTBEAT_RESTART_AFTER_MIN) {
            # terminal novo (logon, pos-reboot, subido pela tarefa Terminal): o status stale e o de antes
            Write-OpsLog ("status stale ha {0:N0} min, mas o terminal arrancou ha {1:N0} min: aguardando o guardiao" -f $staleMin, $upMin) $ORIGEM
        } elseif ((-not $lastR) -or (($now - $lastR).TotalMinutes -ge $RESTART_MIN_INTERVAL_MIN)) {
            Write-OpsLog ("status stale ha {0:N0} min com terminal vivo -> restart" -f $staleMin) $ORIGEM
            Write-StampFile $fLastRestart
            try { & $startScript -Restart | Out-Null } catch { Write-OpsLog "restart falhou: $($_.Exception.Message)" $ORIGEM }
            $acoes += 'RESTART_TERMINAL'
        } else {
            $anomalias += ("status.json stale ha {0:N0} min mesmo apos reinicio do terminal (ultimo restart {1:yyyy-MM-dd HH:mm}Z); guardiao ou terminal nao esta escrevendo status" -f $staleMin, $lastR)
        }
    } elseif (-not $termOk) {
        $anomalias += 'terminal nao esta rodando e nao subiu via start_terminal.ps1'
    }
} else {
    Remove-StampFile $fStaleSince
}

# --- 4. Anomalias com status fresco ---------------------------------
$equityIni = Get-InitialEquity
if (-not $stale -and $st) {
    # DISCONNECTED
    if (-not $st.Connected) {
        $d = Read-StampFile $fDiscSince
        if (-not $d) { Write-StampFile $fDiscSince; $d = $now }
        $dm = ($now - $d).TotalMinutes
        if ($dm -ge $DISCONNECTED_ALERT_MIN) {
            $anomalias += ("terminal DESCONECTADO do servidor ha {0:N0} min (status connected=false)" -f $dm)
        }
    } else {
        Remove-StampFile $fDiscSince
    }
    # HALT recem-detectado
    $prev = ''
    if (Test-Path -LiteralPath $fLastState) { $prev = (Get-Content -LiteralPath $fLastState -ErrorAction SilentlyContinue | Select-Object -First 1) }
    if (-not $prev) { $prev = '' }
    $curState = $st.State
    if ($st.Halt) { $curState = 'HALT' }
    $inv = [Globalization.CultureInfo]::InvariantCulture
    if ($curState -eq 'HALT' -and $prev -ne 'HALT') {
        $anomalias += ("guardiao entrou em HALT (estado anterior '{0}'); equity={1} dd={2}% ultimo_cmd={3}/{4}" -f $prev, $st.Equity.ToString('0.00', $inv), $st.DdPct.ToString('0.0', $inv), $st.LastCmd, $st.LastCmdResult)
    }
    [IO.File]::WriteAllText($fLastState, $curState, (New-Object System.Text.UTF8Encoding($false)))
    # Equity critica
    if ($st.Equity -gt 0 -and $equityIni -gt 0 -and $st.Equity -le ($EQUITY_CRITICAL_FRAC * $equityIni)) {
        $anomalias += ("equity {0} <= {1}% do inicial {2}" -f $st.Equity.ToString('0.00', $inv), [int]($EQUITY_CRITICAL_FRAC * 100), $equityIni.ToString('0.00', $inv))
    }
    # Conta errada no terminal (o estado SURV_* e por login; o guardiao zera o estado se mudar)
    if ($EXPECTED_LOGIN -gt 0 -and $st.Login -gt 0 -and $st.Login -ne $EXPECTED_LOGIN) {
        $anomalias += ("terminal logado na conta {0}, esperada {1} (config EXPECTED_LOGIN)" -f $st.Login, $EXPECTED_LOGIN)
    }
    # Posicao aberta com magic fora do portfolio (by_magic lista so posicoes abertas).
    # Falha aqui nunca derruba o heartbeat: so registra no ops.log.
    try {
        $permitidos = @($SURV_ALLOWED_MAGICS | ForEach-Object { [long]$_ })
        if ($permitidos.Count -gt 0 -and $st.Raw -and ($st.Raw.PSObject.Properties.Name -contains 'by_magic')) {
            $naoAut = @()
            foreach ($bm in @($st.Raw.by_magic)) {
                if ($null -eq $bm) { continue }
                $mg = [long](ConvertTo-Num $bm.magic -1)
                if ($mg -lt 0) { continue }
                if ($permitidos -notcontains $mg) { $naoAut += ("{0} (n={1})" -f $mg, $bm.n) }
            }
            if ($naoAut.Count -gt 0) {
                $anomalias += ("magic nao autorizado com posicao aberta: {0}; permitidos {1}; E2 202605122 ou E4 550555 = preset errado, outro = EA desconhecido (CLAUDE.md 9.3)" -f ($naoAut -join ', '), ($permitidos -join ','))
            }
        }
    } catch {
        Write-OpsLog ("checagem de magics falhou: {0}" -f $_.Exception.Message) $ORIGEM
    }
}

# --- Disparo ---------------------------------------------------------
if ($anomalias.Count -gt 0) {
    $motivo = ($anomalias -join ' | ')
    $acoes += (Invoke-Incidente $motivo)
}
if ($acoes.Count -eq 0) { $acoes += 'ok' }

# --- 5. Linha do heartbeat -------------------------------------------
$eq = '-'; $dd = '-'; $state = '-'; $conn = '-'
if ($st) {
    $eq = $st.Equity.ToString('0.00', [Globalization.CultureInfo]::InvariantCulture)
    $dd = $st.DdPct.ToString('0.0', [Globalization.CultureInfo]::InvariantCulture)
    $state = $st.State
    if ($st.Connected) { $conn = 'on' } else { $conn = 'OFF' }
}
$termTxt = 'DOWN'
if ($termOk) { $termTxt = 'up' }
$ageTxt = 'ausente'
if ($age -ge 0) { $ageTxt = "$age" }
$line = "{0} | eq={1} | dd={2} | state={3} | conn={4} | term={5} | idade_s={6} | acao={7}" -f (Get-UtcStamp), $eq, $dd, $state, $conn, $termTxt, $ageTxt, ($acoes -join '+')
Add-Utf8Line $hbLog $line
if ($Eco) { Write-Host $line }
exit 0
