// lab_core.cs - nucleo de calculo do laboratorio (ops\lab.ps1). Compilado pelo proprio lab.ps1 com Add-Type
// (C# 5 / .NET Framework 4.x do Windows: sem interpolacao de string, sem out var, sem tuplas).
// Tres partes:
//   1. Rpt: le o relatorio .htm do Strategy Tester (UTF-16, rotulos pt-BR/ingles), extrai o resumo, os inputs
//      efetivos e os deals, e casa saidas com entradas por FIFO (porte fiel do campanha\parse_reports.py).
//   2. Mc: Monte Carlo por blocos de trades com as regras do guardiao (porte do campanha\montecarlo.py).
//   3. Spa: teste SPA de Hansen (2005) studentizado com bootstrap estacionario (Politis-Romano), sobre series
//      diarias de diferenca de retorno variante - controle.
// Nada aqui escreve arquivo: o lab.ps1 grava tudo.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;

namespace SurvLab
{
    public class Deal
    {
        public DateTime Hora; public long Numero; public string Simbolo; public string Tipo; public string Direcao;
        public double Volume; public double Preco; public long Ordem; public double Comissao; public double Swap;
        public double Lucro; public double Saldo; public string Comentario;
    }

    public class Trade
    {
        public int N; public DateTime Abertura; public bool TemAbertura; public DateTime Fechamento; public string Simbolo;
        public string Direcao; public double Volume; public double PrecoEntrada; public double PrecoSaida;
        public double Lucro; public double Comissao; public double Swap; public double LucroLiquido; public double SaldoApos;
        public string Estrategia; public string ComentarioEntrada; public string ComentarioSaida; public string Atribuicao;
        public long DealIn; public long DealOut;
    }

    public class Relatorio
    {
        public Dictionary<string, string> Campos = new Dictionary<string, string>();
        public List<KeyValuePair<string, string>> Inputs = new List<KeyValuePair<string, string>>();
        public List<Deal> Deals = new List<Deal>();
        public List<Trade> Trades = new List<Trade>();
        public Dictionary<long, double[]> OrdensSlTp = new Dictionary<long, double[]>(); // ordem -> {sl, tp} na colocacao
        public string Erro = "";
    }

    public static class Rpt
    {
        static readonly CultureInfo CI = CultureInfo.InvariantCulture;
        static readonly Regex RePar = new Regex("<td nowrap colspan=\"3\"\\s*>(.*?)</td>\\s*<td nowrap[^>]*><b>(.*?)</b></td>", RegexOptions.Singleline | RegexOptions.Compiled);
        static readonly Regex ReLinha = new Regex("<tr bgcolor=\"#(?:FFFFFF|F7F7F7)\" align=right>(.*?)</tr>", RegexOptions.Singleline | RegexOptions.Compiled);
        static readonly Regex ReTd = new Regex("<td[^>]*>(.*?)</td>", RegexOptions.Singleline | RegexOptions.Compiled);
        static readonly Regex ReTag = new Regex("<[^>]+>", RegexOptions.Compiled);
        static readonly Regex ReNum = new Regex("-?\\d[\\d ]*(?:\\.\\d+)?", RegexOptions.Compiled);
        static readonly Regex ReEspacos = new Regex("\\s+", RegexOptions.Compiled);

        static readonly Dictionary<string, string> Rotulos = MontarRotulos();

        static Dictionary<string, string> MontarRotulos()
        {
            string[] pares = new string[] {
                "expert advisor (robo)", "expert", "expert advisor", "expert",
                "ativo", "simbolo", "symbol", "simbolo",
                "periodo", "periodo", "period", "periodo",
                "empresa", "empresa", "company", "empresa",
                "moeda", "moeda", "currency", "moeda",
                "deposito inicial", "deposito", "initial deposit", "deposito",
                "alavancagem", "alavancagem", "leverage", "alavancagem",
                "qualidade do historico", "qualidade", "history quality", "qualidade",
                "barras", "barras", "bars", "barras", "ticks", "ticks",
                "ativos", "n_ativos", "symbols", "n_ativos",
                "lucro liquido total", "lucro_liquido", "total net profit", "lucro_liquido",
                "lucro bruto", "lucro_bruto", "gross profit", "lucro_bruto",
                "perda bruta", "perda_bruta", "gross loss", "perda_bruta",
                "rebaixamento absoluto do saldo", "dd_abs_saldo", "balance drawdown absolute", "dd_abs_saldo",
                "rebaixamento absoluto do capital liquido", "dd_abs_equity", "equity drawdown absolute", "dd_abs_equity",
                "rebaixamento maximo do saldo", "dd_max_saldo", "balance drawdown maximal", "dd_max_saldo",
                "rebaixamento maximo do capital liquido", "dd_max_equity", "equity drawdown maximal", "dd_max_equity",
                "rebaixamento relativo do saldo", "dd_rel_saldo", "balance drawdown relative", "dd_rel_saldo",
                "rebaixamento relativo do capital liquido", "dd_rel_equity", "equity drawdown relative", "dd_rel_equity",
                "fator de lucro", "pf", "profit factor", "pf",
                "retorno esperado (payoff)", "payoff", "expected payoff", "payoff",
                "fator de recuperacao", "fator_recuperacao", "recovery factor", "fator_recuperacao",
                "indice de sharpe", "sharpe", "sharpe ratio", "sharpe",
                "total de negociacoes", "trades", "total trades", "trades",
                "ofertas total", "deals", "total deals", "deals",
                "negociacoes com lucro (% of total)", "ganhos", "profit trades (% of total)", "ganhos",
                "maior perda na negociacao", "maior_perda", "largest loss trade", "maior_perda",
                "maximo perdas consecutivas ($)", "max_perdas_seq", "maximum consecutive losses ($)", "max_perdas_seq"
            };
            Dictionary<string, string> d = new Dictionary<string, string>();
            for (int i = 0; i + 1 < pares.Length; i += 2) d[pares[i]] = pares[i + 1];
            return d;
        }

        public static string LerTexto(string path)
        {
            byte[] b = File.ReadAllBytes(path);
            if (b.Length >= 2 && b[0] == 0xFF && b[1] == 0xFE) return Encoding.Unicode.GetString(b, 2, b.Length - 2);
            if (b.Length >= 2 && b[0] == 0xFE && b[1] == 0xFF) return Encoding.BigEndianUnicode.GetString(b, 2, b.Length - 2);
            if (b.Length >= 3 && b[0] == 0xEF && b[1] == 0xBB && b[2] == 0xBF) return Encoding.UTF8.GetString(b, 3, b.Length - 3);
            // sem BOM: UTF-16 LE se houver muitos zeros nas posicoes impares
            int zeros = 0; int n = Math.Min(b.Length, 2000);
            for (int i = 1; i < n; i += 2) if (b[i] == 0) zeros++;
            if (n > 0 && zeros > n / 4) return Encoding.Unicode.GetString(b);
            return Encoding.UTF8.GetString(b);
        }

        public static string Limpar(string s)
        {
            s = ReTag.Replace(s ?? "", "");
            s = System.Net.WebUtility.HtmlDecode(s).Replace('\u00A0', ' ');
            return s.Trim();
        }

        public static string NormRotulo(string s)
        {
            s = Limpar(s);
            string f = s.Normalize(NormalizationForm.FormKD);
            StringBuilder sb = new StringBuilder();
            foreach (char c in f)
                if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) sb.Append(c);
            s = sb.ToString().ToLowerInvariant().Trim().TrimEnd(':').Trim();
            return ReEspacos.Replace(s, " ");
        }

        // '7 450.19' -> 7450.19 ; '1 125.75 (17.08%)' -> 1125.75 ; '' -> NaN
        public static double Num(string s)
        {
            if (string.IsNullOrEmpty(s)) return double.NaN;
            Match m = ReNum.Match(s.Replace('\u00A0', ' '));
            if (!m.Success) return double.NaN;
            double v;
            if (double.TryParse(m.Value.Replace(" ", ""), NumberStyles.Float, CI, out v)) return v;
            return double.NaN;
        }

        public static double PctParenteses(string s)
        {
            Match m = Regex.Match(s ?? "", "\\((-?[\\d.]+)%\\)");
            double v;
            if (m.Success && double.TryParse(m.Groups[1].Value, NumberStyles.Float, CI, out v)) return v;
            return double.NaN;
        }

        public static double ValorParenteses(string s)
        {
            Match m = Regex.Match(s ?? "", "\\(\\s*(-?[\\d ]+(?:\\.\\d+)?)\\s*\\)");
            double v;
            if (m.Success && double.TryParse(m.Groups[1].Value.Replace(" ", ""), NumberStyles.Float, CI, out v)) return v;
            return double.NaN;
        }

        static long Inteiro(string s)
        {
            double v = Num(s);
            return double.IsNaN(v) ? 0 : (long)v;
        }

        static double Zero(double v) { return double.IsNaN(v) ? 0.0 : v; }

        public static Relatorio Ler(string path)
        {
            Relatorio r = new Relatorio();
            string txt;
            try { txt = LerTexto(path); }
            catch (Exception e) { r.Erro = "leitura: " + e.Message; return r; }
            if (txt.IndexOf("<html", StringComparison.OrdinalIgnoreCase) < 0) { r.Erro = "nao e html"; return r; }

            // tabela 1: resumo e inputs
            int fim = txt.IndexOf("<b>Ordens</b>", StringComparison.Ordinal);
            if (fim < 0) fim = txt.IndexOf("<b>Orders</b>", StringComparison.Ordinal);
            string cab = fim > 0 ? txt.Substring(0, fim) : txt;
            bool emInputs = false;
            foreach (Match m in RePar.Matches(cab))
            {
                string rot = NormRotulo(m.Groups[1].Value);
                string val = Limpar(m.Groups[2].Value);
                if (rot.StartsWith("parametros de entrada") || rot.StartsWith("inputs"))
                {
                    emInputs = true;
                    AddInput(r, val);
                    continue;
                }
                if (rot.Length == 0)
                {
                    if (emInputs) AddInput(r, val);
                    continue;
                }
                emInputs = false;
                string chave;
                if (Rotulos.TryGetValue(rot, out chave) && !r.Campos.ContainsKey(chave)) r.Campos[chave] = val;
            }

            // ordens: SL/TP de cada ordem na colocacao (para casar a saida "sl X"/"tp X" com a entrada certa)
            int ini = txt.IndexOf("<b>Transa", StringComparison.Ordinal);
            if (ini < 0) ini = txt.IndexOf("<b>Deals</b>", StringComparison.Ordinal);
            if (fim > 0)
            {
                string ords = ini > fim ? txt.Substring(fim, ini - fim) : txt.Substring(fim);
                foreach (Match m in ReLinha.Matches(ords))
                {
                    MatchCollection tds = ReTd.Matches(m.Groups[1].Value);
                    if (tds.Count != 11) continue;
                    long ord = Inteiro(Limpar(tds[1].Groups[1].Value));
                    double sl = Num(Limpar(tds[6].Groups[1].Value)), tp = Num(Limpar(tds[7].Groups[1].Value));
                    if (ord > 0 && !r.OrdensSlTp.ContainsKey(ord)) r.OrdensSlTp[ord] = new double[] { sl, tp };
                }
            }
            // deals
            if (ini >= 0)
            {
                string corpo = txt.Substring(ini);
                foreach (Match m in ReLinha.Matches(corpo))
                {
                    MatchCollection tds = ReTd.Matches(m.Groups[1].Value);
                    if (tds.Count != 13) continue;
                    string[] c = new string[13];
                    for (int i = 0; i < 13; i++) c[i] = Limpar(tds[i].Groups[1].Value);
                    string tipo = c[3].ToLowerInvariant();
                    if (tipo != "buy" && tipo != "sell") continue;
                    Deal d = new Deal();
                    d.Hora = DateTime.ParseExact(c[0].Trim(), "yyyy.MM.dd HH:mm:ss", CI);
                    d.Numero = Inteiro(c[1]); d.Simbolo = c[2]; d.Tipo = tipo;
                    d.Direcao = Regex.Replace(c[4].ToLowerInvariant(), "[^a-z]", "");
                    d.Volume = Zero(Num(c[5])); d.Preco = Num(c[6]); d.Ordem = Inteiro(c[7]);
                    d.Comissao = Zero(Num(c[8])); d.Swap = Zero(Num(c[9])); d.Lucro = Zero(Num(c[10]));
                    d.Saldo = Num(c[11]); d.Comentario = c[12];
                    r.Deals.Add(d);
                }
                // ordenacao estavel por (hora, numero), como o sort do Python
                r.Deals = r.Deals.Select((d, i) => new { d, i }).OrderBy(x => x.d.Hora).ThenBy(x => x.d.Numero).ThenBy(x => x.i).Select(x => x.d).ToList();
            }
            r.Trades = CasarTrades(r.Deals, r.OrdensSlTp);
            return r;
        }

        static void AddInput(Relatorio r, string val)
        {
            if (val.IndexOf('=') >= 0 && !val.StartsWith("==="))
            {
                int p = val.IndexOf('=');
                r.Inputs.Add(new KeyValuePair<string, string>(val.Substring(0, p).Trim(), val.Substring(p + 1).Trim()));
            }
        }

        public static string TagEstrategia(string comentario)
        {
            string c = (comentario ?? "").Trim();
            if (c.Length == 0) return "NA";
            Match m = Regex.Match(c, "^(E\\d+)\\b");
            if (m.Success) return m.Groups[1].Value;
            string p = Regex.Split(c, "[_\\s]")[0];
            return p.Length > 12 ? p.Substring(0, 12) : p;
        }

        class Aberta
        {
            public DateTime Hora; public double Vol; public double Preco; public string Comentario;
            public double Comissao; public double Swap; public long Deal; public double Sl; public double Tp;
        }

        static readonly Regex ReSaidaNivel = new Regex("^\\s*(sl|tp)\\s+(-?[\\d.]+)", RegexOptions.IgnoreCase | RegexOptions.Compiled);

        public static List<Trade> CasarTrades(List<Deal> deals)
        {
            return CasarTrades(deals, null);
        }

        // Casa cada deal "out" com uma entrada aberta do mesmo simbolo e lado. Ordem de preferencia:
        // (0) saida pelo servidor "sl X"/"tp X" -> a entrada cujo SL/TP inicial e X, com o mesmo volume (resolve a troca
        //     E1<->E3 de mesmo volume do FIFO puro; vale quando o nivel nao foi movido depois da entrada); (1) FIFO com
        //     volume igual; (2) FIFO com volume maior (parcial); (3) a primeira da fila (aprox). ordens=null: porte fiel
        //     do parse_reports.py.
        public static List<Trade> CasarTrades(List<Deal> deals, Dictionary<long, double[]> ordens)
        {
            Dictionary<string, List<Aberta>> abertos = new Dictionary<string, List<Aberta>>();
            List<Trade> trades = new List<Trade>();
            Func<string, List<Aberta>> fila = delegate (string k)
            {
                List<Aberta> l;
                if (!abertos.TryGetValue(k, out l)) { l = new List<Aberta>(); abertos[k] = l; }
                return l;
            };
            Action<Deal, double, string> abrir = delegate (Deal d, double volume, string comentario)
            {
                string lado = d.Tipo == "buy" ? "long" : "short";
                Aberta a = new Aberta();
                a.Hora = d.Hora; a.Vol = volume; a.Preco = d.Preco; a.Comentario = comentario;
                a.Comissao = d.Comissao; a.Swap = d.Swap; a.Deal = d.Numero;
                a.Sl = double.NaN; a.Tp = double.NaN;
                double[] st;
                if (ordens != null && ordens.TryGetValue(d.Ordem, out st)) { a.Sl = st[0]; a.Tp = st[1]; }
                fila(d.Simbolo + "|" + lado).Add(a);
            };
            Action<Deal, double> fechar = delegate (Deal d, double volume)
            {
                string lado = d.Tipo == "sell" ? "long" : "short";
                List<Aberta> f = fila(d.Simbolo + "|" + lado);
                Aberta pos = null; string modo = "nao";
                if (ordens != null)
                {
                    Match mn = ReSaidaNivel.Match(d.Comentario ?? "");
                    double nivel;
                    if (mn.Success && double.TryParse(mn.Groups[2].Value, NumberStyles.Float, CI, out nivel))
                    {
                        bool porSl = mn.Groups[1].Value.ToLowerInvariant() == "sl";
                        foreach (Aberta p in f)
                        {
                            double alvo = porSl ? p.Sl : p.Tp;
                            if (!double.IsNaN(alvo) && Math.Abs(alvo - nivel) < 0.006 && Math.Abs(p.Vol - volume) < 1e-9) { pos = p; modo = "exata"; break; }
                        }
                    }
                }
                if (pos == null) foreach (Aberta p in f) if (Math.Abs(p.Vol - volume) < 1e-9) { pos = p; modo = "exata"; break; }
                if (pos == null) foreach (Aberta p in f) if (p.Vol > volume + 1e-9) { pos = p; modo = "parcial"; break; }
                if (pos == null && f.Count > 0) { pos = f[0]; modo = "aprox"; }
                double comIn = 0.0, swapIn = 0.0;
                if (pos != null)
                {
                    double frac = pos.Vol > 0 ? Math.Min(1.0, volume / pos.Vol) : 1.0;
                    comIn = pos.Comissao * frac; swapIn = pos.Swap * frac;
                    pos.Comissao -= comIn; pos.Swap -= swapIn; pos.Vol -= volume;
                    if (pos.Vol <= 1e-9) f.Remove(pos);
                }
                Trade t = new Trade();
                t.N = trades.Count + 1;
                t.TemAbertura = pos != null; if (pos != null) t.Abertura = pos.Hora;
                t.Fechamento = d.Hora; t.Simbolo = d.Simbolo; t.Direcao = lado; t.Volume = volume;
                t.PrecoEntrada = pos != null ? pos.Preco : double.NaN; t.PrecoSaida = d.Preco;
                t.Lucro = Math.Round(d.Lucro, 2); t.Comissao = Math.Round(d.Comissao + comIn, 2);
                t.Swap = Math.Round(d.Swap + swapIn, 2);
                t.LucroLiquido = Math.Round(d.Lucro + d.Comissao + d.Swap + comIn + swapIn, 2);
                t.SaldoApos = d.Saldo;
                t.Estrategia = pos != null ? TagEstrategia(pos.Comentario) : "NA";
                t.ComentarioEntrada = pos != null ? pos.Comentario : ""; t.ComentarioSaida = d.Comentario;
                t.Atribuicao = modo; t.DealIn = pos != null ? pos.Deal : 0; t.DealOut = d.Numero;
                trades.Add(t);
            };
            foreach (Deal d in deals)
            {
                if (d.Direcao == "in") abrir(d, d.Volume, d.Comentario);
                else if (d.Direcao == "out") fechar(d, d.Volume);
                else
                {
                    string ladoFechado = d.Tipo == "sell" ? "long" : "short";
                    double aberto = fila(d.Simbolo + "|" + ladoFechado).Sum(p => p.Vol);
                    double fecha = Math.Min(aberto, d.Volume);
                    if (fecha > 0) fechar(d, fecha);
                    double resto = d.Volume - fecha;
                    if (resto > 1e-9) abrir(d, resto, d.Comentario);
                }
            }
            return trades;
        }

        // Serie diaria fracionaria em DIAS UTEIS (seg-sex) de [de, ate]: lucro liquido dos trades fechados no dia (filtrados
        // por estrategia, "" = todas) dividido pelo saldo no inicio do dia (deposito + tudo o que fechou antes, de todas as
        // estrategias). Fechamento em sabado/domingo (nao deveria haver) entra na sexta anterior. Dia sem fechamento = 0.
        public static DateTime[] DiasUteis(DateTime de, DateTime ate)
        {
            List<DateTime> l = new List<DateTime>();
            for (DateTime d = de.Date; d <= ate.Date; d = d.AddDays(1))
                if (d.DayOfWeek != DayOfWeek.Saturday && d.DayOfWeek != DayOfWeek.Sunday) l.Add(d);
            return l.ToArray();
        }

        static int IndiceDia(DateTime[] dias, DateTime h)
        {
            DateTime d = h.Date;
            if (d.DayOfWeek == DayOfWeek.Saturday) d = d.AddDays(-1);
            else if (d.DayOfWeek == DayOfWeek.Sunday) d = d.AddDays(-2);
            int i = Array.BinarySearch(dias, d);
            return i;
        }

        // porDiaDoSinal=true: o P&L de cada trade entra no dia util da ENTRADA (a E1 e a E3 tem um sinal por dia), com o
        // saldo no inicio desse dia como denominador (= resultado em R x risco%). Assim uma variante que so muda o dia da
        // saida nao desalinha o par variante x controle. false: dia do fechamento.
        public static double[] SerieDiaria(List<Trade> trades, double deposito, DateTime de, DateTime ate, string estrategia, bool porDiaDoSinal)
        {
            DateTime[] dias = DiasUteis(de, ate);
            int n = dias.Length;
            double[] plDia = new double[n]; double[] plFech = new double[n];
            double saldo = deposito;
            foreach (Trade t in trades)
            {
                // saldo no inicio de cada dia = deposito + tudo que FECHOU antes (independe da indexacao)
                if (t.Fechamento.Date < de.Date) saldo += t.LucroLiquido;
                else { int j = IndiceDia(dias, t.Fechamento); if (j >= 0) plFech[j] += t.LucroLiquido; }
                DateTime h = porDiaDoSinal && t.TemAbertura ? t.Abertura : t.Fechamento;
                if (h.Date < de.Date) continue;
                int i = IndiceDia(dias, h);
                if (i < 0) continue;
                if (string.IsNullOrEmpty(estrategia) || t.Estrategia == estrategia) plDia[i] += t.LucroLiquido;
            }
            double[] r = new double[n];
            for (int i = 0; i < n; i++)
            {
                r[i] = saldo > 0 ? plDia[i] / saldo : 0.0;
                saldo += plFech[i];
            }
            return r;
        }

        public static double[] SerieDiaria(List<Trade> trades, double deposito, DateTime de, DateTime ate, string estrategia)
        {
            return SerieDiaria(trades, deposito, de, ate, estrategia, true);
        }

        // assinatura da lista de trades (abertura, fechamento, volume, lucro) para detectar variante inerte e sanduiche
        public static string Assinatura(List<Trade> trades)
        {
            StringBuilder sb = new StringBuilder();
            foreach (Trade t in trades)
                sb.Append(t.TemAbertura ? t.Abertura.ToString("yyyyMMddHHmmss", CI) : "-").Append('|')
                  .Append(t.Fechamento.ToString("yyyyMMddHHmmss", CI)).Append('|')
                  .Append(t.Volume.ToString("0.00", CI)).Append('|').Append(t.LucroLiquido.ToString("0.00", CI)).Append(';');
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] h = md5.ComputeHash(Encoding.ASCII.GetBytes(sb.ToString()));
                return BitConverter.ToString(h).Replace("-", "");
            }
        }

        // numero de trades de 'a' que nao existem em 'b' (mesma abertura, fechamento, volume e lucro)
        public static int TradesDiferentes(List<Trade> a, List<Trade> b)
        {
            Dictionary<string, int> cont = new Dictionary<string, int>();
            foreach (Trade t in b)
            {
                string k = Chave(t); int c; cont.TryGetValue(k, out c); cont[k] = c + 1;
            }
            int dif = 0;
            foreach (Trade t in a)
            {
                string k = Chave(t); int c;
                if (cont.TryGetValue(k, out c) && c > 0) cont[k] = c - 1; else dif++;
            }
            return dif;
        }

        static string Chave(Trade t)
        {
            return (t.TemAbertura ? t.Abertura.ToString("yyyyMMddHHmmss", CI) : "-") + "|" + t.Fechamento.ToString("yyyyMMddHHmmss", CI)
                + "|" + t.Volume.ToString("0.00", CI) + "|" + t.LucroLiquido.ToString("0.00", CI);
        }

        // chave do "sinal": entrada, saida e preco de saida. Volume e lucro ficam de fora: depois da primeira diferenca de
        // saldo o lote de todas as pernas muda (piso de 0,01), e isso nao e um sinal diferente.
        static string ChaveSinal(Trade t)
        {
            return (t.TemAbertura ? t.Abertura.ToString("yyyyMMddHHmmss", CI) : "-") + "|" + t.Fechamento.ToString("yyyyMMddHHmmss", CI)
                + "|" + (double.IsNaN(t.PrecoSaida) ? "-" : t.PrecoSaida.ToString("0.000", CI));
        }

        // numero de SINAIS (estrategia + dia da entrada) com alguma perna diferente entre a e b; estrategia "" = todas
        public static int SinaisDiferentes(List<Trade> a, List<Trade> b, string estrategia)
        {
            Dictionary<string, List<string>> da = new Dictionary<string, List<string>>(), db = new Dictionary<string, List<string>>();
            Action<List<Trade>, Dictionary<string, List<string>>> montar = delegate (List<Trade> ts, Dictionary<string, List<string>> dd)
            {
                foreach (Trade t in ts)
                {
                    if (!string.IsNullOrEmpty(estrategia) && t.Estrategia != estrategia) continue;
                    string dia = t.Estrategia + "|" + (t.TemAbertura ? t.Abertura : t.Fechamento).ToString("yyyyMMdd", CI);
                    List<string> l; if (!dd.TryGetValue(dia, out l)) { l = new List<string>(); dd[dia] = l; }
                    l.Add(ChaveSinal(t));
                }
            };
            montar(a, da); montar(b, db);
            HashSet<string> todos = new HashSet<string>(da.Keys); todos.UnionWith(db.Keys);
            int dif = 0;
            foreach (string k in todos)
            {
                List<string> la, lb;
                if (!da.TryGetValue(k, out la) || !db.TryGetValue(k, out lb)) { dif++; continue; }
                la.Sort(StringComparer.Ordinal); lb.Sort(StringComparer.Ordinal);
                if (la.Count != lb.Count) { dif++; continue; }
                for (int i = 0; i < la.Count; i++) if (la[i] != lb[i]) { dif++; break; }
            }
            return dif;
        }
    }

    // gerador determinístico (xorshift128+), para a semente registrada reproduzir o resultado
    public class Rng
    {
        ulong s0, s1;
        public Rng(ulong seed)
        {
            ulong z = seed + 0x9E3779B97F4A7C15UL;
            s0 = Mix(ref z); s1 = Mix(ref z);
            if (s0 == 0 && s1 == 0) s1 = 1;
        }
        static ulong Mix(ref ulong z)
        {
            z += 0x9E3779B97F4A7C15UL;
            ulong x = z;
            x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9UL;
            x = (x ^ (x >> 27)) * 0x94D049BB133111EBUL;
            return x ^ (x >> 31);
        }
        public ulong Next()
        {
            ulong x = s0, y = s1;
            s0 = y; x ^= x << 23; s1 = x ^ y ^ (x >> 17) ^ (y >> 26);
            return s1 + y;
        }
        public double NextDouble() { return (Next() >> 11) * (1.0 / 9007199254740992.0); }
        public int NextInt(int n) { return (int)(NextDouble() * n); }
    }

    public class McResultado
    {
        public double DdMediana, DdP95, DdP99, PDd20, PHalt, PDd50, PRuina, RetMediana, RetP5, RetP95, PRetNeg;
        public int Horizonte, Caminhos, Bloco, NTrades;
    }

    public static class Mc
    {
        // r = retornos fracionarios por trade (lucro / saldo antes). escalaRisco multiplica cada r (1.0 = como rodou).
        // guardiao: lock (DD que reduz), reset (DD abaixo do qual volta), halt, escalaLock; halt <= 0 = modo cru.
        public static McResultado Rodar(double[] r, int caminhos, int bloco, int horizonte, ulong seed, double ruina,
                                        double escalaRisco, double lockDd, double resetDd, double haltDd, double escalaLock)
        {
            int N = r.Length;
            McResultado res = new McResultado();
            res.Horizonte = horizonte; res.Caminhos = caminhos; res.Bloco = bloco; res.NTrades = N;
            if (N < 2 * bloco) return null;
            Rng rng = new Rng(seed);
            int nb = (int)Math.Ceiling(horizonte / (double)bloco);
            double[] maxdd = new double[caminhos]; double[] ret = new double[caminhos]; bool[] ruiu = new bool[caminhos];
            bool guard = haltDd > 0;
            for (int c = 0; c < caminhos; c++)
            {
                double eq = 1.0, pico = 1.0, escala = 1.0, mdd = 0.0; bool parado = false, ru = false;
                int j = 0;
                for (int b = 0; b < nb && j < horizonte; b++)
                {
                    int st = rng.NextInt(N);
                    for (int k = 0; k < bloco && j < horizonte; k++, j++)
                    {
                        double x = r[(st + k) % N] * escalaRisco;
                        double ref_ = guard ? (parado ? 0.0 : x * escala) : x;
                        eq = eq * Math.Max(1.0 + ref_, 0.0);
                        if (eq > pico) pico = eq;
                        double dd = 1.0 - eq / Math.Max(pico, 1e-12);
                        if (dd > mdd) mdd = dd;
                        if (eq <= ruina) ru = true;
                        if (guard)
                        {
                            if (dd >= haltDd) parado = true;
                            if (dd >= lockDd) escala = escalaLock; else if (dd < resetDd) escala = 1.0;
                        }
                    }
                }
                maxdd[c] = mdd; ret[c] = (ru ? ruina : eq) - 1.0; ruiu[c] = ru;
            }
            res.DdMediana = 100 * Pct(maxdd, 50); res.DdP95 = 100 * Pct(maxdd, 95); res.DdP99 = 100 * Pct(maxdd, 99);
            res.PDd20 = 100.0 * maxdd.Count(v => v >= 0.20) / caminhos;
            res.PHalt = 100.0 * maxdd.Count(v => v >= (guard ? haltDd : 0.35)) / caminhos;
            res.PDd50 = 100.0 * maxdd.Count(v => v >= 0.50) / caminhos;
            res.PRuina = 100.0 * ruiu.Count(v => v) / caminhos;
            res.RetMediana = 100 * Pct(ret, 50); res.RetP5 = 100 * Pct(ret, 5); res.RetP95 = 100 * Pct(ret, 95);
            res.PRetNeg = 100.0 * ret.Count(v => v < 0) / caminhos;
            return res;
        }

        // percentil com interpolacao linear (igual ao numpy.percentile default)
        public static double Pct(double[] a, double q)
        {
            double[] s = (double[])a.Clone(); Array.Sort(s);
            if (s.Length == 0) return double.NaN;
            double pos = (s.Length - 1) * q / 100.0;
            int lo = (int)Math.Floor(pos); int hi = Math.Min(lo + 1, s.Length - 1);
            return s[lo] + (s[hi] - s[lo]) * (pos - lo);
        }

        public static double[] RetornosFracionais(List<Trade> trades, double deposito)
        {
            List<Trade> ord = trades.OrderBy(t => t.Fechamento).ToList();
            List<double> r = new List<double>(); double eq = deposito;
            foreach (Trade t in ord) { if (eq <= 0) break; r.Add(t.LucroLiquido / eq); eq += t.LucroLiquido; }
            return r.ToArray();
        }
    }

    public class SpaResultado
    {
        public double PConsistente, PInferior, PSuperior, Estatistica;
        public double[] Media, Omega, PIndividual; // por variante: media diaria de d, omega (desvio de longo prazo), p isolado
        public int Dias, Replicas; public double BlocoMedio;
    }

    public static class Spa
    {
        // d[k][t] = r_variante_k(t) - r_controle(t). H0: max_k E[d_k] <= 0 (nenhuma variante melhor que o controle).
        // Hansen (2005): T = max(0, max_k sqrt(n) dbar_k / omega_k); omega por bootstrap; recentragem l/c/u.
        public static SpaResultado Rodar(double[][] d, int replicas, double blocoMedio, ulong seed)
        {
            int K = d.Length; int n = d[0].Length;
            SpaResultado res = new SpaResultado();
            res.Dias = n; res.Replicas = replicas; res.BlocoMedio = blocoMedio;
            double[] dbar = new double[K];
            for (int k = 0; k < K; k++) dbar[k] = d[k].Average();
            double sn = Math.Sqrt(n);
            // indices do bootstrap estacionario, os mesmos para todas as variantes (preserva a correlacao entre elas)
            Rng rng = new Rng(seed);
            double p = 1.0 / blocoMedio;
            double[][] bm = new double[replicas][]; // media bootstrap por replica e variante
            int[] idx = new int[n];
            for (int b = 0; b < replicas; b++)
            {
                int cur = rng.NextInt(n);
                for (int t = 0; t < n; t++)
                {
                    if (t > 0) cur = rng.NextDouble() < p ? rng.NextInt(n) : (cur + 1) % n;
                    idx[t] = cur;
                }
                bm[b] = new double[K];
                for (int k = 0; k < K; k++)
                {
                    double s = 0; double[] dk = d[k];
                    for (int t = 0; t < n; t++) s += dk[idx[t]];
                    bm[b][k] = s / n;
                }
            }
            // Correcao de amostra finita: o bootstrap estacionario circular subestima a variancia de longo prazo da media
            // em ~2(1-q)/(q n) (as autocovariancias amostrais de dados centrados somam negativo). Sem ela o teste rejeitava
            // 6-7% sob o nulo com bloco 20 e 12% com bloco 40 (dados sinteticos, n=520). Os desvios de cada replica em
            // torno da media observada sao alargados por infl = 1/sqrt(fator), e omega usa o mesmo fator.
            double q = 1.0 / blocoMedio;
            double fator = 1.0 - 2.0 * (1.0 - q) / (q * n);
            if (fator < 0.5) fator = 0.5;
            double infl = 1.0 / Math.Sqrt(fator);
            for (int b = 0; b < replicas; b++)
                for (int k = 0; k < K; k++) bm[b][k] = dbar[k] + (bm[b][k] - dbar[k]) * infl;
            // omega_k^2 = var bootstrap de sqrt(n) * dbar*_k (ja corrigida)
            double[] omega = new double[K];
            for (int k = 0; k < K; k++)
            {
                double m = 0; for (int b = 0; b < replicas; b++) m += bm[b][k]; m /= replicas;
                double v = 0; for (int b = 0; b < replicas; b++) { double z = sn * (bm[b][k] - m); v += z * z; }
                omega[k] = Math.Sqrt(v / (replicas - 1));
                if (omega[k] <= 1e-15) omega[k] = 1e-15;
            }
            double tObs = 0;
            for (int k = 0; k < K; k++) tObs = Math.Max(tObs, sn * dbar[k] / omega[k]);
            double limiar = Math.Sqrt(2.0 * Math.Log(Math.Log(n)));
            double[] gL = new double[K], gC = new double[K], gU = new double[K];
            for (int k = 0; k < K; k++)
            {
                gL[k] = Math.Max(dbar[k], 0.0);
                gC[k] = (sn * dbar[k] / omega[k] >= -limiar) ? dbar[k] : 0.0;
                gU[k] = dbar[k];
            }
            int cL = 0, cC = 0, cU = 0;
            int[] cInd = new int[K];
            for (int b = 0; b < replicas; b++)
            {
                double tl = 0, tc = 0, tu = 0;
                for (int k = 0; k < K; k++)
                {
                    double zb = bm[b][k];
                    tl = Math.Max(tl, sn * (zb - gL[k]) / omega[k]);
                    tc = Math.Max(tc, sn * (zb - gC[k]) / omega[k]);
                    tu = Math.Max(tu, sn * (zb - gU[k]) / omega[k]);
                    // p isolado da variante k (teste unilateral studentizado, centragem consistente)
                    if (Math.Max(0.0, sn * (zb - gC[k]) / omega[k]) >= Math.Max(0.0, sn * dbar[k] / omega[k])) cInd[k]++;
                }
                if (tl >= tObs) cL++;
                if (tc >= tObs) cC++;
                if (tu >= tObs) cU++;
            }
            res.Estatistica = tObs;
            res.PInferior = (double)cL / replicas; res.PConsistente = (double)cC / replicas; res.PSuperior = (double)cU / replicas;
            res.Media = dbar; res.Omega = omega;
            res.PIndividual = new double[K];
            for (int k = 0; k < K; k++) res.PIndividual[k] = (double)cInd[k] / replicas;
            return res;
        }
    }

    public class StepmResultado
    {
        public double[] T, PAjustado, Media, Omega;   // por variante (NaN nas nao elegiveis)
        public double CriticoK;                       // (1-alfa) do maximo bootstrap no 1o passo (base do MDE da familia)
        public int Dias, Replicas, Elegiveis; public double BlocoMedio;
    }

    public static class Stepm
    {
        // Romano-Wolf (2005) StepM studentizado, unilateral (variante melhor que o controle), com p ajustado por variante
        // (Romano-Wolf 2016): ordena por T decrescente; p_j = max(p_{j-1}, P*(max_{l nao rejeitadas antes} T*_l >= T_j)).
        // Mesmo bootstrap estacionario circular e mesma correcao de amostra finita do Spa. Variantes nao elegiveis (sinais
        // alterados insuficientes ou d identicamente zero) ficam fora do maximo e recebem NaN.
        public static StepmResultado Rodar(double[][] d, bool[] elegivel, int replicas, double blocoMedio, ulong seed, double alfa)
        {
            int K = d.Length; int n = d[0].Length;
            StepmResultado res = new StepmResultado();
            res.Dias = n; res.Replicas = replicas; res.BlocoMedio = blocoMedio;
            res.T = new double[K]; res.PAjustado = new double[K]; res.Media = new double[K]; res.Omega = new double[K];
            List<int> eleg = new List<int>();
            for (int k = 0; k < K; k++)
            {
                res.T[k] = double.NaN; res.PAjustado[k] = double.NaN; res.Media[k] = d[k].Average(); res.Omega[k] = double.NaN;
                bool zero = true, ruim = false;
                foreach (double x in d[k]) { if (double.IsNaN(x) || double.IsInfinity(x)) { ruim = true; break; } if (x != 0.0) zero = false; }
                if (elegivel[k] && !zero && !ruim) eleg.Add(k);
            }
            res.Elegiveis = eleg.Count;
            res.CriticoK = double.NaN;
            if (eleg.Count == 0) return res;
            double sn = Math.Sqrt(n);
            double q = 1.0 / blocoMedio;
            double fator = 1.0 - 2.0 * (1.0 - q) / (q * n); if (fator < 0.5) fator = 0.5;
            double infl = 1.0 / Math.Sqrt(fator);
            Rng rng = new Rng(seed);
            int E = eleg.Count;
            double[][] dev = new double[replicas][]; // sqrt(n) * (media* - media) * infl, por variante elegivel
            int[] idx = new int[n];
            for (int b = 0; b < replicas; b++)
            {
                int cur = rng.NextInt(n);
                for (int t = 0; t < n; t++) { if (t > 0) cur = rng.NextDouble() < q ? rng.NextInt(n) : (cur + 1) % n; idx[t] = cur; }
                dev[b] = new double[E];
                for (int e = 0; e < E; e++)
                {
                    double[] dk = d[eleg[e]]; double sm = 0; for (int t = 0; t < n; t++) sm += dk[idx[t]];
                    dev[b][e] = sn * (sm / n - res.Media[eleg[e]]) * infl;
                }
            }
            double[] om = new double[E];
            for (int e = 0; e < E; e++)
            {
                double m = 0; for (int b = 0; b < replicas; b++) m += dev[b][e]; m /= replicas;
                double v = 0; for (int b = 0; b < replicas; b++) { double z = dev[b][e] - m; v += z * z; }
                om[e] = Math.Sqrt(v / (replicas - 1)); if (om[e] <= 1e-15) om[e] = 1e-15;
                res.Omega[eleg[e]] = om[e];
                res.T[eleg[e]] = sn * res.Media[eleg[e]] / om[e];
            }
            // ordem decrescente de T
            int[] ord = Enumerable.Range(0, E).OrderByDescending(e => res.T[eleg[e]]).ToArray();
            // T* studentizado por replica
            double[][] ts = new double[replicas][];
            for (int b = 0; b < replicas; b++) { ts[b] = new double[E]; for (int e = 0; e < E; e++) ts[b][e] = dev[b][e] / om[e]; }
            // critico do 1o passo (todas as elegiveis)
            double[] mx = new double[replicas];
            for (int b = 0; b < replicas; b++) { double m = double.NegativeInfinity; for (int e = 0; e < E; e++) m = Math.Max(m, ts[b][e]); mx[b] = m; }
            res.CriticoK = Mc.Pct(mx, 100.0 * (1.0 - alfa));
            double pAnt = 0.0;
            for (int j = 0; j < E; j++)
            {
                int ej = ord[j]; double tj = res.T[eleg[ej]];
                int cont = 0;
                for (int b = 0; b < replicas; b++)
                {
                    double m = double.NegativeInfinity;
                    for (int l = j; l < E; l++) m = Math.Max(m, ts[b][ord[l]]);
                    if (m >= tj) cont++;
                }
                double pj = Math.Max(pAnt, (double)cont / replicas);
                res.PAjustado[eleg[ej]] = pj; pAnt = pj;
            }
            return res;
        }
    }

    public class McParResultado
    {
        public double PDd20Controle, PDd20Variante, PHaltControle, PHaltVariante, DdP95Controle, DdP95Variante,
                      RetMedControle, RetMedVariante;
        public int Caminhos, Horizonte, Bloco;
    }

    public static class McPar
    {
        // Monte Carlo PAREADO por dias: os mesmos blocos de dias-sinal (circulares, bloco fixo) alimentam o controle e a
        // variante, com as regras do guardiao (lock/reset/halt por DD do saldo diario; escala no lock). Compara o risco da
        // variante com o do controle no mesmo caminho de mercado.
        public static McParResultado Rodar(double[] r0, double[] rv, int caminhos, int bloco, int horizonte, ulong seed,
                                          double lockDd, double resetDd, double haltDd, double escalaLock)
        {
            int n = r0.Length;
            McParResultado res = new McParResultado(); res.Caminhos = caminhos; res.Horizonte = horizonte; res.Bloco = bloco;
            if (n < 2 * bloco || rv.Length != n) return null;
            Rng rng = new Rng(seed);
            int nb = (int)Math.Ceiling(horizonte / (double)bloco);
            double[] dd0 = new double[caminhos], ddv = new double[caminhos], ret0 = new double[caminhos], retv = new double[caminhos];
            int[] seq = new int[nb * bloco];
            for (int c = 0; c < caminhos; c++)
            {
                for (int b = 0; b < nb; b++) { int st = rng.NextInt(n); for (int k = 0; k < bloco; k++) seq[b * bloco + k] = (st + k) % n; }
                double m0, mv, f0, fv;
                Caminho(r0, seq, horizonte, lockDd, resetDd, haltDd, escalaLock, out m0, out f0);
                Caminho(rv, seq, horizonte, lockDd, resetDd, haltDd, escalaLock, out mv, out fv);
                dd0[c] = m0; ddv[c] = mv; ret0[c] = f0 - 1.0; retv[c] = fv - 1.0;
            }
            res.PDd20Controle = 100.0 * dd0.Count(v => v >= 0.20) / caminhos; res.PDd20Variante = 100.0 * ddv.Count(v => v >= 0.20) / caminhos;
            res.PHaltControle = 100.0 * dd0.Count(v => v >= haltDd) / caminhos; res.PHaltVariante = 100.0 * ddv.Count(v => v >= haltDd) / caminhos;
            res.DdP95Controle = 100 * Mc.Pct(dd0, 95); res.DdP95Variante = 100 * Mc.Pct(ddv, 95);
            res.RetMedControle = 100 * Mc.Pct(ret0, 50); res.RetMedVariante = 100 * Mc.Pct(retv, 50);
            return res;
        }

        static void Caminho(double[] r, int[] seq, int h, double lockDd, double resetDd, double haltDd, double escalaLock, out double maxdd, out double eqFinal)
        {
            double eq = 1.0, pico = 1.0, escala = 1.0, mdd = 0.0; bool parado = false;
            for (int j = 0; j < h; j++)
            {
                double x = parado ? 0.0 : r[seq[j]] * escala;
                eq *= Math.Max(1.0 + x, 0.0);
                if (eq > pico) pico = eq;
                double dd = 1.0 - eq / Math.Max(pico, 1e-12);
                if (dd > mdd) mdd = dd;
                if (dd >= haltDd) parado = true;
                if (dd >= lockDd) escala = escalaLock; else if (dd < resetDd) escala = 1.0;
            }
            maxdd = mdd; eqFinal = eq;
        }
    }

    // Job Object do Windows para os processos da copia de tester: KILL_ON_JOB_CLOSE (se o lab.ps1 morrer, o handle fecha
    // e o Windows encerra o terminal e o metatester da copia, inclusive um terminal relancado pelo LiveUpdate, que herda
    // o job), limite de memoria do job, afinidade de CPU e prioridade BelowNormal. Um job por processo do lab.ps1.
    public static class LabJob
    {
        [StructLayout(LayoutKind.Sequential)]
        struct BASIC { public long PerProcessUserTimeLimit; public long PerJobUserTimeLimit; public uint LimitFlags;
            public UIntPtr MinimumWorkingSetSize; public UIntPtr MaximumWorkingSetSize; public uint ActiveProcessLimit;
            public UIntPtr Affinity; public uint PriorityClass; public uint SchedulingClass; }
        [StructLayout(LayoutKind.Sequential)]
        struct IO { public ulong a, b, c, d, e, f; }
        [StructLayout(LayoutKind.Sequential)]
        struct EXT { public BASIC Basic; public IO Io; public UIntPtr ProcessMemoryLimit; public UIntPtr JobMemoryLimit;
            public UIntPtr PeakProcessMemoryUsed; public UIntPtr PeakJobMemoryUsed; }

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] static extern IntPtr CreateJobObject(IntPtr a, string n);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool SetInformationJobObject(IntPtr j, int c, IntPtr i, uint l);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool QueryInformationJobObject(IntPtr j, int c, IntPtr i, uint l, IntPtr r);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool AssignProcessToJobObject(IntPtr j, IntPtr p);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool CloseHandle(IntPtr h);
        [DllImport("kernel32.dll", SetLastError = true)] static extern bool TerminateJobObject(IntPtr j, uint code);
        [DllImport("kernel32.dll", SetLastError = true)] static extern uint ResumeThread(IntPtr t);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern bool CreateProcess(string app, StringBuilder cmd, IntPtr pa, IntPtr ta, bool inherit, uint flags,
                                         IntPtr env, string dir, ref STARTUPINFO si, out PROCESS_INFORMATION pi);

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        struct STARTUPINFO { public int cb; public string lpReserved; public string lpDesktop; public string lpTitle;
            public int dwX, dwY, dwXSize, dwYSize, dwXCountChars, dwYCountChars, dwFillAttribute, dwFlags;
            public short wShowWindow, cbReserved2; public IntPtr lpReserved2, hStdInput, hStdOutput, hStdError; }
        [StructLayout(LayoutKind.Sequential)]
        struct PROCESS_INFORMATION { public IntPtr hProcess; public IntPtr hThread; public int dwProcessId; public int dwThreadId; }
        [StructLayout(LayoutKind.Sequential)]
        struct ACCT { public long TotalUserTime, TotalKernelTime, ThisPeriodTotalUserTime, ThisPeriodTotalKernelTime;
            public uint TotalPageFaultCount, TotalProcesses, ActiveProcesses, TotalTerminatedProcesses; }

        static IntPtr job = IntPtr.Zero;

        // Cria o processo SUSPENSO, poe no job e so entao deixa rodar: tudo o que ele criar (o atualizador do LiveUpdate,
        // o terminal relancado por ele, o metatester) ja nasce dentro do job, sem corrida. Devolve o PID (0 = falhou).
        public static int Iniciar(string exe, string args, string dir, out string erro)
        {
            erro = "";
            if (job == IntPtr.Zero) { erro = "job nao criado"; return 0; }
            STARTUPINFO si = new STARTUPINFO(); si.cb = Marshal.SizeOf(typeof(STARTUPINFO));
            PROCESS_INFORMATION pi;
            StringBuilder cmd = new StringBuilder("\"" + exe + "\" " + args);
            if (!CreateProcess(null, cmd, IntPtr.Zero, IntPtr.Zero, false, 0x4 /*CREATE_SUSPENDED*/, IntPtr.Zero, dir, ref si, out pi))
            { erro = "CreateProcess erro " + Marshal.GetLastWin32Error(); return 0; }
            try
            {
                if (!AssignProcessToJobObject(job, pi.hProcess))
                {
                    erro = "AssignProcessToJobObject erro " + Marshal.GetLastWin32Error();
                    try { System.Diagnostics.Process.GetProcessById(pi.dwProcessId).Kill(); } catch { }
                    return 0;
                }
                ResumeThread(pi.hThread);
                return pi.dwProcessId;
            }
            finally { CloseHandle(pi.hThread); CloseHandle(pi.hProcess); }
        }

        // processos vivos no job (o terminal, o metatester, o atualizador e o terminal relancado por ele)
        public static int Ativos()
        {
            if (job == IntPtr.Zero) return 0;
            int len = Marshal.SizeOf(typeof(ACCT));
            IntPtr ptr = Marshal.AllocHGlobal(len);
            try
            {
                if (!QueryInformationJobObject(job, 1, ptr, (uint)len, IntPtr.Zero)) return -1;
                ACCT a = (ACCT)Marshal.PtrToStructure(ptr, typeof(ACCT));
                return (int)a.ActiveProcesses;
            }
            finally { Marshal.FreeHGlobal(ptr); }
        }

        // encerra tudo o que esta no job (abortar um run) sem fechar o job
        public static bool Encerrar()
        {
            if (job == IntPtr.Zero) return false;
            return TerminateJobObject(job, 1);
        }

        public static string Criar(long memoriaMb, int cpus)
        {
            if (job != IntPtr.Zero) return "";
            job = CreateJobObject(IntPtr.Zero, null);
            if (job == IntPtr.Zero) return "CreateJobObject erro " + Marshal.GetLastWin32Error();
            EXT x = new EXT();
            x.Basic.LimitFlags = 0x2000 | 0x20; // KILL_ON_JOB_CLOSE | PRIORITY_CLASS
            x.Basic.PriorityClass = 0x4000;     // BELOW_NORMAL
            if (memoriaMb > 0) { x.Basic.LimitFlags |= 0x200; x.JobMemoryLimit = new UIntPtr((ulong)memoriaMb * 1024UL * 1024UL); }
            int n = Environment.ProcessorCount;
            if (cpus > 0 && cpus < n)
            {
                ulong mask = 0; for (int i = 0; i < cpus; i++) mask |= (1UL << (n - 1 - i)); // os ultimos nucleos
                x.Basic.LimitFlags |= 0x10; x.Basic.Affinity = new UIntPtr(mask);
            }
            int len = Marshal.SizeOf(typeof(EXT));
            IntPtr ptr = Marshal.AllocHGlobal(len);
            try
            {
                Marshal.StructureToPtr(x, ptr, false);
                if (!SetInformationJobObject(job, 9, ptr, (uint)len)) return "SetInformationJobObject erro " + Marshal.GetLastWin32Error();
            }
            finally { Marshal.FreeHGlobal(ptr); }
            return "";
        }

        public static string Atribuir(System.Diagnostics.Process p)
        {
            if (job == IntPtr.Zero) return "job nao criado";
            if (!AssignProcessToJobObject(job, p.Handle)) return "AssignProcessToJobObject erro " + Marshal.GetLastWin32Error();
            return "";
        }

        public static long PicoMemoriaMb()
        {
            if (job == IntPtr.Zero) return -1;
            int len = Marshal.SizeOf(typeof(EXT));
            IntPtr ptr = Marshal.AllocHGlobal(len);
            try
            {
                if (!QueryInformationJobObject(job, 9, ptr, (uint)len, IntPtr.Zero)) return -1;
                EXT x = (EXT)Marshal.PtrToStructure(ptr, typeof(EXT));
                return (long)(x.PeakJobMemoryUsed.ToUInt64() / (1024UL * 1024UL));
            }
            finally { Marshal.FreeHGlobal(ptr); }
        }

        // fecha o handle: com KILL_ON_JOB_CLOSE o Windows encerra tudo que esta no job
        public static void Fechar()
        {
            if (job != IntPtr.Zero) { CloseHandle(job); job = IntPtr.Zero; }
        }
    }
}
