# =====================================================================
#  lab_instalar.ps1 - cria a copia de tester do laboratorio ($LAB_DIR, CLAUDE.md 5.9)
#  Uso (Henrique, no console do VPS, uma vez):  powershell -NoProfile -ExecutionPolicy Bypass -File lab_instalar.ps1
#  O que faz:
#   1. copia SO os programas do terminal ao vivo ($MT5_DIR) para $LAB_DIR: sem config (conta e senha salvas),
#      sem perfis, sem MQL5, sem bases/logs/tester. Nunca apaga nada no destino (sem /MIR, sem /PURGE).
#   2. copia config\servers.dat (lista de servidores, sem conta) e o Concorde_RF.ex5 do ao vivo.
#   3. imprime os passos manuais: logar uma conta DEMO RoboForex-Pro na copia, desligar o MCP interno e o
#      Algo Trading da copia, e preencher $LAB_LOGIN em ops\config.ps1.
#  Nao abre nenhum terminal e nao mexe no terminal ao vivo (so le dele).
# =====================================================================
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\config.ps1"
. "$PSScriptRoot\common.ps1"
$ORIGEM = 'lab_instalar'
if (($env:SURV_AGENTE -eq '1') -or [bool]$env:CLAUDECODE) { Write-Host 'RECUSADO: instalacao do laboratorio e so do Henrique.'; exit 1 }
if (-not $LAB_DIR) { $LAB_DIR = 'C:\MT5_RF_Lab' }
$lab = ([string]$LAB_DIR).TrimEnd('\')
$vivo = ([string]$MT5_DIR).TrimEnd('\')
if ($lab.ToLower() -eq $vivo.ToLower() -or $lab.ToLower().StartsWith($vivo.ToLower() + '\') -or $vivo.ToLower().StartsWith($lab.ToLower() + '\')) {
    Write-Host "RECUSADO: LAB_DIR ($lab) nao pode ser o terminal ao vivo nem estar dentro dele ($vivo)."; exit 1
}
if ($lab -match '\\RF_bt\d*$') { Write-Host 'RECUSADO: nao use C:\RF_bt no VPS (o vps_bootstrap.ps1 aborta se existir).'; exit 1 }
if (-not (Test-Path -LiteralPath $MT5_EXE)) { Write-Host "ERRO: terminal ao vivo nao encontrado em $MT5_EXE"; exit 1 }
$disco = [double](Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='" + $lab.Substring(0, 2) + "'")).FreeSpace / 1GB
if ($disco -lt 20) { Write-Host ("ERRO: {0:N1} GB livres; o laboratorio precisa de pelo menos 20 GB (ticks de 2 anos + cache do tester)." -f $disco); exit 1 }

Write-Host "Copiando os programas de $vivo para $lab ..."
& robocopy.exe $vivo $lab /E /XD config bases history logs Logs Tester tester MQL5 Profiles profiles Files llm-agent /XF *.log *.dat *.ini /R:1 /W:1 /NP /NFL /NDL | Out-Null
$rc = $LASTEXITCODE
if ($rc -ge 8) { Write-Host "ERRO: robocopy falhou (codigo $rc)"; exit 1 }
if (-not (Test-Path -LiteralPath (Join-Path $lab 'terminal64.exe'))) { Write-Host 'ERRO: terminal64.exe nao chegou na copia'; exit 1 }
Ensure-Dir (Join-Path $lab 'config')
$srv = Join-Path $vivo 'config\servers.dat'
if (Test-Path -LiteralPath $srv) { Copy-Item -LiteralPath $srv -Destination (Join-Path $lab 'config\servers.dat') -Force }
foreach ($f in 'accounts.dat', 'common.ini', 'settings.ini') {
    if (Test-Path -LiteralPath (Join-Path $lab "config\$f")) { Write-Host "  (config\$f da copia ja existe e foi mantido)" }
}
$ex5 = Join-Path $MT5_DATA 'MQL5\Experts\Sobrevivencia\Concorde_RF.ex5'
if (-not (Test-Path -LiteralPath $ex5)) { $ex5 = Join-Path $WS 'mql5\Experts\Concorde_RF.ex5' }
Ensure-Dir (Join-Path $lab 'MQL5\Experts')
Copy-Item -LiteralPath $ex5 -Destination (Join-Path $lab 'MQL5\Experts\Concorde_RF.ex5') -Force
Ensure-Dir "$WS\campanha\lab\fila"; Ensure-Dir "$WS\campanha\lab\lotes"; Ensure-Dir "$WS\campanha\lab\news"
Write-OpsLog "copia de tester criada/atualizada em $lab" $ORIGEM
# 60 min de manutencao: o heartbeat nao encerra a copia aberta a mao para o login da demo (so sem posicao aberta)
[IO.File]::WriteAllText((Join-Path $LOG_DIR 'lab.manutencao'), (Get-UtcStamp), (New-Object Text.UTF8Encoding($false)))

Write-Host ''
Write-Host '=== Copia criada. Passos manuais (so voce, pelo RDP) ==='
Write-Host ("1. Abra a copia: {0}\terminal64.exe /portable   (nunca abra sem /portable; NAO e o terminal ao vivo)" -f $lab)
Write-Host '2. Arquivo > Abrir uma conta > RoboForex-Pro > conta DEMO (nova ou uma demo que voce ja tem), marcando Salvar senha.'
Write-Host '   NUNCA logue a conta real 52012798 nesta copia: um tester na mesma conta derruba a sessao ao vivo.'
Write-Host '3. Ferramentas > Opcoes > MCP: DESMARCAR "Enable internal server" > OK (a porta 22346 e do terminal ao vivo).'
Write-Host '4. Ferramentas > Opcoes > Expert Advisors: DESMARCAR "Permitir negociacao algoritmica" > OK. Nenhum grafico com EA.'
Write-Host '5. Feche a copia (Arquivo > Sair). Voce tem 60 min (ops\logs\lab.manutencao) antes de o heartbeat encerrar a copia aberta;'
Write-Host '   com posicao aberta na conta real a manutencao nao vale: faca no fim de semana ou com a conta sem posicao.'
Write-Host '6. Em ops\config.ps1, troque  $LAB_LOGIN = 0  pelo numero da conta demo (ou me passe o numero).'
Write-Host '7. Registre a tarefa:  powershell -NoProfile -ExecutionPolicy Bypass -File C:\Sobrevivencia\ops\register_tasks.ps1 -SoLab'
Write-Host '8. Confira:  powershell -NoProfile -ExecutionPolicy Bypass -File C:\Sobrevivencia\ops\lab.ps1   (deve dizer "copia: ok")'
Write-Host 'O primeiro teste roda sozinho no sabado a partir das 04:30 UTC (sonda de 1 semana, depois o trimestre).'
exit 0
