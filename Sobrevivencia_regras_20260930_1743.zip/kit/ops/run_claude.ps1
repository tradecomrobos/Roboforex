# =====================================================================
#  run_claude.ps1 - executa o agente Claude Code em modo headless (claude -p)
#  Uso:  run_claude.ps1 -Modo diario|semanal|incidente|preabertura|lab [-Motivo "..."]
#                       [-TimeoutMin 45] [-PromptFile x.md] [-DryRun]
#  - Monta o prompt a partir de $WS\prompts\<modo>.md substituindo {MOTIVO},
#    {MODO} e {DATA_UTC}; grava a versao renderizada em logs\claude_<modo>_<ts>.prompt.md.
#  - Executa em $WS:  claude -p --permission-mode acceptEdits --output-format text
#        --add-dir <survival> <MQL5\Logs> <logs>  [--model X] [extras]
#    com o prompt via STDIN (evita limite/quoting da linha de comando) e stdout/stderr
#    redirecionados para logs\claude_<modo>_<ts>.log (+ .err.log anexado no fim).
#  - Timeout (default $CLAUDE_TIMEOUT_MIN): mata a arvore do processo e registra.
#  - Lock (logs\claude.lock): nunca duas execucoes simultaneas. Modo incidente (disparado
#    pelo heartbeat, sem retry do Task Scheduler) ESPERA a anterior terminar (ate
#    $CLAUDE_LOCK_WAIT_MIN); os modos agendados saem com codigo 3 e o Task Scheduler
#    tenta de novo em 15 min (RestartCount=2 em register_tasks.ps1). O modo lab
#    (chamado pelo ops\lab.ps1 ao fim de um lote) espera ate 30 min; um incidente
#    encerra uma acordada do modo lab que esteja segurando o lock (reducao de risco
#    vem antes de ler relatorio de laboratorio).
#  - Exit != 0 sem ser auth/limite/timeout -> alerta ATENCAO (acordada perdida sem diario).
#  - Se o log indicar falta de login -> anexa pedido de relogin em $WS\ALERTAS.md (+ notify).
#  Permissoes: NAO usa --dangerously-skip-permissions (proibido pelo Henrique). As
#  ferramentas liberadas vem de $WS\.claude\settings.json (allowlist). Alternativas:
#    --permission-mode acceptEdits (default aqui): edicoes dentro de $WS sem prompt; o
#         resto obedece o settings.json; o que nao estiver liberado e NEGADO em -p.
#    --permission-mode dontAsk: nega tudo que nao estiver na allowlist (mais estrito).
#    --permission-prompts none: (versoes >= 2.1) explicita que ninguem responde prompts.
#  Codigos de saida: 0 ok | 1 config/prompt/claude ausente | 2 timeout | 3 ocupado (lock)
#                    | 4 problema de autenticacao | outro = exit code do claude
# =====================================================================
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('diario', 'semanal', 'incidente', 'preabertura', 'lab')]
    [string]$Modo,
    [string]$Motivo = '',
    [int]$TimeoutMin = 0,
    [string]$PromptFile = '',
    [switch]$DryRun
)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\config.ps1"
. "$PSScriptRoot\common.ps1"
$ORIGEM = "run_claude[$Modo]"
Ensure-Dir $LOG_DIR
if ($TimeoutMin -le 0) { $TimeoutMin = $CLAUDE_TIMEOUT_MIN }

function Add-Alerta([string]$Nivel, [string]$Titulo, [string]$Msg) {
    $n = Join-Path $PSScriptRoot 'notify.ps1'
    try { & $n -Titulo $Titulo -Mensagem $Msg -Nivel $Nivel | Out-Null } catch { Write-OpsLog "notify falhou: $($_.Exception.Message)" $ORIGEM }
}

# --- Pre-requisitos --------------------------------------------------
if (-not $CLAUDE_CMD -or -not (Test-Path -LiteralPath $CLAUDE_CMD)) {
    Write-OpsLog 'ERRO: claude CLI nao encontrado (ver Find-ClaudeCmd em config.ps1)' $ORIGEM
    Add-Alerta 'CRITICO' 'claude CLI ausente' 'run_claude.ps1 nao achou claude.exe/claude.cmd; instale ou ajuste $CLAUDE_CMD em config.local.ps1'
    exit 1
}
if (-not $PromptFile) { $PromptFile = Join-Path $PROMPTS_DIR "$Modo.md" }
if (-not (Test-Path -LiteralPath $PromptFile)) {
    Write-OpsLog "ERRO: prompt nao encontrado: $PromptFile" $ORIGEM
    Add-Alerta 'CRITICO' 'prompt ausente' "run_claude.ps1 -Modo $Modo nao achou $PromptFile"
    exit 1
}
if (-not (Test-Path -LiteralPath $WS)) {
    Write-OpsLog "ERRO: workspace nao existe: $WS" $ORIGEM
    exit 1
}

# --- Lock ------------------------------------------------------------
$lock = Join-Path $LOG_DIR 'claude.lock'
$waitMax = 0
if ($Modo -eq 'incidente') { $waitMax = $CLAUDE_LOCK_WAIT_MIN }
if ($Modo -eq 'lab') { $waitMax = 30 }
$tWait = [DateTime]::UtcNow
$avisado = $false
while (Test-Path -LiteralPath $lock) {
    $info = @(Get-Content -LiteralPath $lock -ErrorAction SilentlyContinue)
    $oldPid = 0
    if ($info.Count -gt 0) { [int]::TryParse($info[0], [ref]$oldPid) | Out-Null }
    $alive = $false
    if ($oldPid -gt 0) { $alive = ($null -ne (Get-Process -Id $oldPid -ErrorAction SilentlyContinue)) }
    if (-not $alive) {
        Write-OpsLog "lock orfao removido ($($info -join ' '))" $ORIGEM
        Remove-Item -LiteralPath $lock -Force -ErrorAction SilentlyContinue
        break
    }
    # incidente nao espera uma acordada do modo lab (so le relatorio): encerra a arvore dela e segue
    if ($Modo -eq 'incidente' -and $info.Count -ge 2 -and "$($info[1])" -eq 'lab') {
        Write-OpsLog "incidente: encerrando a acordada do modo lab (PID $oldPid) que segurava o lock" $ORIGEM
        try { & taskkill.exe /PID $oldPid /T /F 2>&1 | Out-Null } catch { }
        Remove-Item -LiteralPath $lock -Force -ErrorAction SilentlyContinue
        break
    }
    if (([DateTime]::UtcNow - $tWait).TotalMinutes -ge $waitMax) {
        Write-OpsLog "ocupado: outra execucao em andamento (PID $oldPid, $($info -join ' '))" $ORIGEM
        Write-Host "Ocupado: execucao anterior ainda roda (PID $oldPid)."
        exit 3
    }
    if (-not $avisado) {
        Write-OpsLog "ocupado (PID $oldPid, $($info -join ' ')): incidente aguardando ate ${waitMax}min pelo lock" $ORIGEM
        $avisado = $true
    }
    Start-Sleep -Seconds 30
}

# --- Prompt ----------------------------------------------------------
$ts = [DateTime]::UtcNow.ToString('yyyyMMdd_HHmm')
$logFile = Join-Path $LOG_DIR "claude_${Modo}_$ts.log"
$errFile = Join-Path $LOG_DIR "claude_${Modo}_$ts.err.log"
$pFile   = Join-Path $LOG_DIR "claude_${Modo}_$ts.prompt.md"
$tpl = Read-TextAuto $PromptFile
if (-not $tpl) { Write-OpsLog "ERRO: prompt vazio: $PromptFile" $ORIGEM; exit 1 }
$motivoSafe = $Motivo
if (-not $motivoSafe) { $motivoSafe = '(nao informado)' }
$prompt = $tpl.Replace('{MOTIVO}', $motivoSafe).Replace('{MODO}', $Modo).Replace('{DATA_UTC}', (Get-UtcStamp))
[IO.File]::WriteAllText($pFile, $prompt, (New-Object System.Text.UTF8Encoding($false)))

# --- Argumentos ------------------------------------------------------
$cargs = @('-p', '--permission-mode', $CLAUDE_PERMISSION_MODE, '--output-format', 'text')
if ($CLAUDE_MODEL) { $cargs += @('--model', $CLAUDE_MODEL) }
foreach ($d in $CLAUDE_ADD_DIRS) {
    if ($d -and (Test-Path -LiteralPath $d)) { $cargs += @('--add-dir', ('"{0}"' -f $d)) }
}
if ($CLAUDE_EXTRA_ARGS -and $CLAUDE_EXTRA_ARGS.Count -gt 0) { $cargs += $CLAUDE_EXTRA_ARGS }
$cmdLine = ('{0} {1}' -f $CLAUDE_CMD, ($cargs -join ' '))

if ($DryRun) {
    Write-Host "DRY-RUN"
    Write-Host "  cwd    : $WS"
    Write-Host "  cmd    : $cmdLine"
    Write-Host "  stdin  : $pFile"
    Write-Host "  stdout : $logFile"
    Write-Host "  timeout: $TimeoutMin min"
    Write-OpsLog "dry-run: $cmdLine" $ORIGEM
    exit 0
}

# Se este script for chamado de dentro de uma sessao do Claude Code, o CLI recusa
# a execucao aninhada; limpa as variaveis de ambiente que sinalizam isso.
foreach ($ev in @('CLAUDECODE', 'CLAUDE_CODE_ENTRYPOINT', 'CLAUDE_CODE_SSE_PORT')) {
    if (Test-Path "Env:$ev") { Remove-Item "Env:$ev" -ErrorAction SilentlyContinue }
}
# Marca o processo do agente (herdado pelos comandos dele): o cmd.ps1 recusa -Force com isso.
$env:SURV_AGENTE = '1'

Write-OpsLog ("inicio | motivo='{0}' | timeout={1}min | log={2}" -f $motivoSafe, $TimeoutMin, (Split-Path -Leaf $logFile)) $ORIGEM
$t0 = [DateTime]::UtcNow
try {
    $p = Start-Process -FilePath $CLAUDE_CMD -ArgumentList $cargs -WorkingDirectory $WS `
        -RedirectStandardInput $pFile -RedirectStandardOutput $logFile -RedirectStandardError $errFile `
        -NoNewWindow -PassThru
} catch {
    Write-OpsLog "ERRO ao iniciar claude: $($_.Exception.Message)" $ORIGEM
    exit 1
}
# Quirk do PowerShell: sem ler .Handle antes do fim do processo, .ExitCode vem nulo
$null = $p.Handle
[IO.File]::WriteAllLines($lock, @("$($p.Id)", "$Modo", (Get-UtcStamp)), (New-Object System.Text.UTF8Encoding($false)))

$finished = $p.WaitForExit($TimeoutMin * 60 * 1000)
$code = 0
if (-not $finished) {
    Write-OpsLog "TIMEOUT apos $TimeoutMin min; matando arvore do PID $($p.Id)" $ORIGEM
    try { & taskkill.exe /PID $p.Id /T /F 2>&1 | Out-Null } catch { }
    Start-Sleep -Seconds 3
    try { if (-not $p.HasExited) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue } } catch { }
    $code = 2
} else {
    try { $code = $p.ExitCode } catch { $code = -1 }
    if ($null -eq $code) { $code = -1 }
}
Remove-Item -LiteralPath $lock -Force -ErrorAction SilentlyContinue
$dur = [int]([DateTime]::UtcNow - $t0).TotalMinutes

# --- Pos-processamento do log ----------------------------------------
try {
    if (Test-Path -LiteralPath $errFile) {
        $errTxt = Read-TextAuto $errFile
        if ($errTxt -and $errTxt.Trim()) {
            Add-Utf8Line $logFile ''
            Add-Utf8Line $logFile '===== STDERR ====='
            Add-Utf8Line $logFile $errTxt
        }
        Remove-Item -LiteralPath $errFile -Force -ErrorAction SilentlyContinue
    }
} catch { }
if ($finished) {
    Add-Utf8Line $logFile ("===== FIM exit={0} duracao={1}min =====" -f $code, $dur)
} else {
    Add-Utf8Line $logFile ("===== TIMEOUT {0}min (processo morto) =====" -f $TimeoutMin)
}

$logTxt = ''
try { $logTxt = Read-TextAuto $logFile } catch { $logTxt = '' }
$authProblem = $false
# Mensagem real observada em 2.1.260: "Failed to authenticate. API Error: 401 OAuth access token has expired. Re-authenticate to continue."
if ($logTxt -match '(?i)not logged in|please (run|use) /login|failed to authenticate|re-authenticate|authentication|not authenticated|invalid api key|oauth[^\r\n]{0,40}token[^\r\n]{0,40}(expired|revoked|invalid)|api error: 401|login required') {
    $authProblem = $true
}
$limitProblem = ($logTxt -match '(?i)usage limit|rate limit|out of (extra )?usage|limit reached')

Write-OpsLog ("fim | exit={0} | duracao={1}min | auth_problem={2} | limit={3}" -f $code, $dur, $authProblem, $limitProblem) $ORIGEM

if ($authProblem) {
    # CLAUDE.md secao 6 pede a linha 'ERRO auth' em heartbeat.log; o Claude nao consegue
    # escreve-la quando nem chega a rodar, entao o script grava por ele.
    Add-Utf8Line (Join-Path $LOG_DIR 'heartbeat.log') ("{0} | ERRO auth | run_claude[{1}] | {2}" -f (Get-UtcStamp), $Modo, (Split-Path -Leaf $logFile))
    Add-Alerta 'CRITICO' 'Claude sem login' ("run_claude -Modo $Modo falhou por autenticacao. Faca RDP no VPS, abra um console e rode: claude auth login  (login por assinatura no navegador do VPS; alternativa duravel: claude setup-token + variavel CLAUDE_CODE_OAUTH_TOKEN). Log: " + (Split-Path -Leaf $logFile))
    if ($code -eq 0) { $code = 4 }
}
if ($limitProblem) {
    Add-Alerta 'ATENCAO' 'Claude com limite de uso' ("run_claude -Modo $Modo bateu em limite de uso/rate limit. Log: " + (Split-Path -Leaf $logFile))
}
if (-not $finished) {
    Add-Alerta 'ATENCAO' 'Claude timeout' ("run_claude -Modo $Modo estourou $TimeoutMin min e foi morto. Log: " + (Split-Path -Leaf $logFile))
}
if ($finished -and $code -ne 0 -and -not $authProblem -and -not $limitProblem) {
    # flag desconhecida numa versao nova, MCP/config quebrado etc.: a acordada nao aconteceu
    Add-Alerta 'ATENCAO' 'Claude terminou com erro' ("run_claude -Modo $Modo saiu com exit=$code (acordada provavelmente sem diario). Log: " + (Split-Path -Leaf $logFile))
}
exit $code
