# =====================================================================
#  checar.ps1 - os calculos das regras do agente, com veredito de passa ou falha
#  Uso:  checar.ps1 -Acao diario|semanal|preabertura|incidente|saude|numeros|desempenho|degrau|regime|autoteste
#                   [-Slippage <csv>] [-AgoraUtc "yyyy-MM-dd HH:mm"] [-SemJson]
#
#  SOMENTE LEITURA. Le status.json, STATE.md, ALERTAS.md, o snapshot do perfil (.chr),
#  ops\logs\heartbeat.log, guardian.log, regime.csv, trades_mfe.csv, os diarios do Expert,
#  o disco, o relogio e o registro. A unica escrita e o relatorio JSON
#  ops\logs\checar_<acao>_<ts>.json (nem isso com -SemJson). Nao chama o MCP, nao manda
#  comando ao guardiao, nao mexe no terminal nem no laboratorio.
#
#  Saida: uma linha por checagem
#     <VEREDITO> <id> | <valor> | <limite> | <texto>  [modulo de regras]
#  VEREDITO:
#     PASSA     a checagem passou
#     FALHA     a checagem falhou: o modulo citado diz o que fazer
#     ATENCAO   fora do normal, sem falhar (pre-alerta, divergencia a registrar)
#     INFO      so registro (numeros para o DIARIO/STATE)
#     SEM_DADO  faltou dado para decidir: conta como NAO passou
#     AGENTE    depende do MCP ou de julgamento: o agente faz pelo modulo citado
#  Fim:  "RESULTADO <acao>: OK" (so PASSA, INFO e AGENTE) ou "RESULTADO <acao>: VER (...)".
#  Exit: 0 = OK; 2 = ha FALHA, ATENCAO ou SEM_DADO; 1 = erro do proprio script.
#
#  O script so calcula. Quem decide a acao e o protocolo do modo (prompts\<modo>.md) com os
#  modulos de C:\Sobrevivencia\regras\. Os numeros de referencia abaixo espelham esses modulos
#  e so mudam com OK do Henrique (o agente nao edita este arquivo).
#  -Slippage: CSV (separador ;) com cabecalho ticket;estrategia;nivel_sl;preco_saida;dir, uma
#  linha por saida por SL da E3 (nivel do comentario [sl X] da ordem de saida, pelo MCP). As
#  saidas por SL da E1 usam o sl_inicial do trades_mfe.csv (o SL da E1 nao se move).
#  -AgoraUtc: so para teste (fixa o "agora" das contas de data).
#  Sem acentos (PowerShell 5.1 le .ps1 sem BOM como ANSI). Sem && e sem ternario.
# =====================================================================
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('diario', 'semanal', 'preabertura', 'incidente', 'saude', 'numeros', 'desempenho', 'degrau', 'regime', 'autoteste')]
    [string]$Acao,
    [string]$Slippage = '',
    [string]$AgoraUtc = '',
    [switch]$SemJson
)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\config.ps1"
. "$PSScriptRoot\common.ps1"
$CI = [Globalization.CultureInfo]::InvariantCulture

# --- Referencias (espelham regras\*.md; mudam so com OK do Henrique) ---------------------------
# Degrau A: C22 corrigido (noticias na hora do servidor), DD relativo 15,32%; pausa fixa 30,8%.
# Degrau B: C23, DD 27,69%; pausa fixa 41,5%.
$REF_A = @{ Nome = 'C22 corrigido'; Dd = 15.32; Pausa = 30.8; E1 = 0.4; E3 = 1.2; Stop = 8.0; Halt = 35.0 }
$REF_B = @{ Nome = 'C23'; Dd = 27.69; Pausa = 41.5; E1 = 0.4; E3 = 1.8; Stop = 12.0; Halt = 45.0 }
$LIM_G35 = @(10.0, 20.0, 10.0, 35.0)     # limit_daily_loss_pct, limit_dd_reduce_pct, limit_dd_hysteresis_pct, limit_dd_halt_pct
$LIM_G45 = @(15.0, 25.0, 12.0, 45.0)
$MAGICS_OK = @(202512, 202533, 202534)
$MAGIC_E2 = 202605122
$MAGIC_E4 = 550555
$SUB_TRADES = 40; $SUB_DIAS = 21; $SUB_SEMANAS_DESCIDA = 56; $SUB_PF = 1.10; $SUB_DD = 15.3; $SUB_DD_AGORA = 10.0
$SUB_NE1 = 10; $SUB_NE3 = 5; $SLIP_E1 = 0.124; $SLIP_E3 = 0.568; $SLIP_FATOR = 1.5
$DESCIDA_DD = 25.0; $DESCIDA_G35_DD = 30.0
$script:DESCIDA_FEITA = $false; $script:REGARQ_FEITO = $false
$PAUSA_PF = 0.8; $PAUSA_PF_TRADES = 40; $PRE_PF = 1.0; $PRE_PF_MIN = 20
$RITMO_24H = 8; $RITMO_7D = 30
$REG_FRACO = 1.40; $REG_MUITO_FRACO = 1.20; $REG_DIAS_FECHAR = 5; $REG_ATRASO_UTEIS = 2
$DISCO_INCIDENTE_GB = 5; $DISCO_SEMANAL_GB = 10
$ESCALA_05_SEMANAS = 4
$RELOGIO_MAX_S = 5

# --- Agora -------------------------------------------------------------------------------------
$AGORA = [DateTime]::UtcNow
if ($AgoraUtc) {
    $tmpA = [DateTime]::MinValue
    if (-not [DateTime]::TryParseExact($AgoraUtc, [string[]]@('yyyy-MM-dd HH:mm', 'yyyy-MM-dd HH:mm:ss', "yyyy-MM-dd'T'HH:mm"), $CI, [Globalization.DateTimeStyles]::None, [ref]$tmpA)) {
        Write-Host 'ERRO: -AgoraUtc invalido (use "yyyy-MM-dd HH:mm").'
        exit 1
    }
    $AGORA = [DateTime]::SpecifyKind($tmpA, [DateTimeKind]::Utc)
}

# --- Resultado ---------------------------------------------------------------------------------
$RES = New-Object Collections.Generic.List[object]
function Add-R([string]$Id, [string]$Ver, $Valor, $Limite, [string]$Texto, [string]$Regra) {
    $o = New-Object PSObject -Property ([ordered]@{ id = $Id; veredito = $Ver; valor = "$Valor"; limite = "$Limite"; texto = $Texto; regra = $Regra })
    $RES.Add($o)
    $ln = '{0,-8} {1,-24} | {2} | {3} | {4}' -f $Ver, $Id, $Valor, $Limite, $Texto
    if ($Regra) { $ln += "  [$Regra]" }
    Write-Host $ln
}
function Write-Secao([string]$T) { Write-Host ''; Write-Host "=== $T" }
function F2([double]$v) { return $v.ToString('0.00', $CI) }
function F1([double]$v) { return $v.ToString('0.0', $CI) }
function Fmt-Pf([double]$v) {
    if ([double]::IsPositiveInfinity($v)) { return 'sem perda' }
    return $v.ToString('0.00', $CI)
}
function To-Num([string]$s, [double]$def) {
    $v = 0.0
    if ($null -eq $s) { return $def }
    $t = $s.Trim().Replace(',', '.')
    if ($t -eq '') { return $def }
    if ([double]::TryParse($t, [Globalization.NumberStyles]::Float, $CI, [ref]$v)) {
        if ([double]::IsNaN($v) -or [double]::IsInfinity($v)) { return $def }
        return $v
    }
    return $def
}

# --- Horario do servidor (GMT+3 no verao europeu, GMT+2 no inverno) -----------------------------
function Get-UltimoDomingo([int]$Ano, [int]$Mes) {
    $d = New-Object DateTime($Ano, $Mes, [DateTime]::DaysInMonth($Ano, $Mes), 0, 0, 0, [DateTimeKind]::Utc)
    while ($d.DayOfWeek -ne [DayOfWeek]::Sunday) { $d = $d.AddDays(-1) }
    return $d
}
function Test-VeraoEu([DateTime]$Utc) {
    $ini = (Get-UltimoDomingo $Utc.Year 3).AddHours(1)
    $fim = (Get-UltimoDomingo $Utc.Year 10).AddHours(1)
    return ($Utc -ge $ini -and $Utc -lt $fim)
}
function ConvertFrom-Servidor([DateTime]$Srv) {
    $u = [DateTime]::SpecifyKind($Srv.AddHours(-3), [DateTimeKind]::Utc)
    if (-not (Test-VeraoEu $u)) { $u = [DateTime]::SpecifyKind($Srv.AddHours(-2), [DateTimeKind]::Utc) }
    return $u
}
function ConvertTo-Servidor([DateTime]$Utc) {
    if (Test-VeraoEu $Utc) { return $Utc.AddHours(3) }
    return $Utc.AddHours(2)
}
function Parse-Srv([string]$s) {
    $d = [DateTime]::MinValue
    if ([DateTime]::TryParseExact($s.Trim(), [string[]]@('yyyy.MM.dd HH:mm:ss', 'yyyy.MM.dd HH:mm', 'yyyy.MM.dd'), $CI, [Globalization.DateTimeStyles]::None, [ref]$d)) { return $d }
    return $null
}

# --- Leitores ----------------------------------------------------------------------------------
function Read-KeyValues([string]$Txt) {
    $d = @{}
    foreach ($l in ($Txt -split "`r?`n")) {
        $t = $l.Trim()
        if (-not $t -or $t.StartsWith(';') -or $t.StartsWith('#') -or $t.StartsWith('<')) { continue }
        $i = $t.IndexOf('=')
        if ($i -le 0) { continue }
        $k = $t.Substring(0, $i).Trim(); $v = $t.Substring($i + 1).Trim()
        $j = $v.IndexOf('||'); if ($j -ge 0) { $v = $v.Substring(0, $j) }
        if ($k -match '^[A-Za-z_][A-Za-z0-9_]*$' -and -not $d.ContainsKey($k)) { $d[$k] = $v }
    }
    return $d
}

function Read-Estado {
    # Linhas de STATE.md que o script usa. O agente mantem o rotulo e o formato "rotulo: **valor**".
    $e = @{ Existe = $false; Degrau = $null; G45Descida = $false; OkDegrau = $null; UltimaDescida = $null; Inicio = $null
            EquityInicial = 0.0; RiskTxt = ''; RiskEscala = $null; RiskManual = $null; RiskRegime = $false; RiskHisterese = $false
            RegimeInstalado = $null; OkAlternativa = $null; Faltam = @() }
    $t = Read-TextAuto (Join-Path $WS 'STATE.md')
    if (-not $t) { $e.Faltam += 'STATE.md'; return $e }
    $e.Existe = $true
    $m = [regex]::Match($t, '(?im)^[ \t]*Degrau do preset[ \t]*:[ \t]*\**[ \t]*([AB])\b[ \t]*\**[ \t]*(\([ \t]*guardi.o[ \t]+G45)?')
    if ($m.Success) {
        $e.Degrau = $m.Groups[1].Value.ToUpper()
        if ($m.Groups[2].Success -and $e.Degrau -eq 'A') { $e.G45Descida = $true }
    } else { $e.Faltam += 'Degrau do preset' }
    $m = [regex]::Match($t, '(?im)^[ \t]*risk_scale esperado do guardi.o[ \t]*:[ \t]*(.*)$')
    if ($m.Success) {
        $resto = $m.Groups[1].Value
        $mb = [regex]::Match($resto, '^\*\*([^*]+)\*\*')
        $seg = $resto
        if ($mb.Success) { $seg = $mb.Groups[1].Value }
        $e.RiskTxt = $seg.Trim()
        $mv = [regex]::Match($seg, '([0-9]+(?:[.,][0-9]+)?)[ \t]*(AUTO|FIXO)?', 'IgnoreCase')
        if ($mv.Success) {
            $e.RiskEscala = To-Num $mv.Groups[1].Value -1
            if ($mv.Groups[2].Success) { $e.RiskManual = ($mv.Groups[2].Value.ToUpper() -eq 'FIXO') }
        }
        if ($seg -match '(?i)\(regime\)') { $e.RiskRegime = $true }
        if ($seg -match '(?i)histerese') { $e.RiskHisterese = $true }
        if ($null -eq $e.RiskEscala -or $e.RiskEscala -lt 0 -or $null -eq $e.RiskManual) { $e.Faltam += 'risk_scale esperado do guardiao' }
    } else { $e.Faltam += 'risk_scale esperado do guardiao' }
    $m = [regex]::Match($t, '(?im)^[ \t]*OK DEGRAU pendente de confer.ncia[ \t]*:[ \t]*\**[ \t]*([^*\r\n(]+)')
    if ($m.Success) {
        $v = $m.Groups[1].Value.Trim()
        if ($v -match '(?i)^nenhum') { $e.OkDegrau = '' }
        elseif ($v -match '(?i)DEGRAU\s+([AB])\b') { $e.OkDegrau = $Matches[1].ToUpper() }
        elseif ($v -match '\b([AB])\b') { $e.OkDegrau = $Matches[1].ToUpper() }
        else { $e.OkDegrau = '?' }
    } else { $e.Faltam += 'OK DEGRAU pendente de conferencia' }
    $m = [regex]::Match($t, '(?im)^[ \t]*.ltima descida conferida[ \t]*:[ \t]*\**[ \t]*([^*\r\n(]+)')
    if ($m.Success) {
        $v = $m.Groups[1].Value.Trim()
        if ($v -match '(\d{4}-\d{2}-\d{2})') { $e.UltimaDescida = [DateTime]::SpecifyKind([DateTime]::ParseExact($Matches[1], 'yyyy-MM-dd', $CI), [DateTimeKind]::Utc) }
    } else { $e.Faltam += 'Ultima descida conferida' }
    $m = [regex]::Match($t, '(?im)In.cio ao vivo do Concorde[ \t]*[|:][ \t]*\**[ \t]*(\d{4}-\d{2}-\d{2})(?:[ T](\d{2}:\d{2}))?')
    if ($m.Success) {
        $s = $m.Groups[1].Value
        if ($m.Groups[2].Success) { $s += ' ' + $m.Groups[2].Value } else { $s += ' 00:00' }
        $e.Inicio = [DateTime]::SpecifyKind([DateTime]::ParseExact($s, 'yyyy-MM-dd HH:mm', $CI), [DateTimeKind]::Utc)
    } else { $e.Faltam += 'Inicio ao vivo do Concorde' }
    $e.EquityInicial = Get-InitialEquity
    $m = [regex]::Match($t, '(?im)RegimeLogger instalado[ \t]*[|:][ \t]*\**[ \t]*([^|\r\n]*)')
    if ($m.Success) {
        $v = $m.Groups[1].Value.Trim()
        if ($v -match '(?i)^\**[ \t]*n.o\b') { $e.RegimeInstalado = $false }
        elseif ($v -match '\d{4}-\d{2}-\d{2}' -or $v -match '(?i)^\**[ \t]*sim') { $e.RegimeInstalado = $true }
    }
    $m = [regex]::Match($t, '(?im)OK ALTERNATIVA pendente de confer.ncia[ \t]*:[ \t]*\**[ \t]*([^*\r\n(]+)')
    if ($m.Success) {
        $v = $m.Groups[1].Value.Trim()
        if ($v -match '(?i)^nenhum') { $e.OkAlternativa = '' } else { $e.OkAlternativa = $v }
    }
    return $e
}

function Read-Snapshot {
    $r = @{ Existe = $false; Arquivos = 0; Concorde = @(); Guardiao = @(); Regime = @(); Outros = @() }
    $dir = Join-Path $WS "ops\profile\$PROFILE_NAME"
    if (-not (Test-Path -LiteralPath $dir)) { return $r }
    foreach ($f in @(Get-ChildItem -LiteralPath $dir -Filter '*.chr' -File)) {
        $r.Arquivos++
        $t = Read-TextAuto $f.FullName
        if (-not $t) { continue }
        $sym = ''
        $msy = [regex]::Match($t, '(?m)^\s*symbol\s*=\s*(\S+)')
        if ($msy.Success) { $sym = $msy.Groups[1].Value }
        foreach ($mx in [regex]::Matches($t, '(?s)<expert>(.*?)</expert>')) {
            $blk = $mx.Groups[1].Value
            $nm = ''
            $mn = [regex]::Match($blk, '(?m)^\s*name\s*=\s*(.+?)\s*$')
            if ($mn.Success) { $nm = $mn.Groups[1].Value }
            $inp = @{}
            $mi = [regex]::Match($blk, '(?s)<inputs>(.*?)</inputs>')
            if ($mi.Success) { $inp = Read-KeyValues $mi.Groups[1].Value }
            $o = @{ Arquivo = $f.Name; Simbolo = $sym; Nome = $nm; Inputs = $inp }
            if ($nm -match '^Concorde_RF') { $r.Concorde += , $o }
            elseif ($nm -match '^SurvivalGuardian') { $r.Guardiao += , $o }
            elseif ($nm -match '^RegimeLogger') { $r.Regime += , $o }
            else { $r.Outros += , $o }
        }
    }
    $r.Existe = ($r.Arquivos -gt 0)
    return $r
}

function Read-Trades {
    # trades_mfe.csv do RegimeLogger: uma linha por posicao fechada da E1/E3 (magics 202512/202533/202534)
    $o = @{ Existe = $false; Lista = @(); IdadeMin = -1; Linhas = 0; Invalidas = 0; Motivo = 'arquivo ausente'; Arquivo = (Join-Path $SURV_DIR 'trades_mfe.csv') }
    if (-not (Test-Path -LiteralPath $o.Arquivo)) { return $o }
    $o.Existe = $true; $o.Motivo = ''
    $o.IdadeMin = [int]([DateTime]::UtcNow - (Get-Item -LiteralPath $o.Arquivo).LastWriteTimeUtc).TotalMinutes
    $t = Read-TextAuto $o.Arquivo
    if (-not $t) { return $o }
    $lst = New-Object Collections.Generic.List[object]
    $ls = $t -split "`r?`n"
    # cabecalho do RegimeLogger v1.20 (RL_TR_CABECALHO): outro cabecalho = outra versao do arquivo, nao da para ler
    $cabTr = 'fechamento_servidor;ticket_posicao;magic;estrategia;perna;dir;volume;abertura_servidor;preco_entrada;sl_inicial;tp_inicial;preco_saida;lucro;risco_usd;resultado_r;mfe_r;mae_r;motivo_saida;gerado_em'
    if ($ls[0].Trim().TrimStart([char]0xFEFF) -ne $cabTr) { $o.Existe = $false; $o.Motivo = 'cabecalho diferente do RegimeLogger v1.20'; return $o }
    for ($i = 1; $i -lt $ls.Count; $i++) {
        $l = $ls[$i].Trim()
        if (-not $l) { continue }
        $c = $l.Split(';')
        if ($c.Count -ne 19) { $o.Invalidas++; continue }
        $fe = Parse-Srv $c[0]; $ab = Parse-Srv $c[7]
        if ($null -eq $fe) { $o.Invalidas++; continue }
        $mg = [long](To-Num $c[2] 0)
        $x = New-Object PSObject -Property @{
            FechSrv = $fe; FechUtc = (ConvertFrom-Servidor $fe); AbSrv = $ab; AbUtc = $null
            Ticket = $c[1]; Magic = $mg; Estrategia = $c[3].Trim().ToUpper(); Perna = $c[4]; Dir = [int](To-Num $c[5] 0)
            Volume = (To-Num $c[6] 0); Entrada = (To-Num $c[8] 0); SlIni = (To-Num $c[9] 0); Saida = (To-Num $c[11] 0)
            Lucro = (To-Num $c[12] 0); RiscoUsd = (To-Num $c[13] -1); Motivo = $c[17].Trim().ToUpper()
        }
        if ($ab) { $x.AbUtc = ConvertFrom-Servidor $ab }
        $lst.Add($x)
    }
    $o.Linhas = $lst.Count
    $o.Lista = @($lst | Sort-Object FechUtc)
    if ($o.Linhas -eq 0 -and $o.Invalidas -gt 0) { $o.Existe = $false; $o.Motivo = ("nenhuma linha valida ({0} invalidas)" -f $o.Invalidas) }
    return $o
}

function Read-Heartbeat {
    # linhas do vigia: "yyyy-MM-dd HH:mm:ssZ | eq=.. | dd=.. | state=.. | conn=.. | ..."
    $lst = New-Object Collections.Generic.List[object]
    $t = Read-TextAuto (Join-Path $LOG_DIR 'heartbeat.log')
    if (-not $t) { return @() }
    foreach ($l in ($t -split "`r?`n")) {
        $m = [regex]::Match($l, '^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}(?::\d{2})?)Z? \| eq=([^ |]*) \| dd=([^ |]*) \| state=([^ |]*) \| conn=([^ |]*)')
        if (-not $m.Success) { continue }
        $ts = [DateTime]::MinValue
        if (-not [DateTime]::TryParseExact($m.Groups[1].Value, [string[]]@('yyyy-MM-dd HH:mm:ss', 'yyyy-MM-dd HH:mm'), $CI, [Globalization.DateTimeStyles]::None, [ref]$ts)) { continue }
        $lst.Add((New-Object PSObject -Property @{ Utc = [DateTime]::SpecifyKind($ts, [DateTimeKind]::Utc); Eq = (To-Num $m.Groups[2].Value -1); Dd = (To-Num $m.Groups[3].Value -1); State = $m.Groups[4].Value; Conn = $m.Groups[5].Value }))
    }
    return $lst.ToArray()
}

function Read-Guardiao {
    # guardian.log: "yyyy.MM.dd HH:mm:ss | mensagem" (hora do servidor)
    $lst = New-Object Collections.Generic.List[object]
    $t = Read-TextAuto $GUARDIAN_LOG
    if (-not $t) { return @() }
    foreach ($l in ($t -split "`r?`n")) {
        $m = [regex]::Match($l, '^(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2}) \| (.*)$')
        if (-not $m.Success) { continue }
        $s = Parse-Srv $m.Groups[1].Value
        if ($null -eq $s) { continue }
        $lst.Add((New-Object PSObject -Property @{ Srv = $s; Utc = (ConvertFrom-Servidor $s); Msg = $m.Groups[2].Value }))
    }
    return $lst.ToArray()
}

function Read-Regime {
    $o = @{ Existe = $false; Linhas = @(); Arquivo = (Join-Path $SURV_DIR 'regime.csv') }
    $t = Read-TextAuto $o.Arquivo
    if ($null -eq $t) { return $o }
    $o.Existe = $true
    $lst = New-Object Collections.Generic.List[object]
    foreach ($l in ($t -split "`r?`n")) {
        $c = $l.Split(';')
        if ($c.Count -lt 9) { continue }
        $d = Parse-Srv $c[0]
        if ($null -eq $d) { continue }
        $lst.Add((New-Object PSObject -Property @{ Data = $d.Date; Amp = (To-Num $c[6] -1); Atr = (To-Num $c[7] -1); Vol20 = (To-Num $c[8] -1) }))
    }
    $o.Linhas = @($lst | Sort-Object Data)
    return $o
}

function Read-Alertas {
    # ALERTAS.md: "## AAAA-MM-DD HH:MM UTC - NIVEL - titulo" (travessao); estado = ultima linha "- Estado: ..."
    $lst = New-Object Collections.Generic.List[object]
    $t = Read-TextAuto (Join-Path $WS 'ALERTAS.md')
    if (-not $t) { return @() }
    $t = [regex]::Replace($t, '(?s)```.*?```', '')
    $atual = $null
    foreach ($l in ($t -split "`r?`n")) {
        $m = [regex]::Match($l, '^##\s+(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2})\s*UTC\s*[\u2014\u2013-]+\s*(.+?)\s*[\u2014\u2013-]+\s*(.+?)\s*$')
        if ($m.Success) {
            $atual = New-Object PSObject -Property @{ Quando = $m.Groups[1].Value; Nivel = $m.Groups[2].Value.Trim().ToUpper(); Titulo = $m.Groups[3].Value.Trim(); Estado = ''; Aberto = $true }
            $lst.Add($atual)
            continue
        }
        if ($l -match '^##\s') { $atual = $null; continue }
        if ($atual) {
            $me = [regex]::Match($l, '^\s*[-*]\s*Estado\s*:\s*(.+)$')
            if ($me.Success) { $atual.Estado = $me.Groups[1].Value.Trim(); $atual.Aberto = -not ($atual.Estado -match '(?i)^\**\s*FECHADO') }
        }
    }
    return $lst.ToArray()
}

function Get-DiasUteis([DateTime]$De, [DateTime]$Ate) {
    # dias de segunda a sexta em (De, Ate], contando datas
    $n = 0
    $d = $De.Date.AddDays(1)
    while ($d -le $Ate.Date) {
        if ($d.DayOfWeek -ne [DayOfWeek]::Saturday -and $d.DayOfWeek -ne [DayOfWeek]::Sunday) { $n++ }
        $d = $d.AddDays(1)
    }
    return $n
}

function Get-Stats($Lista) {
    $n = 0; $gp = 0.0; $gl = 0.0; $win = 0; $maior = 0.0; $cum = 0.0; $pk = 0.0; $queda = 0.0; $tot = 0.0
    foreach ($x in @($Lista | Sort-Object FechUtc)) {
        $n++
        $p = [double]$x.Lucro
        $tot += $p
        if ($p -gt 0) { $gp += $p; $win++ } else { $gl += -$p }
        if ($p -lt $maior) { $maior = $p }
        $cum += $p
        if ($cum -gt $pk) { $pk = $cum }
        if (($pk - $cum) -gt $queda) { $queda = $pk - $cum }
    }
    $pf = 0.0
    if ($gl -gt 0) { $pf = $gp / $gl } elseif ($gp -gt 0) { $pf = [double]::PositiveInfinity }
    $acerto = 0.0; $medio = 0.0
    if ($n -gt 0) { $acerto = 100.0 * $win / $n; $medio = $tot / $n }
    return New-Object PSObject -Property @{ N = $n; Lucro = $tot; Pf = $pf; Acerto = $acerto; MaiorPerda = $maior; Queda = $queda; Medio = $medio }
}

function Get-DdMax([DateTime]$Desde, $Hb, $Gl, $St) {
    # maior DD (definicao unica: equity contra o pico = dd_pct) desde $Desde: dd= do heartbeat, DD das linhas do
    # guardian.log (menos as linhas de erro, como um SET_HWM recusado que "implicaria" DD) e o dd_pct atual.
    # Devolve @(valor, amostras do heartbeat na janela, maior buraco sem amostra do heartbeat, em horas)
    $mx = -1.0; $n = 0; $ult = $Desde; $buraco = 0.0
    foreach ($h in $Hb) {
        if ($h.Utc -lt $Desde -or $h.Dd -lt 0) { continue }
        $n++
        $gap = ($h.Utc - $ult).TotalHours
        if ($gap -gt $buraco) { $buraco = $gap }
        $ult = $h.Utc
        if ($h.Dd -gt $mx) { $mx = $h.Dd }
    }
    $gap = ($AGORA - $ult).TotalHours
    if ($gap -gt $buraco) { $buraco = $gap }
    foreach ($g in $Gl) {
        if ($g.Utc -lt $Desde) { continue }
        if ($g.Msg -match '(?i)implicaria|ERRO') { continue }
        foreach ($mm in [regex]::Matches($g.Msg, '(?i)\bDD[ =:]*([0-9]+(?:[.,][0-9]+)?)\s*%')) { $v = To-Num $mm.Groups[1].Value -1; if ($v -ge 0 -and $v -gt $mx) { $mx = $v } }
    }
    if ($St -and $St.DdPct -gt $mx) { $mx = $St.DdPct }
    return @($mx, $n, $buraco)
}

function Get-RefDegrau($Hb) {
    # Referencia de DD de 5.2: a do degrau em vigor; depois de uma descida de B para A, o C23 ate a conta fazer HWM novo
    # (uma amostra dd=0 no heartbeat, ou o dd_pct atual 0, depois da data da descida conferida).
    if ($EST.Degrau -eq 'B') { return @($REF_B, '') }
    if ($EST.UltimaDescida) {
        $novo = $false
        foreach ($h in $Hb) { if ($h.Utc -ge $EST.UltimaDescida -and $h.Dd -ge 0 -and $h.Dd -lt 0.05) { $novo = $true; break } }
        if ($ST -and $ST.DdPct -lt 0.05) { $novo = $true }
        if (-not $novo) { return @($REF_B, ("sem HWM novo desde a descida de {0:yyyy-MM-dd}: vale o C23" -f $EST.UltimaDescida)) }
    }
    return @($REF_A, '')
}

# --- Carga -------------------------------------------------------------------------------------
$EST = Read-Estado
$ST = Read-SurvStatus
$RAW = $null
if ($ST) { $RAW = $ST.Raw }
function Get-Raw([string]$Nome, $Def) {
    if (-not $RAW) { return $Def }
    $p = $RAW.PSObject.Properties[$Nome]
    if ($p) { return $p.Value }
    return $Def
}
$REF = $REF_A
if ($EST.Degrau -eq 'B') { $REF = $REF_B }
$DEGRAU_TXT = "$($EST.Degrau)"
if ($EST.G45Descida) { $DEGRAU_TXT = 'A (guardiao G45 da descida)' }

Write-Host ("=== checar.ps1 -Acao {0} | agora {1:yyyy-MM-dd HH:mm} UTC | workspace {2}" -f $Acao, $AGORA, $WS)
Write-Host ("estado lido do STATE.md: degrau {0} | escala esperada '{1}' | inicio do Concorde {2} | ultima descida {3} | OK DEGRAU pendente '{4}' | equity inicial {5}" -f `
    $DEGRAU_TXT, $EST.RiskTxt, $(if ($EST.Inicio) { $EST.Inicio.ToString('yyyy-MM-dd HH:mm') } else { '?' }), $(if ($EST.UltimaDescida) { $EST.UltimaDescida.ToString('yyyy-MM-dd') } else { 'nenhuma' }), $EST.OkDegrau, (F2 $EST.EquityInicial))
if ($EST.Faltam.Count -gt 0) { Add-R 'ESTADO.rotulos' 'SEM_DADO' ($EST.Faltam -join ', ') 'todos' 'linhas do STATE.md que o script nao conseguiu ler (rotulo ou formato mudou?)' 'CLAUDE.md, STATE.md' }

# --- Checagens ---------------------------------------------------------------------------------
function Check-Saude([string]$Modo) {
    Write-Secao 'SAUDE (parte que sai dos arquivos; o resto e AGENTE)'
    # P2 guardiao vivo
    if (-not $ST) {
        Add-R 'SAUDE.guardiao' 'FALHA' 'status.json ausente ou invalido' "<= $STATUS_STALE_SEC s" 'guardiao sem heartbeat' 'saude.md P2; incidente.md'
    } elseif ($ST.AgeSec -gt $STATUS_STALE_SEC) {
        Add-R 'SAUDE.guardiao' 'FALHA' ("{0} s" -f $ST.AgeSec) "<= $STATUS_STALE_SEC s" 'status.json parado: guardiao sem heartbeat' 'saude.md P2; incidente.md'
    } else {
        Add-R 'SAUDE.guardiao' 'PASSA' ("{0} s" -f $ST.AgeSec) "<= $STATUS_STALE_SEC s" 'status.json fresco' 'saude.md P2'
    }
    if (-not $ST) { return }
    # conta
    if ($EXPECTED_LOGIN -gt 0) {
        if ($ST.Login -eq $EXPECTED_LOGIN) { Add-R 'SAUDE.conta' 'PASSA' $ST.Login $EXPECTED_LOGIN 'login da conta real' 'saude.md P1' }
        else { Add-R 'SAUDE.conta' 'FALHA' $ST.Login $EXPECTED_LOGIN 'terminal logado em outra conta' 'saude.md P1; incidente.md (qualquer outro)' }
    }
    # P1 conexao
    if ($ST.Connected -and -not $ST.Syncing) {
        Add-R 'SAUDE.conexao' 'PASSA' 'connected=true' 'true' 'terminal conectado (confirmar com get_trading_account_info e o diario do terminal)' 'saude.md P1'
    } elseif ($ST.Syncing) {
        Add-R 'SAUDE.conexao' 'ATENCAO' 'syncing=true' 'false' 'guardiao em aquecimento/sincronizacao (limites suspensos por 3 ciclos): repetir em alguns minutos' 'saude.md P1'
    } else {
        $desde = $null
        $hbl = @(Read-Heartbeat)
        for ($i = $hbl.Count - 1; $i -ge 0; $i--) { if ($hbl[$i].Conn -eq 'OFF') { $desde = $hbl[$i].Utc } else { break } }
        $min = 0
        if ($desde) { $min = [int]($AGORA - $desde).TotalMinutes }
        if ($min -ge $DISCONNECTED_ALERT_MIN) { Add-R 'SAUDE.conexao' 'FALHA' ("desconectado ha {0} min" -f $min) "< $DISCONNECTED_ALERT_MIN min" 'terminal desconectado' 'saude.md P1; incidente.md' }
        else { Add-R 'SAUDE.conexao' 'ATENCAO' ("desconectado ha {0} min (heartbeat)" -f $min) "< $DISCONNECTED_ALERT_MIN min" 'desconexao curta: repetir a checagem' 'saude.md P1' }
    }
    # P4 AutoTrading (terminal e conta pelo status.json; o do Concorde e AGENTE)
    $tt = ConvertTo-Bool (Get-Raw 'trade_allowed_terminal' $false)
    $ta = ConvertTo-Bool (Get-Raw 'trade_allowed_account' $false)
    $te = ConvertTo-Bool (Get-Raw 'trade_allowed_expert' $false)
    if ($tt -and $ta -and $te) { Add-R 'SAUDE.autotrading' 'PASSA' 'terminal/conta/guardiao = true' 'true' 'AutoTrading ligado (o do Concorde: AGENTE)' 'saude.md P4' }
    else { Add-R 'SAUDE.autotrading' 'FALHA' ("terminal={0} conta={1} guardiao={2}" -f $tt, $ta, $te) 'true' 'AutoTrading desligado ou sem permissao de trade' 'saude.md P4; incidente.md' }
    Add-R 'SAUDE.graficos' 'AGENTE' '' '1 Concorde_RF XAUUSD M15, 1 SurvivalGuardian, RegimeLogger XAUUSD D1' 'list_open_charts: exatamente os graficos do STATE.md' 'saude.md P3'
    # P5 magics das posicoes abertas
    $temBm = ($RAW -and $RAW.PSObject.Properties['by_magic'])
    $bm = @(Get-Raw 'by_magic' @())
    $proib = @(); $desc = @(); $txt = @(); $somaN = 0
    foreach ($b in $bm) {
        if (-not $b) { continue }
        $mg = [long](To-Num "$($b.magic)" 0)
        $somaN += [int](To-Num "$($b.n)" 0)
        $txt += ("{0}x{1}" -f $mg, $b.n)
        if ($mg -eq $MAGIC_E2 -or $mg -eq $MAGIC_E4) { $proib += $mg }
        elseif ($MAGICS_OK -notcontains $mg) { $desc += $mg }
    }
    $vtxt = 'nenhuma posicao'; if ($txt.Count -gt 0) { $vtxt = $txt -join ' ' }
    $geridos = "$(Get-Raw 'managed_magics' 'ALL')"
    if ($proib.Count -eq 0 -and $desc.Count -eq 0 -and (-not $temBm -or $somaN -ne $ST.Positions)) {
        Add-R 'SAUDE.magics_abertos' 'SEM_DADO' ("{0}; positions={1}" -f $vtxt, $ST.Positions) '202512, 202533, 202534' 'by_magic ausente ou sem todas as posicoes abertas: conferir os magics pelo get_trading_open_positions' 'saude.md P5'
    }
    elseif ($proib.Count -eq 0 -and $desc.Count -eq 0 -and $geridos.Trim().ToUpper() -ne 'ALL') {
        Add-R 'SAUDE.magics_abertos' 'ATENCAO' ("{0}; managed_magics={1}" -f $vtxt, $geridos) '202512, 202533, 202534' 'o guardiao so enxerga parte dos magics: conferir os magics pelo get_trading_open_positions' 'saude.md P5'
    }
    elseif ($proib.Count -gt 0) { Add-R 'SAUDE.magics_abertos' 'FALHA' $vtxt '202512, 202533, 202534' ("posicao aberta com magic de E2/E4 ({0}): preset errado, HALT" -f ($proib -join ',')) 'saude.md P5; incidente.md' }
    elseif ($desc.Count -gt 0) { Add-R 'SAUDE.magics_abertos' 'FALHA' $vtxt '202512, 202533, 202534' ("posicao aberta com magic desconhecido ({0}): EA desconhecido, HALT" -f ($desc -join ',')) 'saude.md P5; incidente.md' }
    else { Add-R 'SAUDE.magics_abertos' 'PASSA' $vtxt '202512, 202533, 202534' 'posicoes abertas so com magics autorizados (ordens pendentes e deals de entrada de 24 h: AGENTE)' 'saude.md P5' }
    Add-R 'SAUDE.magics_deals' 'AGENTE' '' 'so 202512/202533/202534' 'ordens abertas e deals de ENTRADA das ultimas 24 h (get_trading_history_orders/positions), com as excecoes de incidente ja tratado' 'saude.md P5'
    # P6 preset e guardiao em vigor
    Check-Preset
    # escala
    Check-Escala
    # HALT e lock
    if ($ST.Halt) {
        $quando = ''
        foreach ($g in @(Read-Guardiao)) { if ($g.Msg -match '^HALT ATIVADO') { $quando = $g.Srv.ToString('yyyy.MM.dd HH:mm') } }
        Add-R 'SAUDE.halt' 'ATENCAO' ("halt=true (HALT ATIVADO {0}, hora do servidor)" -f $quando) 'false' 'HALT ativo: sem alerta aberto de HALT = incidente; com alerta, so registrar. Nunca RESUME sem OK RESUME (e so no fim de semana)' 'incidente.md; CLAUDE.md regra 4'
    } else { Add-R 'SAUDE.halt' 'INFO' 'halt=false' '' 'sem HALT' '' }
    if ($ST.DailyLock) {
        if ($Modo -eq 'preabertura') { Add-R 'SAUDE.lock' 'FALHA' 'daily_lock=true' 'false' 'lock diario atravessou o fim de semana: bug, CRITICO; nunca UNLOCK' 'preabertura; incidente.md' }
        else { Add-R 'SAUDE.lock' 'INFO' 'daily_lock=true' '' 'lock diario ativo (e o desenho; volta sozinho no dia seguinte do servidor)' 'incidente.md' }
    } else { Add-R 'SAUDE.lock' 'INFO' 'daily_lock=false' '' '' '' }
    # equity contra o inicial
    if ($EST.EquityInicial -gt 0 -and $ST.Equity -gt 0) {
        $lim = $EQUITY_CRITICAL_FRAC * $EST.EquityInicial
        if ($ST.Equity -le $lim) { Add-R 'SAUDE.equity50' 'FALHA' (F2 $ST.Equity) ("> {0}" -f (F2 $lim)) 'equity abaixo de 50% do inicial: CRITICO; RISK_SCALE 0.25 se a escala for maior' 'incidente.md' }
        else { Add-R 'SAUDE.equity50' 'PASSA' (F2 $ST.Equity) ("> {0}" -f (F2 $lim)) 'equity acima de 50% do inicial' 'incidente.md' }
    }
    Check-RegimeArquivo
    Check-Lab $Modo
    Check-Disco $DISCO_INCIDENTE_GB 'incidente.md'
}

function Check-Preset {
    $snap = Read-Snapshot
    if (-not $snap.Existe) { Add-R 'SAUDE.preset' 'SEM_DADO' 'sem snapshot' 'ops\profile\sobrevivencia\*.chr' 'snapshot do perfil ausente: registrar e pedir ao Henrique o save_profile.ps1' 'saude.md P6'; return }
    if (-not $EST.Degrau) { Add-R 'SAUDE.preset' 'SEM_DADO' '' '' 'STATE.md sem a linha "Degrau do preset"' 'saude.md P6'; return }
    $nC = @($snap.Concorde).Count; $nG = @($snap.Guardiao).Count; $nR = @($snap.Regime).Count; $nO = @($snap.Outros).Count
    $vSnap = "{0} arquivo(s): Concorde_RF {1}, SurvivalGuardian {2}, RegimeLogger {3}, outros {4}" -f $snap.Arquivos, $nC, $nG, $nR, $nO
    if ($EST.RegimeInstalado -eq $true -and $nR -ne 1) { Add-R 'SAUDE.snapshot' 'ATENCAO' $vSnap '1 / 1 / 1 / 0' 'RegimeLogger instalado mas fora do snapshot (ou duplicado): o proximo arranque perde o grafico; pedir ao Henrique o save_profile.ps1 (5.7, linha do RegimeLogger da secao 6)' 'saude.md P3; regime.md' }
    elseif ($nO -gt 0) { Add-R 'SAUDE.snapshot' 'ATENCAO' $vSnap '1 / 1 / 1 / 0' 'EA fora do STATE.md gravado no perfil do kit: conferir com list_open_charts (EA desconhecido?)' 'saude.md P3' }
    else { Add-R 'SAUDE.snapshot' 'INFO' $vSnap '1 / 1 / 1 / 0' 'graficos gravados no perfil do kit (os graficos ao vivo: AGENTE)' 'saude.md P3' }
    if ($nC -ne 1) { Add-R 'SAUDE.preset' 'FALHA' ("{0} bloco(s) do Concorde_RF no snapshot" -f $nC) '1' 'snapshot do perfil com Concorde ausente ou duplicado' 'saude.md P6'; return }
    $cin = $snap.Concorde[0].Inputs
    $e2 = "$($cin['Estrategia2_Ativada'])".ToLower(); $e4 = "$($cin['Estrategia4_Ativada'])".ToLower()
    $vE1 = To-Num "$($cin['E1_RiscoPorPernaPct'])" -1; $vE3 = To-Num "$($cin['E3_RiscoPorPernaPct'])" -1
    $vStop = To-Num "$($cin['Concorde_StopDiarioGlobalPct'])" -1
    $vHalt = -1.0
    if ($nG -ge 1) { $vHalt = To-Num "$($snap.Guardiao[0].Inputs['Inp_DD_HaltPct'])" -1 }
    $lim = @((To-Num "$(Get-Raw 'limit_daily_loss_pct' '')" -1), (To-Num "$(Get-Raw 'limit_dd_reduce_pct' '')" -1), (To-Num "$(Get-Raw 'limit_dd_hysteresis_pct' '')" -1), (To-Num "$(Get-Raw 'limit_dd_halt_pct' '')" -1))
    $vals = "E2={0} E4={1} E1={2} E3={3} stop={4} halt={5} | limit_*={6}" -f $e2, $e4, $vE1.ToString($CI), $vE3.ToString($CI), $vStop.ToString($CI), $vHalt.ToString($CI), (($lim | ForEach-Object { F1 $_ }) -join '/')
    if ($e2 -eq 'true' -or $e4 -eq 'true') { Add-R 'SAUDE.preset' 'FALHA' $vals 'E2=false E4=false' 'E2 ou E4 LIGADA no snapshot: CRITICO (sem HALT se nenhum magic proibido opera; nenhum RESUME enquanto nao resolver)' 'saude.md P6'; return }
    # vetor conferido: E1, E3, stop global, HALT do guardiao no snapshot e os 4 limit_* do status.json
    $vetor = @($vE1, $vE3, $vStop, $vHalt) + $lim
    function Get-Esperado([string]$D, [bool]$ComG45) {
        $r = $REF_A; if ($D -eq 'B') { $r = $REF_B }
        $gl = $LIM_G35; $hl = 35.0
        if ($D -eq 'B' -or $ComG45) { $gl = $LIM_G45; $hl = 45.0 }
        return @($r.E1, $r.E3, $r.Stop, $hl) + $gl
    }
    function Test-Vetor($Esp) {
        for ($k = 0; $k -lt 8; $k++) { if ([Math]::Abs($vetor[$k] - $Esp[$k]) -gt 1e-6) { return $false } }
        return $true
    }
    $esperado = "degrau {0}" -f $DEGRAU_TXT
    $espAtual = Get-Esperado $EST.Degrau $EST.G45Descida
    if (Test-Vetor $espAtual) { Add-R 'SAUDE.preset' 'PASSA' $vals $esperado 'snapshot e limites do guardiao batem com o degrau do STATE.md' 'saude.md P6'; return }
    if ($EST.G45Descida -and (Test-Vetor (Get-Esperado 'A' $false))) {
        Add-R 'SAUDE.preset' 'ATENCAO' $vals $esperado 'troca do guardiao para o G35 feita depois da descida: conferir (5.6) e voltar a linha para "Degrau do preset: A"' 'saude.md P6; degrau.md'
        return
    }
    if ($EST.OkDegrau -eq 'A' -or $EST.OkDegrau -eq 'B') {
        # excecao (b) da 4.3: cada valor e o do degrau em vigor ou o do autorizado, no todo ou em parte
        $espAut = Get-Esperado $EST.OkDegrau $false
        $okParcial = $true
        for ($k = 0; $k -lt 8; $k++) {
            if ([Math]::Abs($vetor[$k] - $espAtual[$k]) -gt 1e-6 -and [Math]::Abs($vetor[$k] - $espAut[$k]) -gt 1e-6) { $okParcial = $false }
        }
        if ($okParcial) {
            Add-R 'SAUDE.preset' 'ATENCAO' $vals ("{0} ou o autorizado {1}" -f $esperado, $EST.OkDegrau) 'OK DEGRAU autorizado e ainda nao conferido: nao e divergencia; fazer a conferencia do degrau nesta acordada (5.6)' 'saude.md P6; degrau.md'
            return
        }
    }
    if ($EST.OkAlternativa) { Add-R 'SAUDE.preset' 'ATENCAO' $vals $esperado 'OK ALTERNATIVA pendente: conferir o snapshot contra o .set da alternativa' 'saude.md P6; laboratorio.md'; return }
    Add-R 'SAUDE.preset' 'FALHA' $vals $esperado 'snapshot ou limites divergem do degrau do STATE.md: ATENCAO + notify, sem HALT se nenhum magic proibido opera; nenhum RESUME enquanto nao resolver. Se ha linha OK DEGRAU nova no INBOX desta acordada, e a excecao (b) da 4.3: fazer a conferencia de 5.6' 'saude.md P6'
}

function Check-Escala {
    $man = ConvertTo-Bool (Get-Raw 'risk_scale_manual' $false)
    $modo = 'AUTO'; if ($man) { $modo = 'FIXO' }
    $vtxt = "{0} {1}" -f (F2 $ST.RiskScale), $modo
    if ($null -eq $EST.RiskEscala -or $null -eq $EST.RiskManual) { Add-R 'SAUDE.escala' 'SEM_DADO' $vtxt '?' 'STATE.md sem "risk_scale esperado do guardiao" legivel' 'saude.md'; return }
    $etxt = $EST.RiskTxt
    # escala FIXA suspende a reducao automatica do guardiao: com o DD no limite de reducao, eu mando 0.5 (secao 10, 5.6)
    $limRed = To-Num "$(Get-Raw 'limit_dd_reduce_pct' '')" -1
    if ($man -and $ST.RiskScale -gt 0.5001 -and $limRed -gt 0 -and $ST.DdPct -ge $limRed) {
        Add-R 'SAUDE.escala_manual_dd' 'FALHA' ("escala FIXA {0} com DD {1}%" -f (F2 $ST.RiskScale), (F2 $ST.DdPct)) ("DD < {0}% (limite de reducao)" -f (F1 $limRed)) 'com escala fixa o guardiao nao reduz sozinho: mandar RISK_SCALE 0.5 (reducao) pelo ops\cmd.ps1' 'CLAUDE.md 10; degrau.md'
    }
    if ($EST.RiskManual) {
        if ($man -and [Math]::Abs($ST.RiskScale - $EST.RiskEscala) -lt 0.006) { Add-R 'SAUDE.escala' 'PASSA' $vtxt $etxt 'escala igual a esperada' 'saude.md' }
        else { Add-R 'SAUDE.escala' 'ATENCAO' $vtxt $etxt 'escala diferente da esperada no STATE.md' 'saude.md' }
        return
    }
    if ($man) { Add-R 'SAUDE.escala' 'ATENCAO' $vtxt $etxt 'escala FIXA sem registro no STATE.md' 'saude.md; desempenho.md 5.3'; return }
    # AUTO: 1,0 ou a escala reduzida do guardiao (0,5) por DD; 0,67 so com "(histerese)" registrado
    $okA = ([Math]::Abs($ST.RiskScale - 1.0) -lt 0.006 -or [Math]::Abs($ST.RiskScale - 0.5) -lt 0.006)
    if (-not $okA -and $EST.RiskHisterese -and [Math]::Abs($ST.RiskScale - $EST.RiskEscala) -lt 0.006) { $okA = $true }
    if ($okA) { Add-R 'SAUDE.escala' 'PASSA' $vtxt $etxt 'escala automatica do guardiao coerente com o STATE.md' 'saude.md' }
    else { Add-R 'SAUDE.escala' 'ATENCAO' $vtxt $etxt 'escala automatica fora do esperado' 'saude.md' }
}

function Check-RegimeArquivo {
    if ($script:REGARQ_FEITO) { return }
    $script:REGARQ_FEITO = $true
    if ($EST.RegimeInstalado -ne $true) { Add-R 'REGIME.arquivo' 'INFO' 'RegimeLogger nao instalado pelo STATE.md' '' 'registrar a ausencia' 'regime.md'; return }
    $rg = Read-Regime
    if (-not $rg.Existe -or @($rg.Linhas).Count -eq 0) { Add-R 'REGIME.arquivo' 'ATENCAO' 'regime.csv ausente ou vazio' '' 'RegimeLogger parado: ATENCAO + notify, nunca HALT nem reinicio' 'regime.md; incidente.md'; return }
    $ult = $rg.Linhas[$rg.Linhas.Count - 1]
    $atraso = Get-DiasUteis $ult.Data $AGORA
    $v = "ultima linha {0} (vol20 {1}%, amplitude {2}%, atr14 {3}%)" -f $ult.Data.ToString('yyyy-MM-dd'), (F2 $ult.Vol20), (F2 $ult.Amp), (F2 $ult.Atr)
    if ($atraso -gt $REG_ATRASO_UTEIS) {
        $tx = 'regime.csv parado: ATENCAO + notify, nunca HALT nem reinicio (feriado sem barra D1 nao conta: conferir)'
        if ($ST -and $ST.Halt) { $tx = 'atraso e efeito do HALT (o guardiao fecha os outros graficos): so registrar' }
        Add-R 'REGIME.arquivo' 'ATENCAO' ("{0}; {1} dia(s) util(eis) de atraso" -f $v, $atraso) "<= $REG_ATRASO_UTEIS" $tx 'regime.md; incidente.md'
    } else { Add-R 'REGIME.arquivo' 'PASSA' ("{0}; {1} dia(s) util(eis) de atraso" -f $v, $atraso) "<= $REG_ATRASO_UTEIS" 'regime.csv em dia' 'regime.md' }
}

function Check-Lab([string]$Modo) {
    $procs = @(Get-LabProcesses)
    $dentro = Test-LabJanela $AGORA
    $lk = Get-LabLockInfo
    if ($procs.Count -eq 0) { Add-R 'SAUDE.lab' 'INFO' 'nenhum processo da copia de tester' '' '' 'laboratorio.md'; return }
    if (-not $lk -and (Test-LabManutencao)) { Add-R 'SAUDE.lab' 'ATENCAO' ("{0} processo(s) da copia {1}" -f $procs.Count, $LAB_DIR) 'lab.manutencao fresco e conta sem posicao' 'manutencao da copia pelo Henrique em curso (ops\logs\lab.manutencao, ate 60 min): nao parar' 'laboratorio.md'; return }
    if (-not $dentro) { Add-R 'SAUDE.lab' 'FALHA' ("{0} processo(s) da copia {1} fora da janela" -f $procs.Count, $LAB_DIR) 'nenhum fora de sab 04:30 - dom 17:30 UTC' 'rodar ops\lab.ps1 -Acao parar e registrar ATENCAO' 'laboratorio.md; incidente.md'; return }
    if (-not $lk) { Add-R 'SAUDE.lab' 'FALHA' ("{0} processo(s) da copia sem o lab.ps1 vivo" -f $procs.Count) 'so com o lab.ps1' 'rodar ops\lab.ps1 -Acao parar e registrar ATENCAO' 'laboratorio.md; incidente.md'; return }
    Add-R 'SAUDE.lab' 'INFO' ("laboratorio rodando ({0}, desde {1})" -f $lk.Acao, $lk.Desde) '' 'dentro da janela' 'laboratorio.md'
}

function Check-Disco([double]$MinGb, [string]$Regra) {
    $idD = 'SAUDE.disco'; if ($MinGb -gt $DISCO_INCIDENTE_GB) { $idD = 'SAUDE.disco_10gb' }
    $livre = -1.0
    try { $di = New-Object IO.DriveInfo 'C'; $livre = $di.AvailableFreeSpace / 1GB } catch { }
    if ($livre -lt 0) { Add-R $idD 'SEM_DADO' '' ">= $MinGb GB" 'nao consegui ler o disco C:' $Regra; return }
    if ($livre -lt $MinGb) { Add-R $idD 'ATENCAO' ("{0} GB livres" -f (F1 $livre)) ">= $MinGb GB" 'pouco espaco em C: registrar e escalar; nao apagar nada' $Regra }
    else { Add-R $idD 'PASSA' ("{0} GB livres" -f (F1 $livre)) ">= $MinGb GB" '' $Regra }
}

function Check-Numeros {
    Write-Secao 'NUMEROS DO DIA'
    if (-not $ST) { Add-R 'NUM.conta' 'SEM_DADO' 'status.json ausente' '' '' 'saude.md'; return }
    Add-R 'NUM.conta' 'INFO' ("equity {0} | saldo {1} | HWM {2} | DD {3}% | dia {4}% | escala {5}" -f (F2 $ST.Equity), (F2 $ST.Balance), (F2 $ST.Hwm), (F2 $ST.DdPct), (F2 $ST.DayPnlPct), (F2 $ST.RiskScale)) '' 'numeros do status.json (conferir com get_trading_account_info)' 'saude.md'
    Check-DdReferencia $ST.DdPct 'DD atual'
    $tr = Read-Trades
    if (-not $tr.Existe) {
        Add-R 'NUM.trades' 'SEM_DADO' ("trades_mfe.csv: {0}" -f $tr.Motivo) '' 'ritmo e P&L por magic pelo MCP, como antes, e ATENCAO' 'saude.md'
        if ($EST.Degrau -eq 'B') { Check-Descida $tr }
        return
    }
    if ($tr.Invalidas -gt 0) { Add-R 'NUM.trades_invalidas' 'ATENCAO' ("{0} linha(s) invalida(s) no trades_mfe.csv" -f $tr.Invalidas) '0' 'linhas descartadas: conferir as contagens com o MCP' 'saude.md' }
    $l24 = @($tr.Lista | Where-Object { $_.FechUtc -gt $AGORA.AddHours(-24) -and $_.FechUtc -le $AGORA })
    $l7 = @($tr.Lista | Where-Object { $_.FechUtc -gt $AGORA.AddDays(-7) -and $_.FechUtc -le $AGORA })
    $l30 = @($tr.Lista | Where-Object { $_.FechUtc -gt $AGORA.AddDays(-30) -and $_.FechUtc -le $AGORA })
    $ultimo = '-'; if (@($tr.Lista).Count -gt 0) { $ultimo = $tr.Lista[$tr.Lista.Count - 1].FechSrv.ToString('yyyy.MM.dd HH:mm') }
    Add-R 'NUM.trades_fonte' 'INFO' ("trades_mfe.csv: {0} posicoes, ultimo fechamento {1} (servidor), arquivo de {2} min" -f $tr.Linhas, $ultimo, $tr.IdadeMin) '' 'conferir a contagem de 7 dias com get_trading_history_positions; se nao bater, usar o MCP e registrar ATENCAO' 'saude.md'
    foreach ($par in @(@('E1', @(202512)), @('E3', @(202533, 202534)))) {
        $nm = $par[0]; $mgs = $par[1]
        $s7 = Get-Stats @($l7 | Where-Object { $mgs -contains $_.Magic })
        $s30 = Get-Stats @($l30 | Where-Object { $mgs -contains $_.Magic })
        Add-R ("NUM.pl_{0}" -f $nm) 'INFO' ("7 d: {0} trades {1} USC | 30 d: {2} trades {3} USC PF {4}" -f $s7.N, (F2 $s7.Lucro), $s30.N, (F2 $s30.Lucro), (Fmt-Pf $s30.Pf)) '' ("P&L de {0} ({1})" -f $nm, ($mgs -join '+')) 'saude.md'
    }
    # ritmo e duplicacao
    $anom = @()
    if ($l24.Count -gt $RITMO_24H) { $anom += "24h" }
    if ($l7.Count -gt $RITMO_7D) { $anom += "7d" }
    $sinais = @{}; $porDia = @{}
    foreach ($x in @($tr.Lista | Where-Object { $_.FechUtc -gt $AGORA.AddDays(-7) -and $_.AbSrv })) {
        $k = "{0}|{1}" -f $x.Estrategia, $x.AbSrv.ToString('yyyy.MM.dd HH:mm')
        if (-not $sinais.ContainsKey($k)) { $sinais[$k] = 0 }
        $sinais[$k]++
        $kd = "{0}|{1}" -f $x.Estrategia, $x.AbSrv.ToString('yyyy.MM.dd')
        if (-not $porDia.ContainsKey($kd)) { $porDia[$kd] = @{} }
        $porDia[$kd][$x.AbSrv.ToString('HH:mm')] = 1
    }
    $pernas3 = @($sinais.Keys | Where-Object { $sinais[$_] -gt 2 })
    $dois = @($porDia.Keys | Where-Object { $porDia[$_].Count -gt 1 })
    if ($pernas3.Count -gt 0) { $anom += "pernas" }
    if ($dois.Count -gt 0) { $anom += "sinais_dia" }
    $vr = "{0} em 24 h, {1} em 7 d; sinais com mais de 2 pernas: {2}; estrategia com 2+ sinais no dia: {3}" -f $l24.Count, $l7.Count, $(if ($pernas3.Count) { $pernas3 -join ' ' } else { 'nenhum' }), $(if ($dois.Count) { $dois -join ' ' } else { 'nenhuma' })
    if ($anom.Count -gt 0) { Add-R 'NUM.ritmo' 'ATENCAO' $vr '<= 8 em 24 h; <= 30 em 7 d; 2 pernas; 1 sinal/dia' 'ritmo anomalo: ATENCAO + notify, checar duplicacao (graficos e tickets no mesmo minuto) e o risco por perna abaixo' 'saude.md numeros' }
    else { Add-R 'NUM.ritmo' 'PASSA' $vr '<= 8 em 24 h; <= 30 em 7 d; 2 pernas; 1 sinal/dia' '' 'saude.md numeros' }
    # risco realizado por perna (7 dias): volume x |entrada - SL| x 100 contra pct x equity x escala
    $hb = @(Read-Heartbeat)
    $dobro = @(); $nAval = 0
    foreach ($x in $l7) {
        if ($x.RiscoUsd -le 0 -or -not $x.AbUtc) { continue }
        $eq = -1.0
        foreach ($h in $hb) { if ($h.Utc -le $x.AbUtc -and $h.Eq -gt 0) { $eq = $h.Eq } }
        if ($eq -le 0) { continue }
        $pct = $REF.E1; if ($x.Estrategia -eq 'E3') { $pct = $REF.E3 }
        $plan = $pct / 100.0 * $eq * $ST.RiskScale
        $real = $x.Volume * $x.RiscoUsd * 100.0
        $nAval++
        if ($x.Volume -gt 0.0100001 -and $real -gt 1.5 * $plan) { $dobro += ("{0} {1} vol {2} risco {3} USC (plano {4})" -f $x.Ticket, $x.Estrategia, $x.Volume, (F1 $real), (F1 $plan)) }
    }
    $verR = 'INFO'
    if ($dobro.Count -gt 0 -and $anom.Count -gt 0) { $verR = 'ATENCAO' }
    $txR = 'nenhuma perna acima de 1,5x o risco planejado (fora o piso de 0,01)'
    if ($dobro.Count -gt 0) { $txR = 'acima de 1,5x o planejado: ' + ($dobro -join '; ') }
    Add-R 'NUM.risco_perna' $verR ("{0} perna(s) avaliadas em 7 d (escala atual {1}, equity do heartbeat na entrada)" -f $nAval, (F2 $ST.RiskScale)) '<= 1,5x' $txR 'saude.md numeros'
    if ($EST.Degrau -eq 'B') { Check-Descida $tr }
}

function Check-DdReferencia([double]$Dd, [string]$Rot, [string]$Id = 'NUM.dd_referencia', [bool]$Parcial = $false) {
    $rr = Get-RefDegrau @(Read-Heartbeat)
    $ref = $rr[0]
    $v = "{0} {1}%" -f $Rot, (F2 $Dd)
    $lim = "ref {0} {1}% / pausa > {2}%" -f $ref.Nome, (F2 $ref.Dd), (F1 $ref.Pausa)
    if ($rr[1]) { $lim += " ({0})" -f $rr[1] }
    if ($Dd -gt $ref.Pausa) { Add-R $Id 'FALHA' $v $lim 'acima do limite de pausa do degrau (a pausa e decidida na semanal)' 'desempenho.md 5.2' }
    elseif ($Parcial) { Add-R $Id 'SEM_DADO' $v $lim 'heartbeat insuficiente no periodo: o DD maximo nao pode ser confirmado (conferir DIARIO.md e guardian.log)' 'desempenho.md 5.2' }
    elseif ($Dd -ge $ref.Dd) { Add-R $Id 'ATENCAO' $v $lim 'pre-alerta: so registrar, nao agir' 'desempenho.md 5.2' }
    else { Add-R $Id 'PASSA' $v $lim 'abaixo da referencia' 'desempenho.md 5.2' }
}

function Check-Reinicios {
    # limite da secao 6: no maximo 2 reinicios do terminal por hora, contando os do heartbeat (linhas "start_terminal |
    # iniciando:" do ops.log na ultima hora)
    $n = 0
    $t = Read-TextAuto (Join-Path $LOG_DIR 'ops.log')
    if ($t) {
        foreach ($l in ($t -split "`r?`n")) {
            $m = [regex]::Match($l, '^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})Z \| start_terminal \| iniciando:')
            if (-not $m.Success) { continue }
            $ts = [DateTime]::SpecifyKind([DateTime]::ParseExact($m.Groups[1].Value, 'yyyy-MM-dd HH:mm:ss', $CI), [DateTimeKind]::Utc)
            if ($ts -gt $AGORA.AddHours(-1) -and $ts -le $AGORA) { $n++ }
        }
    }
    if ($n -ge 2) { Add-R 'INC.reinicios' 'FALHA' ("{0} arranque(s) do terminal na ultima hora" -f $n) '< 2' 'limite de reinicios atingido: nao reiniciar de novo; escalar (CRITICO + notify se nao voltou)' 'incidente.md' }
    else { Add-R 'INC.reinicios' 'INFO' ("{0} arranque(s) do terminal na ultima hora" -f $n) '< 2' 'ainda cabe um reinicio, se a tabela da secao 6 mandar' 'incidente.md' }
}

function Check-VezGuardiao {
    # preset A com o G45 da descida (dd_pct >= 30% na troca): a vez do G35 chega com o DD abaixo de 30% (5.6)
    if (-not $EST.G45Descida) { return }
    $haltLim = To-Num "$(Get-Raw 'limit_dd_halt_pct' '')" -1
    if ($ST -and [Math]::Abs($haltLim - 35.0) -lt 1e-6) { Add-R 'DEG.vez_guardiao' 'ATENCAO' ("limit_dd_halt_pct {0}" -f (F1 $haltLim)) 'G45 ate a troca' 'o guardiao ja esta no G35: conferir a troca (5.6) e voltar a linha para "Degrau do preset: A"' 'degrau.md descida' }
    elseif ($ST -and $ST.DdPct -lt $DESCIDA_G35_DD) { Add-R 'DEG.vez_guardiao' 'ATENCAO' ("dd_pct {0}%" -f (F2 $ST.DdPct)) '< 30%' 'vez do guardiao: linha de Estado no alerta da descida (carregar SurvivalGuardian_G35.set) + notify' 'degrau.md descida' }
    else { Add-R 'DEG.vez_guardiao' 'INFO' $(if ($ST) { "dd_pct {0}%" -f (F2 $ST.DdPct) } else { '?' }) '< 30%' 'guardiao G45 continua ate o DD cair abaixo de 30%' 'degrau.md descida' }
}

function Check-Descida($Tr) {
    Write-Secao 'DESCIDA (degrau B)'
    # o gatilho olha o DD atual e o maior DD dos ultimos 7 dias (o DD pode ter passado de 25% entre duas acordadas)
    $script:DESCIDA_FEITA = $true
    if (-not $ST) { Add-R 'DEG.descida_dd' 'SEM_DADO' 'status.json ausente' "<= $DESCIDA_DD%" '' 'degrau.md descida'; return }
    $d7 = Get-DdMax ($AGORA.AddDays(-7)) @(Read-Heartbeat) @(Read-Guardiao) $ST
    $vD = "DD atual {0}%, maximo de 7 dias {1}% ({2} amostras do heartbeat, maior buraco {3} h)" -f (F2 $ST.DdPct), (F2 $d7[0]), $d7[1], (F1 $d7[2])
    $gatDd = ($ST.DdPct -gt $DESCIDA_DD -or $d7[0] -gt $DESCIDA_DD)
    if ($gatDd) { Add-R 'DEG.descida_dd' 'FALHA' $vD "<= $DESCIDA_DD%" 'gatilho de descida: alerta AGUARDANDO OK (unico), troca valida pelo dd_pct atual' 'degrau.md descida' }
    elseif ($d7[1] -eq 0 -or $d7[2] -gt 24) { Add-R 'DEG.descida_dd' 'SEM_DADO' $vD "<= $DESCIDA_DD%" 'heartbeat insuficiente nos 7 dias: o DD maximo nao pode ser confirmado (conferir DIARIO.md e guardian.log)' 'degrau.md descida' }
    else { Add-R 'DEG.descida_dd' 'PASSA' $vD "<= $DESCIDA_DD%" '' 'degrau.md descida' }
    $gatPf = $false
    if (-not $Tr -or -not $Tr.Existe) { Add-R 'DEG.descida_pf' 'SEM_DADO' 'trades_mfe.csv indisponivel' '>= 1,0 (com 40+ trades)' 'PF de 60 dias pelo MCP' 'degrau.md descida' }
    else {
        $l60 = @($Tr.Lista | Where-Object { $_.FechUtc -gt $AGORA.AddDays(-60) -and $_.FechUtc -le $AGORA })
        $s60 = Get-Stats $l60
        $gatPf = ($s60.N -ge $PAUSA_PF_TRADES -and $s60.Pf -lt $PRE_PF)
        if ($gatPf) { Add-R 'DEG.descida_pf' 'FALHA' ("PF 60 d {0} com {1} trades" -f (Fmt-Pf $s60.Pf), $s60.N) '>= 1,0 (com 40+ trades)' 'gatilho de descida pelo PF' 'degrau.md descida' }
        else { Add-R 'DEG.descida_pf' 'PASSA' ("PF 60 d {0} com {1} trades" -f (Fmt-Pf $s60.Pf), $s60.N) '>= 1,0 (com 40+ trades)' '' 'degrau.md descida' }
    }
    if ($gatDd -or $gatPf) {
        if ([Math]::Abs($ST.RiskScale - 1.0) -lt 0.006) { Add-R 'DEG.escala_067' 'INFO' 'risk_scale 1,00' '' 'pode mandar RISK_SCALE 0.67 (reducao), anotado no STATE.md' 'degrau.md descida' }
        else { Add-R 'DEG.escala_067' 'INFO' ("risk_scale {0}" -f (F2 $ST.RiskScale)) '' '0,67 seria aumento: nao mandar nada alem do registro' 'degrau.md descida' }
        $troca = 'Concorde_E13_A + SurvivalGuardian_G35'
        if ($ST.DdPct -ge $DESCIDA_G35_DD) { $troca = 'so o Concorde_E13_A; o guardiao fica no G45 ate o DD cair abaixo de 30%' }
        Add-R 'DEG.troca_valida' 'INFO' ("dd_pct {0}%" -f (F2 $ST.DdPct)) '30%' ("troca valida agora: {0}" -f $troca) 'degrau.md descida'
    }
}

function Check-Desempenho {
    Write-Secao 'DESEMPENHO (5.1 a 5.3)'
    $tr = Read-Trades
    $ini = $EST.Inicio
    if (-not $ini) { $ini = [DateTime]::SpecifyKind([DateTime]::ParseExact('2026-09-23 00:56', 'yyyy-MM-dd HH:mm', $CI), [DateTimeKind]::Utc) }
    if (-not $tr.Existe) { Add-R 'DES.fonte' 'SEM_DADO' ("trades_mfe.csv: {0}" -f $tr.Motivo) '' 'fazer a revisao por magic e o PF de 60 dias pelo MCP, como antes, e registrar ATENCAO' 'desempenho.md' }
    else {
    $ultimo = '-'; if (@($tr.Lista).Count -gt 0) { $ultimo = $tr.Lista[$tr.Lista.Count - 1].FechSrv.ToString('yyyy.MM.dd HH:mm') }
    $verF = 'INFO'; if ($tr.Invalidas -gt 0) { $verF = 'ATENCAO' }
    Add-R 'DES.fonte' $verF ("trades_mfe.csv: {0} posicoes, {1} linha(s) invalida(s), ultimo fechamento {2} (servidor), arquivo de {3} min" -f $tr.Linhas, $tr.Invalidas, $ultimo, $tr.IdadeMin) '' 'conferir a contagem de cada janela com get_trading_history_positions; se nao bater, calcular pelo MCP e registrar ATENCAO' 'desempenho.md 5.1'
    Write-Host ''
    Write-Host '| magic | janela | trades | lucro USC | PF | acerto | maior perda | maior queda | lucro medio |'
    Write-Host '|---|---|---|---|---|---|---|---|---|'
    $grupos = @(@('202512 (E1)', @(202512)), @('202533 (E3 p1)', @(202533)), @('202534 (E3 p2)', @(202534)), @('E3 (202533+202534)', @(202533, 202534)), @('Concorde (total)', @(202512, 202533, 202534)))
    $janelas = @(@('desde o inicio', $ini), @('30 dias', $AGORA.AddDays(-30)), @('60 dias', $AGORA.AddDays(-60)))
    foreach ($g in $grupos) {
        foreach ($j in $janelas) {
            $de = $j[1]; if ($de -lt $ini) { $de = $ini }
            $sub = @($tr.Lista | Where-Object { $g[1] -contains $_.Magic -and $_.FechUtc -ge $de -and $_.FechUtc -le $AGORA })
            $s = Get-Stats $sub
            Write-Host ('| {0} | {1} | {2} | {3} | {4} | {5}% | {6} | {7} | {8} |' -f $g[0], $j[0], $s.N, (F2 $s.Lucro), (Fmt-Pf $s.Pf), (F1 $s.Acerto), (F2 $s.MaiorPerda), (F2 $s.Queda), (F2 $s.Medio))
        }
    }
    Write-Host ''
    }
    # 5.2 regras objetivas (Concorde inteiro)
    $hb = @(Read-Heartbeat); $gl = @(Read-Guardiao)
    $semana = Get-DdMax ($AGORA.AddDays(-7)) $hb $gl $ST
    $parcial = (-not $ST -or $semana[1] -eq 0 -or $semana[2] -gt 24)
    Check-DdReferencia $semana[0] ("DD maximo dos ultimos 7 dias ({0} amostras do heartbeat, maior buraco {1} h)" -f $semana[1], (F1 $semana[2])) 'DES.dd_7d' $parcial
    if ($tr.Existe) {
        $l60 = @($tr.Lista | Where-Object { $_.FechUtc -gt $AGORA.AddDays(-60) -and $_.FechUtc -le $AGORA })
        $s60 = Get-Stats $l60
        $v60 = "PF 60 d {0} com {1} trades" -f (Fmt-Pf $s60.Pf), $s60.N
        if ($s60.N -ge $PAUSA_PF_TRADES -and $s60.Pf -lt $PAUSA_PF) { Add-R 'DES.pausa_pf' 'FALHA' $v60 'PF >= 0,8 com 40+ trades' 'pausa obrigatoria pelo PF' 'desempenho.md 5.2' }
        elseif ($s60.N -ge $PRE_PF_MIN -and $s60.N -lt $PAUSA_PF_TRADES -and $s60.Pf -lt $PRE_PF) { Add-R 'DES.pausa_pf' 'ATENCAO' $v60 'PF >= 1,0 com 20 a 39 trades' 'pre-alerta pelo PF: so registrar' 'desempenho.md 5.2' }
        else { Add-R 'DES.pausa_pf' 'PASSA' $v60 'PF >= 0,8 (40+) / >= 1,0 (20 a 39)' '' 'desempenho.md 5.2' }
    } else { Add-R 'DES.pausa_pf' 'SEM_DADO' 'trades_mfe.csv indisponivel' 'PF >= 0,8 (40+) / >= 1,0 (20 a 39)' 'PF de 60 dias pelo MCP' 'desempenho.md 5.2' }
    # 5.3 conta como um todo
    $locks = @{}
    foreach ($g in $gl) { if ($g.Utc -ge $AGORA.AddDays(-7) -and $g.Msg -match '^LOCK DIARIO ATIVADO') { $locks[$g.Srv.ToString('yyyy.MM.dd')] = 1 } }
    if ($locks.Count -ge 3) { Add-R 'DES.locks' 'ATENCAO' ("{0} dia(s) com lock na semana" -f $locks.Count) '< 3' 'lock diario 3x na semana: pre-alerta de portfolio' 'desempenho.md 5.3; incidente.md' }
    else { Add-R 'DES.locks' 'INFO' ("{0} dia(s) com lock diario nos ultimos 7 dias" -f $locks.Count) '< 3' '' 'desempenho.md 5.3' }
    $stops = Get-StopsDiarios 14
    $st10 = @($stops | Where-Object { $_ -ge (Get-DataUteisAtras 10) })
    if ($st10.Count -ge 3) { Add-R 'DES.stop_ea' 'ATENCAO' ("{0} disparo(s) do stop diario do EA em 10 dias uteis" -f $st10.Count) '< 3' 'pre-alerta' 'desempenho.md 5.3; incidente.md' }
    else { Add-R 'DES.stop_ea' 'INFO' ("{0} disparo(s) do stop diario do EA em 10 dias uteis ({1} na semana)" -f $st10.Count, @($stops | Where-Object { $_ -ge $AGORA.AddDays(-7).Date }).Count) '< 3' 'pelos diarios do Expert (CONCORDE STOP DIARIO GLOBAL)' 'desempenho.md 5.3' }
    $man = ConvertTo-Bool (Get-Raw 'risk_scale_manual' $false)
    # escala 0,5 ha mais de 4 semanas (fora o 0,5 FIXO do regime)
    # (o heartbeat nao grava a escala: conta o estado RISCO_REDUZIDO, tolerando lock diario, SYNC e desconexao no meio,
    # e exige a escala 0,5 agora)
    $desde = $null
    for ($i = $hb.Count - 1; $i -ge 0; $i--) {
        if ($hb[$i].State -eq 'RISCO_REDUZIDO') { $desde = $hb[$i].Utc }
        elseif ($hb[$i].State -in @('LOCK_DIARIO', 'SYNC', 'DISCONNECTED', '-')) { continue }
        else { break }
    }
    $em05 = ($ST -and [Math]::Abs($ST.RiskScale - 0.5) -lt 0.006)
    if ($desde -and $em05 -and ($AGORA - $desde).TotalDays -gt 7 * $ESCALA_05_SEMANAS -and -not ($man -and $EST.RiskRegime)) { Add-R 'DES.escala_05' 'ATENCAO' ("risco reduzido desde {0:yyyy-MM-dd}" -f $desde) "<= $ESCALA_05_SEMANAS semanas" 'portfolio errado para o tamanho da conta' 'desempenho.md 5.3' }
    else { Add-R 'DES.escala_05' 'INFO' $(if ($desde) { "risco reduzido desde {0:yyyy-MM-dd}" -f $desde } else { 'sem periodo de risco reduzido em curso' }) "<= $ESCALA_05_SEMANAS semanas" '' 'desempenho.md 5.3' }
    if ($man) {
        if ($EST.RiskRegime) { Add-R 'DES.escala_manual' 'INFO' ("FIXO {0}" -f (F2 $ST.RiskScale)) '' ("0,5 FIXO do regime, justificado mesmo com o alerta fechado: {0}" -f $EST.RiskTxt) 'desempenho.md 5.3' }
        elseif ($EST.RiskManual) { Add-R 'DES.escala_manual' 'AGENTE' ("FIXO {0}" -f (F2 $ST.RiskScale)) '' ("registrado no STATE.md ({0}): conferir se ha alerta aberto ou reducao registrada que justifique (o 0,67 de 5.6, uma reducao de incidente); sem isso, ATENCAO" -f $EST.RiskTxt) 'desempenho.md 5.3' }
        else { Add-R 'DES.escala_manual' 'ATENCAO' ("FIXO {0}" -f (F2 $ST.RiskScale)) '' 'risk_scale_manual=true sem registro no STATE.md: ver se ha alerta que justifique' 'desempenho.md 5.3' }
    }
    if ($ST -and $EST.EquityInicial -gt 0) { Add-R 'DES.crescimento' 'INFO' ("{0}%" -f (F2 (100.0 * ($ST.Equity / $EST.EquityInicial - 1.0)))) '' ("equity {0} contra o inicial {1}" -f (F2 $ST.Equity), (F2 $EST.EquityInicial)) 'desempenho.md 5.3' }
    Check-Disco $DISCO_SEMANAL_GB 'desempenho.md 5.5'
}

function Get-DataUteisAtras([int]$N) {
    $d = $AGORA.Date; $k = 0
    while ($k -lt $N) { $d = $d.AddDays(-1); if ($d.DayOfWeek -ne [DayOfWeek]::Saturday -and $d.DayOfWeek -ne [DayOfWeek]::Sunday) { $k++ } }
    return $d
}

function Get-StopsDiarios([int]$Dias) {
    # datas (UTC, pelo nome do arquivo) com "CONCORDE STOP DIARIO GLOBAL" nos diarios do Expert
    $r = @()
    $dir = Join-Path $MT5_DATA 'MQL5\Logs'
    for ($i = 0; $i -le $Dias; $i++) {
        $d = $AGORA.Date.AddDays(-$i)
        $f = Join-Path $dir ($d.ToString('yyyyMMdd') + '.log')
        if (-not (Test-Path -LiteralPath $f)) { continue }
        $t = Read-TextAuto $f
        if ($t -and $t -match '(?i)CONCORDE STOP DI.RIO GLOBAL') { $r += $d }
    }
    return $r
}

function Check-Degrau {
    Write-Secao 'DEGRAU (5.6)'
    if (-not $EST.Degrau) { Add-R 'DEG.estado' 'SEM_DADO' '' '' 'STATE.md sem o degrau' 'degrau.md'; return }
    $tr = Read-Trades
    if ($EST.Degrau -eq 'B') { if (-not $script:DESCIDA_FEITA) { Check-Descida $tr }; return }
    Check-VezGuardiao
    if (-not $EST.Inicio) { Add-R 'DEG.subida' 'SEM_DADO' '' '' 'STATE.md sem "Inicio ao vivo do Concorde": criterios nao avaliados (subida: nao)' 'degrau.md'; return }
    if (-not $tr.Existe) { Add-R 'DEG.subida' 'SEM_DADO' 'trades_mfe.csv ausente' '' 'criterios 1, 2 e 6 pelo MCP, como antes' 'degrau.md'; return }
    $conta = $EST.Inicio
    if ($EST.UltimaDescida -and $EST.UltimaDescida -gt $conta) { $conta = $EST.UltimaDescida }
    $falhou = @(); $agente = @()
    # 1
    $lst = @($tr.Lista | Where-Object { $MAGICS_OK -contains $_.Magic -and $_.FechUtc -ge $conta -and $_.FechUtc -le $AGORA })
    $dias = ($AGORA - $conta).TotalDays
    $ok1 = ($lst.Count -ge $SUB_TRADES -and $dias -ge $SUB_DIAS)
    $v1 = "{0} trades em {1} dias desde {2:yyyy-MM-dd}" -f $lst.Count, (F1 $dias), $conta
    if ($EST.UltimaDescida) {
        $sd = ($AGORA - $EST.UltimaDescida).TotalDays
        $v1 += "; {0} dias desde a descida" -f (F1 $sd)
        if ($sd -lt $SUB_SEMANAS_DESCIDA) { $ok1 = $false }
    }
    if ($ok1) { Add-R 'DEG.c1_trades' 'PASSA' $v1 ">= $SUB_TRADES trades e >= $SUB_DIAS dias (8 semanas depois de descida)" '' 'degrau.md crit.1' } else { Add-R 'DEG.c1_trades' 'FALHA' $v1 ">= $SUB_TRADES trades e >= $SUB_DIAS dias (8 semanas depois de descida)" '' 'degrau.md crit.1'; $falhou += 1 }
    # 2
    $s = Get-Stats $lst
    $v2 = "PF {0} ({1} trades, {2} USC)" -f (Fmt-Pf $s.Pf), $s.N, (F2 $s.Lucro)
    if ($s.N -gt 0 -and $s.Pf -ge $SUB_PF) { Add-R 'DEG.c2_pf' 'PASSA' $v2 ">= 1,10" '' 'degrau.md crit.2' } else { Add-R 'DEG.c2_pf' 'FALHA' $v2 '>= 1,10' '' 'degrau.md crit.2'; $falhou += 2 }
    # 3
    $d8 = $AGORA.AddDays(-56); if ($d8 -lt $EST.Inicio) { $d8 = $EST.Inicio }
    $hb = @(Read-Heartbeat); $gl = @(Read-Guardiao)
    $dm = Get-DdMax $d8 $hb $gl $ST
    $agoraDd = -1.0; if ($ST) { $agoraDd = $ST.DdPct }
    $v3 = "DD max {0}% desde {1:yyyy-MM-dd} ({2} amostras do heartbeat, maior buraco {3} h); dd_pct agora {4}%" -f (F2 $dm[0]), $d8, $dm[1], (F1 $dm[2]), (F2 $agoraDd)
    $lim3 = "<= $SUB_DD% e agora < $SUB_DD_AGORA%"
    if (-not $ST -or $dm[1] -eq 0) { Add-R 'DEG.c3_dd' 'SEM_DADO' $v3 $lim3 'sem status.json ou sem heartbeat no periodo' 'degrau.md crit.3'; $falhou += 3 }
    elseif ($dm[0] -gt $SUB_DD -or $agoraDd -ge $SUB_DD_AGORA) { Add-R 'DEG.c3_dd' 'FALHA' $v3 $lim3 '' 'degrau.md crit.3'; $falhou += 3 }
    elseif ($dm[2] -gt 24) { Add-R 'DEG.c3_dd' 'SEM_DADO' $v3 $lim3 'heartbeat com buraco de mais de 24 h no periodo: o DD maximo nao pode ser confirmado (conferir os dd_pct do DIARIO.md e o guardian.log)' 'degrau.md crit.3'; $falhou += 3 }
    else { Add-R 'DEG.c3_dd' 'PASSA' $v3 $lim3 'o maior DD registrado nas acordadas (DIARIO.md) tambem conta: conferir' 'degrau.md crit.3' }
    # 4
    $halts = @($gl | Where-Object { $_.Utc -ge $EST.Inicio -and $_.Msg -match '^HALT ATIVADO' })
    if ($halts.Count -eq 0) { Add-R 'DEG.c4_halt' 'PASSA' 'nenhum HALT ATIVADO no guardian.log desde o inicio' 'nenhum' 'HALT de incidente registrado so no ALERTAS.md tambem conta: conferir' 'degrau.md crit.4' }
    else { Add-R 'DEG.c4_halt' 'FALHA' ("{0} HALT(s), o primeiro em {1:yyyy.MM.dd HH:mm} (servidor)" -f $halts.Count, $halts[0].Srv) 'nenhum' '' 'degrau.md crit.4'; $falhou += 4 }
    # 5
    $abertos = @(Read-Alertas | Where-Object { $_.Aberto -and ($_.Nivel -match 'ATENCAO|ATEN..O|CRITICO|CR.TICO') })
    if ($null -eq (Read-TextAuto (Join-Path $WS 'ALERTAS.md'))) { Add-R 'DEG.c5_incidentes' 'SEM_DADO' 'ALERTAS.md ausente ou ilegivel' 'nenhum incidente de execucao aberto' '' 'degrau.md crit.5'; $falhou += 5 }
    elseif ($abertos.Count -eq 0) { Add-R 'DEG.c5_incidentes' 'PASSA' 'nenhum alerta ATENCAO/CRITICO aberto' 'nenhum incidente de execucao aberto' '' 'degrau.md crit.5' }
    else {
        $lt = @($abertos | ForEach-Object { "[{0}] {1} {2}" -f $_.Nivel, $_.Quando, $_.Titulo })
        Add-R 'DEG.c5_incidentes' 'AGENTE' ("{0} alerta(s) aberto(s): {1}" -f $abertos.Count, ($lt -join ' ; ')) 'nenhum incidente de execucao aberto' 'decidir quais sao de execucao (conexao, terminal, EA, magic, ordem, guardiao); regime, RegimeLogger e laboratorio nao contam' 'degrau.md crit.5'
        $agente += 5
    }
    # 6
    $desde6 = $EST.Inicio
    $sl = @($tr.Lista | Where-Object { $_.Motivo -eq 'SL' -and $_.FechUtc -ge $desde6 -and $_.FechUtc -le $AGORA })
    $slE1 = @($sl | Where-Object { $_.Estrategia -eq 'E1' }); $slE3 = @($sl | Where-Object { $_.Estrategia -eq 'E3' })
    $lim6 = 'media <= 1,5 x (0,124 nE1 + 0,568 nE3)/(nE1+nE3); nE1 >= 10 e nE3 >= 5'
    if ($slE1.Count -lt $SUB_NE1 -or $slE3.Count -lt $SUB_NE3) {
        Add-R 'DEG.c6_slippage' 'FALHA' ("saidas por SL: E1 {0}, E3 {1}" -f $slE1.Count, $slE3.Count) $lim6 'criterio ainda sem amostra: nao passa' 'degrau.md crit.6'; $falhou += 6
    } else {
        $niveis = @{}
        if ($Slippage) {
            if (-not (Test-Path -LiteralPath $Slippage)) { Add-R 'DEG.c6_slippage' 'SEM_DADO' $Slippage '' 'arquivo -Slippage nao encontrado' 'degrau.md crit.6'; $falhou += 6; return (Fim-Degrau $falhou $agente) }
            # Import-Csv aceita aspas e a linha #TYPE do Export-Csv; colunas pelo nome
            foreach ($r in @(Import-Csv -LiteralPath $Slippage -Delimiter ';')) {
                $tk = "$($r.ticket)".Trim().Trim('"')
                if ($tk) { $niveis[$tk] = To-Num "$($r.nivel_sl)".Trim().Trim('"') -1 }
            }
        }
        $slips = @(); $faltam = @(); $e1s = @(); $e3s = @(); $suspeitas = @()
        foreach ($x in $sl) {
            $nivel = -1.0
            if ($niveis.ContainsKey("$($x.Ticket)".Trim())) { $nivel = $niveis["$($x.Ticket)".Trim()] }
            elseif ($x.Estrategia -eq 'E1' -and $x.SlIni -gt 0) {
                $nivel = $x.SlIni
                if ($x.RiscoUsd -gt 0 -and [Math]::Abs($x.Saida - $x.SlIni) -gt 0.3 * $x.RiscoUsd) { $suspeitas += $x.Ticket; $nivel = -1.0 }
            }
            if ($nivel -le 0) { $faltam += ("{0}({1})" -f $x.Ticket, $x.Estrategia); continue }
            $sv = ($nivel - $x.Saida) * $x.Dir
            $slips += $sv
            if ($x.Estrategia -eq 'E1') { $e1s += $sv } else { $e3s += $sv }
        }
        if ($faltam.Count -gt 0) {
            Add-R 'DEG.c6_slippage' 'AGENTE' ("sem o nivel do SL em {0} saida(s): {1}" -f $faltam.Count, ($faltam -join ' ')) $lim6 'montar o CSV -Slippage (ticket;estrategia;nivel_sl;preco_saida;dir) com o [sl X] das ordens de saida (get_trading_history_orders) e rodar de novo' 'degrau.md crit.6'
            $agente += 6
        } else {
            $nE1 = $e1s.Count; $nE3 = $e3s.Count
            $limite = $SLIP_FATOR * ($SLIP_E1 * $nE1 + $SLIP_E3 * $nE3) / ($nE1 + $nE3)
            $media = ($slips | Measure-Object -Average).Average
            $m1 = 0.0; if ($nE1) { $m1 = ($e1s | Measure-Object -Average).Average }
            $m3 = 0.0; if ($nE3) { $m3 = ($e3s | Measure-Object -Average).Average }
            $v6 = "media {0} USD/oz (E1 {1} em {2}; E3 {3} em {4})" -f $media.ToString('0.000', $CI), $m1.ToString('0.000', $CI), $nE1, $m3.ToString('0.000', $CI), $nE3
            if ($media -le $limite) { Add-R 'DEG.c6_slippage' 'PASSA' $v6 ("<= {0}" -f $limite.ToString('0.000', $CI)) '' 'degrau.md crit.6' }
            else { Add-R 'DEG.c6_slippage' 'FALHA' $v6 ("<= {0}" -f $limite.ToString('0.000', $CI)) '' 'degrau.md crit.6'; $falhou += 6 }
        }
    }
    Fim-Degrau $falhou $agente
}

function Fim-Degrau($Falhou, $Agente) {
    if (@($Falhou).Count -gt 0) { Add-R 'DEG.subida' 'FALHA' ("criterio(s) {0}" -f (@($Falhou) -join ', ')) 'todos' 'subida: nao (fechar alerta de subida aberto, se houver)' 'degrau.md' }
    elseif (@($Agente).Count -gt 0) { Add-R 'DEG.subida' 'AGENTE' ("criterio(s) {0} dependem do agente" -f (@($Agente) -join ', ')) 'todos' 'os demais passaram' 'degrau.md' }
    else { Add-R 'DEG.subida' 'PASSA' 'os 6 criterios passaram' 'todos' 'alerta AGUARDANDO OK DO HENRIQUE com a tabela e a linha OK DEGRAU B' 'degrau.md' }
}

function Check-Regime {
    Write-Secao 'REGIME (5.7)'
    Check-RegimeArquivo
    if ($EST.RegimeInstalado -ne $true) { return }
    $rg = Read-Regime
    $ls = @($rg.Linhas)
    if ($ls.Count -eq 0) { return }
    $ult = $ls[$ls.Count - 1]
    if ($ult.Vol20 -lt 0) { Add-R 'REGIME.nivel' 'SEM_DADO' ("vol20 vazio na linha de {0:yyyy-MM-dd}" -f $ult.Data) '' 'coluna vol20_pct vazia na ultima linha: regime sem dado; alertas de regime ficam como estao' 'regime.md'; return }
    if ((Get-DiasUteis $ult.Data $AGORA) -gt $REG_ATRASO_UTEIS) { Add-R 'REGIME.nivel' 'SEM_DADO' 'regime sem dado' '' 'sem linha recente: itens 2 a 5 nao avaliados; alertas de regime ficam como estao' 'regime.md'; return }
    $s14 = 0; $s12 = 0
    for ($i = $ls.Count - 1; $i -ge 0; $i--) { if ($ls[$i].Vol20 -ge 0 -and $ls[$i].Vol20 -lt $REG_FRACO) { $s14++ } else { break } }
    for ($i = $ls.Count - 1; $i -ge 0; $i--) { if ($ls[$i].Vol20 -ge 0 -and $ls[$i].Vol20 -lt $REG_MUITO_FRACO) { $s12++ } else { break } }
    $sem = @($ls | Where-Object { $_.Data -gt $AGORA.Date.AddDays(-7) -and $_.Vol20 -ge 0 })
    $mn = '-'; $mx = '-'
    if ($sem.Count -gt 0) { $mn = F2 (($sem | Measure-Object -Property Vol20 -Minimum).Minimum); $mx = F2 (($sem | Measure-Object -Property Vol20 -Maximum).Maximum) }
    $v = "vol20 {0}% em {1:yyyy-MM-dd}; dias seguidos < 1,40%: {2}; < 1,20%: {3}; semana min {4}% max {5}%" -f (F2 $ult.Vol20), $ult.Data, $s14, $s12, $mn, $mx
    if ($ult.Vol20 -lt $REG_MUITO_FRACO) {
        $txt = 'regime fraco: ATENCAO para E1 e AGUARDANDO OK recomendando RISK_SCALE 0.5 (nunca aplicar sozinho)'
        if ($ST -and $ST.RiskScale -le 0.5001) { $txt = 'regime fraco: ATENCAO para E1; escala ja em 0,5 ou menos: registrar, sem pedido' }
        Add-R 'REGIME.nivel' 'ATENCAO' $v '>= 1,40% (E1) / >= 1,20% (reducao)' $txt 'regime.md'
    } elseif ($ult.Vol20 -lt $REG_FRACO) { Add-R 'REGIME.nivel' 'ATENCAO' $v '>= 1,40%' 'regime fraco para E1: ATENCAO (ou linha de Estado no alerta aberto); nada a pedir' 'regime.md' }
    else { Add-R 'REGIME.nivel' 'PASSA' $v '>= 1,40%' '' 'regime.md' }
    $ult5 = @($ls | Select-Object -Last $REG_DIAS_FECHAR)
    $fechar = ($ult5.Count -eq $REG_DIAS_FECHAR -and @($ult5 | Where-Object { $_.Vol20 -lt $REG_FRACO }).Count -eq 0)
    $abertosReg = @(Read-Alertas | Where-Object { $_.Aberto -and $_.Titulo -match '(?i)regime fraco' })
    if ($fechar -and $abertosReg.Count -gt 0) { Add-R 'REGIME.fechamento' 'ATENCAO' ("{0} alerta(s) de regime aberto(s)" -f $abertosReg.Count) '5 dias >= 1,40%' ("fechar com Estado: FECHADO (vol20 >= 1,40% por 5 dias: {0}) + notify" -f (($ult5 | ForEach-Object { F2 $_.Vol20 }) -join ', ')) 'regime.md' }
    elseif ($abertosReg.Count -gt 0) { Add-R 'REGIME.fechamento' 'INFO' ("{0} alerta(s) de regime aberto(s)" -f $abertosReg.Count) '5 dias >= 1,40%' 'ainda nao fecha: linha de Estado com os numeros atualizados' 'regime.md' }
    if ($EST.RiskRegime) { Add-R 'REGIME.escala' 'INFO' $EST.RiskTxt '' '0,5 FIXO do regime: nunca mandar RISK_SCALE AUTO, nem pela descida' 'regime.md' }
}

function Check-Preabertura {
    Write-Secao 'PRE-ABERTURA (maquina e noticias)'
    # relogio
    $off = $null
    try {
        $w = (& w32tm.exe /query /status 2>&1) -join "`n"
        $m = [regex]::Match($w, '(?im)^(Phase Offset|Deslocamento de fase|Deslocamento da fase)\s*:\s*([-+]?[0-9]+(?:[.,][0-9]+)?)s')
        if ($m.Success) { $off = To-Num $m.Groups[2].Value 999 }
    } catch { }
    if ($null -eq $off) { Add-R 'PRE.relogio' 'AGENTE' '' "< $RELOGIO_MAX_S s" 'w32tm /query /status sem "Phase Offset" legivel: conferir a mao' 'preabertura' }
    elseif ([Math]::Abs($off) -lt $RELOGIO_MAX_S) { Add-R 'PRE.relogio' 'PASSA' ("{0} s" -f $off.ToString('0.000', $CI)) "< $RELOGIO_MAX_S s" '' 'preabertura' }
    else { Add-R 'PRE.relogio' 'ATENCAO' ("{0} s" -f $off.ToString('0.000', $CI)) "< $RELOGIO_MAX_S s" 'relogio fora: registrar para o Henrique' 'preabertura' }
    # reinicio pendente
    $pend = $false
    try { $pend = Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired' } catch { }
    if ($pend) { Add-R 'PRE.reinicio' 'ATENCAO' 'RebootRequired presente' 'ausente' 'reinicio pendente: registrar para o Henrique decidir; nunca reiniciar o Windows' 'preabertura' }
    else { Add-R 'PRE.reinicio' 'PASSA' 'sem reinicio pendente' 'ausente' '' 'preabertura' }
    # news.csv (fallback e tester)
    $nf = Join-Path (Join-Path $env:APPDATA 'MetaQuotes\Terminal\Common\Files') 'news.csv'
    if (-not (Test-Path -LiteralPath $nf)) { Add-R 'PRE.news_csv' 'ATENCAO' 'news.csv ausente em Common\Files' '' 'pendencia para o Henrique' 'preabertura' }
    else {
        $max = [DateTime]::MinValue
        foreach ($l in [IO.File]::ReadAllLines($nf)) {
            $c = $l.Split(',')
            if ($c.Count -lt 3) { continue }
            $d = [DateTime]::MinValue
            if ([DateTime]::TryParseExact($c[2].Trim(), 'MM-dd-yyyy', $CI, [Globalization.DateTimeStyles]::None, [ref]$d)) { if ($d -gt $max) { $max = $d } }
        }
        $fimMes = New-Object DateTime($AGORA.Year, $AGORA.Month, [DateTime]::DaysInMonth($AGORA.Year, $AGORA.Month))
        if ($max -ge $fimMes) { Add-R 'PRE.news_csv' 'PASSA' ("ultimo evento {0:yyyy-MM-dd}" -f $max) (">= {0:yyyy-MM-dd}" -f $fimMes) '' 'preabertura' }
        else { Add-R 'PRE.news_csv' 'ATENCAO' ("ultimo evento {0:yyyy-MM-dd}" -f $max) (">= {0:yyyy-MM-dd}" -f $fimMes) 'news.csv vencido: pendencia para o Henrique' 'preabertura' }
    }
    Add-R 'PRE.noticias' 'AGENTE' '' 'eventos > 0' 'calendario nativo: linha FILTRO NOTICIAS Concorde com eventos > 0; listar os eventos de impacto alto de USD/EUR/JPY/AUD/CAD da semana' 'preabertura'
    Check-Disco $DISCO_SEMANAL_GB 'preabertura'
}

function Check-Autoteste {
    Write-Secao 'AUTOTESTE (o que o script consegue ler)'
    foreach ($k in @('Degrau', 'G45Descida', 'RiskTxt', 'RiskEscala', 'RiskManual', 'RiskRegime', 'RiskHisterese', 'OkDegrau', 'UltimaDescida', 'Inicio', 'EquityInicial', 'RegimeInstalado', 'OkAlternativa')) {
        $v = $EST[$k]
        if ($v -is [DateTime]) { $v = $v.ToString('yyyy-MM-dd HH:mm') }
        if ($null -eq $v) { $v = '(nulo)' }
        Add-R ("ESTADO.{0}" -f $k) 'INFO' $v '' '' 'STATE.md'
    }
    $arqs = @(@('status.json', $STATUS_FILE), @('guardian.log', $GUARDIAN_LOG), @('heartbeat.log', (Join-Path $LOG_DIR 'heartbeat.log')), @('regime.csv', (Join-Path $SURV_DIR 'regime.csv')), @('trades_mfe.csv', (Join-Path $SURV_DIR 'trades_mfe.csv')), @('ALERTAS.md', (Join-Path $WS 'ALERTAS.md')), @('snapshot', (Join-Path $WS "ops\profile\$PROFILE_NAME")))
    foreach ($a in $arqs) {
        if (Test-Path -LiteralPath $a[1]) { Add-R ("ARQ.{0}" -f $a[0]) 'PASSA' $a[1] '' 'existe' '' } else { Add-R ("ARQ.{0}" -f $a[0]) 'ATENCAO' $a[1] '' 'nao encontrado' '' }
    }
    $tr = Read-Trades
    Add-R 'ARQ.trades_linhas' 'INFO' ("{0} validas, {1} invalidas" -f $tr.Linhas, $tr.Invalidas) '' '' ''
    Add-R 'ARQ.heartbeat_linhas' 'INFO' ("{0} linhas com dd=" -f @(Read-Heartbeat).Count) '' '' ''
    Add-R 'ARQ.alertas' 'INFO' ("{0} alertas, {1} abertos" -f @(Read-Alertas).Count, @(Read-Alertas | Where-Object { $_.Aberto }).Count) '' '' ''
    $snap = Read-Snapshot
    Add-R 'ARQ.snapshot' 'INFO' ("{0} arquivo(s): Concorde {1}, guardiao {2}, RegimeLogger {3}, outros {4}" -f $snap.Arquivos, @($snap.Concorde).Count, @($snap.Guardiao).Count, @($snap.Regime).Count, @($snap.Outros).Count) '' '' ''
}

# --- Execucao ------------------------------------------------------------------------------------
try {
    switch ($Acao) {
        'saude'       { Check-Saude 'saude' }
        'incidente'   { Check-Saude 'incidente'; Check-Reinicios }
        'numeros'     { Check-Numeros }
        'diario'      { Check-Saude 'diario'; Check-Numeros }
        'semanal'     { Check-Saude 'semanal'; Check-Numeros; Check-Desempenho; Check-Regime; Check-Degrau }
        'preabertura' { Check-Saude 'preabertura'; Check-Preabertura; Check-VezGuardiao }
        'desempenho'  { Check-Desempenho }
        'degrau'      { Check-Degrau }
        'regime'      { Check-Regime }
        'autoteste'   { Check-Autoteste }
    }
} catch {
    Write-Host ("ERRO do checar.ps1: {0} (linha {1})" -f $_.Exception.Message, $_.InvocationInfo.ScriptLineNumber)
    exit 1
}

$cont = @{}
foreach ($r in $RES) { if (-not $cont.ContainsKey($r.veredito)) { $cont[$r.veredito] = 0 }; $cont[$r.veredito]++ }
$ruins = 0
foreach ($k in @('FALHA', 'ATENCAO', 'SEM_DADO')) { if ($cont.ContainsKey($k)) { $ruins += $cont[$k] } }
$resumo = (@('PASSA', 'FALHA', 'ATENCAO', 'SEM_DADO', 'AGENTE', 'INFO') | ForEach-Object { $n = 0; if ($cont.ContainsKey($_)) { $n = $cont[$_] }; "{0} {1}" -f $n, $_ }) -join ', '
Write-Host ''
if ($ruins -eq 0) { Write-Host ("RESULTADO {0}: OK ({1})" -f $Acao, $resumo) } else { Write-Host ("RESULTADO {0}: VER ({1})" -f $Acao, $resumo) }
if (-not $SemJson) {
    try {
        Ensure-Dir $LOG_DIR
        $jf = Join-Path $LOG_DIR ("checar_{0}_{1}.json" -f $Acao, [DateTime]::UtcNow.ToString('yyyyMMdd_HHmmss'))
        $obj = New-Object PSObject -Property ([ordered]@{ acao = $Acao; agora_utc = $AGORA.ToString('yyyy-MM-dd HH:mm'); degrau = $DEGRAU_TXT; resultados = $RES.ToArray() })
        [IO.File]::WriteAllText($jf, ($obj | ConvertTo-Json -Depth 4), (New-Object Text.UTF8Encoding($false)))
        Write-Host "relatorio: $jf"
    } catch { Write-Host ("AVISO: nao gravei o JSON: {0}" -f $_.Exception.Message) }
}
if ($ruins -gt 0) { exit 2 }
exit 0
