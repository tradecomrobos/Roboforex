# =====================================================================
#  lab.ps1 - laboratorio de testes do kit Sobrevivencia (CLAUDE.md 5.9)
#  Roda backtests do Concorde_RF numa COPIA de tester separada ($LAB_DIR), logada numa conta DEMO,
#  so com o ouro fechado (sab 04:30 a dom 17:30 UTC), um teste por vez, dentro de um Job Object com
#  limite de memoria. Gera, por lote, um relatorio deterministico com as alternativas classificadas e,
#  para as aprovadas, o .set pronto. NUNCA aplica nada: quem aplica e o Henrique (OK ALTERNATIVA).
#
#  Acoes:
#   -Acao status      (padrao) estado da copia, do lock, dos lotes e das candidatas. Somente leitura.
#   -Acao parar       encerra o lab.ps1 em execucao e os processos da copia (pelo caminho). Permitido ao agente.
#   -Acao agendado    tarefa Sobrevivencia-Lab (a cada 30 min): fora da janela so vigia; dentro, relanca o
#                     executor destacado (Start-Detached) se nao houver um vivo. Recusado ao agente.
#   -Acao executar    o executor: sonda semanal, lote trimestral, fila, analise. Recusado ao agente.
#   -Acao conferir -Proposta <arquivo.set>   (Henrique, antes de aplicar) confere a proposta contra o lote e
#                     o grafico ao vivo (snapshot do perfil): so chaves da lista branca, sem aumento de risco.
#   -Acao relatorio -Lote <id>               refaz a analise de um lote ja rodado. Recusado ao agente.
#  -Local (so na estacao do Henrique, sem terminal ao vivo na maquina): ignora janela e checagens do ao vivo;
#   exige -LabDir, -LabLogin e -Ws. -TesteJanela 'AAAA.MM.DD-AAAA.MM.DD' cria um lote curto de teste.
#
#  O agente (SURV_AGENTE=1 ou CLAUDECODE) so pode usar status e parar; pedidos de teste vao pela fila
#  (campanha\lab\fila\*.json, CLAUDE.md 5.9). Arquivo ASCII de proposito (PowerShell 5.1 le .ps1 sem BOM como ANSI).
# =====================================================================
param(
    [ValidateSet('status', 'parar', 'agendado', 'executar', 'conferir', 'relatorio')]
    [string]$Acao = 'status',
    [string]$Lote = '',
    [string]$Proposta = '',
    [switch]$Local,
    [string]$LabDir = '',
    [long]$LabLogin = 0,
    [string]$Ws = '',
    [string]$TesteJanela = '',
    [switch]$SemFamilia,
    [string]$SoVariantes = '',
    [int]$SegMeses = -1
)
$ErrorActionPreference = 'Stop'
# $Ws e $WS sao a MESMA variavel (PowerShell nao diferencia maiusculas): guardar os parametros antes do config
$wsArg = $Ws; $labDirArg = $LabDir; $labLoginArg = $LabLogin
. "$PSScriptRoot\config.ps1"
. "$PSScriptRoot\common.ps1"
$ORIGEM = 'lab'
$CI = [Globalization.CultureInfo]::InvariantCulture

# --- defaults (config antigo sem as variaveis do lab) -------------------------------------------
if (-not $LAB_DIR) { $LAB_DIR = 'C:\MT5_RF_Lab' }
if ($null -eq $LAB_LOGIN) { $LAB_LOGIN = 0 }
if (-not $LAB_SERVER) { $LAB_SERVER = 'RoboForex-Pro' }
if (-not $LAB_PORT) { $LAB_PORT = 3500 }
if (-not $LAB_MEM_LIMIT_MB) { $LAB_MEM_LIMIT_MB = 2500 }
if (-not $LAB_RAM_FOLGA_MB) { $LAB_RAM_FOLGA_MB = 1000 }
if (-not $LAB_RAM_MIN_MB) { $LAB_RAM_MIN_MB = 700 }
if (-not $LAB_CPUS) { $LAB_CPUS = 2 }
if (-not $LAB_DISCO_MIN_GB) { $LAB_DISCO_MIN_GB = 15 }
if (-not $LAB_STATUS_MAX_SEC) { $LAB_STATUS_MAX_SEC = 60 }
if (-not $LAB_RUN_TIMEOUT_MIN) { $LAB_RUN_TIMEOUT_MIN = 180 }
if ($null -eq $LAB_SEGMENTO_MESES) { $LAB_SEGMENTO_MESES = 6 }

# --- agente: so status e parar ------------------------------------------------------------------
$ehAgente = (($env:SURV_AGENTE -eq '1') -or ([bool]$env:CLAUDECODE))
if ($ehAgente -and $Acao -notin @('status', 'parar')) {
    Write-Host "RECUSADO: o agente so usa 'status' e 'parar'. Pedidos de teste vao pela fila (campanha\lab\fila\*.json, CLAUDE.md 5.9)."
    try { Write-OpsLog ("RECUSADO ao agente: -Acao {0}" -f $Acao) $ORIGEM } catch { }
    exit 1
}

# --- modo local (estacao do Henrique) -----------------------------------------------------------
if (-not $Local -and ($TesteJanela -or $SemFamilia -or $SoVariantes -or $SegMeses -ge 0 -or $labDirArg -or $labLoginArg -or $wsArg)) {
    Write-Host 'RECUSADO: -TesteJanela, -SemFamilia, -SoVariantes, -SegMeses, -LabDir, -LabLogin e -Ws so valem com -Local (estacao).'; exit 1
}
if ($Local) {
    if (Test-Path -LiteralPath $MT5_EXE) { Write-Host "RECUSADO: -Local nao roda numa maquina com o terminal ao vivo ($MT5_EXE)."; exit 1 }
    if (-not $labDirArg -or -not $labLoginArg -or -not $wsArg) { Write-Host 'RECUSADO: -Local exige -LabDir, -LabLogin e -Ws.'; exit 1 }
    $LAB_DIR = $labDirArg; $LAB_LOGIN = $labLoginArg; $WS = $wsArg
    $LOG_DIR = "$WS\ops\logs"; $PROMPTS_DIR = "$WS\prompts"
    if ($SegMeses -ge 0) { $LAB_SEGMENTO_MESES = $SegMeses }
}
$LAB_DIR = ([string]$LAB_DIR).TrimEnd('\')
$LAB_WS = "$WS\campanha\lab"
$FILA_DIR = "$LAB_WS\fila"
$LOTES_DIR = "$LAB_WS\lotes"
$NEWS_EXTRA_DIR = "$LAB_WS\news"
$REGISTRO = "$LOTES_DIR\registro.json"
$LAB_LOG = Join-Path $LOG_DIR 'lab.log'
$LOCK = Join-Path $LOG_DIR 'lab.lock'
$COMMON_FILES = Join-Path $env:APPDATA 'MetaQuotes\Terminal\Common\Files'
$NEWS_LAB = 'news_lab_srv.csv'
Ensure-Dir $LOG_DIR

function Log([string]$m) {
    Write-OpsLog $m $ORIGEM $LAB_LOG
    Write-OpsLog $m $ORIGEM
    Write-Host ("{0} {1}" -f (Get-UtcStamp), $m)
}

function Notify([string]$Nivel, [string]$Titulo, [string]$Corpo) {
    if ($Local) { Write-Host "[notify $Nivel] $Titulo - $Corpo"; return }
    try { & (Join-Path $PSScriptRoot 'notify.ps1') -Nivel $Nivel -Titulo $Titulo -Corpo $Corpo | Out-Null } catch { }
}

function Assert-LabPath([string]$Path) {
    # Toda escrita, copia e encerramento de processo do lab passa por aqui: o caminho tem de estar DENTRO de
    # $LAB_DIR e nunca dentro de $MT5_DIR (terminal ao vivo).
    $full = [IO.Path]::GetFullPath($Path).ToLower()
    $lab = ($LAB_DIR + '\').ToLower()
    $vivo = (([string]$MT5_DIR).TrimEnd('\') + '\').ToLower()
    if (-not $full.StartsWith($lab) -or $full.StartsWith($vivo) -or $lab -eq $vivo -or $LAB_DIR.Length -lt 4) { throw "caminho fora da copia de tester: $Path" }
    # nenhum diretorio entre a copia e o alvo pode ser junction/link (apagar o cache nao pode alcancar o ao vivo)
    $d = [IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($Path))
    while ($d -and $d.Length -ge $LAB_DIR.Length) {
        if (Test-Path -LiteralPath $d) { if ((Get-Item -LiteralPath $d -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "junction/link dentro da copia: $d" } }
        $d = [IO.Path]::GetDirectoryName($d)
    }
}

function Get-Hash([string]$Path, [string]$Alg = 'MD5') {
    return (Get-FileHash -LiteralPath $Path -Algorithm $Alg).Hash
}

function Save-Json($Obj, [string]$Path) {
    $txt = $Obj | ConvertTo-Json -Depth 12
    $tmp = "$Path.tmp"
    [IO.File]::WriteAllText($tmp, $txt, (New-Object Text.UTF8Encoding($false)))
    Move-Item -LiteralPath $tmp -Destination $Path -Force
}

function Load-Json([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    return ([IO.File]::ReadAllText($Path) | ConvertFrom-Json)
}

function F([double]$v, [string]$fmt = '0.00') {
    if ([double]::IsNaN($v) -or [double]::IsInfinity($v)) { return '-' }
    return $v.ToString($fmt, $CI)
}

# --- datas, fuso do servidor (regra europeia: GMT+2 no inverno, GMT+3 no verao) ------------------
function Get-LastSunday([int]$Ano, [int]$Mes) {
    $d = New-Object DateTime($Ano, $Mes, [DateTime]::DaysInMonth($Ano, $Mes), 0, 0, 0, [DateTimeKind]::Utc)
    while ($d.DayOfWeek -ne [DayOfWeek]::Sunday) { $d = $d.AddDays(-1) }
    return $d
}
function Test-EuDst([DateTime]$Utc) {
    $ini = (Get-LastSunday $Utc.Year 3).AddHours(1)
    $fim = (Get-LastSunday $Utc.Year 10).AddHours(1)
    return ($Utc -ge $ini -and $Utc -lt $fim)
}
function Get-SrvOffset([DateTime]$DataServidor) {
    # mesmo criterio do Concorde no tester (Concorde_SrvGmtOffset: GMT aproximado com o fuso de inverno)
    if (Test-EuDst ($DataServidor.AddHours(-2))) { return 3 }
    return 2
}
function D([string]$s) { return [DateTime]::ParseExact($s, 'yyyy.MM.dd', $CI) }
function DS([DateTime]$d) { return $d.ToString('yyyy.MM.dd', $CI) }

function Get-TrimestreAnterior([DateTime]$Utc) {
    # trimestre civil completo mais recente: {id, fim}
    $q = [int][Math]::Floor(($Utc.Month - 1) / 3)          # 0..3 = trimestre corrente
    $ano = $Utc.Year; $qa = $q - 1
    if ($qa -lt 0) { $qa = 3; $ano-- }
    $fim = (New-Object DateTime($ano, ($qa * 3 + 3), 1)).AddMonths(1).AddDays(-1)
    return New-Object PSObject -Property @{ Id = ('{0}Q{1}' -f $ano, ($qa + 1)); Fim = $fim }
}

function Get-Segmentos([DateTime]$De, [DateTime]$Ate) {
    $r = @()
    if ($LAB_SEGMENTO_MESES -le 0) { return @(, @($De, $Ate)) }
    $ini = $De
    while ($ini -le $Ate) {
        $fim = $ini.AddMonths($LAB_SEGMENTO_MESES).AddDays(-1)
        if ($fim -gt $Ate) { $fim = $Ate }
        $r += , @($ini, $fim)
        $ini = $fim.AddDays(1)
    }
    return $r
}

# --- nucleo C# --------------------------------------------------------------------------------
$script:coreOk = $false
function Import-LabCore {
    if ($script:coreOk) { return }
    if (-not ('SurvLab.Rpt' -as [type])) {
        Add-Type -TypeDefinition ([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'lab_core.cs'))) -Language CSharp -ReferencedAssemblies System.Core
    }
    $script:coreOk = $true
}

# --- lista branca e familia padrao -------------------------------------------------------------
# tipo: i (inteiro), d (decimal), b (bool); faixa [min, max]; 'reduz' = so pode ficar <= o valor da base
$LISTA_BRANCA = [ordered]@{
    'E1_HoraSaidaGMT_Minutos'   = @('i', 420, 780)
    'E1_BufferRompimentoPips'   = @('i', 'base', 110)
    'E1_AlvoPerna1_R'           = @('d', 2.0, 8.0)
    'E1_AlvoPerna2_R'           = @('d', 2.0, 8.0)
    'E1_TakeProfitMinimoR'      = @('d', 1.0, 5.0)
    'E3_StopLossXAtr'           = @('d', 3.0, 9.0)
    'E3_AlvoPerna1_R'           = @('d', 1.5, 6.0)
    'E3_AlvoPerna2_R'           = @('d', 2.0, 8.0)
    'E3_SessaoLondres_FimGMT'   = @('i', 9, 12)
    'E3_MinRangeAsiaXAtr'       = @('d', 0.0, 5.0)
    'E3_AtivarBreakEven'        = @('b', 0, 0)
    'E3_BreakEvenBufferPips'    = @('d', 0.0, 50.0)
    'E3_AtivarTrailingStop'     = @('b', 0, 0)
    'E3_TrailingIncrementoPontos' = @('d', 5.0, 100.0)
    'E3_AtivarAtrDinamico'      = @('b', 0, 0)
    'E3_AtivarFechamentoFimDia' = @('b', 0, 0)
    'E3_HoraFechamentoServidor' = @('i', 12, 23)
    'News_MinutesBefore'        = @('i', 0, 60)
    'News_MinutesAfter'         = @('i', 0, 60)
    'News_CloseTrades'          = @('b', 0, 0)
    'Concorde_MaxPernasMesmaDir' = @('i', 1, 'reduz')
    'E1_RiscoPorPernaPct'       = @('d', 0.05, 'reduz')
    'E3_RiscoPorPernaPct'       = @('d', 0.05, 'reduz')
    'Estrategia1_Ativada'       = @('b', 0, 'reduz')
    'Estrategia3_Ativada'       = @('b', 0, 'reduz')
}
# chaves que o lab fixa so no tester (infra): nunca entram numa proposta nem vem da fila
$INFRA = @('Panel_Mostrar', 'E2_MostrarStatusGrafico', 'News_Source', 'News_CsvFileName', 'News_CsvCommonFolder', 'News_SourceGMTOffset',
    'News_CsvFormat', 'News_CsvDelimiter', 'E4_Use1', 'E4_Use2', 'E4_Use3', 'E4_Use4')

function Get-FamiliaV1($Base) {
    # Familia padrao v1 (29/09/2026; muda so com OK do Henrique). Vizinhos de 1 passo nas alavancas que decidem o
    # resultado: stop, alvo longo e trailing da E3; horario de saida da E1 (saida dominante: 520 de 938 pernas);
    # janela de noticias (saida dominante da E3: 481 de 670 pernas). Stop da E3 com o MESMO lote do controle
    # (risco x 4,5/6), ou comparado com o controle escalado (7,5), para nao medir alavancagem.
    $sl = ConvertTo-Num $Base['E3_StopLossXAtr'] 6.0
    $r3 = ConvertTo-Num $Base['E3_RiscoPorPernaPct'] 1.2
    $f = @()
    $f += [pscustomobject]@{ id = 'E3_SL45'; serie = 'E3'; escala = 1.0; overrides = [ordered]@{ E3_StopLossXAtr = '4.5'; E3_RiscoPorPernaPct = (F ($r3 * 4.5 / $sl) '0.00') } }
    $f += [pscustomobject]@{ id = 'E3_SL75'; serie = 'E3'; escala = [Math]::Round($sl / 7.5, 6); overrides = [ordered]@{ E3_StopLossXAtr = '7.5' } }
    $f += [pscustomobject]@{ id = 'E3_TPM'; serie = 'E3'; escala = 1.0; overrides = [ordered]@{ E3_AlvoPerna1_R = '3.5'; E3_AlvoPerna2_R = '5.0' } }
    $f += [pscustomobject]@{ id = 'E3_TRAIL0'; serie = 'E3'; escala = 1.0; overrides = [ordered]@{ E3_AtivarTrailingStop = 'false' } }
    $f += [pscustomobject]@{ id = 'E1_S540'; serie = 'E1'; escala = 1.0; overrides = [ordered]@{ E1_HoraSaidaGMT_Minutos = '540' } }
    $f += [pscustomobject]@{ id = 'E1_S660'; serie = 'E1'; escala = 1.0; overrides = [ordered]@{ E1_HoraSaidaGMT_Minutos = '660' } }
    $f += [pscustomobject]@{ id = 'NEWS5'; serie = 'total'; escala = 1.0; overrides = [ordered]@{ News_MinutesBefore = '5' } }
    $f += [pscustomobject]@{ id = 'NEWS20'; serie = 'total'; escala = 1.0; overrides = [ordered]@{ News_MinutesBefore = '20' } }
    return $f
}

function Test-Overrides($Ov, $Base) {
    # valida e NORMALIZA overrides (vindos da fila ou da familia). Devolve @(ok, mensagem, ordered normalizado).
    $out = [ordered]@{}
    foreach ($k in @($Ov.Keys)) {
        if (-not $LISTA_BRANCA.Contains($k)) { return @($false, "input fora da lista branca: $k", $null) }
        $regra = $LISTA_BRANCA[$k]; $v = "$($Ov[$k])".Trim()
        if (-not $Base.Contains($k)) { return @($false, "input $k nao existe na base", $null) }
        switch ($regra[0]) {
            'b' {
                $vl = $v.ToLower()
                if ($vl -ne 'true' -and $vl -ne 'false') { return @($false, "$k deve ser true/false", $null) }
                if ($regra[2] -eq 'reduz' -and $vl -eq 'true' -and ("$($Base[$k])".ToLower() -ne 'true')) { return @($false, "$k so pode desligar", $null) }
                $out[$k] = $vl
            }
            default {
                $x = 0.0
                if (-not [double]::TryParse($v, [Globalization.NumberStyles]::Float, $CI, [ref]$x) -or [double]::IsNaN($x) -or [double]::IsInfinity($x)) { return @($false, "$k nao numerico", $null) }
                $max = $regra[2]; $min = $regra[1]
                if ($max -eq 'reduz') { $max = ConvertTo-Num $Base[$k] 0 }
                if ($min -eq 'base') { $min = ConvertTo-Num $Base[$k] 0 }
                if ($x -lt [double]$min - 1e-9 -or $x -gt [double]$max + 1e-9) { return @($false, ("{0}={1} fora da faixa [{2}, {3}]" -f $k, $v, $min, $max), $null) }
                if ($regra[0] -eq 'i') {
                    if ([Math]::Abs($x - [Math]::Round($x)) -gt 1e-9) { return @($false, "$k deve ser inteiro", $null) }
                    $out[$k] = ([long][Math]::Round($x)).ToString($CI)
                } else { $out[$k] = $x.ToString('0.######', $CI) }
            }
        }
    }
    # coerencia: alvo minimo da E1 abaixo dos dois alvos
    $tmin = ConvertTo-Num $(if ($out.Contains('E1_TakeProfitMinimoR')) { $out['E1_TakeProfitMinimoR'] } else { $Base['E1_TakeProfitMinimoR'] }) 3
    $a1 = ConvertTo-Num $(if ($out.Contains('E1_AlvoPerna1_R')) { $out['E1_AlvoPerna1_R'] } else { $Base['E1_AlvoPerna1_R'] }) 4.5
    $a2 = ConvertTo-Num $(if ($out.Contains('E1_AlvoPerna2_R')) { $out['E1_AlvoPerna2_R'] } else { $Base['E1_AlvoPerna2_R'] }) 5
    if ($tmin -gt [Math]::Min($a1, $a2) + 1e-9) { return @($false, 'E1_TakeProfitMinimoR acima de um alvo da E1 (o alvo efetivo seria o minimo)', $null) }
    # o lote da E3 e proporcional a risco / distancia do SL: SL mais curto com o mesmo risco = lote maior (alavancagem)
    $rb = ConvertTo-Num $Base['E3_RiscoPorPernaPct'] 1; $rv = ConvertTo-Num $(if ($out.Contains('E3_RiscoPorPernaPct')) { $out['E3_RiscoPorPernaPct'] } else { $Base['E3_RiscoPorPernaPct'] }) $rb
    $sb = ConvertTo-Num $Base['E3_StopLossXAtr'] 6; $sv = ConvertTo-Num $(if ($out.Contains('E3_StopLossXAtr')) { $out['E3_StopLossXAtr'] } else { $Base['E3_StopLossXAtr'] }) $sb
    $exp3 = 1.0; if ($rb -gt 0 -and $sv -gt 0) { $exp3 = ($rv / $rb) * ($sb / $sv) }
    if ($exp3 -gt 1 + 1e-6) { return @($false, ("E3: lote x{0} (risco/SL) = aumento de exposicao; reduza E3_RiscoPorPernaPct na mesma proporcao" -f $exp3.ToString('0.00', $CI)), $null) }
    return @($true, '', $out, $exp3)
}

# --- entradas da base (grafico ao vivo) --------------------------------------------------------
function Read-KeyValues([string]$Txt) {
    $d = [ordered]@{}
    foreach ($l in ($Txt -split "`r?`n")) {
        $t = $l.Trim()
        if (-not $t -or $t.StartsWith(';') -or $t.StartsWith('#') -or $t.StartsWith('<')) { continue }
        $i = $t.IndexOf('=')
        if ($i -le 0) { continue }
        $k = $t.Substring(0, $i).Trim(); $v = $t.Substring($i + 1).Trim()
        $j = $v.IndexOf('||'); if ($j -ge 0) { $v = $v.Substring(0, $j) }
        if ($k -match '^[A-Za-z_][A-Za-z0-9_]*$' -and -not $d.Contains($k)) { $d[$k] = $v }
    }
    return $d
}

function Read-SnapshotInputs {
    # snapshot do perfil ao vivo (ops\profile\sobrevivencia\*.chr, salvo pelo save_profile.ps1): UM bloco <expert> do
    # Concorde_RF com os inputs. Devolve $null se nao houver exatamente um.
    $dir = Join-Path $WS "ops\profile\$PROFILE_NAME"
    if (-not (Test-Path -LiteralPath $dir)) { return $null }
    $achados = @()
    foreach ($f in @(Get-ChildItem -LiteralPath $dir -Filter '*.chr' -File)) {
        $t = Read-TextAuto $f.FullName
        if (-not $t) { continue }
        foreach ($m in [regex]::Matches($t, '(?s)<expert>(.*?)</expert>')) {
            $blk = $m.Groups[1].Value
            if ($blk -notmatch '(?m)^\s*name\s*=\s*Concorde_RF\s*$') { continue }
            $mi = [regex]::Match($blk, '(?s)<inputs>(.*?)</inputs>')
            if ($mi.Success) { $achados += , @($f.Name, (Read-KeyValues $mi.Groups[1].Value)) }
        }
    }
    if ($achados.Count -ne 1) { return $null }
    return $achados[0]
}

function Get-DegrauState {
    $f = Join-Path $WS 'STATE.md'
    $t = Read-TextAuto $f
    if ($t) {
        $m = [regex]::Match($t, '(?im)Degrau do preset\s*:\s*\**\s*([AB])\b')
        if ($m.Success) { return $m.Groups[1].Value.ToUpper() }
    }
    return 'A'
}

function Get-BaseInputs {
    # Base = entradas do grafico ao vivo (snapshot). Sem snapshot valido: preset do degrau em vigor (STATE.md), com
    # base NAO confirmada (o lab testa, mas nao gera proposta). Nunca preset A fixo.
    $degrau = Get-DegrauState
    $presetF = Join-Path $WS ("mql5\Presets\Concorde_E13_{0}.set" -f $degrau)
    $preset = $null
    if (Test-Path -LiteralPath $presetF) { $preset = Read-KeyValues (Read-TextAuto $presetF) }
    $snap = Read-SnapshotInputs
    $fonte = ''; $inp = $null; $conf = $false; $difPreset = @()
    if ($snap -and $snap[1].Count -ge 170) {
        $inp = $snap[1]; $fonte = "snapshot:" + $snap[0]; $conf = $true
        if ($preset) {
            foreach ($k in $preset.Keys) {
                if ($k -in @('Panel_Mostrar', 'E2_MostrarStatusGrafico')) { continue }
                if (-not $inp.Contains($k)) { $difPreset += "$k(ausente)"; continue }
                $a = "$($inp[$k])"; $b = "$($preset[$k])"
                $na = 0.0; $nb = 0.0
                if ([double]::TryParse($a, [Globalization.NumberStyles]::Float, $CI, [ref]$na) -and [double]::TryParse($b, [Globalization.NumberStyles]::Float, $CI, [ref]$nb)) {
                    if ([Math]::Abs($na - $nb) -gt 1e-9) { $difPreset += "$k=$a(preset $b)" }
                } elseif ($a.ToLower() -ne $b.ToLower()) { $difPreset += "$k=$a(preset $b)" }
            }
        }
    } elseif ($preset) {
        $inp = $preset; $fonte = "preset:Concorde_E13_$degrau.set"; $conf = $false
    } else { throw "sem base: nem snapshot do perfil nem $presetF" }
    $canon = ($inp.Keys | Sort-Object | Where-Object { $_ -notin $INFRA } | ForEach-Object { "$_=$($inp[$_])" }) -join "`n"
    $md5 = [BitConverter]::ToString([Security.Cryptography.MD5]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($canon))).Replace('-', '')
    return New-Object PSObject -Property @{ Inputs = $inp; Fonte = $fonte; Confirmada = $conf; Degrau = $degrau; Md5 = $md5; DifPreset = $difPreset }
}

# --- noticias em hora do servidor ---------------------------------------------------------------
function Update-NewsLab {
    # news.csv (Common\Files, GMT) + campanha\lab\news\*.csv (mesmo formato, GMT; o agente pode acrescentar eventos
    # do calendario) -> Common\Files\news_lab_srv.csv com data/hora do servidor por evento (GMT+3 no verao europeu,
    # GMT+2 no inverno). Com News_SourceGMTOffset = fuso do inicio do teste, o Concorde ve cada noticia na hora certa
    # nos dois regimes (o CSV original tinha 1 h de defasagem no inverno nos backtests). Devolve cobertura USD.
    $fontes = @()
    $base = Join-Path $COMMON_FILES 'news.csv'
    if (Test-Path -LiteralPath $base) { $fontes += $base }
    if (Test-Path -LiteralPath $NEWS_EXTRA_DIR) { $fontes += @(Get-ChildItem -LiteralPath $NEWS_EXTRA_DIR -Filter '*.csv' -File | ForEach-Object { $_.FullName }) }
    if ($fontes.Count -eq 0) { throw "news.csv ausente em $COMMON_FILES" }
    $vistos = @{}; $linhas = New-Object Collections.Generic.List[string]
    $linhas.Add('Title,Country,Date,Time,Impact,Forecast,Previous')
    $usdMin = [DateTime]::MaxValue; $usdMax = [DateTime]::MinValue; $n = 0
    foreach ($f in $fontes) {
        foreach ($l in [IO.File]::ReadAllLines($f)) {
            $c = $l.Split(',')
            if ($c.Count -lt 5) { continue }
            $dt = [DateTime]::MinValue
            if (-not [DateTime]::TryParseExact(($c[2].Trim() + ' ' + $c[3].Trim()), 'MM-dd-yyyy H:mm', $CI, [Globalization.DateTimeStyles]::None, [ref]$dt)) { continue }
            $imp = $c[4].Trim().ToUpper()
            if ($imp -ne 'HIGH' -and $imp -ne '3') { continue }
            $chave = $c[0].Trim() + '|' + $c[1].Trim().ToUpper() + '|' + $dt.ToString('yyyyMMddHHmm', $CI)
            if ($vistos.ContainsKey($chave)) { continue }
            $vistos[$chave] = 1
            $utc = [DateTime]::SpecifyKind($dt, [DateTimeKind]::Utc)
            $off = 2; if (Test-EuDst $utc) { $off = 3 }
            $srv = $utc.AddHours($off)
            $t = ($c[0] -replace '[^\x20-\x7E]', '?').Trim()
            $linhas.Add(('{0},{1},{2},{3},High,,' -f $t, $c[1].Trim().ToUpper(), $srv.ToString('MM-dd-yyyy', $CI), $srv.ToString('HH:mm', $CI)))
            $n++
            if ($c[1].Trim().ToUpper() -eq 'USD') { if ($utc -lt $usdMin) { $usdMin = $utc }; if ($utc -gt $usdMax) { $usdMax = $utc } }
        }
    }
    $dst = Join-Path $COMMON_FILES $NEWS_LAB
    [IO.File]::WriteAllLines($dst, $linhas.ToArray(), (New-Object Text.ASCIIEncoding))
    return New-Object PSObject -Property @{ Eventos = $n; UsdDe = $usdMin; UsdAte = $usdMax; Md5 = (Get-Hash $dst) }
}

# --- ambiente ---------------------------------------------------------------------------------
function Get-RamDisponivelMb {
    try { return [int]((Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).FreePhysicalMemory / 1024) } catch { return -1 }
}
function Get-DiscoLivreGb {
    try { $d = Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='" + $LAB_DIR.Substring(0, 2) + "'") -ErrorAction Stop; return [double]$d.FreeSpace / 1GB } catch { return -1 }
}
function Test-RebootPendente {
    foreach ($k in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired', 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending')) {
        if (Test-Path $k) { return $true }
    }
    return $false
}
function Get-DonoPorta([int]$Porta) {
    try {
        $c = @(Get-NetTCPConnection -LocalPort $Porta -State Listen -ErrorAction Stop)
        if ($c.Count -eq 0) { return '' }
        $p = Get-CimInstance Win32_Process -Filter ("ProcessId=" + $c[0].OwningProcess) -ErrorAction Stop
        return "$($p.ExecutablePath)"
    } catch { return '' }
}
function Get-LabLoginIni {
    $f = Join-Path $LAB_DIR 'config\common.ini'
    $t = Read-TextAuto $f
    if (-not $t) { return 0 }
    $m = [regex]::Match($t, '(?ims)^\[Common\][^\[]*?^\s*Login\s*=\s*(\d+)')
    if ($m.Success) { return [long]$m.Groups[1].Value }
    return 0
}

function Test-CopiaOk {
    # conferencias da copia (valem tambem no -Local): exe, login da demo fixado no config, nunca a conta real
    if (-not (Test-Path -LiteralPath (Join-Path $LAB_DIR 'terminal64.exe'))) { return "copia de tester ausente ($LAB_DIR\terminal64.exe)" }
    if (-not $LAB_LOGIN -or $LAB_LOGIN -le 0) { return 'LAB_LOGIN nao configurado (config.ps1): laboratorio desligado' }
    $reais = @(52012798); if ($EXPECTED_LOGIN) { $reais += [long]$EXPECTED_LOGIN }
    if ($LAB_LOGIN -in $reais) { return 'LAB_LOGIN igual ao da conta real: RECUSADO' }
    $li = Get-LabLoginIni
    if ($li -in $reais) { return 'a copia esta logada na CONTA REAL (config\common.ini): RECUSADO; logar a demo' }
    if ($li -ne $LAB_LOGIN) { return ("a copia esta logada em {0}, diferente de LAB_LOGIN {1}" -f $li, $LAB_LOGIN) }
    $prof = Join-Path $LAB_DIR 'MQL5\Profiles\Charts'
    if (Test-Path -LiteralPath $prof) {
        foreach ($c in @(Get-ChildItem -LiteralPath $prof -Filter '*.chr' -File -Recurse -ErrorAction SilentlyContinue)) {
            $t = Read-TextAuto $c.FullName
            if ($t -and $t -match '<expert>') { return ("grafico com EA na copia ({0}): remover" -f $c.FullName) }
        }
    }
    return ''
}

function Test-PodeRodar([int]$MinutosPrevistos) {
    # Antes de CADA run. Devolve '' (pode) ou o motivo. No -Local so as conferencias de recurso da maquina.
    $agora = [DateTime]::UtcNow
    if (-not $Local) {
        if (-not (Test-LabJanela $agora)) { return 'fora da janela' }
        $fim = Get-FimJanela $agora
        if ($agora.AddMinutes($MinutosPrevistos) -gt $fim) { return ("sem tempo na janela (previsto {0} min, fim {1:HH:mm}Z)" -f $MinutosPrevistos, $fim) }
        # nao disputar RAM nem o lock com a semanal (sab 12:00): nao comecar um run que termine entre 11:45 e 12:45
        $sem = New-Object DateTime($agora.Year, $agora.Month, $agora.Day, 11, 45, 0, [DateTimeKind]::Utc)
        if ($agora.DayOfWeek -eq [DayOfWeek]::Saturday -and $agora -lt $sem.AddMinutes(60) -and $agora.AddMinutes($MinutosPrevistos) -gt $sem) { return 'acordada semanal das 12:00 (aguardando)' }
        if (Test-Path -LiteralPath (Join-Path $LOG_DIR 'claude.lock')) { return 'acordada do agente em andamento (claude.lock)' }
        if (Test-RebootPendente) { return 'reinicio do Windows pendente' }
        $boot = Get-SystemBootTimeUtc
        if ($boot -and ($agora - $boot).TotalMinutes -lt 20) { return 'Windows reiniciado ha menos de 20 min' }
        $vivos = @(Get-Mt5Process)
        if ($vivos.Count -eq 0) { return 'terminal ao vivo nao esta rodando' }
        $up = Get-Mt5UptimeMin
        if ($up -ge 0 -and $up -lt 15) { return 'terminal ao vivo com menos de 15 min de vida' }
        $st = Read-SurvStatus
        if (-not $st -or $st.AgeSec -gt $LAB_STATUS_MAX_SEC) { return 'status.json do guardiao velho ou ausente' }
        $dono = Get-DonoPorta 22346
        if (-not $dono -or $dono.ToLower() -ne ([string]$MT5_EXE).ToLower()) { return ("porta 22346 (MCP) nao e do terminal ao vivo (dono: '{0}')" -f $dono) }
    }
    if (@(Get-LabProcesses).Count -gt 0) { return 'ja existe processo da copia rodando (orfao?)' }
    $ram = Get-RamDisponivelMb
    if ($ram -ge 0 -and $ram -lt ($LAB_MEM_LIMIT_MB + $LAB_RAM_FOLGA_MB)) { return ("RAM disponivel {0} MB < {1} MB" -f $ram, ($LAB_MEM_LIMIT_MB + $LAB_RAM_FOLGA_MB)) }
    $disco = Get-DiscoLivreGb
    if ($disco -ge 0 -and $disco -lt $LAB_DISCO_MIN_GB) { return ("disco livre {0:N1} GB < {1} GB" -f $disco, $LAB_DISCO_MIN_GB) }
    $c = Test-CopiaOk
    if ($c) { return $c }
    return ''
}

function Get-FimJanela([DateTime]$Utc) {
    $d = $Utc.Date
    while ($d.DayOfWeek -ne [DayOfWeek]::Sunday) { $d = $d.AddDays(1) }
    return (New-Object DateTime($d.Year, $d.Month, $d.Day, 17, 30, 0, [DateTimeKind]::Utc))
}

# --- lock ---------------------------------------------------------------------------------------
function Set-LabLock([string]$Oque) {
    $cl = ''
    try { $cl = "$((Get-CimInstance Win32_Process -Filter ('ProcessId=' + $PID) -ErrorAction Stop).CommandLine)" } catch { }
    if ($cl -notmatch 'lab\.ps1') { throw 'rode o executor com: powershell -File ...\ops\lab.ps1 -Acao executar (o heartbeat reconhece o dono do lock pela linha de comando)' }
    $me = Get-Process -Id $PID
    $l = @("$PID", "$($me.StartTime.ToUniversalTime().Ticks)", $Oque, (Get-UtcStamp))
    [IO.File]::WriteAllLines($LOCK, $l, (New-Object Text.UTF8Encoding($false)))
}
function Remove-LabLock {
    $li = Get-LabLockInfo
    if ($li -and $li.Pid -eq $PID) { Remove-Item -LiteralPath $LOCK -Force -ErrorAction SilentlyContinue }
}

# --- ini de um run -----------------------------------------------------------------------------
function Write-RunIni([string]$Nome, [DateTime]$De, [DateTime]$Ate, $Base, $Ov, [int]$NewsOffset, [string]$NewsArq) {
    $inp = [ordered]@{}
    foreach ($k in $Base.Keys) { $inp[$k] = "$($Base[$k])" }
    foreach ($k in $Ov.Keys) { $inp[$k] = "$($Ov[$k])" }
    # infra do tester (nunca vai para proposta): painel off, noticias do CSV em hora do servidor, E4 sem carregar
    # os 4 pares (com a E4 desligada nao muda nenhuma operacao e o tester carrega so os ticks do ouro)
    $infra = [ordered]@{ Panel_Mostrar = 'false'; E2_MostrarStatusGrafico = 'false'; News_Source = '0'; News_CsvFileName = $NewsArq
        News_CsvCommonFolder = 'true'; News_SourceGMTOffset = "$NewsOffset"; News_CsvFormat = '0'; News_CsvDelimiter = ','
        E4_Use1 = 'false'; E4_Use2 = 'false'; E4_Use3 = 'false'; E4_Use4 = 'false' }
    foreach ($k in $infra.Keys) { if ($inp.Contains($k)) { $inp[$k] = $infra[$k] } }
    $l = New-Object Collections.Generic.List[string]
    $l.Add('[Tester]')
    foreach ($kv in @(('Expert', 'Concorde_RF.ex5'), ('Symbol', 'XAUUSD'), ('Period', 'M15'), ('Login', "$LAB_LOGIN"), ('Server', $LAB_SERVER),
            ('Model', '4'), ('ExecutionMode', '0'), ('Optimization', '0'), ('FromDate', (DS $De)), ('ToDate', (DS $Ate)), ('ForwardMode', '0'),
            ('Deposit', '10000'), ('Currency', 'USD'), ('ProfitInPips', '0'), ('Leverage', '1:1000'), ('Visual', '0'), ('Report', $Nome),
            ('ReplaceReport', '1'), ('ShutdownTerminal', '1'), ('Port', "$LAB_PORT"))) { $l.Add($kv[0] + '=' + $kv[1]) }
    $l.Add('[TesterInputs]')
    foreach ($k in $inp.Keys) {
        $v = "$($inp[$k])"
        if ($v -match '[\r\n]') { throw "valor com quebra de linha em $k" }
        $l.Add("$k=$v")
    }
    $ini = Join-Path $LAB_DIR "$Nome.ini"
    Assert-LabPath $ini
    [IO.File]::WriteAllLines($ini, $l.ToArray(), (New-Object Text.ASCIIEncoding))
    return @($ini, $inp)
}

# --- logs da copia ------------------------------------------------------------------------------
function Get-LogSnapshot([string]$Dir) {
    $s = @{}
    if (Test-Path -LiteralPath $Dir) { foreach ($f in @(Get-ChildItem -LiteralPath $Dir -Filter '*.log' -File)) { $s[$f.FullName] = $f.Length } }
    return $s
}
function Get-LogNovo([string]$Dir, $Snap) {
    # texto acrescentado aos logs (UTF-16) desde o snapshot
    $sb = New-Object Text.StringBuilder
    if (-not (Test-Path -LiteralPath $Dir)) { return '' }
    foreach ($f in @(Get-ChildItem -LiteralPath $Dir -Filter '*.log' -File | Sort-Object LastWriteTime)) {
        $ini = 0L
        if ($Snap.ContainsKey($f.FullName)) { $ini = [long]$Snap[$f.FullName] }
        if ($f.Length -le $ini) { continue }
        try {
            $fs = [IO.File]::Open($f.FullName, [IO.FileMode]::Open, [IO.FileAccess]::Read, ([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
            try {
                $inicio = $ini; if ($inicio -lt 2) { $inicio = 0 }
                if ($inicio % 2 -ne 0) { $inicio-- }
                $fs.Seek($inicio, [IO.SeekOrigin]::Begin) | Out-Null
                $buf = New-Object byte[] ($fs.Length - $inicio)
                $lidos = $fs.Read($buf, 0, $buf.Length)
                $txt = [Text.Encoding]::Unicode.GetString($buf, 0, $lidos)
                if ($txt.Length -gt 0 -and $txt[0] -eq [char]0xFEFF) { $txt = $txt.Substring(1) }
                [void]$sb.Append($txt)
            } finally { $fs.Dispose() }
        } catch { }
    }
    return $sb.ToString()
}

# --- execucao de um run ------------------------------------------------------------------------
function Invoke-Run($L, $R, $Base, [string]$LoteDir) {
    # Roda o run $R do lote $L. Atualiza $R (estado, veredito, build, memoria, noticias, relatorio). Devolve
    # 'ok', 'falhou' ou 'abortar' (condicao do ambiente: parar o lote e tentar depois).
    $nome = ('lab_{0}_{1}' -f $L.seq, $R.nome)
    $de = D $R.de; $ate = D $R.ate
    $off = Get-SrvOffset $de
    $ov = [ordered]@{}; foreach ($p in $R.overrides.PSObject.Properties) { $ov[$p.Name] = "$($p.Value)" }
    $narq = Join-Path $COMMON_FILES $L.noticias.arquivo
    if (-not (Test-Path -LiteralPath $narq) -or (Get-Hash $narq) -ne $L.noticias.md5) { $R.erro = "noticias do lote ($($L.noticias.arquivo)) ausentes ou alteradas"; return 'abortar' }
    $w = Write-RunIni $nome $de $ate $Base $ov $off $L.noticias.arquivo
    $ini = $w[0]
    $htm = Join-Path $LAB_DIR "$nome.htm"
    Assert-LabPath $htm
    if (Test-Path -LiteralPath $htm) { Remove-Item -LiteralPath $htm -Force }
    $cache = Join-Path $LAB_DIR 'Tester\cache'
    if (Test-Path -LiteralPath $cache) { foreach ($c in @(Get-ChildItem -LiteralPath $cache -File)) { Assert-LabPath $c.FullName; Remove-Item -LiteralPath $c.FullName -Force -ErrorAction SilentlyContinue } }
    $logT = Join-Path $LAB_DIR 'logs'
    $logA = Join-Path $LAB_DIR ("Tester\Agent-127.0.0.1-{0}\logs" -f $LAB_PORT)
    $snapT = Get-LogSnapshot $logT; $snapA = Get-LogSnapshot $logA
    $exe = Join-Path $LAB_DIR 'terminal64.exe'
    Assert-LabPath $exe
    $t0 = [DateTime]::UtcNow
    $R.inicio = Get-UtcStamp; $R.estado = 'rodando'
    # o terminal nasce SUSPENSO e entra no job antes de rodar: o atualizador do LiveUpdate (que o terminal lanca logo
    # no arranque, de dentro de AppData) e o terminal que ele relanca com o mesmo ini ficam no job. O run so termina
    # quando nao sobra nenhum processo no job (conferido em 29/09: o LiveUpdate relanca o teste ~2 min depois).
    $erroIni = ''
    $novoPid = [SurvLab.LabJob]::Iniciar($exe, ('/portable /config:"{0}"' -f $ini), $LAB_DIR, [ref]$erroIni)
    if ($novoPid -le 0) { $R.estado = 'falhou'; $R.erro = "inicio: $erroIni"; return 'abortar' }
    Log ("run {0} {1} {2}-{3} PID {4}" -f $L.id, $R.nome, $R.de, $R.ate, $novoPid)
    $abort = ''; $autorizado = $false
    Start-Sleep -Seconds 2
    while ([SurvLab.LabJob]::Ativos() -gt 0) {
        Start-Sleep -Seconds 15
        if ((Get-LogNovo $logT $snapT) -match 'LiveUpdate\s+start') { $R | Add-Member -NotePropertyName atualizacao -NotePropertyValue $true -Force }
        $min = ([DateTime]::UtcNow - $t0).TotalMinutes
        $txtT = Get-LogNovo $logT $snapT
        # na estacao (-Local) nao ha terminal ao vivo disputando a porta do MCP: so no VPS isso aborta
        if ($txtT -match 'MCP started' -and -not $Local) { $abort = 'a copia abriu o MCP interno (desligar em Ferramentas > Opcoes > MCP da copia)'; break }
        $ma = [regex]::Match($txtT, "'(\d+)'\s*:\s*authorized")
        if ($ma.Success) {
            if ([long]$ma.Groups[1].Value -ne $LAB_LOGIN) { $abort = ("a copia autorizou a conta {0}, nao a demo {1}" -f $ma.Groups[1].Value, $LAB_LOGIN); break }
            $autorizado = $true
        }
        if ($txtT -match 'authorization failed') { $abort = 'authorization failed (demo expirada ou senha nao salva?)'; break }
        if (-not $autorizado -and $min -gt 6) { $abort = 'sem autorizacao da demo em 6 min'; break }
        if (-not $Local) {
            foreach ($porta in 22345, 22346) {
                $dono = Get-DonoPorta $porta
                if ($dono -and $dono.ToLower().StartsWith(($LAB_DIR + '\').ToLower())) { $abort = "a copia esta escutando a porta $porta" }
            }
        }
        if ($abort) { break }
        if ($min -gt $LAB_RUN_TIMEOUT_MIN) { $abort = "timeout de $LAB_RUN_TIMEOUT_MIN min"; break }
        if (-not $Local) {
            if (-not (Test-LabJanela ([DateTime]::UtcNow))) { $abort = 'fim da janela do laboratorio'; break }
            $st = Read-SurvStatus
            if (-not $st -or $st.AgeSec -gt $LAB_STATUS_MAX_SEC) { $abort = 'status.json do guardiao envelheceu durante o run'; break }
            if (@(Get-Mt5Process).Count -eq 0) { $abort = 'o terminal ao vivo caiu durante o run'; break }
        }
        $ram = Get-RamDisponivelMb
        if ($ram -ge 0 -and $ram -lt $LAB_RAM_MIN_MB) { $abort = "RAM disponivel caiu para $ram MB"; break }
        $disco = Get-DiscoLivreGb
        if ($disco -ge 0 -and $disco -lt 10) { $abort = ("disco livre caiu para {0:N1} GB" -f $disco); break }
    }
    if ($abort) {
        [void][SurvLab.LabJob]::Encerrar()
        Stop-LabProcesses ("abortado: " + $abort) $ORIGEM | Out-Null
        $R.estado = 'abortado'; $R.erro = $abort; $R.fim = Get-UtcStamp
        Log ("run {0} {1} ABORTADO: {2}" -f $L.id, $R.nome, $abort)
        return 'abortar'
    }
    # espera a copia soltar os arquivos (nenhum processo dela vivo, nem fora do job)
    for ($i = 0; $i -lt 40 -and @(Get-LabProcesses).Count -gt 0; $i++) { Start-Sleep -Seconds 3 }
    if (@(Get-LabProcesses).Count -gt 0) { Stop-LabProcesses 'sobra de processo da copia depois do run' $ORIGEM | Out-Null }
    Start-Sleep -Seconds 5
    $R.fim = Get-UtcStamp; $R.dur_s = [int]([DateTime]::UtcNow - $t0).TotalSeconds
    $txtT = Get-LogNovo $logT $snapT; $txtA = Get-LogNovo $logA $snapA
    $mbs = [regex]::Matches($txtT, 'build\s+(\d{4,5})'); if ($mbs.Count -gt 0) { $R.build = $mbs[$mbs.Count - 1].Groups[1].Value }
    $mm = [regex]::Matches($txtA, '(\d+)\s*Mb memory used'); if ($mm.Count -gt 0) { $R.memoria_mb = [int]$mm[$mm.Count - 1].Groups[1].Value }
    $R.pico_job_mb = [SurvLab.LabJob]::PicoMemoriaMb()
    $mn = [regex]::Match($txtA, 'FILTRO NOT.CIAS Concorde:.*?fonte=(\S+).*?GMT\+(\d+).*?eventos=(\d+)')
    if ($mn.Success) { $R.noticias = ('fonte={0} GMT+{1} eventos={2}' -f $mn.Groups[1].Value, $mn.Groups[2].Value, $mn.Groups[3].Value) }
    $vr = [regex]::Matches($txtT, 'last test passed with result "([^"]+)"')
    if ($vr.Count -gt 0 -and $vr[$vr.Count - 1].Groups[1].Value -eq 'successfully finished') { $R.veredito = 'passou' }
    elseif ($vr.Count -gt 0) { $R.veredito = 'falhou: ' + $vr[$vr.Count - 1].Groups[1].Value }
    elseif ($txtT -match '(?i)test failed|stopped|cannot|error') { $R.veredito = 'falhou' }
    else { $R.veredito = 'sem veredito' }
    if (-not (Test-Path -LiteralPath $htm)) { $R.estado = 'falhou'; $R.erro = "sem relatorio ($($R.veredito))"; return 'falhou' }
    $dstDir = Join-Path $LoteDir 'reports'; Ensure-Dir $dstDir
    $dst = Join-Path $dstDir ("{0}.htm" -f $R.nome)
    Copy-Item -LiteralPath $htm -Destination $dst -Force
    Copy-Item -LiteralPath $ini -Destination (Join-Path $dstDir ("{0}.ini" -f $R.nome)) -Force
    Remove-Item -LiteralPath $htm -Force -ErrorAction SilentlyContinue
    foreach ($png in @(Get-ChildItem -LiteralPath $LAB_DIR -Filter "$nome*.png" -File -ErrorAction SilentlyContinue)) { Assert-LabPath $png.FullName; Remove-Item -LiteralPath $png.FullName -Force -ErrorAction SilentlyContinue }
    Remove-Item -LiteralPath $ini -Force -ErrorAction SilentlyContinue
    $R.relatorio = "reports\{0}.htm" -f $R.nome
    # validacao do relatorio: inputs efetivos = ini, deposito, alavancagem, periodo, noticias
    $rep = [SurvLab.Rpt]::Ler($dst)
    $prob = @()
    if ($rep.Erro) { $prob += $rep.Erro }
    $efet = @{}; foreach ($kv in $rep.Inputs) { $efet[$kv.Key] = $kv.Value }
    foreach ($k in $w[1].Keys) {
        if (-not $efet.ContainsKey($k)) { $prob += "input $k ausente no relatorio"; continue }
        $a = "$($w[1][$k])"; $b = "$($efet[$k])"; $na = 0.0; $nb = 0.0
        if ([double]::TryParse($a, [Globalization.NumberStyles]::Float, $CI, [ref]$na) -and [double]::TryParse($b, [Globalization.NumberStyles]::Float, $CI, [ref]$nb)) {
            if ([Math]::Abs($na - $nb) -gt 1e-9 * [Math]::Max(1, [Math]::Abs($na))) { $prob += "input $k=$b (ini $a)" }
        } elseif ($a.ToLower() -ne $b.ToLower()) { $prob += "input $k=$b (ini $a)" }
    }
    if ([SurvLab.Rpt]::Num($rep.Campos['deposito']) -ne 10000) { $prob += "deposito $($rep.Campos['deposito'])" }
    if ([double]::IsNaN([SurvLab.Rpt]::Num($rep.Campos['dd_rel_equity'])) -or [double]::IsNaN([SurvLab.Rpt]::Num($rep.Campos['pf']))) { $prob += 'DD relativo de equity ou PF ilegivel no relatorio (idioma?)' }
    if ("$($rep.Campos['alavancagem'])" -notmatch '1:1000') { $prob += "alavancagem $($rep.Campos['alavancagem'])" }
    if ("$($rep.Campos['periodo'])" -notmatch [regex]::Escape($R.de)) { $prob += "periodo $($rep.Campos['periodo'])" }
    if ($R.noticias -notmatch ('GMT\+{0}\b' -f $off)) { $prob += ("noticias: esperado GMT+{0}, log '{1}'" -f $off, $R.noticias) }
    if ($R.noticias -notmatch ('eventos={0}\b' -f $L.noticias.eventos)) { $prob += ("noticias: esperado eventos={0}, log '{1}'" -f $L.noticias.eventos, $R.noticias) }
    if ($R.veredito -ne 'passou') { $prob += "veredito do tester: $($R.veredito)" }
    $R.trades = $rep.Trades.Count
    if ($prob.Count -gt 0) { $R.estado = 'invalido'; $R.erro = ($prob | Select-Object -First 6) -join '; '; Log ("run {0} {1} INVALIDO: {2}" -f $L.id, $R.nome, $R.erro); return 'falhou' }
    $R.estado = 'ok'; $R.erro = ''
    Log ("run {0} {1} ok: {2} trades, {3} s, memoria {4} MB (job {5} MB)" -f $L.id, $R.nome, $R.trades, $R.dur_s, $R.memoria_mb, $R.pico_job_mb)
    return 'ok'
}

# --- lotes -------------------------------------------------------------------------------------
function Get-Lotes {
    $r = @()
    if (-not (Test-Path -LiteralPath $LOTES_DIR)) { return $r }
    foreach ($d in @(Get-ChildItem -LiteralPath $LOTES_DIR -Directory | Sort-Object Name)) {
        $j = Load-Json (Join-Path $d.FullName 'lote.json')
        if ($j) { $r += $j }
    }
    return $r
}
function Save-Lote($L) { Save-Json $L (Join-Path (Join-Path $LOTES_DIR $L.id) 'lote.json') }

function New-Lote([string]$Tipo, [string]$Trimestre, [DateTime]$De, [DateTime]$Ate, $Variantes, [string]$Motivo, $BaseInfo, $News) {
    Ensure-Dir $LOTES_DIR
    $seq = @(Get-Lotes).Count + 1
    $id = ('{0}_{1}_{2}_{3:000}' -f $Trimestre, $Tipo, [DateTime]::UtcNow.ToString('yyyyMMdd'), $seq)
    $segs = @(Get-Segmentos $De $Ate)
    if ($Tipo -eq 'sonda') { $segs = @(, @($De, $Ate)) }
    $runs = @()
    $mk = {
        param($var, $papel, $ov)
        $i = 0
        foreach ($s in $segs) {
            $i++
            $script:runsTmp += [pscustomobject][ordered]@{ nome = ('{0}_s{1}' -f $var, $i); variante = $var; papel = $papel; seg = $i
                de = (DS $s[0]); ate = (DS $s[1]); overrides = $ov; estado = 'pendente'; tentativas = 0; inicio = ''; fim = ''; dur_s = 0
                veredito = ''; build = ''; memoria_mb = 0; pico_job_mb = 0; noticias = ''; trades = 0; relatorio = ''; erro = ''; atualizacao = $false }
        }
    }
    $script:runsTmp = @()
    & $mk 'C0' 'controle' ([ordered]@{})
    foreach ($v in $Variantes) { & $mk $v.id $v.papel $v.overrides }
    if ($Tipo -ne 'sonda') { & $mk 'C0z' 'controle_final' ([ordered]@{}) }
    $runs = $script:runsTmp
    $L = [pscustomobject][ordered]@{
        id = $id; seq = $seq; tipo = $Tipo; trimestre = $Trimestre; motivo = $Motivo; criado = (Get-UtcStamp)
        janela = [pscustomobject][ordered]@{ de = (DS $De); ate = (DS $Ate) }
        segmento_meses = $LAB_SEGMENTO_MESES; estado = 'pendente'
        base = [pscustomobject][ordered]@{ fonte = $BaseInfo.Fonte; confirmada = $BaseInfo.Confirmada; degrau = $BaseInfo.Degrau; md5 = $BaseInfo.Md5; dif_preset = @($BaseInfo.DifPreset) }
        ex5_md5 = ''; conta_demo = $LAB_LOGIN
        noticias = [pscustomobject][ordered]@{ arquivo = $NEWS_LAB; eventos = $News.Eventos; md5 = $News.Md5; usd_de = $News.UsdDe.ToString('yyyy-MM-dd'); usd_ate = $News.UsdAte.ToString('yyyy-MM-dd') }
        variantes = @($Variantes); runs = @($runs); analise = $null; agente_chamado = ''; hashes = [pscustomobject]@{}
    }
    Ensure-Dir (Join-Path $LOTES_DIR $id)
    # noticias congeladas no lote: copia propria em Common\Files (controle e variantes leem o MESMO arquivo, mesmo que
    # campanha\lab\news receba eventos novos no meio do fim de semana)
    $narq = ('news_lab_{0:000}.csv' -f $seq)
    Copy-Item -LiteralPath (Join-Path $COMMON_FILES $NEWS_LAB) -Destination (Join-Path $COMMON_FILES $narq) -Force
    $L.noticias.arquivo = $narq
    $L.noticias.md5 = Get-Hash (Join-Path $COMMON_FILES $narq)
    Save-Lote $L
    Log ("lote criado: {0} ({1} runs, janela {2}-{3}, {4})" -f $id, $runs.Count, (DS $De), (DS $Ate), $Motivo)
    return $L
}

function Get-Registro {
    $r = Load-Json $REGISTRO
    if (-not $r) { $r = [pscustomobject]@{ variantes = @() } }
    return $r
}

function Get-VariantesAtivas {
    # candidatas congeladas e extras em teste fora da amostra (CLAUDE.md 5.9): rodam em todo lote trimestral
    $r = @()
    foreach ($e in @((Get-Registro).variantes)) { if ($e.estado -in @('CANDIDATA', 'EM_TESTE')) { $r += $e } }
    return $r
}

function Read-Fila($Base) {
    # pedidos do agente: campanha\lab\fila\*.json  {"tipo":"extra","motivo":"...","variantes":[{"id":"...","serie":"E3","overrides":{...}}]}
    # ou {"tipo":"volta","motivo":"..."}. Validados aqui (lista branca, faixas, so reducao de risco); rejeitados vao para
    # fila\rejeitados com o motivo. Maximo de 4 extras ativas.
    $out = @()
    if (-not (Test-Path -LiteralPath $FILA_DIR)) { return $out }
    $rej = Join-Path $FILA_DIR 'rejeitados'; $ok = Join-Path $FILA_DIR 'aceitos'
    $usados = @{}
    foreach ($e in @((Get-Registro).variantes)) { $usados["$($e.id)"] = 1 }
    foreach ($lx in @(Get-Lotes)) { foreach ($vx in @($lx.variantes)) { $usados["$($vx.id)"] = 1 } }
    foreach ($f in @(Get-ChildItem -LiteralPath $FILA_DIR -Filter '*.json' -File | Sort-Object Name)) {
        $motivoRej = ''
        $j = $null
        try { $j = [IO.File]::ReadAllText($f.FullName) | ConvertFrom-Json } catch { $motivoRej = 'JSON invalido' }
        $pedido = $null
        $mot = ''
        if ($j) { $mot = ("$($j.motivo)" -replace '[\x00-\x1F\x7F|`#\[\]<>]', ' ').Trim(); if ($mot.Length -gt 200) { $mot = $mot.Substring(0, 200) } }
        if (-not $motivoRej) {
            $tipo = "$($j.tipo)".ToLower()
            if ($tipo -eq 'volta') { $pedido = [pscustomobject]@{ tipo = 'volta'; motivo = $mot; variantes = @() } }
            elseif ($tipo -eq 'extra') {
                $vs = @(); $ids = @{}
                $ativas = @((Get-Registro).variantes | Where-Object { $_.origem -eq 'extra' -and $_.estado -eq 'EM_TESTE' }).Count
                foreach ($v in @($j.variantes)) {
                    $vid = "$($v.id)"
                    if ($vid -notmatch '^[A-Za-z][A-Za-z0-9_]{0,19}$' -or $vid -in @('C0', 'C0z') -or $ids.ContainsKey($vid)) { $motivoRej = "id invalido: $vid"; break }
                    if ($usados.ContainsKey('X_' + $vid)) { $motivoRej = "id ja usado em outro pedido ou lote: $vid (use um id novo)"; break }
                    $ids[$vid] = 1
                    $serie = @{ e1 = 'E1'; e3 = 'E3'; total = 'total' }["$($v.serie)".ToLower()]; if (-not $serie) { $motivoRej = "serie invalida em $vid"; break }
                    $ov = [ordered]@{}; foreach ($p in $v.overrides.PSObject.Properties) { $ov[$p.Name] = "$($p.Value)" }
                    if ($ov.Count -eq 0) { $motivoRej = "sem overrides em $vid"; break }
                    $t = $null
                    try { $t = Test-Overrides $ov $Base } catch { $t = @($false, $_.Exception.Message, $null) }
                    if (-not $t[0]) { $motivoRej = "$vid : $($t[1])"; break }
                    $esc = 1.0; if ($t.Count -ge 4) { $esc = [Math]::Round([double]$t[3], 6) }
                    if ($esc -lt 1 - 1e-6 -and $serie -ne 'E3') { $motivoRej = "$vid muda a exposicao da E3: use serie E3"; break }
                    $vs += [pscustomobject]@{ id = ('X_' + $vid); papel = 'extra'; serie = $serie; escala = $esc; overrides = $t[2] }
                }
                if (-not $motivoRej -and $vs.Count -eq 0) { $motivoRej = 'sem variantes' }
                if (-not $motivoRej -and ($ativas + $vs.Count) -gt 4) { $motivoRej = "limite de 4 extras em teste (ativas: $ativas)" }
                if (-not $motivoRej) { $pedido = [pscustomobject]@{ tipo = 'extra'; motivo = $mot; variantes = $vs }; foreach ($x in $vs) { $usados[$x.id] = 1 } }
            } else { $motivoRej = "tipo desconhecido: $tipo" }
        }
        if ($motivoRej) {
            Ensure-Dir $rej
            Move-Item -LiteralPath $f.FullName -Destination (Join-Path $rej $f.Name) -Force
            [IO.File]::WriteAllText((Join-Path $rej ($f.BaseName + '.motivo.txt')), $motivoRej, (New-Object Text.UTF8Encoding($false)))
            Log ("fila: pedido {0} REJEITADO: {1}" -f $f.Name, $motivoRej)
        } else {
            Ensure-Dir $ok
            Move-Item -LiteralPath $f.FullName -Destination (Join-Path $ok $f.Name) -Force
            $out += $pedido
            Log ("fila: pedido {0} aceito ({1})" -f $f.Name, $pedido.tipo)
        }
    }
    return $out
}

# --- analise -----------------------------------------------------------------------------------
function Get-VarRuns($L, [string]$Var) { return @($L.runs | Where-Object { $_.variante -eq $Var } | Sort-Object seg) }

function Load-VarDados($L, [string]$Var, [string]$LoteDir) {
    # por segmento: relatorio lido; series (sinal) total/E1/E3, serie total por fechamento, trades concatenados
    $runs = Get-VarRuns $L $Var
    $o = [pscustomobject]@{ ok = $true; segs = @(); tot = @(); e1 = @(); e3 = @(); fech = @(); trades = (New-Object 'Collections.Generic.List[SurvLab.Trade]'); ddEq = 0.0; assin = @(); build = @() }
    foreach ($r in $runs) {
        if ($r.estado -ne 'ok') { $o.ok = $false; continue }
        $rep = [SurvLab.Rpt]::Ler((Join-Path $LoteDir $r.relatorio))
        $de = D $r.de; $ate = D $r.ate
        $o.tot += [SurvLab.Rpt]::SerieDiaria($rep.Trades, 10000.0, $de, $ate, '', $true)
        $o.e1 += [SurvLab.Rpt]::SerieDiaria($rep.Trades, 10000.0, $de, $ate, 'E1', $true)
        $o.e3 += [SurvLab.Rpt]::SerieDiaria($rep.Trades, 10000.0, $de, $ate, 'E3', $true)
        $o.fech += [SurvLab.Rpt]::SerieDiaria($rep.Trades, 10000.0, $de, $ate, '', $false)
        foreach ($t in $rep.Trades) { $o.trades.Add($t) }
        $o.segs += , $rep
        $dd = [SurvLab.Rpt]::Num($rep.Campos['dd_rel_equity']); if ($dd -gt $o.ddEq) { $o.ddEq = $dd }
        $o.assin += [SurvLab.Rpt]::Assinatura($rep.Trades)
        $o.build += $r.build
    }
    return $o
}

function Get-Dd([double[]]$r) {
    $eq = 1.0; $pico = 1.0; $m = 0.0
    foreach ($x in $r) { $eq *= (1.0 + $x); if ($eq -gt $pico) { $pico = $eq }; $dd = 1.0 - $eq / $pico; if ($dd -gt $m) { $m = $dd } }
    return 100.0 * $m
}
function Get-Pf($trades, [string]$Est) {
    $g = 0.0; $p = 0.0
    foreach ($t in $trades) { if ($Est -and $t.Estrategia -ne $Est) { continue }; if ($t.LucroLiquido -gt 0) { $g += $t.LucroLiquido } else { $p -= $t.LucroLiquido } }
    if ($p -le 0) { return [double]::NaN }
    return $g / $p
}
function Get-Serie($Dados, [string]$Serie) {
    switch ($Serie) { 'E1' { return [double[]]$Dados.e1 } 'E3' { return [double[]]$Dados.e3 } default { return [double[]]$Dados.tot } }
}
function Sum([double[]]$a, [int]$i0, [int]$i1) { $s = 0.0; for ($i = $i0; $i -lt $i1; $i++) { $s += $a[$i] }; return $s }

function Invoke-Analise($L) {
    Import-LabCore
    $dir = Join-Path $LOTES_DIR $L.id
    $de = D $L.janela.de; $ate = D $L.janela.ate
    $dias = [SurvLab.Rpt]::DiasUteis($de, $ate)
    $n = $dias.Length
    $ano = $n * 365.25 / [Math]::Max(1, (($ate - $de).TotalDays + 1))   # dias uteis por ano na serie (~261)
    $c0 = Load-VarDados $L 'C0' $dir
    $res = [ordered]@{ lote = $L.id; valido = $true; motivos = @(); variantes = @(); solucoes = $null; c0 = $null }
    if (-not $c0.ok) { $res.valido = $false; $res.motivos += 'controle C0 incompleto' }
    if ($L.tipo -ne 'sonda') {
        $cz = Load-VarDados $L 'C0z' $dir
        if (-not $cz.ok) { $res.valido = $false; $res.motivos += 'controle final C0z incompleto' }
        elseif (($c0.assin -join ',') -ne ($cz.assin -join ',')) { $res.valido = $false; $res.motivos += 'sanduiche: C0 e C0z diferentes (dados de ticks mudaram durante o lote)' }
    }
    $builds = @($L.runs | Where-Object { $_.estado -eq 'ok' -and $_.build } | ForEach-Object { $_.build } | Sort-Object -Unique)
    if ($builds.Count -gt 1) { $res.valido = $false; $res.motivos += ("builds diferentes no lote: {0}" -f ($builds -join ',')) }
    if (-not $res.valido) { return $res }
    if ($c0.tot.Count -ne $n) { $res.valido = $false; $res.motivos += "serie do C0 com $($c0.tot.Count) dias (esperado $n)"; return $res }

    # controle
    $h = [int][Math]::Floor($n / 2)
    $g = @{ A = @(0.20, 0.10, 0.35, 0.5); B = @(0.25, 0.12, 0.45, 0.5) }[$L.base.degrau]
    if (-not $g) { $g = @(0.20, 0.10, 0.35, 0.5) }
    $c0info = [ordered]@{ trades = $c0.trades.Count; pf = (Get-Pf $c0.trades ''); pf_e1 = (Get-Pf $c0.trades 'E1'); pf_e3 = (Get-Pf $c0.trades 'E3')
        ret_anual = (([double[]]$c0.tot | Measure-Object -Average).Average * $ano * 100); dd_fech = (Get-Dd ([double[]]$c0.fech)); dd_eq_seg = $c0.ddEq
        h1 = (Sum ([double[]]$c0.tot) 0 $h) * 100; h2 = (Sum ([double[]]$c0.tot) $h $n) * 100
        e1_h1 = (Sum ([double[]]$c0.e1) 0 $h) * 100; e1_h2 = (Sum ([double[]]$c0.e1) $h $n) * 100; e3_h1 = (Sum ([double[]]$c0.e3) 0 $h) * 100; e3_h2 = (Sum ([double[]]$c0.e3) $h $n) * 100 }
    $dd0c = [Math]::Max($c0info.dd_fech, $c0info.dd_eq_seg)
    $c0info.gate = (($c0info.pf -ge 1.3) -and ($dd0c -le 30) -and ($c0info.trades -ge 100) -and ($c0info.h1 -gt 0) -and ($c0info.h2 -gt 0))
    $res.c0 = $c0info

    # solucoes analiticas: escala de risco do controle (Monte Carlo por trades, guardiao do degrau)
    $rf = @()
    foreach ($seg in $c0.segs) { $rf += [SurvLab.Mc]::RetornosFracionais($seg.Trades, 10000.0) }
    $rf = [double[]]$rf
    $hor = [Math]::Max(20, [int][Math]::Round($rf.Length * 365.25 / [Math]::Max(1, ($ate - $de).TotalDays + 1)))
    $sol = @()
    foreach ($esc in 1.0, 0.75, 0.5) {
        $m = [SurvLab.Mc]::Rodar($rf, 5000, 20, $hor, 20260929, 0.05, $esc, $g[0], $g[1], $g[2], $g[3])
        if ($m) { $sol += [pscustomobject][ordered]@{ escala = $esc; p_halt = $m.PHalt; p_dd20 = $m.PDd20; dd_p95 = $m.DdP95; ret_med = $m.RetMediana; ret_p5 = $m.RetP5; p_neg = $m.PRetNeg } }
    }
    $res.solucoes = $sol

    # variantes
    $vars = @($L.variantes)
    $dados = @{}
    foreach ($v in $vars) { $dados[$v.id] = Load-VarDados $L $v.id $dir }
    # StepM so na familia fixa (K = familia), blocos 10/20/40, vale o maior p ajustado
    $fam = @($vars | Where-Object { $_.papel -eq 'familia' })
    $pAdj = @{}; $critK = [double]::NaN; $omega = @{}
    if ($fam.Count -gt 0) {
        $dm = @(); $eleg = @()
        foreach ($v in $fam) {
            $dv = $dados[$v.id]
            $s0 = Get-Serie $c0 $v.serie
            if (-not $dv.ok -or $dv.tot.Count -ne $n) { $dm += , (New-Object double[] $n); $eleg += $false; continue }
            $sv = Get-Serie $dv $v.serie
            $d = New-Object double[] $n
            for ($i = 0; $i -lt $n; $i++) { $d[$i] = $sv[$i] - [double]$v.escala * $s0[$i] }
            $dm += , $d
            $sin = 0; for ($k = 0; $k -lt $dv.segs.Count; $k++) { $sin += [SurvLab.Rpt]::SinaisDiferentes($dv.segs[$k].Trades, $c0.segs[$k].Trades, $(if ($v.serie -eq 'total') { '' } else { $v.serie })) }
            $eleg += ($sin -ge 30)
        }
        foreach ($bl in 10, 20, 40) {
            $sm = [SurvLab.Stepm]::Rodar([double[][]]$dm, [bool[]]$eleg, 5000, $bl, [uint64](20260929 + $bl), 0.05)
            for ($k = 0; $k -lt $fam.Count; $k++) {
                $pk = $sm.PAjustado[$k]
                if (-not [double]::IsNaN($pk)) { if (-not $pAdj.ContainsKey($fam[$k].id) -or $pk -gt $pAdj[$fam[$k].id]) { $pAdj[$fam[$k].id] = $pk } }
                if ($bl -eq 20) { $omega[$fam[$k].id] = $sm.Omega[$k] }
            }
            if ($bl -eq 20) { $critK = $sm.CriticoK }
        }
    }
    $reg = Get-Registro
    foreach ($v in $vars) {
        $dv = $dados[$v.id]
        $o = [ordered]@{ id = $v.id; papel = $v.papel; serie = $v.serie; escala = [double]$v.escala; overrides = $v.overrides; classe = ''; motivos = @() }
        if (-not $dv.ok -or $dv.tot.Count -ne $n) { $o.classe = 'INVALIDA'; $o.motivos += 'run incompleto ou invalido'; $res.variantes += [pscustomobject]$o; continue }
        $s0 = Get-Serie $c0 $v.serie; $sv = Get-Serie $dv $v.serie
        $d = New-Object double[] $n
        for ($i = 0; $i -lt $n; $i++) { $d[$i] = $sv[$i] - [double]$v.escala * $s0[$i] }
        $media = ($d | Measure-Object -Average).Average
        $sin = 0; for ($k = 0; $k -lt $dv.segs.Count; $k++) { $sin += [SurvLab.Rpt]::SinaisDiferentes($dv.segs[$k].Trades, $c0.segs[$k].Trades, $(if ($v.serie -eq 'total') { '' } else { $v.serie })) }
        $o.sinais_alterados = $sin
        $o.delta_anual = $media * $ano * 100
        $o.delta_h1 = (Sum $d 0 $h) / [Math]::Max(1, $h) * $ano * 100
        $o.delta_h2 = (Sum $d $h $n) / [Math]::Max(1, $n - $h) * $ano * 100
        # efeito na conta toda (transbordo E1<->E3 pelo stop diario global e pelo limite de pernas), mesma exposicao
        $dT = New-Object double[] $n
        for ($i = 0; $i -lt $n; $i++) { $dT[$i] = $dv.tot[$i] - $c0.tot[$i]; if ($v.serie -eq 'E3') { $dT[$i] += (1 - [double]$v.escala) * $c0.e3[$i] } }
        $o.delta_total_anual = (($dT | Measure-Object -Average).Average) * $ano * 100
        # concentracao por mes
        $meses = @{}
        for ($i = 0; $i -lt $n; $i++) { $mk = $dias[$i].ToString('yyyy-MM'); if (-not $meses.ContainsKey($mk)) { $meses[$mk] = 0.0 }; $meses[$mk] += $d[$i] }
        $tot = Sum $d 0 $n
        $o.maior_mes_pct = [double]::NaN
        if ($tot -gt 0) { $o.maior_mes_pct = 100.0 * (($meses.Values | Measure-Object -Maximum).Maximum) / $tot }
        $o.trades = $dv.trades.Count; $o.pf = Get-Pf $dv.trades ''; $o.pf_serie = Get-Pf $dv.trades $(if ($v.serie -eq 'total') { '' } else { $v.serie })
        $o.dd_fech = Get-Dd ([double[]]$dv.fech); $o.dd_eq_seg = $dv.ddEq
        $o.ret_anual = (([double[]]$dv.tot | Measure-Object -Average).Average * $ano * 100)
        $sH1 = (Sum ([double[]]$dv.tot) 0 $h); $sH2 = (Sum ([double[]]$dv.tot) $h $n)
        $ddv = [Math]::Max($o.dd_fech, $o.dd_eq_seg); $dd0 = [Math]::Max($c0info.dd_fech, $c0info.dd_eq_seg)
        $o.gate = (($o.pf -ge 1.3) -and ($ddv -le 30) -and ($o.trades -ge 100) -and ($sH1 -gt 0) -and ($sH2 -gt 0))
        $mp = [SurvLab.McPar]::Rodar([double[]]$c0.tot, [double[]]$dv.tot, 5000, 20, [int][Math]::Round($ano), [uint64]20260929, $g[0], $g[1], $g[2], $g[3])
        if ($mp) { $o.mc_pdd20 = $mp.PDd20Variante; $o.mc_pdd20_c0 = $mp.PDd20Controle; $o.mc_phalt = $mp.PHaltVariante; $o.mc_ret_med = $mp.RetMedVariante; $o.mc_ret_med_c0 = $mp.RetMedControle }
        $mcOk = ($mp -and ($mp.PDd20Variante -le $mp.PDd20Controle + 2.0) -and ($mp.PHaltVariante -le 1.0))
        $retRel = [Math]::Abs($c0info.ret_anual)
        $crit = [ordered]@{
            'p ajustado <= 0,05'           = $false
            'delta > 0 nas duas metades'   = (($o.delta_h1 -gt 0) -and ($o.delta_h2 -gt 0))
            'maior mes <= 50% do delta'    = ((-not [double]::IsNaN($o.maior_mes_pct)) -and ($o.maior_mes_pct -le 50))
            'delta >= 10% do retorno'      = ($o.delta_anual -ge 0.10 * $retRel)
            'DD <= DD do C0 + 3 p.p.'      = ($ddv -le $dd0 + 3.0)
            'gate 5.2'                     = $o.gate
            'Monte Carlo pareado'          = [bool]$mcOk
            'conta toda nao piora'         = ($o.delta_total_anual -ge 0)
        }
        if ($v.papel -eq 'familia') {
            $o.p_ajustado = $(if ($pAdj.ContainsKey($v.id)) { $pAdj[$v.id] } else { [double]::NaN })
            $crit['p ajustado <= 0,05'] = ((-not [double]::IsNaN($o.p_ajustado)) -and $o.p_ajustado -le 0.05)
            if ($omega.ContainsKey($v.id) -and -not [double]::IsNaN($omega[$v.id])) {
                $se = $omega[$v.id] / [Math]::Sqrt($n) * $ano * 100
                $o.se_anual = $se; $o.ic90 = @(($o.delta_anual - 1.645 * $se), ($o.delta_anual + 1.645 * $se)); $o.mde = ($critK + 0.84) * $se
            }
        }
        $o.criterios = $crit
        $falhas = @($crit.Keys | Where-Object { -not $crit[$_] })
        if ($sin -eq 0) { $o.classe = 'INERTE' }
        elseif ($sin -lt 30) { $o.classe = 'INCONCLUSIVA'; $o.motivos += "so $sin sinais alterados (< 30)" }
        elseif ($o.delta_anual -le 0) { $o.classe = 'PIOR' }
        elseif ($v.papel -eq 'familia' -and $falhas.Count -eq 0) { $o.classe = 'CANDIDATA' }
        else { $o.classe = 'INCONCLUSIVA'; $o.motivos += ('nao cumpriu: ' + ($falhas -join ', ')) }
        $ef = @($reg.variantes | Where-Object { $_.id -eq $v.id -and $_.estado -in @('APROVADA', 'EXPIRADA') })
        if ($ef.Count -gt 0 -and $o.classe -eq 'CANDIDATA') { $o.classe = 'INCONCLUSIVA'; $o.motivos += ("ja {0} no registro: nao congela de novo" -f $ef[0].estado) }
        # fora da amostra (candidata congelada ou extra em teste); fora da familia os overrides tem de ser os mesmos
        $ovj = ($v.overrides | ConvertTo-Json -Compress)
        $e = @($reg.variantes | Where-Object { $_.id -eq $v.id -and $_.estado -in @('CANDIDATA', 'EM_TESTE') -and ($v.papel -eq 'familia' -or (($_.overrides | ConvertTo-Json -Compress) -eq $ovj)) })
        if ($e.Count -gt 0) {
            $cong = D $e[0].congelada_em
            $idx = @(); for ($i = 0; $i -lt $n; $i++) { if ($dias[$i] -gt $cong) { $idx += $i } }
            $o.oos_dias = $idx.Count
            if ($idx.Count -gt 0) {
                $xs = [double[]]($idx | ForEach-Object { $d[$_] })
                $mo = ($xs | Measure-Object -Average).Average
                $sd = [Math]::Sqrt((($xs | ForEach-Object { ($_ - $mo) * ($_ - $mo) }) | Measure-Object -Sum).Sum / [Math]::Max(1, $xs.Length - 1))
                $o.oos_soma = ($xs | Measure-Object -Sum).Sum * 100
                $o.oos_t = $(if ($sd -gt 0) { $mo / ($sd / [Math]::Sqrt($xs.Length)) } else { 0.0 })
            }
            $orig = "$($e[0].trimestre_origem)"
            $trims = @(@($e[0].historico) | Where-Object { "$($_.trimestre)" -match '^\d{4}Q[1-4]$' -and "$($_.trimestre)" -gt $orig } | ForEach-Object { "$($_.trimestre)" } | Sort-Object -Unique)
            if ($L.tipo -eq 'trimestral' -and $L.trimestre -match '^\d{4}Q[1-4]$' -and $L.trimestre -gt $orig -and $L.trimestre -notin $trims) { $trims += $L.trimestre }
            $o.oos_trimestres = $trims.Count
            $o.estado_registro = $e[0].estado
            $okOos = ($o.oos_soma -gt 0)
            # extras nunca passaram pelo StepM: fora da amostra precisam de evidencia propria (>= 100 dias e t >= 1,645)
            if ($e[0].origem -eq 'extra') { $okOos = $okOos -and ($o.oos_dias -ge 100) -and ($o.oos_t -ge 1.645) }
            if ($o.oos_trimestres -ge 2 -and $okOos -and $o.delta_anual -gt 0 -and $o.delta_total_anual -ge 0 -and $o.gate -and $mcOk) { $o.classe = 'APROVADA' }
            elseif ($o.oos_trimestres -ge 4 -or ($o.oos_dias -ge 40 -and $o.oos_t -lt -1)) { $o.classe = 'EXPIRADA' }
            elseif ($o.classe -ne 'INVALIDA') { $o.classe = 'EM_QUARENTENA'; $o.motivos = @("fora da amostra: {0} dias, soma {1} %, {2} trimestre(s) de 2" -f $o.oos_dias, (F $o.oos_soma), $o.oos_trimestres) }
        } elseif ($v.papel -eq 'extra') {
            if ($o.classe -notin @('INVALIDA', 'INERTE')) { $o.motivos += 'extra: resultado DENTRO da amostra, so informativo; entra em teste fora da amostra' }
        }
        $res.variantes += [pscustomobject]$o
    }
    return $res
}

function Update-Registro($L, $Res, $Hs) {
    # candidatas da familia sao congeladas (data = fim da janela); extras entram EM_TESTE (data = criacao do lote);
    # aprovadas/expiradas saem da lista de acompanhamento. So o lab escreve aqui.
    if (-not $Res.valido -or $L.tipo -eq 'sonda' -or $L.trimestre -notmatch '^\d{4}Q[1-4]$') { return }
    $reg = Get-Registro
    $lista = @($reg.variantes)
    foreach ($v in $Res.variantes) {
        $e = @($lista | Where-Object { $_.id -eq $v.id })
        $hist = [pscustomobject]@{ lote = $L.id; trimestre = $L.trimestre; classe = $v.classe; delta_anual = $v.delta_anual }
        if ($e.Count -eq 0) {
            $novo = $null
            if ($v.classe -eq 'CANDIDATA') { $novo = 'CANDIDATA'; $cong = $L.janela.ate }
            elseif ($v.papel -eq 'extra' -and $v.classe -notin @('INVALIDA', 'INERTE')) { $novo = 'EM_TESTE'; $cong = [DateTime]::UtcNow.ToString('yyyy.MM.dd') }
            if ($novo) {
                $lista += [pscustomobject][ordered]@{ id = $v.id; origem = $(if ($v.papel -eq 'extra') { 'extra' } else { 'familia' }); serie = $v.serie; escala = $v.escala
                    overrides = $v.overrides; estado = $novo; congelada_em = $cong; trimestre_origem = $L.trimestre; historico = @($hist) }
                Log ("registro: {0} -> {1} (congelada em {2})" -f $v.id, $novo, $cong)
            }
        } else {
            if (@(@($e[0].historico) | Where-Object { $_.lote -eq $L.id }).Count -eq 0) { $e[0].historico = @($e[0].historico) + $hist }
            if ($v.classe -eq 'APROVADA' -and -not ($Hs -and $Hs.Contains($v.id))) { Log ("registro: {0} passaria, mas o .set nao foi gerado (base mudou ou nao confirmada): continua {1}" -f $v.id, $e[0].estado) }
            elseif ($v.classe -in @('APROVADA', 'EXPIRADA')) { $e[0].estado = $v.classe; Log ("registro: {0} -> {1}" -f $v.id, $v.classe) }
        }
    }
    $reg.variantes = $lista
    Save-Json $reg $REGISTRO
}

# --- relatorio e propostas ----------------------------------------------------------------------
function Write-Propostas($L, $Res, $BaseInp) {
    $dir = Join-Path (Join-Path $LOTES_DIR $L.id) 'propostas'
    $hs = [ordered]@{}
    if (-not $L.base.confirmada) { return $hs }
    foreach ($v in $Res.variantes) {
        if ($v.classe -ne 'APROVADA') { continue }
        Ensure-Dir $dir
        $linhas = New-Object Collections.Generic.List[string]
        $ovTxt = ($v.overrides.PSObject.Properties | ForEach-Object { "$($_.Name)=$($_.Value)" }) -join ' '
        $linhas.Add(("; lab lote={0} variante={1} base_md5={2} overrides={3} gerado={4}" -f $L.id, $v.id, $L.base.md5, $ovTxt, (Get-UtcStamp)))
        foreach ($k in $BaseInp.Keys) {
            $val = "$($BaseInp[$k])"
            $p = $v.overrides.PSObject.Properties[$k]
            if ($p) { $val = "$($p.Value)" }
            if ($k -in @('Panel_Mostrar', 'E2_MostrarStatusGrafico')) { $val = 'false' }
            $linhas.Add("$k=$val")
        }
        $f = Join-Path $dir ("{0}.set" -f $v.id)
        [IO.File]::WriteAllText($f, (($linhas.ToArray() -join "`r`n") + "`r`n"), (New-Object Text.UnicodeEncoding($false, $true)))
        $hs[$v.id] = Get-Hash $f 'SHA256'
        Log ("proposta {0}\{1}.set sha256={2}" -f $L.id, $v.id, $hs[$v.id])
    }
    return $hs
}

function Write-Relatorio($L, $Res) {
    $dir = Join-Path $LOTES_DIR $L.id
    $s = New-Object Text.StringBuilder
    $w = { param($x) [void]$s.AppendLine($x) }
    & $w ("# Laboratorio - lote {0}" -f $L.id)
    & $w ''
    & $w ("Gerado por ops\lab.ps1 em {0}. Relatorio deterministico: os numeros saem dos relatorios do tester em reports\. RESULTADO HIPOTETICO (backtest)." -f (Get-UtcStamp))
    & $w ''
    & $w ("- Tipo: {0} | trimestre {1} | janela {2} a {3} (segmentos de {4} meses) | motivo: {5}" -f $L.tipo, $L.trimestre, $L.janela.de, $L.janela.ate, $L.segmento_meses, $L.motivo)
    & $w ("- Conta de teste: demo {0} ({1}) | .ex5 md5 {2} | base: {3} (confirmada: {4}, degrau {5}, md5 {6})" -f $L.conta_demo, $LAB_SERVER, $L.ex5_md5, $L.base.fonte, $L.base.confirmada, $L.base.degrau, $L.base.md5)
    if (@($L.base.dif_preset).Count -gt 0) { & $w ("- ATENCAO: o grafico ao vivo difere do preset do degrau em: {0}" -f (@($L.base.dif_preset) -join ', ')) }
    & $w ("- Noticias: {0} eventos em hora do servidor (USD de {1} a {2}), md5 {3}" -f $L.noticias.eventos, $L.noticias.usd_de, $L.noticias.usd_ate, $L.noticias.md5)
    $okRuns = @($L.runs | Where-Object { $_.estado -eq 'ok' }).Count
    & $w ("- Runs: {0} de {1} ok; builds {2}; memoria maxima {3} MB (job {4} MB)" -f $okRuns, @($L.runs).Count, ((@($L.runs | ForEach-Object { $_.build } | Where-Object { $_ } | Sort-Object -Unique)) -join ','), (@($L.runs | ForEach-Object { [int]$_.memoria_mb }) | Measure-Object -Maximum).Maximum, (@($L.runs | ForEach-Object { [int]$_.pico_job_mb }) | Measure-Object -Maximum).Maximum)
    & $w ''
    if (-not $Res.valido) {
        & $w '## LOTE INVALIDO'
        foreach ($m in $Res.motivos) { & $w "- $m" }
        & $w ''
        & $w 'Nada deste lote vale como evidencia. O lab roda o trimestre de novo no proximo fim de semana.'
        [IO.File]::WriteAllText((Join-Path $dir 'relatorio.md'), $s.ToString(), (New-Object Text.UTF8Encoding($false)))
        return
    }
    $c = $Res.c0
    & $w '## Controle (configuracao em uso)'
    & $w ''
    & $w ("Trades {0} | PF {1} (E1 {2}, E3 {3}) | retorno medio anual {4}% (fracionario, sem composicao) | DD de saldo fechado {5}% | maior DD de equity de um segmento {6}%" -f $c.trades, (F $c.pf), (F $c.pf_e1), (F $c.pf_e3), (F $c.ret_anual '0.0'), (F $c.dd_fech '0.0'), (F $c.dd_eq_seg '0.0'))
    $gt = 'NAO PASSA'; if ($c.gate) { $gt = 'PASSA' }
    & $w ("Gate 5.2 do controle (PF >= 1,3, DD <= 30%, >= 100 trades, lucro nas duas metades): {0}" -f $gt)
    & $w ("Metades (soma dos retornos diarios, %): total H1 {0} / H2 {1}; E1 {2} / {3}; E3 {4} / {5}" -f (F $c.h1 '0.0'), (F $c.h2 '0.0'), (F $c.e1_h1 '0.0'), (F $c.e1_h2 '0.0'), (F $c.e3_h1 '0.0'), (F $c.e3_h2 '0.0'))
    & $w ''
    & $w '## Alternativas testadas'
    & $w ''
    & $w '| variante | muda | serie | sinais alterados | delta anual (p.p.) | IC 90% | H1 / H2 | conta toda | p ajustado | MDE | PF | DD | MC P(DD>=20%) var/C0 | classe |'
    & $w '|---|---|---|---|---|---|---|---|---|---|---|---|---|---|'
    foreach ($v in $Res.variantes) {
        $ov = ($v.overrides.PSObject.Properties | ForEach-Object { "$($_.Name)=$($_.Value)" }) -join ' '
        if ($v.escala -ne 1.0) { $ov += (" (vs controle x{0})" -f (F $v.escala '0.00')) }
        $ic = '-'; if ($v.ic90) { $ic = ("{0} a {1}" -f (F $v.ic90[0] '0.0'), (F $v.ic90[1] '0.0')) }
        $pa = '-'; if ($v.PSObject.Properties['p_ajustado']) { $pa = F $v.p_ajustado '0.000' }
        $mde = '-'; if ($v.PSObject.Properties['mde']) { $mde = F $v.mde '0.0' }
        $mc = '-'; if ($v.PSObject.Properties['mc_pdd20']) { $mc = ("{0} / {1}" -f (F $v.mc_pdd20 '0.0'), (F $v.mc_pdd20_c0 '0.0')) }
        if ($v.classe -eq 'INVALIDA') { & $w ("| {0} | {1} | {2} | - | - | - | - | - | - | - | - | - | - | INVALIDA |" -f $v.id, $ov, $v.serie); continue }
        & $w ("| {0} | {1} | {2} | {3} | {4} | {5} | {6} / {7} | {8} | {9} | {10} | {11} | {12} | {13} | **{14}** |" -f $v.id, $ov, $v.serie, $v.sinais_alterados, (F $v.delta_anual '0.0'), $ic, (F $v.delta_h1 '0.0'), (F $v.delta_h2 '0.0'), (F $v.delta_total_anual '0.0'), $pa, $mde, (F $v.pf), (F ([Math]::Max($v.dd_fech, $v.dd_eq_seg)) '0.0'), $mc, $v.classe)
    }
    & $w ''
    foreach ($v in $Res.variantes) {
        if ($v.motivos -and @($v.motivos).Count -gt 0) { & $w ("- {0}: {1}" -f $v.id, (@($v.motivos) -join '; ')) }
        if ($v.papel -eq 'extra' -and $v.classe -in @('INVALIDA', 'INERTE')) { & $w ("- ATENCAO: a extra {0} saiu {1} e NAO entra em teste fora da amostra (pedir de novo com outro id, se fizer sentido)." -f $v.id, $v.classe) }
    }
    & $w ''
    & $w 'Classes: INERTE (nenhum sinal mudou), INCONCLUSIVA (sem evidencia suficiente; e o resultado esperado na maioria dos trimestres), PIOR, CANDIDATA (passou em tudo DENTRO da amostra: fica congelada e so vale depois de 2 trimestres fora da amostra), EM_QUARENTENA, APROVADA (passou fora da amostra: .set em propostas\), EXPIRADA, INVALIDA.'
    & $w 'p ajustado: StepM de Romano-Wolf sobre a familia fixa (bootstrap estacionario, blocos de 10, 20 e 40 dias; vale o maior). MDE: menor efeito anual que a familia detectaria com ~80% de chance.'
    & $w ''
    & $w '## Solucoes de risco (sem backtest novo: Monte Carlo dos trades do controle, guardiao do degrau em vigor)'
    & $w ''
    & $w '| escala de risco | P(parada total) | P(DD>=20%) | DD p95 | retorno mediano 12 m | retorno p5 | P(ano negativo) |'
    & $w '|---|---|---|---|---|---|---|'
    foreach ($x in $Res.solucoes) { & $w ("| {0} | {1}% | {2}% | {3}% | {4}% | {5}% | {6}% |" -f (F $x.escala '0.00'), (F $x.p_halt '0.0'), (F $x.p_dd20 '0.0'), (F $x.dd_p95 '0.0'), (F $x.ret_med '0.0'), (F $x.ret_p5 '0.0'), (F $x.p_neg '0.0')) }
    & $w ''
    & $w 'Reducao de risco pode ser aplicada pelo agente (RISK_SCALE, regras de 5.2/5.7); aumento e troca de parametro so com OK do Henrique.'
    $apr = @($Res.variantes | Where-Object { $_.classe -eq 'APROVADA' })
    & $w ''
    & $w '## Linhas para o INBOX'
    if ($apr.Count -eq 0) { & $w ''; & $w 'Nenhuma alternativa aprovada: manter a configuracao atual.' }
    foreach ($v in $apr) {
        & $w ''
        & $w ("- {0}: ``AAAA-MM-DD OK ALTERNATIVA {1}/{0}`` (antes de aplicar: ``ops\lab.ps1 -Acao conferir -Proposta campanha\lab\lotes\{1}\propostas\{0}.set``)" -f $v.id, $L.id)
    }
    [IO.File]::WriteAllText((Join-Path $dir 'relatorio.md'), $s.ToString(), (New-Object Text.UTF8Encoding($false)))
}

function Complete-Lote($L) {
    $dir = Join-Path $LOTES_DIR $L.id
    $base = Get-BaseInputs
    $res = Invoke-Analise $L
    $L.analise = [pscustomobject]@{ valido = $res.valido; motivos = @($res.motivos); classes = @($res.variantes | ForEach-Object { "{0}={1}" -f $_.id, $_.classe }) }
    Save-Json ([pscustomobject]$res) (Join-Path $dir 'analise.json')
    Write-Relatorio $L $res
    $hs = [ordered]@{ relatorio = (Get-Hash (Join-Path $dir 'relatorio.md') 'SHA256') }
    if ($res.valido) {
        $baseInp = $base.Inputs
        if ($base.Md5 -ne $L.base.md5) { Log ("AVISO: a base mudou desde a criacao do lote {0}: sem propostas" -f $L.id) }
        else { $p = Write-Propostas $L ([pscustomobject]$res) $baseInp; foreach ($k in $p.Keys) { $hs[$k] = $p[$k] } }
        Update-Registro $L ([pscustomobject]$res) $hs
        $L.estado = 'concluido'
    } else { $L.estado = 'invalido' }
    $L.hashes = [pscustomobject]$hs
    Save-Lote $L
    Log ("lote {0} {1}: {2} | relatorio sha256 {3}" -f $L.id, $L.estado, ($L.analise.classes -join ' '), $hs['relatorio'])
    return $res
}

# --- agente ------------------------------------------------------------------------------------
function Test-PodeChamarAgente {
    if ($Local) { return $false }
    $a = [DateTime]::UtcNow
    if ($a.DayOfWeek -eq [DayOfWeek]::Sunday -and ($a.Hour * 60 + $a.Minute) -ge 990) { return $false }   # dom 16:30
    foreach ($s in @(@([DayOfWeek]::Saturday, 12, 0), @([DayOfWeek]::Sunday, 18, 0))) {
        if ($a.DayOfWeek -eq $s[0]) {
            $t = New-Object DateTime($a.Year, $a.Month, $a.Day, $s[1], $s[2], 0, [DateTimeKind]::Utc)
            if ($t -gt $a -and ($t - $a).TotalMinutes -lt 75) { return $false }
        }
    }
    return $true
}

function Invoke-Agente($L) {
    if (-not (Test-PodeChamarAgente)) { Log ("agente nao chamado agora para {0}: a proxima acordada agendada colhe o lote" -f $L.id); return $false }
    $ps = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $a = ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -Modo lab -TimeoutMin 20 -Motivo "lote {1} {2}"' -f (Join-Path $PSScriptRoot 'run_claude.ps1'), $L.id, $L.estado)
    $np = Start-Detached -FilePath $ps -Arguments $a -WorkingDirectory $PSScriptRoot
    $L.agente_chamado = Get-UtcStamp
    Save-Lote $L
    Log ("agente chamado (run_claude -Modo lab, PID {0}) para o lote {1}" -f $np, $L.id)
    return ($np -gt 0)
}

# --- ex5 da copia ------------------------------------------------------------------------------
function Sync-Ex5 {
    # o .ex5 do laboratorio e SEMPRE o mesmo binario que opera ao vivo (copia do terminal ao vivo para a copia)
    $src = Join-Path $MT5_DATA 'MQL5\Experts\Sobrevivencia\Concorde_RF.ex5'
    if (-not (Test-Path -LiteralPath $src)) { $src = Join-Path $WS 'mql5\Experts\Concorde_RF.ex5' }
    if (-not (Test-Path -LiteralPath $src)) { throw 'Concorde_RF.ex5 nao encontrado' }
    $dst = Join-Path $LAB_DIR 'MQL5\Experts\Concorde_RF.ex5'
    Assert-LabPath $dst
    Ensure-Dir (Split-Path -Parent $dst)
    Copy-Item -LiteralPath $src -Destination $dst -Force
    return (Get-Hash $dst)
}

# --- execucao principal ------------------------------------------------------------------------
function Invoke-Executor {
    Import-LabCore
    $li = Get-LabLockInfo
    if ($li -and $li.Pid -ne $PID) { Write-Host "ja existe um lab.ps1 rodando (PID $($li.Pid))"; return }
    Set-LabLock 'executar'
    $je = [SurvLab.LabJob]::Criar($LAB_MEM_LIMIT_MB, $LAB_CPUS)
    if ($je) { Log "ERRO ao criar o job da copia: $je"; Remove-LabLock; return }
    try {
        $cop = Test-CopiaOk
        if ($cop) { Log "laboratorio parado: $cop"; Notify 'ATENCAO' 'Laboratorio parado' $cop; return }
        $ex5 = Sync-Ex5
        $news = Update-NewsLab
        $base = Get-BaseInputs
        $agora = [DateTime]::UtcNow
        $lotes = @(Get-Lotes)
        $fimSem = $agora.Date; while ($fimSem.DayOfWeek -ne [DayOfWeek]::Saturday) { $fimSem = $fimSem.AddDays(-1) }  # sabado deste fim de semana
        # 1) sonda da semana (controle na ultima semana util)
        if ($TesteJanela) {
            $pz = $TesteJanela.Split('-'); $de = D $pz[0]; $ate = D $pz[1]
            $fam = @(); if (-not $SemFamilia) { $fam = @(Get-FamiliaV1 $base.Inputs | ForEach-Object { $_ | Add-Member -NotePropertyName papel -NotePropertyValue 'familia' -PassThru }) }
            if ($SoVariantes) { $so = $SoVariantes.Split(','); $fam = @($fam | Where-Object { $_.id -in $so }) }
            if (-not @($lotes | Where-Object { $_.trimestre -eq 'TESTE' -and $_.estado -in @('pendente', 'rodando') })) {
                New-Lote 'trimestral' 'TESTE' $de $ate $fam 'teste local' $base $news | Out-Null
            }
        } elseif (-not @($lotes | Where-Object { $_.tipo -eq 'sonda' -and (D $_.janela.ate) -ge $fimSem.AddDays(-1) })) {
            $sex = $fimSem.AddDays(-1); $seg = $sex.AddDays(-4)
            New-Lote 'sonda' ('S' + $sex.ToString('yyyyMMdd')) $seg $sex @() 'sonda semanal' $base $news | Out-Null
        }
        # 2) trimestral do ultimo trimestre completo, se ainda nao ha lote concluido ou pendente dele
        $tq = Get-TrimestreAnterior $agora
        $doTrim = @(Get-Lotes | Where-Object { $_.tipo -eq 'trimestral' -and $_.trimestre -eq $tq.Id -and $_.estado -in @('pendente', 'rodando', 'concluido') })
        $invEsteFds = @(Get-Lotes | Where-Object { $_.tipo -eq 'trimestral' -and $_.trimestre -eq $tq.Id -and $_.estado -eq 'invalido' -and $_.criado -ge $fimSem.ToString('yyyy-MM-dd') })
        if (-not $TesteJanela -and $doTrim.Count -eq 0 -and $invEsteFds.Count -eq 0) {
            $ate = $tq.Fim; $de = $ate.AddMonths(-24).AddDays(1)
            if ($news.UsdAte -lt $ate.AddDays(-3) -or $news.UsdDe -gt $de.AddDays(3)) {
                Log ("trimestral {0} NAO criado: noticias USD cobrem {1:yyyy-MM-dd} a {2:yyyy-MM-dd}, janela {3} a {4}" -f $tq.Id, $news.UsdDe, $news.UsdAte, (DS $de), (DS $ate))
                Notify 'ATENCAO' 'Laboratorio: noticias nao cobrem a janela' ("news.csv (+ campanha\lab\news) cobre USD ate {0:yyyy-MM-dd}; a revalidacao {1} precisa ate {2:yyyy-MM-dd}. Atualizar o calendario (CLAUDE.md 5.9)." -f $news.UsdAte, $tq.Id, $ate)
            } else {
                $vs = @(Get-FamiliaV1 $base.Inputs | ForEach-Object { $_ | Add-Member -NotePropertyName papel -NotePropertyValue 'familia' -PassThru })
                $idsFam = @($vs | ForEach-Object { $_.id })
                foreach ($e in @(Get-VariantesAtivas)) {
                    if ($e.id -in $idsFam) { continue }
                    $vs += [pscustomobject]@{ id = $e.id; papel = $(if ($e.origem -eq 'extra') { 'extra' } else { 'acompanhamento' }); serie = $e.serie; escala = [double]$e.escala; overrides = $e.overrides }
                }
                New-Lote 'trimestral' $tq.Id $de $ate $vs ("revalidacao do trimestre {0}" -f $tq.Id) $base $news | Out-Null
            }
        }
        # 3) fila do agente
        foreach ($pd in @(Read-Fila $base.Inputs)) {
            $ate = $tq.Fim; $de = $ate.AddMonths(-24).AddDays(1)
            New-Lote $pd.tipo $tq.Id $de $ate @($pd.variantes) $pd.motivo $base $news | Out-Null
        }
        # 4) rodar os lotes pendentes (sonda, trimestral, volta, extra), run a run
        $ordem = @{ sonda = 0; trimestral = 1; volta = 2; extra = 3 }
        foreach ($L in @(Get-Lotes | Where-Object { $_.estado -in @('pendente', 'rodando') } | Sort-Object { $ordem["$($_.tipo)"] }, seq)) {
            if ($L.base.md5 -ne $base.Md5) {
                $L.estado = 'invalido'; $L.analise = [pscustomobject]@{ valido = $false; motivos = @('a base do grafico ao vivo mudou durante o lote'); classes = @() }
                Save-Lote $L; Log ("lote {0} invalidado: base mudou" -f $L.id); continue
            }
            $L.ex5_md5 = $ex5; $L.estado = 'rodando'; Save-Lote $L
            $dir = Join-Path $LOTES_DIR $L.id
            $parar = $false
            foreach ($R in @($L.runs)) {
                if ($R.estado -eq 'ok') { continue }
                if ($R.estado -in @('invalido', 'falhou') -and $R.tentativas -ge 2) { continue }
                $prev = @($L.runs | Where-Object { $_.estado -eq 'ok' -and $_.dur_s -gt 0 } | ForEach-Object { $_.dur_s })
                $est = 75; if ($prev.Count -gt 0) { $est = [int][Math]::Ceiling((($prev | Measure-Object -Maximum).Maximum) / 60 * 1.3) + 5 }
                $motivo = Test-PodeRodar $est
                if ($motivo) { Log ("pausa antes de {0} {1}: {2}" -f $L.id, $R.nome, $motivo); $parar = $true; break }
                $R.tentativas = [int]$R.tentativas + 1
                $rr = Invoke-Run $L $R $base.Inputs $dir
                Save-Lote $L
                if ($rr -eq 'abortar') { $R.estado = 'pendente'; Save-Lote $L; Notify 'ATENCAO' ("Laboratorio: run abortado ({0})" -f $L.id) $R.erro; $parar = $true; break }
                # a porta 22346 continua do terminal ao vivo?
                if (-not $Local) {
                    $dono = Get-DonoPorta 22346
                    if ($dono -and $dono.ToLower() -ne ([string]$MT5_EXE).ToLower()) { Log "porta 22346 com dono errado ($dono)"; Notify 'ATENCAO' 'Laboratorio: porta do MCP' "Dono da 22346: $dono"; $parar = $true; break }
                }
                Start-Sleep -Seconds 20
            }
            if ($parar) { break }
            $falhos = @($L.runs | Where-Object { $_.estado -ne 'ok' })
            if ($falhos.Count -gt 0 -and @($falhos | Where-Object { $_.tentativas -lt 2 }).Count -gt 0) { continue }
            $res = Complete-Lote $L
            if ($L.tipo -eq 'sonda') {
                if (-not $res.valido -or $falhos.Count -gt 0) { Notify 'ATENCAO' 'Laboratorio: sonda semanal falhou' (($falhos | ForEach-Object { "$($_.nome): $($_.erro)" }) -join ' | ') }
                continue
            }
            [void](Invoke-Agente $L)
            # espera a acordada do agente (ate 30 min) e reprocessa a fila no mesmo fim de semana
            if (-not $Local) {
                $t1 = [DateTime]::UtcNow
                while ((([DateTime]::UtcNow - $t1).TotalMinutes -lt 30) -and ((Test-Path -LiteralPath (Join-Path $LOG_DIR 'claude.lock')) -or (([DateTime]::UtcNow - $t1).TotalMinutes -lt 2))) { Start-Sleep -Seconds 30 }
                foreach ($pd in @(Read-Fila $base.Inputs)) { $ate = $tq.Fim; $de = $ate.AddMonths(-24).AddDays(1); New-Lote $pd.tipo $tq.Id $de $ate @($pd.variantes) $pd.motivo $base $news | Out-Null }
            }
        }
        # limpeza: logs dos agentes de teste com mais de 30 dias
        foreach ($lf in @(Get-ChildItem -LiteralPath (Join-Path $LAB_DIR 'Tester') -Recurse -Filter '*.log' -File -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-30) })) {
            Assert-LabPath $lf.FullName; Remove-Item -LiteralPath $lf.FullName -Force -ErrorAction SilentlyContinue
        }
    } catch {
        Log ("ERRO no executor: {0} @ {1}" -f $_.Exception.Message, $_.InvocationInfo.PositionMessage)
        Notify 'ATENCAO' 'Laboratorio: erro no executor' $_.Exception.Message
    } finally {
        [SurvLab.LabJob]::Fechar()
        Stop-LabProcesses 'fim do executor' $ORIGEM | Out-Null
        Remove-LabLock
    }
}

# --- conferir uma proposta (Henrique, antes de aplicar) -----------------------------------------
function Invoke-Conferir([string]$Arq) {
    # Henrique, antes de aplicar. Recusa qualquer coisa que nao seja exatamente a alternativa APROVADA pelo lab sobre o
    # grafico ao vivo de hoje. Limite conhecido: o agente tem Bash e poderia forjar lote.json e registro.json; por isso a
    # saida mostra, lado a lado, cada valor que muda (conferir com o relatorio.md antes de aplicar).
    if (-not (Test-Path -LiteralPath $Arq)) { Write-Host "RECUSADO: arquivo nao existe: $Arq"; exit 1 }
    $Arq = (Resolve-Path -LiteralPath $Arq -ErrorAction Stop).ProviderPath
    $txt = Read-TextAuto $Arq
    $m = [regex]::Match($txt, '^;\s*lab lote=(\S+) variante=(\S+) base_md5=([0-9A-F]{32})\s')
    if (-not $m.Success) { Write-Host 'RECUSADO: sem cabecalho do laboratorio na 1a linha'; exit 1 }
    $lid = $m.Groups[1].Value; $vid = $m.Groups[2].Value; $bmd5 = $m.Groups[3].Value
    if ($lid -notmatch '^[A-Za-z0-9_]{1,60}$' -or $vid -notmatch '^[A-Za-z0-9_]{1,24}$') { Write-Host 'RECUSADO: cabecalho invalido'; exit 1 }
    $esp = [IO.Path]::GetFullPath((Join-Path $LOTES_DIR "$lid\propostas\$vid.set"))
    if ([IO.Path]::GetFullPath($Arq) -ne $esp) { Write-Host "RECUSADO: use o arquivo gerado pelo lab: $esp"; exit 1 }
    $L = Load-Json (Join-Path (Join-Path $LOTES_DIR $lid) 'lote.json')
    if (-not $L) { Write-Host "RECUSADO: lote $lid nao encontrado"; exit 1 }
    $h = Get-Hash $Arq 'SHA256'
    $hp = $L.hashes.PSObject.Properties[$vid]
    if (-not $hp -or $hp.Value -ne $h) { Write-Host 'RECUSADO: o hash do .set nao bate com o registrado pelo lab no lote (arquivo alterado?)'; exit 1 }
    $reg = Get-Registro
    $e = @($reg.variantes | Where-Object { $_.id -eq $vid })
    if ($e.Count -ne 1 -or $e[0].estado -ne 'APROVADA') { Write-Host "RECUSADO: $vid nao esta APROVADA no registro do laboratorio"; exit 1 }
    $lv = @($L.variantes | Where-Object { $_.id -eq $vid })
    if ($lv.Count -ne 1) { Write-Host 'RECUSADO: variante fora do lote'; exit 1 }
    # linhas do .set: sem chave repetida (nem por maiuscula/minuscula), sem linha estranha
    $set = [ordered]@{}; $vistos = @{}
    foreach ($ln in ($txt -split "`r?`n")) {
        $t = $ln.Trim(); if (-not $t -or $t.StartsWith(';')) { continue }
        $i = $t.IndexOf('='); if ($i -le 0) { Write-Host "RECUSADO: linha invalida '$t'"; exit 1 }
        $kk = $t.Substring(0, $i).Trim(); $kl = $kk.ToLower()
        if ($vistos.ContainsKey($kl)) { Write-Host "RECUSADO: $kk repetida no .set"; exit 1 }
        $vistos[$kl] = 1; $set[$kk] = $t.Substring($i + 1).Trim()
    }
    $base = Get-BaseInputs
    if (-not $base.Confirmada) { Write-Host 'RECUSADO: sem snapshot do perfil ao vivo (rode ops\save_profile.ps1)'; exit 1 }
    if ($base.Md5 -ne $bmd5) { Write-Host 'RECUSADO: o grafico ao vivo mudou desde o lote (base diferente). A alternativa precisa ser testada de novo.'; exit 1 }
    # o perfil salvo pelo terminal ao vivo tem de bater com o snapshot do kit (senao o snapshot esta velho)
    $vivoDir = $PROFILE_DST_DIR
    if (Test-Path -LiteralPath $vivoDir) {
        foreach ($f in @(Get-ChildItem -LiteralPath $vivoDir -Filter '*.chr' -File)) {
            $tv = Read-TextAuto $f.FullName
            foreach ($mm in [regex]::Matches("$tv", '(?s)<expert>(.*?)</expert>')) {
                if ($mm.Groups[1].Value -notmatch '(?m)^\s*name\s*=\s*Concorde_RF\s*$') { continue }
                $mi = [regex]::Match($mm.Groups[1].Value, '(?s)<inputs>(.*?)</inputs>')
                if (-not $mi.Success) { continue }
                $kv = Read-KeyValues $mi.Groups[1].Value
                foreach ($k in $kv.Keys) {
                    if ($k -in @('Panel_Mostrar', 'E2_MostrarStatusGrafico')) { continue }
                    if ("$($kv[$k])" -ne "$($base.Inputs[$k])") { Write-Host "RECUSADO: o perfil salvo no terminal difere do snapshot em $k ($($kv[$k]) x $($base.Inputs[$k])). Salve o perfil e rode ops\save_profile.ps1 antes."; exit 1 }
                }
            }
        }
    }
    $dif = @()
    foreach ($k in $set.Keys) {
        if ($k -in @('Panel_Mostrar', 'E2_MostrarStatusGrafico')) { continue }
        if (-not $base.Inputs.Contains($k)) { Write-Host "RECUSADO: $k nao existe no grafico ao vivo"; exit 1 }
        if ("$($set[$k])" -ne "$($base.Inputs[$k])") { $dif += $k }
    }
    foreach ($k in $base.Inputs.Keys) { if (-not $set.Contains($k) -and $k -notin @('Panel_Mostrar', 'E2_MostrarStatusGrafico')) { Write-Host "RECUSADO: $k falta no .set"; exit 1 } }
    $ovNomes = @($lv[0].overrides.PSObject.Properties | ForEach-Object { $_.Name })
    foreach ($k in $dif) {
        if ($k -notin $ovNomes) { Write-Host "RECUSADO: $k difere do grafico e nao faz parte da alternativa"; exit 1 }
        if (-not $LISTA_BRANCA.Contains($k)) { Write-Host "RECUSADO: $k fora da lista branca"; exit 1 }
        if ("$($set[$k])" -ne "$($lv[0].overrides.$k)") { Write-Host "RECUSADO: $k=$($set[$k]) nao e o valor testado ($($lv[0].overrides.$k))"; exit 1 }
    }
    $x = [ordered]@{}; foreach ($k in $dif) { $x[$k] = $set[$k] }
    $t = Test-Overrides $x $base.Inputs
    if (-not $t[0]) { Write-Host "RECUSADO: $($t[1])"; exit 1 }
    Write-Host ("OK: {0} muda so isto em relacao ao grafico ao vivo:" -f $vid)
    foreach ($k in $dif) { Write-Host ("   {0}: {1} -> {2}" -f $k, $base.Inputs[$k], $set[$k]) }
    Write-Host ("   risco por perna: E1 {0} -> {1} | E3 {2} -> {3}" -f $base.Inputs['E1_RiscoPorPernaPct'], $set['E1_RiscoPorPernaPct'], $base.Inputs['E3_RiscoPorPernaPct'], $set['E3_RiscoPorPernaPct'])
    Write-Host 'Confira com o relatorio.md do lote. Aplicar no fim de semana: grafico XAUUSD M15 > F7 > Parametros > Carregar este .set > OK; salvar o perfil sobrevivencia e rodar ops\save_profile.ps1.'
    Log ("conferir: {0} OK ({1})" -f $Arq, ($dif -join ','))
}

# --- status -----------------------------------------------------------------------------------
function Show-Status {
    $li = Get-LabLockInfo
    Write-Host ("Laboratorio: copia {0} | demo {1} | janela aberta agora: {2}" -f $LAB_DIR, $LAB_LOGIN, (Test-LabJanela ([DateTime]::UtcNow)))
    $c = Test-CopiaOk; if ($c) { Write-Host "  copia: $c" } else { Write-Host '  copia: ok' }
    if ($li) { Write-Host ("  executor rodando: PID {0} desde {1}" -f $li.Pid, $li.Desde) } else { Write-Host '  executor: parado' }
    $pp = @(Get-LabProcesses); Write-Host ("  processos da copia: {0}" -f $pp.Count)
    Write-Host ("  RAM disponivel: {0} MB (um run precisa de {1} MB) | disco livre: {2:N1} GB (precisa de {3})" -f (Get-RamDisponivelMb), ($LAB_MEM_LIMIT_MB + $LAB_RAM_FOLGA_MB), (Get-DiscoLivreGb), $LAB_DISCO_MIN_GB)
    foreach ($L in @(Get-Lotes | Select-Object -Last 8)) {
        $ok = @($L.runs | Where-Object { $_.estado -eq 'ok' }).Count
        $cl = ''; if ($L.analise) { $cl = (@($L.analise.classes) -join ' ') }
        Write-Host ("  lote {0} [{1}] {2}/{3} runs ok  {4}" -f $L.id, $L.estado, $ok, @($L.runs).Count, $cl)
    }
    foreach ($e in @((Get-Registro).variantes)) { Write-Host ("  registro: {0} {1} (congelada {2}, origem {3})" -f $e.id, $e.estado, $e.congelada_em, $e.origem) }
}

function Invoke-Parar {
    $li = Get-LabLockInfo
    if ($li) {
        try { Stop-Process -Id $li.Pid -Force -ErrorAction Stop; Log ("executor encerrado (PID {0})" -f $li.Pid) } catch { }
        Remove-Item -LiteralPath $LOCK -Force -ErrorAction SilentlyContinue
    }
    $n = Stop-LabProcesses 'lab.ps1 -Acao parar' $ORIGEM
    Write-Host ("Parado. Processos da copia encerrados: {0}" -f $n)
}

# --- despacho -----------------------------------------------------------------------------------
switch ($Acao) {
    'status' { Show-Status; exit 0 }
    'parar' { Invoke-Parar; exit 0 }
    'conferir' { Import-LabCore; Invoke-Conferir $Proposta; exit 0 }
    'relatorio' {
        Import-LabCore
        if ($Lote -notmatch '^[A-Za-z0-9_]{1,60}$') { Write-Host 'lote invalido'; exit 1 }
        $L = Load-Json (Join-Path (Join-Path $LOTES_DIR $Lote) 'lote.json'); if (-not $L) { Write-Host "lote $Lote nao encontrado"; exit 1 }
        if ($L.estado -eq 'concluido') { Write-Host 'RECUSADO: lote ja concluido (registro e propostas gravados); o relatorio.md dele continua valendo.'; exit 1 }
        if (@($L.runs | Where-Object { $_.estado -ne 'ok' }).Count -gt 0 -and $L.estado -ne 'invalido') { Write-Host 'RECUSADO: o lote ainda tem runs pendentes (o executor termina ele)'; exit 1 }
        if (Get-LabLockInfo) { Write-Host 'RECUSADO: o executor esta rodando'; exit 1 }
        Complete-Lote $L | Out-Null; exit 0
    }
    'agendado' {
        if (-not $LAB_LOGIN -or $LAB_LOGIN -le 0) { exit 0 }
        $agora = [DateTime]::UtcNow
        if (-not (Test-LabJanela $agora)) {
            if (@(Get-LabProcesses).Count -gt 0 -and -not (Test-LabManutencao)) { $n = Stop-LabProcesses 'fora da janela (tarefa do lab)' $ORIGEM; Notify 'CRITICO' 'Laboratorio encerrado fora da janela' "$n processo(s) da copia" }
            exit 0
        }
        if (Get-LabLockInfo) { exit 0 }
        $ps = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
        $np = Start-Detached -FilePath $ps -Arguments ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -Acao executar' -f $PSCommandPath) -WorkingDirectory $PSScriptRoot
        Write-OpsLog ("executor do laboratorio iniciado (PID {0})" -f $np) $ORIGEM
        exit 0
    }
    'executar' {
        if (-not $Local -and -not (Test-LabJanela ([DateTime]::UtcNow))) { Write-Host 'fora da janela do laboratorio (sab 04:30 a dom 17:30 UTC)'; exit 0 }
        Invoke-Executor; exit 0
    }
}
