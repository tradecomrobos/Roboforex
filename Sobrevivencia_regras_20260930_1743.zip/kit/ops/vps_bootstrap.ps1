# =====================================================================
#  vps_bootstrap.ps1 - instalador automatico do VPS (kit Sobrevivencia)
#  Automatiza o que da para automatizar do SETUP_VPS.md (secoes 1 a 7) e
#  imprime, no fim, a lista do que CONTINUA MANUAL (login, chaves, senhas).
#
#  ONDE RODAR: no VPS Hyonix (Windows Server 2022), num PowerShell 5.1
#  ABERTO COMO ADMINISTRADOR, logado com o MESMO usuario que tera o
#  auto-logon (a etapa 1 escreve em HKCU: se voce rodar com outro usuario,
#  a proteccao de tela e desligada para o usuario errado).
#
#  USO:
#    powershell -NoProfile -ExecutionPolicy Bypass -File C:\Sobrevivencia\ops\vps_bootstrap.ps1 -DryRun
#    powershell -NoProfile -ExecutionPolicy Bypass -File .\vps_bootstrap.ps1 -KitZip C:\kit.zip -InstalarMT5
#    powershell -NoProfile -ExecutionPolicy Bypass -File .\vps_bootstrap.ps1 -Etapas "1,5,6"
#
#  PARAMETROS:
#    -DryRun          nao altera NADA (nem o proprio log): so mostra o que faria.
#    -Etapas "1,2,4"  roda so as etapas escolhidas. Default: todas (1 a 6).
#                     A etapa 0 (pre-voo) roda sempre.
#    -KitZip <zip>    zip do workspace a extrair em C:\Sobrevivencia (etapa 3).
#                     Sem ele, a etapa 3 fica PULADA (copia manual por robocopy,
#                     SETUP_VPS.md secao 3).
#    -InstalarMT5     baixa (ou usa -MT5Setup) e instala o terminal, depois monta
#                     a instalacao portatil em C:\MT5_RoboForex (etapa 4).
#    -MT5Setup <exe>  instalador do MT5 ja baixado a mao (area do cliente RoboForex).
#                     Usar junto com -InstalarMT5 quando o download automatico falhar.
#    -PularGit        nao instala Git for Windows.
#    -PularClaude     nao instala o Claude Code (CLI).
#    -Reescrever      reescreve valores que ja estao corretos, em vez de reportar
#                     "ja estava configurado". -Force e apelido DESTE, e so deste.
#    -ForcarMaquina   continua mesmo quando a maquina parece a estacao do Henrique
#                     (ver etapa 0). NAO e ligado por -Force de proposito: quem
#                     digita -Force quer reaplicar valores, nao furar a guarda.
#
#  IDEMPOTENTE: rodar duas vezes nao quebra nada; na segunda vez cada item
#  reporta "JA OK". Todo item que muda imprime ANTES e DEPOIS. A etapa 3 PRESERVA
#  os segredos e o estado vivo do VPS (STATE.md, DIARIO.md, ALERTAS.md, INBOX.md),
#  guardando uma copia <arquivo>.antes_<carimbo> antes de reaplicar o kit.
#
#  LOG: C:\Sobrevivencia\ops\logs\bootstrap_<aaaammdd>.log (append) quando
#  C:\Sobrevivencia ja existe; senao C:\bootstrap_<aaaammdd>.log. O log so e
#  ABERTO depois da guarda de maquina (ate la nada e escrito em disco) e em
#  -DryRun nao grava log nenhum.
#
#  SEGURANCA (regras fixas deste script):
#    - NUNCA pede, digita, grava ou loga senha, token ou chave de API.
#    - NUNCA desativa firewall ou antivirus, NUNCA abre porta para a rede.
#    - NUNCA reinicia o Windows sozinho (se algo exigir reinicio, avisa).
#    - NUNCA instala o app desktop do Claude (so o CLI headless).
#    - Todo executavel baixado tem a assinatura digital conferida ANTES de ser
#      executado: status Valid E editor do certificado igual ao esperado
#      (Git = Johannes Schindelin, Autologon = Microsoft, MT5 = MetaQuotes).
#    - Nao registra tarefas agendadas: isso e o register_tasks.ps1, que so
#      roda DEPOIS do login do Claude e do MT5 configurado.
#
#  Codigo de saida: 0 tudo certo, 1 alguma etapa FALHOU, 2 nao e Administrador
#  (ou console elevado com OUTRO usuario), 3 guarda de maquina errada (use
#  -ForcarMaquina se for mesmo o VPS), 4 parametro invalido, 5 sem falhas mas
#  com etapa(s) MANUAL pendente(s).
#
#  Arquivo sem acentos de proposito (PowerShell 5.1 le .ps1 sem BOM como ANSI),
#  no mesmo padrao dos demais scripts de ops\.
# =====================================================================
param(
    [switch]$DryRun,
    [string]$Etapas = '',
    [string]$KitZip = '',
    [switch]$InstalarMT5,
    [string]$MT5Setup = '',
    [switch]$PularGit,
    [switch]$PularClaude,
    [switch]$Reescrever,
    [switch]$ForcarMaquina,
    [switch]$Force
)

# -Force continua existindo, mas APENAS como apelido de -Reescrever. Furar a guarda
# de maquina passou a exigir -ForcarMaquina, escrito por extenso: antes os dois
# sentidos moravam na mesma opcao e quem so queria reaplicar valores desligava a
# guarda sem perceber (e aplicava fuso, energia e Windows Update na estacao).
if ($Force) { $Reescrever = $true }

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# --- Caminhos fixos --------------------------------------------------
# Tem de bater com ops\config.ps1 ($WS e $MT5_DIR). A etapa 6 confere isso
# depois que o kit existe. Este script NAO carrega o config.ps1 de proposito:
# ele precisa rodar antes de o kit chegar na maquina.
$WS_VPS      = 'C:\Sobrevivencia'
$MT5_DIR_VPS = 'C:\MT5_RoboForex'
$MT5_EXE_VPS = "$MT5_DIR_VPS\terminal64.exe"
$LOG_DIR_VPS = "$WS_VPS\ops\logs"
$INST_DIR    = "$WS_VPS\installers"
if (-not (Test-Path -LiteralPath $WS_VPS)) { $INST_DIR = 'C:\installers' }

# URLs oficiais usadas (decisoes documentadas no fim do arquivo):
$URL_CLAUDE_INSTALL = 'https://claude.ai/install.ps1'
$URL_GIT_PAGINA     = 'https://git-scm.com/download/win'
$URL_GIT_API        = 'https://api.github.com/repos/git-for-windows/git/releases/latest'
$URL_AUTOLOGON      = 'https://download.sysinternals.com/files/AutoLogon.zip'
$URL_AUTOLOGON_DOC  = 'https://learn.microsoft.com/sysinternals/downloads/autologon'
# Padrao conhecido do instalador RoboForex no CDN da MetaQuotes. Em 22/09/2026
# esta URL respondeu 404 (conferido); por isso ha fallback para MANUAL.
$URLS_MT5 = @(
    'https://download.mql5.com/cdn/web/roboforex.ltd/mt5/roboforex5setup.exe',
    'https://download.mql5.com/cdn/web/roboforex.limited/mt5/roboforex5setup.exe'
)

$script:Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$script:LOG_FILE  = ''
$script:PRELOG    = @()      # linhas impressas antes de o log existir
$script:RESULT    = @()
$script:AVISOS    = @()
$script:AUTOLOGON_OK = $false # so vira $true com Autologon64.exe em disco E assinado

# =====================================================================
#  Funcoes de apoio
# =====================================================================

function Escreve {
    param([string]$Msg = '')
    Write-Host $Msg
    if ($script:LOG_FILE) {
        try { [IO.File]::AppendAllText($script:LOG_FILE, $Msg + "`r`n", $script:Utf8NoBom) } catch { }
    } elseif (-not $DryRun) {
        # O log ainda nao foi aberto (guarda de maquina nao passou): guarda em memoria.
        $script:PRELOG += $Msg
    }
}

function Abrir-Log {
    # Abre o log DEPOIS da guarda de maquina: assim uma execucao por engano na
    # estacao do Henrique nao cria C:\Sobrevivencia\ops\logs\ nem escreve nada.
    # Se o workspace ainda nao existe, o log vai para a raiz de C:.
    if ($DryRun) { return }
    $dataLog = Get-Date -Format 'yyyyMMdd'
    $alvo = "C:\bootstrap_$dataLog.log"
    try {
        if (Test-Path -LiteralPath $WS_VPS) {
            if (-not (Test-Path -LiteralPath $LOG_DIR_VPS)) { New-Item -ItemType Directory -Path $LOG_DIR_VPS -Force | Out-Null }
            $alvo = "$LOG_DIR_VPS\bootstrap_$dataLog.log"
        }
        [IO.File]::AppendAllText($alvo, '', $script:Utf8NoBom)
        $script:LOG_FILE = $alvo
    } catch {
        try {
            $alvo = "C:\bootstrap_$dataLog.log"
            [IO.File]::AppendAllText($alvo, '', $script:Utf8NoBom)
            $script:LOG_FILE = $alvo
        } catch { $script:LOG_FILE = '' }
    }
    if ($script:LOG_FILE -and ($script:PRELOG.Count -gt 0)) {
        try {
            foreach ($m in $script:PRELOG) { [IO.File]::AppendAllText($script:LOG_FILE, $m + "`r`n", $script:Utf8NoBom) }
        } catch { }
        $script:PRELOG = @()
    }
    Escreve ("log         : {0}" -f $script:LOG_FILE)
}

function Escreve-Titulo {
    param([string]$Texto)
    Escreve ''
    Escreve ('=' * 70)
    Escreve $Texto
    Escreve ('=' * 70)
}

function Escreve-Aviso {
    param([string]$Msg)
    $script:AVISOS += $Msg
    Escreve ("  AVISO: {0}" -f $Msg)
}

function Add-Resultado {
    param([string]$Etapa, [string]$Estado, [string]$Detalhe = '')
    $script:RESULT += (New-Object PSObject -Property @{ Etapa = $Etapa; Estado = $Estado; Detalhe = $Detalhe })
}

function Pior-Estado {
    # Combina os estados dos itens de uma etapa: FALHOU > MANUAL > OK > JA OK > PULADA
    param([string[]]$Estados)
    if ($Estados -contains 'FALHOU') { return 'FALHOU' }
    if ($Estados -contains 'MANUAL') { return 'MANUAL' }
    if ($Estados -contains 'OK')     { return 'OK' }
    if ($Estados -contains 'JA OK')  { return 'JA OK' }
    return 'PULADA'
}

function Test-Administrador {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $pr = New-Object Security.Principal.WindowsPrincipal($id)
    return $pr.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function New-DirSeFalta {
    param([string]$Caminho)
    if (Test-Path -LiteralPath $Caminho) {
        Escreve ("  pasta ANTES=existe DEPOIS=existe : {0}" -f $Caminho)
        return 'JA OK'
    }
    if ($DryRun) {
        Escreve ("  pasta ANTES=(ausente) DEPOIS=criada : {0}   [DryRun: nada escrito]" -f $Caminho)
        return 'OK'
    }
    New-Item -ItemType Directory -Path $Caminho -Force | Out-Null
    Escreve ("  pasta ANTES=(ausente) DEPOIS=criada : {0}" -f $Caminho)
    return 'OK'
}

function Get-RegValor {
    param([string]$Caminho, [string]$Nome)
    try {
        $i = Get-ItemProperty -Path $Caminho -Name $Nome -ErrorAction Stop
        return $i.$Nome
    } catch { return $null }
}

function Set-RegValor {
    # Escreve um valor de registro so se estiver diferente. Imprime ANTES/DEPOIS.
    # Tipo: 'DWord' ou 'String'.
    param([string]$Caminho, [string]$Nome, $Valor, [string]$Tipo, [string]$Descricao)
    $antes = Get-RegValor $Caminho $Nome
    $sAntes = '(ausente)'
    if ($null -ne $antes) { $sAntes = "$antes" }
    $igual = $false
    if ($null -ne $antes) { if ("$antes" -eq "$Valor") { $igual = $true } }
    if ($igual -and (-not $Reescrever)) {
        Escreve ("  {0}: ANTES={1} DEPOIS={1} (ja estava configurado)" -f $Descricao, $sAntes)
        return 'JA OK'
    }
    if ($DryRun) {
        Escreve ("  {0}: ANTES={1} -> DEPOIS={2}   [DryRun: nada escrito]" -f $Descricao, $sAntes, $Valor)
        return 'OK'
    }
    try {
        if (-not (Test-Path -LiteralPath $Caminho)) { New-Item -Path $Caminho -Force | Out-Null }
        New-ItemProperty -Path $Caminho -Name $Nome -Value $Valor -PropertyType $Tipo -Force | Out-Null
        $depois = Get-RegValor $Caminho $Nome
        Escreve ("  {0}: ANTES={1} -> DEPOIS={2}" -f $Descricao, $sAntes, "$depois")
        return 'OK'
    } catch {
        Escreve ("  {0}: FALHOU ({1})" -f $Descricao, $_.Exception.Message)
        return 'FALHOU'
    }
}

function Invoke-Capturado {
    # Roda um executavel curto, devolve objeto com Saida (texto) e Codigo (exit code).
    # $ErrorActionPreference vira 'Continue' aqui dentro de proposito: no PowerShell 5.1,
    # com 'Stop', uma linha que o programa escreva em stderr vira NativeCommandError e
    # aborta a chamada mesmo quando o exit code foi 0 (acontece com git, w32tm, robocopy).
    param([string]$Exe, [string[]]$Argumentos = @())
    $saida = ''
    $codigo = -1
    $eapAntigo = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $tmp = & $Exe @Argumentos 2>&1
        $codigo = $LASTEXITCODE
        if ($null -eq $codigo) { $codigo = 0 }
        $saida = ($tmp | Out-String).Trim()
    } catch {
        $saida = $_.Exception.Message
        $codigo = -1
    } finally {
        $ErrorActionPreference = $eapAntigo
    }
    return (New-Object PSObject -Property @{ Saida = $saida; Codigo = $codigo })
}

function Test-Comando {
    param([string]$Nome)
    $c = Get-Command $Nome -ErrorAction SilentlyContinue
    if ($c) { return $true }
    return $false
}

function Update-PathProcesso {
    # Recarrega o PATH do processo a partir do registro (Machine + User): sem isto
    # o git/claude recem-instalados so aparecem num console novo.
    try {
        $m = [Environment]::GetEnvironmentVariable('Path', 'Machine')
        $u = [Environment]::GetEnvironmentVariable('Path', 'User')
        $novo = $m
        if ($u) { $novo = $m + ';' + $u }
        $local = "$env:USERPROFILE\.local\bin"
        if ($novo -notlike ("*" + $local + "*")) { $novo = $novo + ';' + $local }
        $env:Path = $novo
    } catch { }
}

function Get-ArquivoWeb {
    # Baixa um arquivo para o destino. Devolve $true/$false. Nunca baixa em -DryRun.
    param([string]$Url, [string]$Destino)
    if ($DryRun) {
        Escreve ("  [DryRun] baixaria {0} -> {1}" -f $Url, $Destino)
        return $false
    }
    try {
        $dir = Split-Path -Parent $Destino
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        Escreve ("  baixando: {0}" -f $Url)
        Invoke-WebRequest -Uri $Url -OutFile $Destino -UseBasicParsing -TimeoutSec 600 -Headers @{ 'User-Agent' = 'vps_bootstrap' } -ErrorAction Stop
        $fi = Get-Item -LiteralPath $Destino
        Escreve ("  baixado : {0} ({1:N1} MB)" -f $Destino, ($fi.Length / 1MB))
        try { Unblock-File -LiteralPath $Destino -ErrorAction SilentlyContinue } catch { }
        return $true
    } catch {
        Escreve ("  falha no download: {0}" -f $_.Exception.Message)
        if (Test-Path -LiteralPath $Destino) { Remove-Item -LiteralPath $Destino -Force -ErrorAction SilentlyContinue }
        return $false
    }
}

function Test-Assinatura {
    # Confere a assinatura Authenticode de um executavel baixado.
    # Devolve $true so quando o status e Valid E o certificado e de um dos editores
    # esperados (quando informados): assinatura valida de QUALQUER editor nao basta -
    # um binario trocado por DNS/proxy/cache envenenado tambem pode estar assinado.
    param([string]$Arquivo, [string[]]$EditorEsperado = @())
    if (-not (Test-Path -LiteralPath $Arquivo)) {
        Escreve '  assinatura: arquivo inexistente'
        return $false
    }
    try {
        $sig = Get-AuthenticodeSignature -LiteralPath $Arquivo
        $subject = '(sem certificado)'
        if ($sig.SignerCertificate) { $subject = $sig.SignerCertificate.Subject }
        Escreve ("  assinatura: status={0}" -f $sig.Status)
        Escreve ("  certificado: {0}" -f $subject)
        if ("$($sig.Status)" -ne 'Valid') { return $false }
        if ($EditorEsperado.Count -gt 0) {
            $bate = $false
            foreach ($ed in $EditorEsperado) { if ("$subject" -like ('*' + $ed + '*')) { $bate = $true } }
            if (-not $bate) {
                Escreve ("  assinatura: editor INESPERADO (esperava um de: {0})" -f ($EditorEsperado -join ', '))
                return $false
            }
        }
        return $true
    } catch {
        Escreve ("  assinatura: erro ao ler ({0})" -f $_.Exception.Message)
        return $false
    }
}

function Start-Instalador {
    # Roda um instalador e espera terminar (com limite de tempo). Devolve o exit code
    # (-1 = nao terminou no tempo, -2 = erro ao iniciar).
    param([string]$Exe, [string[]]$Argumentos = @(), [int]$TimeoutMin = 20)
    if ($DryRun) {
        Escreve ("  [DryRun] executaria: {0} {1}" -f $Exe, ($Argumentos -join ' '))
        return 0
    }
    try {
        Escreve ("  executando: {0} {1}" -f $Exe, ($Argumentos -join ' '))
        $p = $null
        if ($Argumentos.Count -gt 0) {
            # Start-Process NAO poe aspas nos elementos do array: um argumento com
            # espaco chega partido no programa (um -File "C:\pasta com espaco\x.ps1"
            # termina em exit code -196608 e o script nem roda). Citar aqui.
            $argsSeguros = @()
            foreach ($a in $Argumentos) {
                if ($a -match '\s') { $argsSeguros += ('"' + $a + '"') } else { $argsSeguros += $a }
            }
            $p = Start-Process -FilePath $Exe -ArgumentList $argsSeguros -PassThru
        } else {
            $p = Start-Process -FilePath $Exe -PassThru
        }
        if (-not $p.WaitForExit($TimeoutMin * 60 * 1000)) {
            Escreve ("  o instalador ainda estava rodando depois de {0} min" -f $TimeoutMin)
            return -1
        }
        Escreve ("  instalador terminou com codigo {0}" -f $p.ExitCode)
        return [int]$p.ExitCode
    } catch {
        Escreve ("  falha ao iniciar o instalador: {0}" -f $_.Exception.Message)
        return -2
    }
}

function Get-IndicePotencia {
    # Le o indice atual (AC) de uma configuracao de energia. -1 = nao consegui ler.
    # Primeiro pelo REGISTRO (independe do idioma do Windows); se a chave nao existir
    # (valor nunca customizado), tenta o texto do powercfg em ingles.
    # $Sub/$Config sao os GUIDs; $SubAlias/$ConfigAlias sao os apelidos (SUB_SLEEP...).
    param([string]$Sub, [string]$Config, [string]$SubAlias, [string]$ConfigAlias)
    try {
        $ativo = ''
        $ra = Invoke-Capturado 'powercfg' @('/getactivescheme')
        $ma = [regex]::Match($ra.Saida, '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})')
        if ($ma.Success) { $ativo = $ma.Groups[1].Value }
        if ($ativo) {
            $chave = "HKLM:\SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes\$ativo\$Sub\$Config"
            $v = Get-RegValor $chave 'ACSettingIndex'
            if ($null -ne $v) { return [int]$v }
        }
    } catch { }
    try {
        $r = Invoke-Capturado 'powercfg' @('/query', 'SCHEME_CURRENT', $SubAlias, $ConfigAlias)
        $m = [regex]::Match($r.Saida, '(?im)Current AC Power Setting Index:\s*(0x[0-9a-fA-F]+)')
        if ($m.Success) { return [Convert]::ToInt32($m.Groups[1].Value, 16) }
        return -1
    } catch { return -1 }
}

function Set-TempoEnergia {
    # Zera um timeout de energia em AC, so se estiver diferente de 0. ANTES/DEPOIS.
    param([string]$Chave, [string]$Sub, [string]$Config, [string]$SubAlias, [string]$ConfigAlias, [string]$Descricao)
    $antes = Get-IndicePotencia $Sub $Config $SubAlias $ConfigAlias
    $sAntes = "$antes"
    if ($antes -lt 0) { $sAntes = '(nao lido)' }
    if ($antes -eq 0 -and (-not $Reescrever)) {
        Escreve ("  {0}: ANTES=0 DEPOIS=0 (ja estava configurado)" -f $Descricao)
        return 'JA OK'
    }
    if ($DryRun) {
        Escreve ("  {0}: ANTES={1} -> DEPOIS=0   [DryRun: nada escrito]" -f $Descricao, $sAntes)
        return 'OK'
    }
    $r = Invoke-Capturado 'powercfg' @('/change', $Chave, '0')
    if ($r.Codigo -ne 0) {
        Escreve ("  {0}: FALHOU (powercfg codigo {1}: {2})" -f $Descricao, $r.Codigo, $r.Saida)
        return 'FALHOU'
    }
    $depois = Get-IndicePotencia $Sub $Config $SubAlias $ConfigAlias
    $sDepois = "$depois"
    if ($depois -lt 0) { $sDepois = '(nao lido)' }
    Escreve ("  {0}: ANTES={1} -> DEPOIS={2}" -f $Descricao, $sAntes, $sDepois)
    return 'OK'
}

# =====================================================================
#  Preparacao: etapas pedidas e arquivo de log
# =====================================================================
$TODAS_ETAPAS = @(1, 2, 3, 4, 5, 6)
$etapasAtivas = @()
if (-not $Etapas) {
    $etapasAtivas = $TODAS_ETAPAS
} else {
    foreach ($pedaco in ($Etapas -split '[,;\s]+')) {
        $t = $pedaco.Trim()
        if (-not $t) { continue }
        $n = 0
        if (-not [int]::TryParse($t, [ref]$n)) {
            Write-Host "ERRO: -Etapas invalido ('$t'). Use numeros separados por virgula, ex.: -Etapas `"1,2,4`""
            exit 4
        }
        if ($TODAS_ETAPAS -notcontains $n) {
            Write-Host "ERRO: etapa $n nao existe. Etapas validas: 1 a 6 (a 0 roda sempre)."
            exit 4
        }
        $etapasAtivas += $n
    }
}
function Etapa-Ativa { param([int]$N) if ($etapasAtivas -contains $N) { return $true } return $false }

# O log NAO e aberto aqui: quem abre e a funcao Abrir-Log, chamada no fim da
# etapa 0, depois da guarda de maquina. Ate la as linhas ficam em $script:PRELOG.

Escreve-Titulo 'vps_bootstrap.ps1 - instalador do kit Sobrevivencia no VPS'
Escreve ("inicio      : {0}Z (UTC)" -f ([DateTime]::UtcNow.ToString('yyyy-MM-dd HH:mm:ss')))
Escreve ("hora local  : {0}  (fuso {1})" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), (Get-TimeZone).Id)
Escreve ("usuario     : {0}\{1}" -f $env:USERDOMAIN, $env:USERNAME)
Escreve ("computador  : {0}" -f $env:COMPUTERNAME)
Escreve ("etapas      : {0}" -f ($etapasAtivas -join ', '))
Escreve ("workspace   : {0}" -f $WS_VPS)
Escreve ("terminal    : {0}" -f $MT5_DIR_VPS)
Escreve ("installers  : {0}" -f $INST_DIR)
if ($DryRun) {
    Escreve 'MODO        : DryRun - NADA sera alterado (nem o arquivo de log)'
}
if ($Reescrever)    { Escreve 'REESCREVER  : ligado (reescreve valores que ja estao corretos)' }
if ($ForcarMaquina) { Escreve 'FORCAR MAQ. : ligado (a guarda de maquina nao vai abortar)' }

# =====================================================================
#  ETAPA 0 - pre-voo (sempre roda)
# =====================================================================
Escreve-Titulo 'ETAPA 0 - pre-voo (ambiente, guarda de maquina)'
$estados0 = @()

# 0.1 Administrador
$ehAdmin = Test-Administrador
Escreve ("  Administrador: {0}" -f $ehAdmin)
if (-not $ehAdmin) {
    if ($DryRun) {
        Escreve-Aviso 'este console NAO e Administrador. Em execucao real o script abortaria aqui.'
        $estados0 += 'OK'
    } else {
        Escreve ''
        Escreve 'ERRO: este script precisa de um PowerShell aberto como Administrador.'
        Escreve 'Como fazer: menu Iniciar > digite "PowerShell" > botao direito > "Executar como administrador"'
        Escreve ('e repita o comando:  powershell -NoProfile -ExecutionPolicy Bypass -File "{0}"' -f $PSCommandPath)
        exit 2
    }
}

# 0.1b O console elevado e do MESMO usuario da sessao interativa (o do auto-logon)?
# Tudo que e "por usuario" vai para o perfil de quem elevou: o Claude Code em
# %USERPROFILE%\.local\bin (o config.ps1 procura no perfil do auto-logon), as chaves
# HKCU da protecao de tela, a ExecutionPolicy CurrentUser e o atalho /portable na
# area de trabalho. Elevar como Administrator estando logado com outro usuario
# manda tudo isso para o perfil errado, em silencio.
$usuarioSessao = ''
try { $usuarioSessao = "$((Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).UserName)" } catch { }
$usuarioConsole = "$env:USERDOMAIN\$env:USERNAME"
Escreve ("  usuario deste console : {0}" -f $usuarioConsole)
if ($usuarioSessao) {
    Escreve ("  usuario da sessao     : {0}" -f $usuarioSessao)
} else {
    Escreve '  usuario da sessao     : (nao lido)'
}
Escreve ("  perfil usado          : {0}" -f $env:USERPROFILE)
if ($usuarioSessao -and ($usuarioSessao.ToLower() -ne $usuarioConsole.ToLower())) {
    Escreve ''
    Escreve 'ERRO: este PowerShell foi elevado com OUTRO usuario. O Claude Code, as chaves'
    Escreve 'HKCU, a ExecutionPolicy e o atalho do MT5 cairiam no perfil errado e o'
    Escreve 'run_claude.ps1 nao acharia o claude.exe. Faca logon COM o usuario do auto-logon'
    Escreve '(que precisa ser membro de Administradores) e repita.'
    Escreve '(Se tiver certeza de que e o mesmo usuario, repita com -ForcarMaquina.)'
    if (-not $ForcarMaquina) {
        Add-Resultado '0 - Pre-voo' 'FALHOU' 'console elevado com outro usuario'
        exit 2
    }
    Escreve-Aviso '-ForcarMaquina ligado: seguindo com o perfil errado, por sua conta.'
}

# 0.2 Sistema operacional, memoria, disco, arquitetura
try {
    $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop
    Escreve ("  Windows     : {0} (build {1}, {2})" -f $os.Caption, $os.BuildNumber, $os.OSArchitecture)
    $memGB = [math]::Round($os.TotalVisibleMemorySize / 1MB, 1)
    Escreve ("  memoria     : {0} GB" -f $memGB)
    if ($memGB -lt 3.5) { Escreve-Aviso ("memoria total de {0} GB: o HS-3 tem 8 GB. Confira o plano contratado." -f $memGB) }
    $cap = "$($os.Caption)"
    $servidorConhecido = $false
    foreach ($v in @('2022', '2019', '2025')) { if ($cap -like ("*Server*" + $v + "*")) { $servidorConhecido = $true } }
    if (-not $servidorConhecido) {
        Escreve-Aviso ("o sistema '{0}' nao e Windows Server 2022/2019/2025. O kit foi pensado para Server 2022; siga com atencao." -f $cap)
    }
} catch {
    Escreve-Aviso ("nao consegui ler os dados do sistema: {0}" -f $_.Exception.Message)
}
if ([Environment]::Is64BitOperatingSystem) {
    Escreve '  arquitetura : x64'
} else {
    Escreve '  arquitetura : NAO e x64'
    Escreve-Aviso 'o terminal MT5 (terminal64.exe) e o Claude Code exigem Windows x64.'
    $estados0 += 'FALHOU'
}
try {
    $cDrive = Get-PSDrive -Name C -ErrorAction Stop
    $livreGB = [math]::Round($cDrive.Free / 1GB, 1)
    Escreve ("  disco C:    : {0} GB livres" -f $livreGB)
    if ($livreGB -lt 10) { Escreve-Aviso ("so {0} GB livres em C:. O terminal cresce ~50 MB/dia com EAs verbosos." -f $livreGB) }
} catch {
    Escreve-Aviso 'nao consegui medir o espaco livre em C:'
}
$cpus = 0
try { $cpus = [int](Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).NumberOfLogicalProcessors } catch { }
if ($cpus -gt 0) { Escreve ("  vCPUs       : {0}" -f $cpus) }

# 0.3 Conectividade basica (so leitura; nenhuma porta e aberta)
$conectado = $false
foreach ($u in @('https://api.github.com', 'https://claude.ai')) {
    try {
        $r = Invoke-WebRequest -Uri $u -Method Head -UseBasicParsing -TimeoutSec 20 -ErrorAction Stop
        Escreve ("  internet    : OK ({0} -> HTTP {1})" -f $u, [int]$r.StatusCode)
        $conectado = $true
        break
    } catch {
        Escreve ("  internet    : falhou em {0} ({1})" -f $u, $_.Exception.Message)
    }
}
if (-not $conectado) { Escreve-Aviso 'sem conectividade HTTPS: as etapas de download (2 e 4) vao falhar e virar MANUAL.' }

# 0.4 GUARDA DE MAQUINA (obrigatoria): isto aqui e o VPS ou a estacao do Henrique?
$indicios = @()
if (Test-Path -LiteralPath 'C:\Users\Henri\Sobrevivencia') { $indicios += 'C:\Users\Henri\Sobrevivencia' }
foreach ($d in @('C:\RF_bt', 'C:\RF_bt2', 'C:\RF_bt3')) { if (Test-Path -LiteralPath $d) { $indicios += $d } }
if ($indicios.Count -gt 0) {
    Escreve ''
    Escreve '  GUARDA: esta maquina tem indicios de ser a ESTACAO DE TRABALHO do Henrique,'
    Escreve '  nao o VPS. Encontrado:'
    foreach ($i in $indicios) { Escreve ("    - {0}" -f $i) }
    if (-not $ForcarMaquina) {
        Escreve ''
        Escreve '  ABORTADO. Se esta e mesmo a maquina certa, repita com -ForcarMaquina.'
        Escreve '  (Rodar isto na estacao mudaria fuso, energia, politicas e Windows Update dela.)'
        Add-Resultado '0 - Pre-voo' 'FALHOU' 'guarda de maquina: indicios de estacao de trabalho; use -ForcarMaquina'
        exit 3
    }
    Escreve-Aviso '-ForcarMaquina ligado: seguindo apesar dos indicios de estacao de trabalho.'
}
# Aviso extra: terminais MT5 de outras instalacoes rodando (campanha de backtest, etc.)
try {
    $outros = @()
    foreach ($p in @(Get-Process -Name 'terminal64' -ErrorAction SilentlyContinue)) {
        $cam = ''
        try { $cam = $p.Path } catch { $cam = '' }
        if ($cam -and ($cam.ToLower() -ne $MT5_EXE_VPS.ToLower())) { $outros += $cam }
    }
    if ($outros.Count -gt 0) {
        Escreve-Aviso ("ha terminal64.exe rodando fora de {0}: {1}. Este script NAO encosta neles." -f $MT5_DIR_VPS, (($outros | Select-Object -Unique) -join ', '))
    }
} catch { }

# Guarda vencida: so agora o script pode escrever em disco.
Abrir-Log

if ($estados0 -contains 'FALHOU') {
    Add-Resultado '0 - Pre-voo' 'FALHOU' 'requisito de hardware/SO nao atendido (ver avisos)'
} else {
    Add-Resultado '0 - Pre-voo' 'OK' ('admin={0}; avisos={1}' -f $ehAdmin, $script:AVISOS.Count)
}

# =====================================================================
#  ETAPA 1 - sistema (fuso, energia, tela, Windows Update, ExecutionPolicy)
# =====================================================================
if (Etapa-Ativa 1) {
    Escreve-Titulo 'ETAPA 1 - sistema: fuso UTC, energia, tela, Windows Update, ExecutionPolicy'
    $e1 = @()
    try {
        # Cada item tem o SEU try/catch: uma falha isolada (politica de fuso gerenciada,
        # GPO bloqueando a ExecutionPolicy) marca FALHOU naquele item e os demais
        # CONTINUAM sendo aplicados. O try externo e so a rede de seguranca - antes ele
        # engolia tudo e o VPS ficava meio configurado sem ninguem saber onde parou.

        # 1.1 Fuso horario UTC (SETUP_VPS 1.2): as tarefas agendadas usam hora local.
        try {
            $tzAntes = (Get-TimeZone).Id
            if ($tzAntes -eq 'UTC' -and (-not $Reescrever)) {
                Escreve ('  fuso horario: ANTES=UTC DEPOIS=UTC (ja estava configurado)')
                $e1 += 'JA OK'
            } elseif ($DryRun) {
                Escreve ("  fuso horario: ANTES={0} -> DEPOIS=UTC   [DryRun: nada escrito]" -f $tzAntes)
                $e1 += 'OK'
            } else {
                Set-TimeZone -Id 'UTC'
                Escreve ("  fuso horario: ANTES={0} -> DEPOIS={1}" -f $tzAntes, (Get-TimeZone).Id)
                $e1 += 'OK'
            }
        } catch {
            Escreve ("  fuso horario: FALHOU ({0})" -f $_.Exception.Message)
            $e1 += 'FALHOU'
        }

        # 1.2 Sincronizacao de relogio (idempotente; nao muda configuracao)
        try {
            if ($DryRun) {
                Escreve '  relogio     : [DryRun] rodaria w32tm /resync'
            } else {
                $r = Invoke-Capturado 'w32tm' @('/resync')
                if ($r.Codigo -eq 0) {
                    Escreve ("  relogio     : w32tm /resync OK ({0})" -f ($r.Saida -replace "`r?`n", ' '))
                } else {
                    Escreve ("  relogio     : w32tm /resync falhou ({0})" -f ($r.Saida -replace "`r?`n", ' '))
                    Escreve-Aviso 'sincronize o relogio a mao: net start w32time ; w32tm /resync /force'
                }
            }
        } catch {
            Escreve ("  relogio     : FALHOU ({0})" -f $_.Exception.Message)
        }

        # 1.3 Energia: nunca dormir, nunca desligar a tela (SETUP_VPS 1.3)
        # GUIDs (leitura no registro, independe do idioma do Windows):
        #   SUB_SLEEP 238c9fa8-... : STANDBYIDLE 29f6c1db-... , HIBERNATEIDLE 9d7815a6-...
        #   SUB_VIDEO 7516b95f-... : VIDEOIDLE   3c0bc021-...
        $gSleep = '238c9fa8-0aad-41ed-83f4-97be242c8f20'
        $gVideo = '7516b95f-f776-4464-8c53-06167f40cc99'
        $e1 += Set-TempoEnergia 'standby-timeout-ac'   $gSleep '29f6c1db-86da-48c5-9fdb-f2b67b1f44da' 'SUB_SLEEP' 'STANDBYIDLE'   'energia standby (AC)'
        $e1 += Set-TempoEnergia 'monitor-timeout-ac'   $gVideo '3c0bc021-c8a8-4e07-a973-6b14cbcb2b7e' 'SUB_VIDEO' 'VIDEOIDLE'     'energia monitor (AC)'
        $e1 += Set-TempoEnergia 'hibernate-timeout-ac' $gSleep '9d7815a6-7ee4-497e-8888-515a05f02364' 'SUB_SLEEP' 'HIBERNATEIDLE' 'energia hibernacao (AC)'

        # 1.4 Proteccao de tela e bloqueio automatico da sessao (SETUP_VPS 1.3)
        # HKCU: vale para o usuario que esta rodando este script. Se o auto-logon for
        # com outro usuario, refazer logado com ele (aviso abaixo).
        Escreve ("  (as chaves HKCU abaixo valem para o usuario {0}\{1})" -f $env:USERDOMAIN, $env:USERNAME)
        $e1 += Set-RegValor 'HKCU:\Control Panel\Desktop' 'ScreenSaveActive'    '0' 'String' 'tela: ScreenSaveActive (0=sem protecao de tela)'
        $e1 += Set-RegValor 'HKCU:\Control Panel\Desktop' 'ScreenSaverIsSecure' '0' 'String' 'tela: ScreenSaverIsSecure (0=nao pede senha)'
        $e1 += Set-RegValor 'HKCU:\Control Panel\Desktop' 'ScreenSaveTimeOut'   '0' 'String' 'tela: ScreenSaveTimeOut (0=sem tempo limite)'
        # Politica equivalente ao gpedit (Configuracao do Usuario > Painel de Controle >
        # Personalizacao > "Habilitar protecao de tela" = Desabilitado)
        $polTela = 'HKCU:\Software\Policies\Microsoft\Windows\Control Panel\Desktop'
        $e1 += Set-RegValor $polTela 'ScreenSaveActive'    '0' 'String' 'politica de tela: ScreenSaveActive=0'
        $e1 += Set-RegValor $polTela 'ScreenSaverIsSecure' '0' 'String' 'politica de tela: ScreenSaverIsSecure=0'

        # Somente leitura: limite de inatividade da maquina (politica de seguranca).
        # Este script NAO mexe em politica de seguranca; se estiver ligado, avisa.
        $inat = Get-RegValor 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'InactivityTimeoutSecs'
        if ($null -ne $inat -and [int]$inat -gt 0) {
            Escreve-Aviso ("InactivityTimeoutSecs={0}: a sessao ainda pode bloquear sozinha. Ajuste a mao em secpol.msc > Opcoes de Seguranca > 'Limite de inatividade de logon interativo' (o script nao mexe em politica de seguranca)." -f $inat)
        }

        # 1.5 Windows Update numa janela de sabado 03:00 (SETUP_VPS 1.4)
        # HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU
        #   NoAutoUpdate=0                  -> atualizacoes automaticas LIGADAS
        #   AUOptions=4                     -> baixar e INSTALAR no horario agendado
        #   ScheduledInstallDay=7           -> 0=todo dia, 1=domingo ... 7=sabado
        #   ScheduledInstallTime=3          -> hora local (o VPS fica em UTC) = 03:00
        #   NoAutoRebootWithLoggedOnUsers=0 -> PODE reiniciar mesmo com usuario logado
        #                                      (auto-logon + tarefa Sobrevivencia-Terminal
        #                                       sobem o terminal de novo)
        $au = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'
        $e1 += Set-RegValor $au 'NoAutoUpdate'                  0 'DWord' 'WU: NoAutoUpdate=0 (updates ligados)'
        $e1 += Set-RegValor $au 'AUOptions'                     4 'DWord' 'WU: AUOptions=4 (baixar e instalar agendado)'
        $e1 += Set-RegValor $au 'ScheduledInstallDay'           7 'DWord' 'WU: ScheduledInstallDay=7 (sabado)'
        $e1 += Set-RegValor $au 'ScheduledInstallTime'          3 'DWord' 'WU: ScheduledInstallTime=3 (03:00 hora local=UTC)'
        $e1 += Set-RegValor $au 'NoAutoRebootWithLoggedOnUsers' 0 'DWord' 'WU: NoAutoRebootWithLoggedOnUsers=0 (pode reiniciar)'
        Escreve '  (depois de qualquer atualizacao, conferir na segunda-feira: ops\status.ps1)'

        # 1.6 ExecutionPolicy do usuario (SETUP_VPS 1.7)
        try {
            $epAntes = Get-ExecutionPolicy -Scope CurrentUser
            if ("$epAntes" -eq 'RemoteSigned' -and (-not $Reescrever)) {
                Escreve '  ExecutionPolicy (CurrentUser): ANTES=RemoteSigned DEPOIS=RemoteSigned (ja estava configurado)'
                $e1 += 'JA OK'
            } elseif ($DryRun) {
                Escreve ("  ExecutionPolicy (CurrentUser): ANTES={0} -> DEPOIS=RemoteSigned   [DryRun: nada escrito]" -f $epAntes)
                $e1 += 'OK'
            } else {
                Set-ExecutionPolicy -Scope CurrentUser RemoteSigned -Force
                Escreve ("  ExecutionPolicy (CurrentUser): ANTES={0} -> DEPOIS={1}" -f $epAntes, (Get-ExecutionPolicy -Scope CurrentUser))
                $e1 += 'OK'
            }
        } catch {
            Escreve ("  ExecutionPolicy (CurrentUser): FALHOU ({0})" -f $_.Exception.Message)
            $e1 += 'FALHOU'
        }

        Add-Resultado '1 - Sistema' (Pior-Estado $e1) 'fuso UTC, energia, tela, Windows Update sab 03:00, ExecutionPolicy'
    } catch {
        Escreve ("  ERRO na etapa 1: {0}" -f $_.Exception.Message)
        Add-Resultado '1 - Sistema' 'FALHOU' $_.Exception.Message
    }
} else {
    Add-Resultado '1 - Sistema' 'PULADA' 'nao pedida em -Etapas'
}

# =====================================================================
#  ETAPA 2 - programas: Git for Windows, Claude Code (CLI), Autologon (so baixa)
# =====================================================================
if (Etapa-Ativa 2) {
    Escreve-Titulo 'ETAPA 2 - programas: Git, Claude Code (CLI) e download do Autologon'
    $e2 = @()
    $detalhe2 = @()
    if (-not $DryRun) {
        if (-not (Test-Path -LiteralPath $INST_DIR)) { New-Item -ItemType Directory -Path $INST_DIR -Force | Out-Null }
    }
    Escreve ("  pasta de downloads: {0}" -f $INST_DIR)

    # --- 2.1 Git for Windows -----------------------------------------
    if ($PularGit) {
        Escreve ''
        Escreve '  [2.1] Git: PULADO (-PularGit)'
        $e2 += 'PULADA'
        $detalhe2 += 'git pulado'
    } else {
        Escreve ''
        Escreve '  [2.1] Git for Windows (usado pela ferramenta Bash do Claude Code)'
        Update-PathProcesso
        $gitAntes = '(ausente)'
        if (Test-Comando 'git') {
            $rv = Invoke-Capturado 'git' @('--version')
            if ($rv.Codigo -eq 0) { $gitAntes = $rv.Saida }
        }
        if ($gitAntes -ne '(ausente)' -and (-not $Reescrever)) {
            Escreve ("  git: ANTES={0} DEPOIS={0} (ja estava instalado)" -f $gitAntes)
            $e2 += 'JA OK'
            $detalhe2 += $gitAntes
        } else {
            $instalouGit = $false
            # Preferir winget quando existir (Server 2022 costuma NAO ter winget)
            if (Test-Comando 'winget') {
                Escreve '  winget encontrado: instalando Git.Git'
                if ($DryRun) {
                    Escreve '  [DryRun] winget install --id Git.Git -e --accept-source-agreements --accept-package-agreements'
                    $instalouGit = $true
                } else {
                    $rw = Invoke-Capturado 'winget' @('install', '--id', 'Git.Git', '-e', '--accept-source-agreements', '--accept-package-agreements')
                    Escreve ("  winget codigo={0}" -f $rw.Codigo)
                    foreach ($l in ($rw.Saida -split "`r?`n")) { if ($l.Trim()) { Escreve ("    | {0}" -f $l.Trim()) } }
                    if ($rw.Codigo -eq 0) { $instalouGit = $true }
                }
            } else {
                Escreve '  winget nao existe nesta maquina: baixando o instalador oficial do Git for Windows'
                # A URL do .exe muda a cada versao. Em vez de inventar um link fixo, o script
                # DESCOBRE o link da ultima versao na API de releases do projeto oficial
                # (git-for-windows/git, que e para onde git-scm.com/download/win aponta) e
                # confere a assinatura Authenticode antes de executar.
                $urlGit = ''
                $nomeGit = ''
                try {
                    if ($DryRun) {
                        Escreve ("  [DryRun] consultaria {0} para achar o Git-*-64-bit.exe" -f $URL_GIT_API)
                    } else {
                        $rel = Invoke-RestMethod -Uri $URL_GIT_API -Headers @{ 'User-Agent' = 'vps_bootstrap' } -TimeoutSec 60 -ErrorAction Stop
                        foreach ($a in $rel.assets) {
                            if ($a.name -like 'Git-*-64-bit.exe') { $urlGit = $a.browser_download_url; $nomeGit = $a.name; break }
                        }
                        if ($urlGit) { Escreve ("  versao encontrada: {0} ({1})" -f $rel.tag_name, $nomeGit) }
                    }
                } catch {
                    Escreve ("  nao consegui consultar a lista de versoes do Git: {0}" -f $_.Exception.Message)
                }
                if ($urlGit) {
                    $destGit = Join-Path $INST_DIR $nomeGit
                    if (Get-ArquivoWeb $urlGit $destGit) {
                        if (Test-Assinatura $destGit @('Johannes Schindelin', 'Git for Windows')) {
                            # Inno Setup: instalacao silenciosa, sem reinicio, sem caixas de dialogo
                            $rc = Start-Instalador $destGit @('/VERYSILENT', '/NORESTART', '/NOCANCEL', '/SP-', '/SUPPRESSMSGBOXES') 20
                            if ($rc -eq 0) { $instalouGit = $true }
                        } else {
                            Escreve '  assinatura invalida: NAO vou executar este instalador.'
                        }
                    }
                }
            }
            Update-PathProcesso
            $gitDepois = '(ausente)'
            if (Test-Comando 'git') {
                $rv2 = Invoke-Capturado 'git' @('--version')
                if ($rv2.Codigo -eq 0) { $gitDepois = $rv2.Saida }
            }
            if ($DryRun) {
                Escreve ("  git: ANTES={0} -> DEPOIS=(instalado)   [DryRun: nada escrito]" -f $gitAntes)
                $e2 += 'OK'
                $detalhe2 += 'git (DryRun)'
            } elseif ($gitDepois -ne '(ausente)') {
                Escreve ("  git: ANTES={0} -> DEPOIS={1}" -f $gitAntes, $gitDepois)
                $e2 += 'OK'
                $detalhe2 += $gitDepois
            } else {
                Escreve ("  git: ANTES={0} -> DEPOIS=(ausente)" -f $gitAntes)
                Escreve ("  MANUAL: baixe e instale o Git for Windows de {0} (opcoes padrao) e rode de novo com -Etapas `"2`"" -f $URL_GIT_PAGINA)
                $e2 += 'MANUAL'
                $detalhe2 += 'git MANUAL'
            }
        }
    }

    # --- 2.2 Claude Code (CLI headless; NUNCA o app desktop) ---------
    if ($PularClaude) {
        Escreve ''
        Escreve '  [2.2] Claude Code: PULADO (-PularClaude)'
        $e2 += 'PULADA'
        $detalhe2 += 'claude pulado'
    } else {
        Escreve ''
        Escreve '  [2.2] Claude Code (CLI nativo, sem Node). NUNCA o app desktop.'
        Update-PathProcesso
        $claudeExe = "$env:USERPROFILE\.local\bin\claude.exe"
        $claudeAntes = '(ausente)'
        if (Test-Comando 'claude') {
            $rc1 = Invoke-Capturado 'claude' @('--version')
            if ($rc1.Codigo -eq 0) { $claudeAntes = $rc1.Saida }
        }
        if ($claudeAntes -ne '(ausente)' -and (-not $Reescrever)) {
            Escreve ("  claude: ANTES={0} DEPOIS={0} (ja estava instalado)" -f $claudeAntes)
            Escreve ("  binario: {0} (existe={1})" -f $claudeExe, (Test-Path -LiteralPath $claudeExe))
            $e2 += 'JA OK'
            $detalhe2 += $claudeAntes
        } else {
            # O instalador oficial (claude.ai/install.ps1) baixa o binario e CONFERE o
            # SHA-256 contra o manifest antes de instalar. Guardamos uma copia do .ps1
            # em installers\ (registro do que foi executado) e o rodamos num processo
            # filho: ele usa Set-StrictMode, que atrapalharia este script se fosse "iex".
            $destPs1 = Join-Path $INST_DIR 'claude_install.ps1'
            $ok = Get-ArquivoWeb $URL_CLAUDE_INSTALL $destPs1
            if ($DryRun) {
                Escreve ("  [DryRun] rodaria: powershell -NoProfile -ExecutionPolicy Bypass -File {0}" -f $destPs1)
                $e2 += 'OK'
                $detalhe2 += 'claude (DryRun)'
            } elseif ($ok) {
                try {
                    $hash = (Get-FileHash -LiteralPath $destPs1 -Algorithm SHA256).Hash
                    Escreve ("  SHA256 do install.ps1: {0}" -f $hash)
                } catch { }
                $psExe = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
                $rc = Start-Instalador $psExe @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $destPs1) 20
                Update-PathProcesso
                $claudeDepois = '(ausente)'
                if (Test-Comando 'claude') {
                    $rc2 = Invoke-Capturado 'claude' @('--version')
                    if ($rc2.Codigo -eq 0) { $claudeDepois = $rc2.Saida }
                }
                Escreve ("  claude: ANTES={0} -> DEPOIS={1}" -f $claudeAntes, $claudeDepois)
                Escreve ("  binario esperado: {0} (existe={1})" -f $claudeExe, (Test-Path -LiteralPath $claudeExe))
                if (Test-Path -LiteralPath $claudeExe) {
                    # Informativo: o proprio instalador ja validou o SHA-256 do binario.
                    Test-Assinatura $claudeExe | Out-Null
                }
                if ($claudeDepois -ne '(ausente)') {
                    $e2 += 'OK'
                    $detalhe2 += $claudeDepois
                } else {
                    Escreve '  MANUAL: abra um PowerShell novo e rode:  irm https://claude.ai/install.ps1 | iex'
                    Escreve '          depois confira:  claude --version'
                    $e2 += 'MANUAL'
                    $detalhe2 += 'claude MANUAL'
                }
            } else {
                Escreve '  MANUAL: abra um PowerShell novo e rode:  irm https://claude.ai/install.ps1 | iex'
                $e2 += 'MANUAL'
                $detalhe2 += 'claude MANUAL'
            }
        }
    }

    # --- 2.3 Sysinternals Autologon: SO BAIXA e confere a assinatura --
    # O script NUNCA configura o auto-logon: isso exige a senha do Henrique.
    Escreve ''
    Escreve '  [2.3] Sysinternals Autologon (download + assinatura; a configuracao e MANUAL)'
    $zipAuto = Join-Path $INST_DIR 'AutoLogon.zip'
    $dirAuto = Join-Path $INST_DIR 'Autologon'
    $exeAuto = Join-Path $dirAuto 'Autologon64.exe'
    # A assinatura e RECONFERIDA a cada execucao (nao basta o arquivo existir): sem
    # isso um Autologon64.exe ja reprovado continuava em disco e a execucao seguinte
    # dizia "ja estava baixado". $script:AUTOLOGON_OK so fica $true com o arquivo em
    # disco E a assinatura da Microsoft conferida - e a lista MANUAL le essa variavel.
    if ((Test-Path -LiteralPath $exeAuto) -and (Test-Assinatura $exeAuto @('Microsoft Corporation')) -and (-not $Reescrever)) {
        Escreve ("  autologon: ANTES=existe DEPOIS=existe : {0} (ja baixado, assinatura conferida)" -f $exeAuto)
        $script:AUTOLOGON_OK = $true
        $e2 += 'JA OK'
    } elseif ($DryRun) {
        Escreve ("  [DryRun] baixaria {0} -> {1} e extrairia em {2}" -f $URL_AUTOLOGON, $zipAuto, $dirAuto)
        $e2 += 'OK'
    } else {
        if (Get-ArquivoWeb $URL_AUTOLOGON $zipAuto) {
            try {
                if (Test-Path -LiteralPath $dirAuto) { Remove-Item -LiteralPath $dirAuto -Recurse -Force -ErrorAction SilentlyContinue }
                Expand-Archive -LiteralPath $zipAuto -DestinationPath $dirAuto -Force
                Escreve ("  extraido em: {0}" -f $dirAuto)
                if (Test-Path -LiteralPath $exeAuto) {
                    if (Test-Assinatura $exeAuto @('Microsoft Corporation')) {
                        $script:AUTOLOGON_OK = $true
                        $e2 += 'OK'
                    } else {
                        # Reprovado: o arquivo NAO pode ficar em disco. E nele que o
                        # Henrique digitaria a senha do Windows do VPS.
                        Remove-Item -LiteralPath $dirAuto -Recurse -Force -ErrorAction SilentlyContinue
                        Remove-Item -LiteralPath $zipAuto -Force -ErrorAction SilentlyContinue
                        Escreve-Aviso ("assinatura do Autologon64.exe invalida: arquivo APAGADO. Baixe a mao de {0} e confira com Get-AuthenticodeSignature antes de executar." -f $URL_AUTOLOGON_DOC)
                        $e2 += 'FALHOU'
                    }
                } else {
                    Escreve-Aviso 'Autologon64.exe nao apareceu no zip.'
                    $e2 += 'MANUAL'
                }
            } catch {
                Escreve ("  falha ao extrair: {0}" -f $_.Exception.Message)
                $e2 += 'MANUAL'
            }
        } else {
            Escreve ("  MANUAL: baixe o Autologon de {0}" -f $URL_AUTOLOGON_DOC)
            $e2 += 'MANUAL'
        }
    }
    Escreve '  (o auto-logon continua MANUAL: Autologon64.exe > usuario/dominio/senha > Enable)'

    Add-Resultado '2 - Programas' (Pior-Estado $e2) (($detalhe2 -join '; '))
} else {
    Add-Resultado '2 - Programas' 'PULADA' 'nao pedida em -Etapas'
}

# =====================================================================
#  ETAPA 3 - kit: extrair o workspace em C:\Sobrevivencia
# =====================================================================
if (Etapa-Ativa 3) {
    Escreve-Titulo 'ETAPA 3 - kit: workspace em C:\Sobrevivencia'
    if (-not $KitZip) {
        Escreve '  sem -KitZip: nada a extrair.'
        Escreve '  Copia manual (SETUP_VPS.md secao 3), com a unidade local montada no RDP:'
        Escreve '    robocopy \\tsclient\C\Users\Henri\Sobrevivencia C:\Sobrevivencia /E /XD logs .git /XF config.local.ps1 notify.secret.ps1 *.log'
        Escreve '    Get-ChildItem C:\Sobrevivencia -Recurse | Unblock-File'
        Add-Resultado '3 - Kit' 'PULADA' 'sem -KitZip (copiar por robocopy, SETUP_VPS secao 3)'
    } else {
        $e3 = @()
        try {
            if (-not (Test-Path -LiteralPath $KitZip)) { throw ("zip nao encontrado: {0}" -f $KitZip) }
            Escreve ("  zip         : {0} ({1:N1} MB)" -f $KitZip, ((Get-Item -LiteralPath $KitZip).Length / 1MB))
            Escreve ("  destino     : {0}" -f $WS_VPS)

            # Arquivos que NUNCA podem ser sobrescritos pelo zip:
            #  - os segredos (nao viajam no pacote);
            #  - o ESTADO VIVO do VPS: STATE.md, DIARIO.md e ALERTAS.md sao escritos
            #    pelo agente e pelo notify.ps1, e INBOX.md guarda a linha
            #    "AAAA-MM-DD OK RESUME" que o ops\cmd.ps1 exige. Reaplicar o kit por
            #    cima apagaria dias de diario, o historico de incidentes e um OK RESUME
            #    pendente - por isso a etapa 3 preserva e ainda guarda um .antes_<carimbo>.
            $preservar = @('ops\config.local.ps1', 'ops\notify.secret.ps1',
                           'STATE.md', 'DIARIO.md', 'ALERTAS.md', 'INBOX.md')
            $carimbo = Get-Date -Format 'yyyyMMdd_HHmm'
            $guardados = @{}
            foreach ($s in $preservar) {
                $p = Join-Path $WS_VPS $s
                if (Test-Path -LiteralPath $p) {
                    $guardados[$s] = [IO.File]::ReadAllBytes($p)
                    $copia = "$p.antes_$carimbo"
                    if ($DryRun) {
                        Escreve ("  preservando : {0} (ja existe no destino; backup em {1})   [DryRun: nada escrito]" -f $s, $copia)
                    } else {
                        try {
                            Copy-Item -LiteralPath $p -Destination $copia -Force
                            Escreve ("  preservando : {0} (ja existe no destino; backup em {1})" -f $s, $copia)
                        } catch {
                            Escreve ("  preservando : {0} (backup FALHOU: {1})" -f $s, $_.Exception.Message)
                        }
                    }
                }
            }

            if ($DryRun) {
                Escreve '  [DryRun] extrairia o zip numa pasta temporaria, copiaria para o destino e restauraria os segredos e os arquivos de estado.'
                $e3 += 'OK'
            } else {
                $tmp = Join-Path $env:TEMP ('surv_kit_' + [Guid]::NewGuid().ToString('N').Substring(0, 8))
                New-Item -ItemType Directory -Path $tmp -Force | Out-Null
                Expand-Archive -LiteralPath $KitZip -DestinationPath $tmp -Force
                # O zip pode ter uma pasta raiz (Sobrevivencia\...) ou o conteudo solto
                $raiz = $tmp
                if (-not (Test-Path -LiteralPath (Join-Path $tmp 'CLAUDE.md'))) {
                    $subs = @(Get-ChildItem -LiteralPath $tmp -Directory)
                    foreach ($d in $subs) {
                        if (Test-Path -LiteralPath (Join-Path $d.FullName 'CLAUDE.md')) { $raiz = $d.FullName; break }
                    }
                }
                Escreve ("  raiz do zip : {0}" -f $raiz)
                if (-not (Test-Path -LiteralPath $WS_VPS)) { New-Item -ItemType Directory -Path $WS_VPS -Force | Out-Null }
                Copy-Item -Path (Join-Path $raiz '*') -Destination $WS_VPS -Recurse -Force
                Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
                # Restaura segredos e estado vivo por cima do que o zip trouxe
                foreach ($k in $guardados.Keys) {
                    $p = Join-Path $WS_VPS $k
                    [IO.File]::WriteAllBytes($p, $guardados[$k])
                    Escreve ("  restaurado  : {0}" -f $k)
                }
                # Arquivos vindos de outra maquina chegam "bloqueados" (Zone.Identifier)
                try {
                    Get-ChildItem -LiteralPath $WS_VPS -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
                    Escreve '  Unblock-File aplicado em todo o workspace'
                } catch { }
                $e3 += 'OK'
            }

            # Conferencia do que chegou
            Escreve ''
            Escreve '  conferencia dos arquivos esperados:'
            $obrigatorios = @(
                'CLAUDE.md', 'STATE.md', 'DIARIO.md', 'ALERTAS.md', 'INBOX.md', 'SETUP_VPS.md',
                '.claude\settings.json',
                'ops\config.ps1', 'ops\common.ps1', 'ops\start.ini', 'ops\start_terminal.ps1',
                'ops\heartbeat.ps1', 'ops\run_claude.ps1', 'ops\cmd.ps1', 'ops\status.ps1',
                'ops\compile.ps1', 'ops\register_tasks.ps1', 'ops\notify.ps1', 'ops\save_profile.ps1',
                'prompts\diario.md', 'prompts\semanal.md', 'prompts\incidente.md', 'prompts\preabertura.md',
                'ops\checar.ps1', 'regras\saude.md', 'regras\inbox.md', 'regras\incidente.md', 'regras\desempenho.md',
                'regras\degrau.md', 'regras\regime.md', 'regras\revalidacao.md', 'regras\laboratorio.md', 'regras\referencia.md',
                'mql5\Experts\SurvivalGuardian.mq5', 'mql5\Experts\Concorde_RF.mq5',
                'mql5\Include\SurvivalGuard.mqh'
            )
            # Os .ex5 sao compilados NO VPS (etapa 5 do SETUP_VPS, ops\compile.ps1) e o
            # .gitignore do kit os exclui: ausencia aqui e normal, nao e erro.
            $opcionais = @('mql5\Experts\SurvivalGuardian.ex5', 'mql5\Experts\Concorde_RF.ex5')
            $faltando = @()
            foreach ($f in $obrigatorios) {
                $p = Join-Path $WS_VPS $f
                if (Test-Path -LiteralPath $p) {
                    Escreve ("    OK     {0}" -f $f)
                } else {
                    Escreve ("    FALTA  {0}" -f $f)
                    $faltando += $f
                }
            }
            foreach ($f in $opcionais) {
                $p = Join-Path $WS_VPS $f
                if (Test-Path -LiteralPath $p) {
                    Escreve ("    OK     {0}" -f $f)
                } else {
                    Escreve ("    -      {0} (normal: sera gerado por ops\compile.ps1 no VPS)" -f $f)
                }
            }
            if ($faltando.Count -gt 0) {
                Escreve-Aviso ("faltaram {0} arquivo(s) obrigatorio(s): {1}" -f $faltando.Count, ($faltando -join ', '))
                $e3 += 'FALHOU'
            }
            Add-Resultado '3 - Kit' (Pior-Estado $e3) ("faltando={0}" -f $faltando.Count)
        } catch {
            Escreve ("  ERRO na etapa 3: {0}" -f $_.Exception.Message)
            Add-Resultado '3 - Kit' 'FALHOU' $_.Exception.Message
        }
    }
} else {
    Add-Resultado '3 - Kit' 'PULADA' 'nao pedida em -Etapas'
}

# =====================================================================
#  ETAPA 4 - MT5 RoboForex em C:\MT5_RoboForex (SEMPRE /portable)
# =====================================================================
if (Etapa-Ativa 4) {
    Escreve-Titulo 'ETAPA 4 - terminal MT5 RoboForex (portatil em C:\MT5_RoboForex)'
    $e4 = @()
    $det4 = @()
    try {
        # O marcador portable_ok.txt so e gravado no FIM de uma copia bem-sucedida.
        # Sem ele, um terminal64.exe solto (robocopy interrompido por Ctrl+C, queda de
        # RDP ou reinicio - o exe e copiado primeiro, as subpastas MQL5\ depois) seria
        # considerado "pronto" para sempre, com a arvore incompleta.
        $marcaOk = Join-Path $MT5_DIR_VPS 'portable_ok.txt'
        $temExe  = Test-Path -LiteralPath $MT5_EXE_VPS
        $jaTem   = $temExe -and (Test-Path -LiteralPath $marcaOk)
        Escreve ("  {0}: ANTES={1}" -f $MT5_EXE_VPS, $(if ($temExe) { 'existe' } else { '(ausente)' }))
        if ($temExe -and (-not $jaTem)) {
            Escreve ("  instalacao portatil INCOMPLETA (falta {0}): a copia parou no meio." -f $marcaOk)
            Escreve '  Vou refazer a copia (robocopy /E e incremental: repetir e barato e seguro).'
        }

        if ($jaTem) {
            Escreve '  terminal portatil ja montado: nao mexo em nada aqui.'
            $e4 += 'JA OK'
            $det4 += 'C:\MT5_RoboForex ja existe'
        } elseif (-not ($InstalarMT5 -or $MT5Setup)) {
            Escreve '  sem -InstalarMT5: nao vou baixar nem instalar o terminal.'
            Escreve '  MANUAL (SETUP_VPS 2.1/2.2): baixe roboforex5setup.exe na area do cliente RoboForex'
            Escreve '  (Plataformas > MetaTrader 5), instale em C:\MT5_RoboForex e feche o terminal que abrir.'
            $e4 += 'MANUAL'
            $det4 += 'instalacao do terminal MANUAL'
        } else {
            # 4.1 Obter o instalador
            $setup = ''
            if ($MT5Setup) {
                if (Test-Path -LiteralPath $MT5Setup) {
                    $setup = (Resolve-Path -LiteralPath $MT5Setup).Path
                    Escreve ("  instalador informado por -MT5Setup: {0}" -f $setup)
                } else {
                    Escreve ("  -MT5Setup nao encontrado: {0}" -f $MT5Setup)
                }
            }
            if (-not $setup) {
                foreach ($u in $URLS_MT5) {
                    $dest = Join-Path $INST_DIR 'roboforex5setup.exe'
                    if (Get-ArquivoWeb $u $dest) { $setup = $dest; break }
                }
            }
            if ((-not $setup) -and $DryRun) {
                Escreve '  [DryRun] seguiria com o instalador baixado (ou o de -MT5Setup).'
                $e4 += 'OK'
                $det4 += 'MT5 (DryRun)'
            } elseif (-not $setup) {
                Escreve ''
                Escreve '  MANUAL: nao consegui baixar o instalador da RoboForex.'
                Escreve '  (Em 22/09/2026 a URL do CDN respondeu 404; a RoboForex pode ter mudado o link.)'
                Escreve '  Faca assim: area do cliente RoboForex > Plataformas > MetaTrader 5 > baixar'
                Escreve '  roboforex5setup.exe, copie para o VPS e rode de novo:'
                Escreve ('    powershell -NoProfile -File "{0}" -Etapas "4" -InstalarMT5 -MT5Setup C:\caminho\roboforex5setup.exe' -f $PSCommandPath)
                $e4 += 'MANUAL'
                $det4 += 'download do instalador falhou'
            } else {
                # 4.2 Assinatura antes de executar
                if ((-not $DryRun) -and (-not (Test-Assinatura $setup @('MetaQuotes', 'RoboForex')))) {
                    Escreve '  assinatura invalida: NAO vou executar este instalador.'
                    $e4 += 'FALHOU'
                    $det4 += 'assinatura do instalador invalida'
                } else {
                    # 4.3 Instalacao silenciosa (/auto e o modo silencioso do instalador MetaQuotes)
                    $rc = Start-Instalador $setup @('/auto') 25
                    if ($rc -ne 0 -and (-not $DryRun)) { Escreve-Aviso ("o instalador terminou com codigo {0}; vou conferir mesmo assim se a pasta apareceu." -f $rc) }

                    # 4.4 Descobrir onde ele instalou
                    $origem = ''
                    if ($DryRun) {
                        Escreve '  [DryRun] procuraria a pasta instalada (registro de desinstalacao + Program Files).'
                    } else {
                        $cands = @()
                        foreach ($raizReg in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall')) {
                            if (-not (Test-Path -LiteralPath $raizReg)) { continue }
                            foreach ($k in (Get-ChildItem -LiteralPath $raizReg -ErrorAction SilentlyContinue)) {
                                $dn = Get-RegValor $k.PSPath 'DisplayName'
                                if (-not $dn) { continue }
                                if (("$dn" -like '*MetaTrader 5*') -or ("$dn" -like '*RoboForex*')) {
                                    $il = Get-RegValor $k.PSPath 'InstallLocation'
                                    if ($il) { $cands += "$il" }
                                }
                            }
                        }
                        $cands += 'C:\Program Files\RoboForex MT5 Terminal'
                        $cands += 'C:\Program Files\MetaTrader 5'
                        foreach ($d in @(Get-ChildItem -LiteralPath 'C:\Program Files' -Directory -ErrorAction SilentlyContinue)) {
                            if (Test-Path -LiteralPath (Join-Path $d.FullName 'terminal64.exe')) { $cands += $d.FullName }
                        }
                        foreach ($c in ($cands | Select-Object -Unique)) {
                            if (-not $c) { continue }
                            $exe = Join-Path $c 'terminal64.exe'
                            if ((Test-Path -LiteralPath $exe) -and ($c.TrimEnd('\').ToLower() -ne $MT5_DIR_VPS.ToLower())) { $origem = $c.TrimEnd('\'); break }
                        }
                    }

                    if ((-not $origem) -and (-not $DryRun)) {
                        Escreve '  nao achei a pasta de instalacao do terminal.'
                        Escreve '  MANUAL: instale a mao (SETUP_VPS 2.2), apontando a pasta para C:\MT5_RoboForex.'
                        $e4 += 'MANUAL'
                        $det4 += 'pasta instalada nao encontrada'
                    } else {
                        if ($origem) { Escreve ("  instalado em: {0}" -f $origem) }
                        # 4.5 O instalador abre o terminal no fim (modo normal, dados em AppData).
                        # Fechamos APENAS o terminal64 que roda de dentro da pasta recem-instalada.
                        if ((-not $DryRun) -and $origem) {
                            foreach ($p in @(Get-Process -Name 'terminal64' -ErrorAction SilentlyContinue)) {
                                $cam = ''
                                try { $cam = $p.Path } catch { $cam = '' }
                                if ($cam -and ($cam.ToLower() -eq (Join-Path $origem 'terminal64.exe').ToLower())) {
                                    Escreve ("  fechando o terminal aberto pelo instalador (PID {0}, {1})" -f $p.Id, $cam)
                                    try { $p.CloseMainWindow() | Out-Null } catch { }
                                    Start-Sleep -Seconds 5
                                    if (-not $p.HasExited) { try { $p.Kill() } catch { } }
                                }
                            }
                        }
                        # 4.6 Montar a instalacao PORTATIL: copiar so os arquivos de programa.
                        # /XD exclui as pastas de dados (config = contas e senhas salvas,
                        # bases/history = historico, logs/tester, MQL5\Files, MQL5\Logs).
                        if ($DryRun) {
                            Escreve ("  [DryRun] copiaria os arquivos de programa para {0} (sem config/bases/history/logs/tester/Files)" -f $MT5_DIR_VPS)
                            $e4 += 'OK'
                            $det4 += 'copia portatil (DryRun)'
                        } else {
                            $argsRc = @($origem, $MT5_DIR_VPS, '/E', '/R:1', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/XD', 'config', 'bases', 'history', 'logs', 'tester', 'profiles', 'Files', 'Logs')
                            $rr = Invoke-Capturado 'robocopy' $argsRc
                            foreach ($l in ($rr.Saida -split "`r?`n")) { if ($l.Trim()) { Escreve ("    | {0}" -f $l.Trim()) } }
                            if ($rr.Codigo -ge 8) {
                                Escreve ("  robocopy falhou (codigo {0})" -f $rr.Codigo)
                                $e4 += 'FALHOU'
                                $det4 += 'copia para C:\MT5_RoboForex falhou'
                            } else {
                                Escreve ("  {0}: ANTES=(ausente) -> DEPOIS={1}" -f $MT5_EXE_VPS, $(if (Test-Path -LiteralPath $MT5_EXE_VPS) { 'existe' } else { '(ausente)' }))
                                if (Test-Path -LiteralPath $MT5_EXE_VPS) {
                                    try {
                                        Set-Content -LiteralPath $marcaOk -Value ([DateTime]::UtcNow.ToString('o')) -Encoding Ascii
                                        Escreve ("  marcador de copia completa: {0}" -f $marcaOk)
                                    } catch {
                                        Escreve-Aviso ("nao consegui gravar {0}: a proxima execucao vai refazer a copia." -f $marcaOk)
                                    }
                                    # A instalacao NAO portatil continua em $origem e os atalhos criados
                                    # pelo instalador apontam para la. Clicar num deles abre o terminal
                                    # SEM /portable e cria uma segunda pasta de dados em AppData (os EAs
                                    # "somem"). Removemos os atalhos; a instalacao em si fica.
                                    $exeOrigem = (Join-Path $origem 'terminal64.exe').ToLower()
                                    $pastasLnk = @()
                                    foreach ($g in @('CommonDesktopDirectory', 'Desktop', 'CommonPrograms', 'Programs')) {
                                        try { $pastasLnk += [Environment]::GetFolderPath($g) } catch { }
                                    }
                                    $shLnk = $null
                                    try { $shLnk = New-Object -ComObject WScript.Shell } catch { }
                                    foreach ($pl in ($pastasLnk | Select-Object -Unique)) {
                                        if (-not $pl) { continue }
                                        if (-not $shLnk) { continue }
                                        if (-not (Test-Path -LiteralPath $pl)) { continue }
                                        foreach ($atl in @(Get-ChildItem -LiteralPath $pl -Filter '*.lnk' -Recurse -ErrorAction SilentlyContinue)) {
                                            $alvoLnk = ''
                                            try { $alvoLnk = "$($shLnk.CreateShortcut($atl.FullName).TargetPath)" } catch { $alvoLnk = '' }
                                            if ($alvoLnk -and ($alvoLnk.ToLower() -eq $exeOrigem)) {
                                                try {
                                                    Remove-Item -LiteralPath $atl.FullName -Force
                                                    Escreve ("  atalho NAO portatil: ANTES={0} -> DEPOIS=(removido)" -f $atl.FullName)
                                                } catch {
                                                    Escreve-Aviso ("nao consegui remover o atalho NAO portatil {0}: apague-o a mao." -f $atl.FullName)
                                                }
                                            }
                                        }
                                    }
                                    Escreve ("  a instalacao NAO portatil continua em {0} (so os atalhos foram removidos)." -f $origem)
                                    $e4 += 'OK'
                                    $det4 += 'terminal copiado para C:\MT5_RoboForex'
                                } else {
                                    $e4 += 'FALHOU'
                                    $det4 += 'terminal64.exe nao chegou ao destino'
                                }
                            }
                        }
                    }
                }
            }
        }

        # 4.7 Atalho portatil na area de trabalho (unico jeito de abrir o terminal a mao)
        Escreve ''
        if (Test-Path -LiteralPath $MT5_EXE_VPS) {
            $desktop = [Environment]::GetFolderPath('Desktop')
            $lnk = Join-Path $desktop 'MT5 RoboForex (portable).lnk'
            $precisa = $true
            if (Test-Path -LiteralPath $lnk) {
                try {
                    $sh = New-Object -ComObject WScript.Shell
                    $at = $sh.CreateShortcut($lnk)
                    if (($at.TargetPath -eq $MT5_EXE_VPS) -and ($at.Arguments -like '*/portable*')) { $precisa = $false }
                } catch { }
            }
            if (-not $precisa -and (-not $Reescrever)) {
                Escreve ("  atalho: ANTES=ok DEPOIS=ok : {0} (ja estava configurado)" -f $lnk)
                $e4 += 'JA OK'
            } elseif ($DryRun) {
                Escreve ("  [DryRun] criaria o atalho {0} -> {1} /portable" -f $lnk, $MT5_EXE_VPS)
                $e4 += 'OK'
            } else {
                try {
                    $sh = New-Object -ComObject WScript.Shell
                    $at = $sh.CreateShortcut($lnk)
                    $at.TargetPath = $MT5_EXE_VPS
                    $at.Arguments = '/portable'
                    $at.WorkingDirectory = $MT5_DIR_VPS
                    $at.Description = 'MetaTrader 5 RoboForex - SEMPRE em modo portable'
                    $at.Save()
                    Escreve ("  atalho: ANTES=(ausente/errado) -> DEPOIS={0} ({1} /portable)" -f $lnk, $MT5_EXE_VPS)
                    $e4 += 'OK'
                } catch {
                    Escreve ("  falha ao criar o atalho: {0}" -f $_.Exception.Message)
                    $e4 += 'FALHOU'
                }
            }
            Escreve '  REGRA: nunca abrir terminal64.exe sem /portable (criaria uma segunda pasta de dados em AppData).'
        } else {
            Escreve ("  atalho: nao criado ({0} ainda nao existe)" -f $MT5_EXE_VPS)
        }
        Add-Resultado '4 - MT5' (Pior-Estado $e4) (($det4 -join '; '))
    } catch {
        Escreve ("  ERRO na etapa 4: {0}" -f $_.Exception.Message)
        Add-Resultado '4 - MT5' 'FALHOU' $_.Exception.Message
    }
} else {
    Add-Resultado '4 - MT5' 'PULADA' 'nao pedida em -Etapas'
}

# =====================================================================
#  ETAPA 5 - pastas do kit
# =====================================================================
if (Etapa-Ativa 5) {
    Escreve-Titulo 'ETAPA 5 - pastas de trabalho'
    $e5 = @()
    try {
        $e5 += New-DirSeFalta $LOG_DIR_VPS
        $e5 += New-DirSeFalta $INST_DIR
        if (Test-Path -LiteralPath "$WS_VPS\ops") {
            # ops\profile e ops\templates: usados por save_profile.ps1 / start_terminal.ps1
            $e5 += New-DirSeFalta "$WS_VPS\ops\profile"
            $e5 += New-DirSeFalta "$WS_VPS\ops\templates"
        } else {
            Escreve ("  {0}\ops ainda nao existe (kit nao copiado): pulo profile/templates." -f $WS_VPS)
        }
        Escreve '  Permissoes: nada a mudar. O kit roda inteiro com o usuario do auto-logon,'
        Escreve '  dono das pastas que ele mesmo cria em C:\Sobrevivencia. Nenhum ACL e alterado.'
        Add-Resultado '5 - Pastas' (Pior-Estado $e5) 'logs, installers, ops\profile, ops\templates'
    } catch {
        Escreve ("  ERRO na etapa 5: {0}" -f $_.Exception.Message)
        Add-Resultado '5 - Pastas' 'FALHOU' $_.Exception.Message
    }
} else {
    Add-Resultado '5 - Pastas' 'PULADA' 'nao pedida em -Etapas'
}

# =====================================================================
#  ETAPA 6 - verificacao (so o que nao depende de login)
# =====================================================================
if (Etapa-Ativa 6) {
    Escreve-Titulo 'ETAPA 6 - verificacao'
    $e6 = @()
    try {
        Update-PathProcesso

        # 6.1 Ferramentas
        $rv = Invoke-Capturado 'claude' @('--version')
        if ($rv.Codigo -eq 0) { Escreve ("  claude --version : {0}" -f $rv.Saida) } else { Escreve '  claude --version : NAO responde'; $e6 += 'MANUAL' }
        $rg = Invoke-Capturado 'git' @('--version')
        if ($rg.Codigo -eq 0) { Escreve ("  git --version    : {0}" -f $rg.Saida) } else { Escreve '  git --version    : NAO responde'; $e6 += 'MANUAL' }

        # 6.2 Fuso
        $tz = (Get-TimeZone).Id
        Escreve ("  Get-TimeZone     : {0}" -f $tz)
        if ($tz -ne 'UTC') {
            if ($DryRun) {
                Escreve-Aviso 'o fuso NAO e UTC (esperado em -DryRun: a etapa 1 nao chegou a aplicar nada).'
            } else {
                Escreve-Aviso 'o fuso NAO e UTC: os horarios das tarefas agendadas ficariam errados. Rode a etapa 1.'
                $e6 += 'MANUAL'
            }
        }

        # 6.3 Politicas aplicadas (leitura do que a etapa 1 escreveu)
        $au = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'
        foreach ($n in @('NoAutoUpdate', 'AUOptions', 'ScheduledInstallDay', 'ScheduledInstallTime', 'NoAutoRebootWithLoggedOnUsers')) {
            $v = Get-RegValor $au $n
            $sv = '(ausente)'
            if ($null -ne $v) { $sv = "$v" }
            Escreve ("  WU {0,-30}: {1}" -f $n, $sv)
        }
        foreach ($n in @('ScreenSaveActive', 'ScreenSaverIsSecure')) {
            $v = Get-RegValor 'HKCU:\Control Panel\Desktop' $n
            $sv = '(ausente)'
            if ($null -ne $v) { $sv = "$v" }
            Escreve ("  tela {0,-28}: {1}" -f $n, $sv)
        }
        Escreve ("  ExecutionPolicy (CurrentUser): {0}" -f (Get-ExecutionPolicy -Scope CurrentUser))

        # 6.4 Kit e EAs
        foreach ($f in @('CLAUDE.md', 'ops\config.ps1', 'ops\register_tasks.ps1', 'mql5\Experts\SurvivalGuardian.mq5', 'mql5\Experts\Concorde_RF.mq5', 'mql5\Include\SurvivalGuard.mqh')) {
            $p = Join-Path $WS_VPS $f
            Escreve ("  kit {0,-38}: {1}" -f $f, $(if (Test-Path -LiteralPath $p) { 'OK' } else { 'FALTA' }))
        }

        # 6.5 Coerencia com ops\config.ps1 (os caminhos deste script tem de bater)
        $cfg = Join-Path $WS_VPS 'ops\config.ps1'
        if (Test-Path -LiteralPath $cfg) {
            $txt = Get-Content -LiteralPath $cfg -Raw -ErrorAction SilentlyContinue
            if ($txt) {
                $mWs = [regex]::Match($txt, "(?m)^\s*\`$WS\s*=\s*'([^']+)'")
                $mMt = [regex]::Match($txt, "(?m)^\s*\`$MT5_DIR\s*=\s*'([^']+)'")
                if ($mWs.Success) {
                    Escreve ("  config.ps1 `$WS      : {0}" -f $mWs.Groups[1].Value)
                    if ($mWs.Groups[1].Value.TrimEnd('\') -ne $WS_VPS) { Escreve-Aviso 'config.ps1 aponta para outro workspace; ajuste um dos dois.' }
                }
                if ($mMt.Success) {
                    Escreve ("  config.ps1 `$MT5_DIR : {0}" -f $mMt.Groups[1].Value)
                    if ($mMt.Groups[1].Value.TrimEnd('\') -ne $MT5_DIR_VPS) { Escreve-Aviso 'config.ps1 aponta para outro terminal; ajuste um dos dois.' }
                }
            }
            if (Test-Path -LiteralPath (Join-Path $WS_VPS 'ops\config.local.ps1')) {
                Escreve-Aviso 'existe ops\config.local.ps1 no VPS: ele SOBRESCREVE os caminhos do config.ps1 (esse arquivo e da maquina local do Henrique). Apague-o se veio junto por engano.'
            }
        } else {
            Escreve '  config.ps1 : ainda nao existe (kit nao copiado)'
        }

        # 6.6 Terminal e disco
        Escreve ("  terminal portatil: {0} -> {1}" -f $MT5_EXE_VPS, $(if (Test-Path -LiteralPath $MT5_EXE_VPS) { 'OK' } else { 'FALTA' }))
        try {
            $cDrive = Get-PSDrive -Name C -ErrorAction Stop
            Escreve ("  disco C: livre   : {0} GB" -f [math]::Round($cDrive.Free / 1GB, 1))
        } catch { }

        # 6.7 MCP do terminal (so informativo: a porta so abre depois do item 2.7 do SETUP_VPS)
        try {
            $nets = Invoke-Capturado 'netstat' @('-ano')
            $l22346 = @($nets.Saida -split "`r?`n" | Where-Object { $_ -match '22346' })
            if ($l22346.Count -gt 0) {
                foreach ($l in $l22346) { Escreve ("  porta MCP        : {0}" -f $l.Trim()) }
                foreach ($l in $l22346) { if ($l -match '0\.0\.0\.0:22346') { Escreve-Aviso 'o MCP do terminal esta escutando em 0.0.0.0: deveria ser so 127.0.0.1 (SETUP_VPS secao 10).' } }
            } else {
                Escreve '  porta MCP 22346  : fechada (normal enquanto o MCP do terminal nao for ativado)'
            }
        } catch { }

        Escreve ''
        Escreve '  NAO registro tarefas agendadas aqui. Depois do login do Claude e do MT5 pronto, rode:'
        Escreve ('    powershell -NoProfile -File {0}\ops\register_tasks.ps1' -f $WS_VPS)
        Escreve ('    powershell -NoProfile -File {0}\ops\register_tasks.ps1 -List' -f $WS_VPS)

        Add-Resultado '6 - Verificacao' (Pior-Estado ($e6 + @('OK'))) 'ferramentas, fuso, politicas, kit, terminal'
    } catch {
        Escreve ("  ERRO na etapa 6: {0}" -f $_.Exception.Message)
        Add-Resultado '6 - Verificacao' 'FALHOU' $_.Exception.Message
    }
} else {
    Add-Resultado '6 - Verificacao' 'PULADA' 'nao pedida em -Etapas'
}

# =====================================================================
#  RESUMO
# =====================================================================
Escreve-Titulo 'RESUMO'
Escreve ("{0,-20} {1,-8} {2}" -f 'ETAPA', 'ESTADO', 'DETALHE')
Escreve ("{0,-20} {1,-8} {2}" -f ('-' * 20), ('-' * 8), ('-' * 40))
foreach ($r in $script:RESULT) {
    Escreve ("{0,-20} {1,-8} {2}" -f $r.Etapa, $r.Estado, $r.Detalhe)
}
if ($script:AVISOS.Count -gt 0) {
    Escreve ''
    Escreve ("AVISOS ({0}):" -f $script:AVISOS.Count)
    $i = 1
    foreach ($a in $script:AVISOS) {
        Escreve ("  {0}. {1}" -f $i, $a)
        $i = $i + 1
    }
}

# =====================================================================
#  O QUE CONTINUA MANUAL (na ordem)
# =====================================================================
Escreve-Titulo 'O QUE CONTINUA MANUAL (na ordem) - nada disto pode ser automatizado com seguranca'
Escreve ''
Escreve ("ANTES DE TUDO: se o usuario do auto-logon NAO for {0}\{1}, repita este script" -f $env:USERDOMAIN, $env:USERNAME)
Escreve '    logado COM ele e com -Etapas "1,2": as chaves HKCU de tela, a ExecutionPolicy,'
Escreve '    o Claude Code e o atalho da area de trabalho valem POR USUARIO. O SETUP_VPS'
Escreve '    secao 10 pede um unico usuario local com auto-logon (Administrator so para'
Escreve '    instalacao); se esse usuario ainda nao existe, crie-o e coloque-o em'
Escreve '    Administradores antes de seguir.'
Escreve ''
Escreve '(a) LOGIN NA CONTA ProCent no MT5 (a senha e sua; este script nunca pede senha)'
Escreve '    Abra o atalho "MT5 RoboForex (portable)" na area de trabalho.'
Escreve '    Arquivo > Login na conta de negociacao > login, senha e servidor (RoboForex-Pro).'
Escreve '    Marque "Salvar senha". No Diario confira: authorized on RoboForex-Pro through'
Escreve '    Netherlands (ping: N ms) - N deve ficar entre 1 e 3 ms.'
Escreve '    Confira tambem: Ferramentas > Opcoes > Servidor > "Ativar noticias" e Calendario'
Escreve '    Economico LIGADOS (o Concorde le o calendario nativo ao vivo).'
Escreve ''
Escreve '(b) MARKET WATCH E NEGOCIACAO ALGORITMICA'
Escreve '    Ctrl+M > botao direito > Mostrar todos; deixe visiveis pelo menos'
Escreve '    XAUUSD, EURUSD, GBPUSD, USDJPY, AUDUSD, USDCAD, USDCHF (anote a Especificacao'
Escreve '    do XAUUSD em STATE.md). Ferramentas > Opcoes > Expert Advisors > marcar'
Escreve '    "Permitir negociacao algoritmica"; desmarcar "Desabilitar quando a conta/perfil muda".'
Escreve '    Ferramentas > Opcoes > Graficos > Max. de barras no grafico = 100000.'
Escreve ''
Escreve '(c) ATIVAR O MCP DO TERMINAL E COPIAR A CHAVE'
Escreve '    Ferramentas > Opcoes > aba Assistente/MCP > Ativar servidor MCP,'
Escreve '    127.0.0.1 porta 22346 > copiar a chave (Bearer) para o gerenciador de senhas.'
Escreve '    A chave do terminal e DIFERENTE da do MetaEditor (22345); a de config\assistant.ini nao serve.'
Escreve ''
Escreve '(d) AUTO-LOGON (Sysinternals Autologon) - o script NUNCA configura a senha'
if ($script:AUTOLOGON_OK) {
    Escreve ("    Executavel baixado e com assinatura da Microsoft conferida NESTA execucao:")
    Escreve ("    {0}\Autologon\Autologon64.exe" -f $INST_DIR)
} else {
    Escreve '    NAO verificado nesta execucao (etapa 2 pulada, download falhou, assinatura'
    Escreve '    reprovada ou modo -DryRun): nao confie no arquivo sem conferir.'
    Escreve ("    Baixe de {0}, extraia e rode" -f $URL_AUTOLOGON_DOC)
    Escreve '    Get-AuthenticodeSignature .\Autologon64.exe   (Status=Valid, Microsoft Corporation)'
    Escreve '    antes de executar - e nele que voce digita a senha do Windows do VPS.'
}
Escreve ("    (origem oficial: {0})" -f $URL_AUTOLOGON_DOC)
Escreve '    Rode Autologon64.exe > usuario / dominio (use "." ou o nome do computador) / senha > Enable.'
Escreve '    Teste com Restart-Computer: ao voltar, a area de trabalho abre sozinha.'
Escreve ''
Escreve '(e) LOGIN DO CLAUDE CODE'
Escreve ('    cd {0}  >  claude  >  aceitar a pasta como confiavel  >  /login  >  concluir no Edge  >  /exit' -f $WS_VPS)
Escreve '    Confirme:  claude -p "responda OK" --permission-mode acceptEdits'
Escreve ''
Escreve '(f) REGISTRAR O MCP NO CLAUDE (com a chave do item c)'
Escreve ('    powershell -NoProfile -File {0}\ops\registrar_mcp.ps1' -f $WS_VPS)
Escreve '    O script pede a chave sem eco, confere o terminal, a porta 22346 e a chave,'
Escreve '    registra no escopo user e confirma no fim. Opcoes: -Chave "<CHAVE>" (nao'
Escreve '    recomendado: vai para o historico), -SoTestar, -Forcar (troca um registro errado).'
Escreve '    A mao, se preferir - no mesmo console, nesta ordem:'
Escreve '    Set-PSReadLineOption -HistorySaveStyle SaveNothing'
Escreve '    claude mcp add --transport http mt5-terminal http://127.0.0.1:22346/mcp --header "Authorization: Bearer <CHAVE>" --scope user'
Escreve '    claude mcp list     # mt5-terminal ... Connected'
Escreve '    O nome TEM de ser mt5-terminal (a allowlist de .claude\settings.json depende disso).'
Escreve ''
Escreve '(g) COMPILAR OS EAs'
Escreve ('    powershell -NoProfile -File {0}\ops\compile.ps1' -f $WS_VPS)
Escreve '    Criterio: 0 errors E .ex5 atualizado. Copie tambem o news.csv (SETUP_VPS secao 5).'
Escreve ''
Escreve '(h) ANEXAR OS EAs E SALVAR O PERFIL'
Escreve '    EURUSD H1 > SurvivalGuardian ; XAUUSD M15 > Concorde_RF ; botao Algo Trading LIGADO.'
Escreve '    Arquivo > Perfis > Salvar como... > "sobrevivencia"  e depois:'
Escreve ('    powershell -NoProfile -File {0}\ops\save_profile.ps1' -f $WS_VPS)
Escreve ''
Escreve '(i) REGISTRAR AS TAREFAS AGENDADAS (so depois de e, f, g e h)'
Escreve ('    powershell -NoProfile -File {0}\ops\register_tasks.ps1' -f $WS_VPS)
Escreve ('    powershell -NoProfile -File {0}\ops\register_tasks.ps1 -List' -f $WS_VPS)
Escreve ''
Escreve '(j) CHECKLIST DE VALIDACAO - secao 8 do SETUP_VPS.md, na ordem (9 itens),'
Escreve '    inclusive o ensaio HALT/RESUME na DEMO ANTES de apontar para a conta real.'
Escreve ''
Escreve '(k) NOTIFICACOES TELEGRAM (SETUP_VPS secao 9) - sem isto o alerta CRITICO de token'
Escreve '    expirado ou de HALT fica so no ALERTAS.md, que ninguem le em tempo real.'
Escreve '    Criar o bot no @BotFather, mandar /start, ler o chat_id em'
Escreve '    https://api.telegram.org/bot<TOKEN>/getUpdates  e gravar como variaveis de'
Escreve '    ambiente DO USUARIO (fora do workspace, nunca em arquivo do kit):'
Escreve "    [Environment]::SetEnvironmentVariable('SURV_TELEGRAM_TOKEN','<TOKEN>','User')"
Escreve "    [Environment]::SetEnvironmentVariable('SURV_TELEGRAM_CHAT','<CHAT_ID>','User')"
Escreve ''
Escreve '(l) SEGURANCA (SETUP_VPS secao 10)'
Escreve '    Restringir o RDP (3389) ao IP de casa ou a VPN da Hyonix; desativar a conta Guest;'
Escreve '    conferir que o MCP escuta SO em 127.0.0.1:   netstat -ano | findstr 22346'
Escreve '    e que NAO existe regra de firewall de entrada para 22346/22345.'
Escreve ''
Escreve 'Lembrete: este script nao reinicia o Windows. Se algum item pedir reinicio'
Escreve '(Git no PATH, auto-logon), reinicie voce mesmo quando for conveniente.'

# =====================================================================
#  Saida
# =====================================================================
$falhou = $false
$manuais = 0
foreach ($r in $script:RESULT) {
    if ($r.Estado -eq 'FALHOU') { $falhou = $true }
    if ($r.Estado -eq 'MANUAL') { $manuais = $manuais + 1 }
}
Escreve ''
Escreve ("fim         : {0}Z (UTC)" -f ([DateTime]::UtcNow.ToString('yyyy-MM-dd HH:mm:ss')))
if ($script:LOG_FILE) { Escreve ("log completo: {0}" -f $script:LOG_FILE) }
if ($falhou) {
    Escreve 'RESULTADO   : alguma etapa FALHOU (veja o resumo acima).'
    exit 1
}
if ($manuais -gt 0) {
    # MANUAL nao e falha, mas tambem nao e "tudo certo": sem isto a ultima linha da
    # tela dizia "sem falhas" com o terminal MT5 e o kit ainda faltando.
    Escreve ("RESULTADO   : sem falhas, mas {0} etapa(s) MANUAL no resumo acima - resolva e rode de novo:" -f $manuais)
    Escreve ('              powershell -NoProfile -ExecutionPolicy Bypass -File "{0}"' -f $PSCommandPath)
    exit 5
}
Escreve 'RESULTADO   : sem falhas.'
exit 0

# =====================================================================
#  DECISOES E FONTES (para auditoria futura)
#  - Git: winget (Git.Git) quando existir; senao a URL da ultima versao e DESCOBERTA
#    em api.github.com/repos/git-for-windows/git/releases/latest (projeto oficial para
#    onde git-scm.com/download/win aponta), asset "Git-*-64-bit.exe", com assinatura
#    Authenticode conferida antes de executar. Se nada disso der certo: MANUAL com
#    https://git-scm.com/download/win. Nenhum link fixo foi inventado.
#  - Claude Code: https://claude.ai/install.ps1 (o proprio instalador confere o SHA-256
#    do binario contra o manifest oficial). Rodado num processo filho porque ele usa
#    Set-StrictMode, que atrapalharia este script se fosse "irm | iex".
#  - Autologon: https://download.sysinternals.com/files/AutoLogon.zip (link de download
#    da pagina oficial learn.microsoft.com/sysinternals/downloads/autologon), extraido e
#    com assinatura conferida. O script NUNCA configura o auto-logon (exige senha).
#  - MT5: tenta https://download.mql5.com/cdn/web/roboforex.ltd/mt5/roboforex5setup.exe
#    (padrao do CDN da MetaQuotes). Conferido em 22/09/2026: respondeu 404 a partir do
#    Brasil. Por isso existe o -MT5Setup e o caminho MANUAL pela area do cliente. NAO
#    usamos o mt5setup.exe generico da MetaQuotes: e outro produto (sem a lista de
#    servidores da RoboForex) e o kit foi validado com o terminal do corretor.
#  - Windows Update: HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU com
#    NoAutoUpdate=0, AUOptions=4, ScheduledInstallDay=7 (1=domingo ... 7=sabado),
#    ScheduledInstallTime=3, NoAutoRebootWithLoggedOnUsers=0. Server 2022 honra essas
#    politicas classicas de AU.
#  - Tela: HKCU\Control Panel\Desktop (ScreenSaveActive, ScreenSaverIsSecure,
#    ScreenSaveTimeOut, REG_SZ) + a politica equivalente em
#    HKCU\Software\Policies\Microsoft\Windows\Control Panel\Desktop.
#    InactivityTimeoutSecs (HKLM) e apenas LIDO: e politica de seguranca.
#  - Editores esperados na conferencia de assinatura (Test-Assinatura, parametro
#    $EditorEsperado): Git for Windows = "Johannes Schindelin" (ou "Git for Windows"),
#    Autologon = "Microsoft Corporation", instalador MT5 = "MetaQuotes" (ou "RoboForex").
#    Assinatura valida de OUTRO editor e recusada e o arquivo nao e executado; no caso
#    do Autologon o arquivo ainda e APAGADO, porque e nele que se digita a senha do VPS.
#  - Energia: powercfg /change standby|monitor|hibernate-timeout-ac 0. O ANTES/DEPOIS e
#    lido no registro (HKLM\SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes\
#    <esquema ativo>\<subgrupo>\<config>\ACSettingIndex), que independe do idioma do
#    Windows; o texto de powercfg /query so e usado como segundo recurso (so em ingles).
# =====================================================================
