# =====================================================================
#  common.ps1 - funcoes compartilhadas pelos scripts de ops\
#  Carregar DEPOIS de config.ps1:   . "$PSScriptRoot\config.ps1"; . "$PSScriptRoot\common.ps1"
#  Sem acentos (PowerShell 5.1 / ANSI).
# =====================================================================

$script:Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

function Get-UtcStamp {
    # Carimbo de tempo sempre em UTC (o VPS roda em UTC; logs ficam sem ambiguidade)
    return [DateTime]::UtcNow.ToString('yyyy-MM-dd HH:mm:ss') + 'Z'
}

function Ensure-Dir([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Add-Utf8Line([string]$Path, [string]$Line) {
    $dir = Split-Path -Parent $Path
    if ($dir) { Ensure-Dir $dir }
    [IO.File]::AppendAllText($Path, $Line + "`r`n", $script:Utf8NoBom)
}

function Write-OpsLog {
    # Linha padrao: "2026-09-22 13:00:00Z | script | mensagem"
    param([string]$Msg, [string]$Origem = 'ops', [string]$File = '')
    if (-not $File) { $File = Join-Path $LOG_DIR 'ops.log' }
    Add-Utf8Line $File ("{0} | {1} | {2}" -f (Get-UtcStamp), $Origem, $Msg)
}

function Read-TextAuto([string]$Path) {
    # Le arquivo de texto detectando BOM (UTF-16 LE / UTF-8) - o MQL5 pode gravar qualquer um.
    # Abre com compartilhamento total (ReadWrite + Delete): o guardiao faz append no
    # guardian.log e rename (FileMove) no status.json enquanto os scripts leem.
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    $bytes = $null
    $fs = $null
    try {
        $fs = [IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, ([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
        $ms = New-Object IO.MemoryStream
        $fs.CopyTo($ms)
        $bytes = $ms.ToArray()
        $ms.Dispose()
    } catch {
        return $null
    } finally {
        if ($fs) { $fs.Dispose() }
    }
    if ($bytes.Length -eq 0) { return '' }
    if ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
        return [Text.Encoding]::Unicode.GetString($bytes, 2, $bytes.Length - 2)
    }
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        return [Text.Encoding]::UTF8.GetString($bytes, 3, $bytes.Length - 3)
    }
    # Sem BOM: heuristica UTF-16 (byte 1 nulo em texto ASCII)
    if ($bytes.Length -ge 2 -and $bytes[1] -eq 0 -and $bytes[0] -ne 0) {
        return [Text.Encoding]::Unicode.GetString($bytes)
    }
    return [Text.Encoding]::UTF8.GetString($bytes)
}

function Get-Field {
    # Devolve o primeiro campo existente entre varios nomes candidatos (tolerante ao schema)
    param($Obj, [string[]]$Names, $Default = $null)
    if ($null -eq $Obj) { return $Default }
    foreach ($n in $Names) {
        $p = $Obj.PSObject.Properties[$n]
        if ($p -and $null -ne $p.Value) { return $p.Value }
    }
    return $Default
}

function ConvertTo-Bool($v) {
    if ($null -eq $v) { return $false }
    if ($v -is [bool]) { return $v }
    $s = ("$v").Trim().ToLower()
    return ($s -eq 'true' -or $s -eq '1' -or $s -eq 'yes' -or $s -eq 'sim')
}

function ConvertTo-Num($v, $Default = 0.0) {
    if ($null -eq $v) { return $Default }
    $d = 0.0
    $s = ("$v").Replace(',', '.')
    if ([double]::TryParse($s, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$d)) { return $d }
    return $Default
}

function Read-SurvStatus {
    # Le status.json do guardiao e normaliza os campos que os scripts usam.
    # Devolve $null se o arquivo nao existir ou nao for JSON valido.
    # Campos normalizados: Ts, AgeSec, Connected, Syncing, Login, State, Halt, DailyLock,
    #   RiskScale, Balance, Equity, Hwm, DdPct, DayPnlPct, Positions, Pending, LastSeq,
    #   LastCmd, LastCmdResult, Raw (objeto original)
    if (-not (Test-Path -LiteralPath $STATUS_FILE)) { return $null }
    $txt = Read-TextAuto $STATUS_FILE
    if (-not $txt -or -not $txt.Trim()) { return $null }
    $j = $null
    try { $j = $txt | ConvertFrom-Json -ErrorAction Stop } catch { return $null }
    $fi = Get-Item -LiteralPath $STATUS_FILE
    $age = [int]([DateTime]::UtcNow - $fi.LastWriteTimeUtc).TotalSeconds
    $state = "$(Get-Field $j @('state','estado','status') 'UNKNOWN')".ToUpper()
    $halt = ConvertTo-Bool (Get-Field $j @('halt','is_halt') $false)
    if ($state -match 'HALT') { $halt = $true }
    $o = New-Object PSObject -Property @{
        Ts            = "$(Get-Field $j @('ts_server','ts','time','timestamp','server_time') '')"
        AgeSec        = $age
        Connected     = ConvertTo-Bool (Get-Field $j @('connected','conectado','is_connected') $false)
        Syncing       = ConvertTo-Bool (Get-Field $j @('syncing','sincronizando') $false)
        Login         = [long](ConvertTo-Num (Get-Field $j @('login','account_login') 0) 0)
        State         = $state
        Halt          = $halt
        DailyLock     = ConvertTo-Bool (Get-Field $j @('daily_lock','locked_today','lock_today') $false)
        RiskScale     = ConvertTo-Num (Get-Field $j @('risk_scale','escala_risco') 1.0) 1.0
        Balance       = ConvertTo-Num (Get-Field $j @('balance','saldo') 0) 0
        Equity        = ConvertTo-Num (Get-Field $j @('equity','capital') 0) 0
        Hwm           = ConvertTo-Num (Get-Field $j @('hwm','high_water_mark') 0) 0
        DdPct         = ConvertTo-Num (Get-Field $j @('dd_pct','dd','drawdown_pct','dd_vs_hwm_pct') 0) 0
        DayPnlPct     = ConvertTo-Num (Get-Field $j @('day_pnl_pct','daily_pnl_pct','dia_pct') 0) 0
        Positions     = [int](ConvertTo-Num (Get-Field $j @('positions','posicoes','open_positions') 0) 0)
        Pending       = [int](ConvertTo-Num (Get-Field $j @('pending','pendentes','orders') 0) 0)
        LastSeq       = [int](ConvertTo-Num (Get-Field $j @('last_seq','seq') 0) 0)
        LastCmd       = "$(Get-Field $j @('last_cmd','ultimo_cmd') '')"
        LastCmdResult = "$(Get-Field $j @('last_cmd_result','last_result','ultimo_resultado') '')"
        Raw           = $j
    }
    return $o
}

function Get-Mt5Process {
    # Instancias de terminal64.exe que pertencem a instalacao configurada ($MT5_EXE).
    # Filtra por Path para NUNCA confundir com outro terminal (Axi, 4XC...) na mesma maquina.
    $all = @(Get-Process -Name 'terminal64' -ErrorAction SilentlyContinue)
    if ($all.Count -eq 0) { return @() }
    $target = $MT5_EXE.ToLower()
    $match = @()
    $noPath = @()
    foreach ($p in $all) {
        $path = $null
        try { $path = $p.Path } catch { $path = $null }
        if ($path) {
            if ($path.ToLower() -eq $target) { $match += $p }
        } else {
            $noPath += $p
        }
    }
    if ($match.Count -eq 0 -and $noPath.Count -gt 0) {
        # Path inacessivel pelo Get-Process (outra sessao/elevado): tenta o caminho pelo CIM (desde 2026-09-29 pode haver
        # a copia de tester do laboratorio, $LAB_DIR, rodando ao lado). So assume "e o nosso" sem caminho nenhum se for o
        # unico terminal64 da maquina.
        $semCim = @()
        foreach ($q in $noPath) {
            $cp = ''
            try { $cp = "$((Get-CimInstance Win32_Process -Filter ('ProcessId=' + $q.Id) -ErrorAction Stop).ExecutablePath)" } catch { $cp = '' }
            if (-not $cp) { $semCim += $q } elseif ($cp.ToLower() -eq $target) { $match += $q }
        }
        if ($match.Count -eq 0 -and $semCim.Count -eq 1 -and $all.Count -eq 1) { $match = $semCim }
    }
    return $match
}

function Get-InitialEquity {
    # Procura em STATE.md uma linha tipo "Equity inicial: 10000" / "Saldo inicial = 10 000 USC";
    # fallback: $INITIAL_EQUITY do config.
    $state = Join-Path $WS 'STATE.md'
    if (Test-Path -LiteralPath $state) {
        $txt = Read-TextAuto $state
        if ($txt) {
            $m = [regex]::Match($txt, '(?im)^\s*[-*]?\s*\**\s*(equity|saldo|capital|deposito)\s+inicial\s*\**\s*[:=]\s*\**\s*([\d][\d\s.,]*)')
            if ($m.Success) {
                $num = $m.Groups[2].Value -replace '[\s]', ''
                $v = ConvertTo-Num $num 0
                if ($v -gt 0) { return $v }
            }
        }
    }
    return [double]$INITIAL_EQUITY
}

function Read-StampFile([string]$Path) {
    # Le um carimbo UTC gravado por Write-StampFile; $null se nao existir/invalido
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    $s = (Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue | Select-Object -First 1)
    if (-not $s) { return $null }
    $d = [DateTime]::MinValue
    if ([DateTime]::TryParseExact($s.Trim(), 'yyyy-MM-dd HH:mm:ss', [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::AssumeUniversal -bor [Globalization.DateTimeStyles]::AdjustToUniversal, [ref]$d)) { return $d }
    return $null
}

function Write-StampFile([string]$Path, [string]$Extra = '') {
    Ensure-Dir (Split-Path -Parent $Path)
    $lines = @([DateTime]::UtcNow.ToString('yyyy-MM-dd HH:mm:ss'))
    if ($Extra) { $lines += $Extra }
    [IO.File]::WriteAllLines($Path, $lines, $script:Utf8NoBom)
}

function Remove-StampFile([string]$Path) {
    if (Test-Path -LiteralPath $Path) { Remove-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue }
}

function Get-LastLines([string]$Path, [int]$N) {
    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    $txt = Read-TextAuto $Path
    if (-not $txt) { return @() }
    $lines = $txt -split "`r?`n" | Where-Object { $_ -ne '' }
    if ($lines.Count -le $N) { return $lines }
    return $lines[($lines.Count - $N)..($lines.Count - 1)]
}

function Get-SystemBootTimeUtc {
    # Hora (UTC) do ultimo boot do Windows; $null se nao der para ler
    try {
        $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop
        return $os.LastBootUpTime.ToUniversalTime()
    } catch { return $null }
}

function Get-Mt5UptimeMin {
    # Minutos desde o arranque da instancia de terminal64 ($MT5_EXE) mais antiga;
    # -1 se nao ha instancia ou o StartTime nao pode ser lido (outra sessao).
    $procs = @(Get-Mt5Process)
    if ($procs.Count -eq 0) { return -1 }
    $best = -1.0
    foreach ($p in $procs) {
        try {
            $m = ([DateTime]::UtcNow - $p.StartTime.ToUniversalTime()).TotalMinutes
            if ($m -gt $best) { $best = $m }
        } catch { }
    }
    return $best
}

function Start-Detached {
    # Inicia um processo FORA do job object do chamador, via WMI (Win32_Process.Create):
    # o pai passa a ser o WmiPrvSE, na mesma sessao interativa do chamador (conferido
    # em PowerShell 5.1: ParentName=WmiPrvSE, SessionId igual).
    # Por que: o Task Scheduler poe os filhos da tarefa no job dela. Enquanto um filho
    # vive a tarefa continua "Running" (com MultipleInstances=IgnoreNew as proximas
    # execucoes sao ignoradas) e, ao estourar o ExecutionTimeLimit, a arvore inteira e
    # encerrada: o terminal64 subido pelo heartbeat morreria 8 min depois, e o
    # run_claude de incidente tambem. Devolve o PID (0 = falhou). Fallback: Start-Process.
    param([string]$FilePath, [string]$Arguments = '', [string]$WorkingDirectory = '')
    $cmd = ('"{0}"' -f $FilePath)
    if ($Arguments) { $cmd += ' ' + $Arguments }
    if (-not $WorkingDirectory) { $WorkingDirectory = Split-Path -Parent $FilePath }
    try {
        $r = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $cmd; CurrentDirectory = $WorkingDirectory } -ErrorAction Stop
        if ($r -and $r.ReturnValue -eq 0 -and $r.ProcessId -gt 0) { return [int]$r.ProcessId }
        $rv = 'null'
        if ($r) { $rv = "$($r.ReturnValue)" }
        Write-OpsLog ("AVISO: Win32_Process.Create devolveu {0} para {1}; usando Start-Process (dentro do job)" -f $rv, $FilePath) 'common'
    } catch {
        Write-OpsLog ("AVISO: Win32_Process.Create falhou ({0}); usando Start-Process (dentro do job)" -f $_.Exception.Message) 'common'
    }
    try {
        $p = $null
        if ($Arguments) {
            $p = Start-Process -FilePath $FilePath -ArgumentList $Arguments -WorkingDirectory $WorkingDirectory -PassThru
        } else {
            $p = Start-Process -FilePath $FilePath -WorkingDirectory $WorkingDirectory -PassThru
        }
        if ($p) { return [int]$p.Id }
    } catch {
        Write-OpsLog ("ERRO: Start-Process falhou ({0})" -f $_.Exception.Message) 'common'
    }
    return 0
}

# --- Laboratorio de testes (copia de tester separada, ops\lab.ps1) ---------
# Usado pelo lab.ps1, pelo heartbeat.ps1 (encerra a copia fora da janela ou sem o lab.ps1 vivo) e pelo
# start_terminal.ps1 (encerra a copia antes de subir o terminal ao vivo). Tudo filtra pelo CAMINHO do
# executavel (CIM, que enxerga outras sessoes); nunca por nome ou PID solto.

function Get-LabDir {
    # '' (desligado) se a pasta for curta demais (C:\) ou contiver o terminal ao vivo: nunca filtrar o disco inteiro
    if (-not $LAB_DIR) { return '' }
    $lab = ([string]$LAB_DIR).TrimEnd('\')
    if ($lab.Length -lt 4) { return '' }
    if ($MT5_DIR) {
        $vivo = ([string]$MT5_DIR).TrimEnd('\').ToLower()
        if (($vivo + '\').StartsWith($lab.ToLower() + '\')) { return '' }
    }
    return $lab
}

function Get-LabProcesses {
    # terminal64/metatester64 cujo ExecutablePath esta DENTRO de $LAB_DIR e fora de $MT5_DIR
    $lab = Get-LabDir
    if (-not $lab) { return @() }
    $pref = ($lab + '\').ToLower()
    $live = ''
    if ($MT5_DIR) { $live = (([string]$MT5_DIR).TrimEnd('\') + '\').ToLower() }
    if ($live -and $pref -eq $live) { return @() }
    $all = @()
    try { $all = @(Get-CimInstance Win32_Process -Filter "Name='terminal64.exe' OR Name='metatester64.exe'" -ErrorAction Stop) } catch { return @() }
    $r = @()
    foreach ($p in $all) {
        $path = "$($p.ExecutablePath)"
        if (-not $path) { continue }
        $pl = $path.ToLower()
        if ($pl.StartsWith($pref) -and -not ($live -and $pl.StartsWith($live))) { $r += $p }
    }
    return $r
}

function Stop-LabProcesses([string]$Motivo, [string]$Origem = 'lab') {
    # Encerra SO processos da copia de tester (caminho conferido de novo, processo a processo). Devolve quantos.
    $n = 0
    $pref = ((Get-LabDir) + '\').ToLower()
    if ($pref -eq '\') { return 0 }
    foreach ($p in @(Get-LabProcesses)) {
        $path = "$($p.ExecutablePath)".ToLower()
        if (-not $path.StartsWith($pref)) { continue }
        if ($MT5_EXE -and $path -eq ([string]$MT5_EXE).ToLower()) { continue }
        try { Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop; $n++ } catch { }
    }
    if ($n -gt 0) { Write-OpsLog ("lab: {0} processo(s) da copia de tester encerrado(s): {1}" -f $n, $Motivo) $Origem }
    return $n
}

function Test-LabJanela([DateTime]$Utc) {
    # Janela do laboratorio (ouro fechado): sabado 04:30 UTC (depois do Windows Update de 03:00) ate domingo 17:30 UTC
    # (a pre-abertura das 18:00 confere que acabou; o mercado abre 22:05).
    $m = $Utc.Hour * 60 + $Utc.Minute
    if ($Utc.DayOfWeek -eq [DayOfWeek]::Saturday -and $m -ge 270) { return $true }
    if ($Utc.DayOfWeek -eq [DayOfWeek]::Sunday -and $m -lt 1050) { return $true }
    return $false
}

function Get-LabLockInfo {
    # Lock do lab.ps1 (ops\logs\lab.lock: PID, StartTime UTC em ticks, acao, carimbo). Devolve o lock so se o dono
    # ainda vive: mesmo PID, mesma hora de criacao (+-2 s) e linha de comando com lab.ps1. PID reaproveitado depois de
    # um reboot nao passa. Senao $null.
    $f = Join-Path $LOG_DIR 'lab.lock'
    if (-not (Test-Path -LiteralPath $f)) { return $null }
    $l = @(Get-Content -LiteralPath $f -ErrorAction SilentlyContinue)
    if ($l.Count -lt 2) { return $null }
    $lp = 0; [int]::TryParse("$($l[0])", [ref]$lp) | Out-Null
    $lt = 0L; [long]::TryParse("$($l[1])", [ref]$lt) | Out-Null
    if ($lp -le 0) { return $null }
    $p = $null
    try { $p = Get-CimInstance Win32_Process -Filter ("ProcessId=" + $lp) -ErrorAction Stop } catch { return $null }
    if (-not $p) { return $null }
    if ("$($p.CommandLine)" -notmatch 'lab\.ps1') { return $null }
    # hora de criacao pela MESMA fonte que o lab.ps1 grava (Get-Process), sem a conversao de fuso do CIM
    $ct = 0L
    try { $ct = (Get-Process -Id $lp -ErrorAction Stop).StartTime.ToUniversalTime().Ticks } catch { return $null }
    if ([Math]::Abs($ct - $lt) -gt 20000000) { return $null }
    $acao = ''; if ($l.Count -ge 3) { $acao = "$($l[2])" }
    $desde = ''; if ($l.Count -ge 4) { $desde = "$($l[3])" }
    return New-Object PSObject -Property @{ Pid = $lp; StartTicks = $lt; Acao = $acao; Desde = $desde }
}

function Test-LabManutencao {
    # ops\logs\lab.manutencao (criado pelo lab_instalar.ps1 ou pelo Henrique): por ate 60 min a copia pode ficar aberta
    # a mao (login da demo, desligar MCP), fora da janela, sem o heartbeat encerra-la. So vale com a conta sem posicao
    # aberta (status.json fresco, positions = 0).
    $f = Join-Path $LOG_DIR 'lab.manutencao'
    if (-not (Test-Path -LiteralPath $f)) { return $false }
    $idade = ([DateTime]::UtcNow - (Get-Item -LiteralPath $f).LastWriteTimeUtc).TotalMinutes
    if ($idade -gt 60) { return $false }
    $st = Read-SurvStatus
    if (-not $st -or $st.AgeSec -gt 180 -or $st.Positions -gt 0) { return $false }
    return $true
}
