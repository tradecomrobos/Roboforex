# =====================================================================
#  start_terminal.ps1 - garante um terminal MT5 RoboForex saudavel (modo /portable)
#  Uso:  powershell -NoProfile -ExecutionPolicy Bypass -File start_terminal.ps1 [-Restart] [-SoIniciar] [-WaitSec 60]
#  Comportamento sem parametros ("deixe um terminal saudavel rodando"):
#    - nao ha instancia de $MT5_EXE            -> inicia
#    - ha instancia e status.json esta fresco   -> nada a fazer
#    - ha instancia mas status.json esta stale (> $STATUS_STALE_SEC) ou connected=false
#                                              -> reinicia (terminal travado/desconectado)
#  -Restart   : reinicia sempre (fechamento gracioso = WM_CLOSE / Arquivo > Sair, espera,
#               Stop-Process se nao fechar, inicia de novo).
#  -SoIniciar : nunca reinicia (so inicia se ausente) - usado pelo heartbeat.
#  Arranque: restaura o perfil "sobrevivencia" de ops\profile\ (se existir a copia,
#  ver save_profile.ps1), depois '/portable' + '/config:<ops\start.ini>' quando
#  $MT5_START_INI existir (o ini religa AutoTrading e carrega o perfil - SETUP_VPS.md).
#  Atencao: o fechamento forcado (Stop-Process) perde o que o MT5 nao gravou; o
#  guardiao v1.10 forca as GVs a disco e mantem survival\state.txt por isso.
#  Registra em $LOG_DIR\ops.log. Saida: 0 ok, 1 exe ausente, 2 nao subiu.
#  Nunca envia ordens; nunca toca control.txt.
# =====================================================================
param(
    [switch]$Restart,
    [switch]$SoIniciar,
    [int]$WaitSec = 60,        # espera pelo processo apos iniciar
    [int]$CloseGraceSec = 20   # espera pelo fechamento gracioso antes de forcar
)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\config.ps1"
. "$PSScriptRoot\common.ps1"
$ORIGEM = 'start_terminal'

if (-not (Test-Path -LiteralPath $MT5_EXE)) {
    Write-OpsLog "ERRO: terminal nao encontrado em $MT5_EXE" $ORIGEM
    Write-Host "ERRO: terminal nao encontrado em $MT5_EXE"
    exit 1
}

$procs = @(Get-Mt5Process)

if ($procs.Count -gt 0 -and -not $Restart) {
    $pids = ($procs | ForEach-Object { $_.Id }) -join ','
    $doente = $false
    $motivo = ''
    if (-not $SoIniciar) {
        $st = Read-SurvStatus
        if (-not $st) {
            if (Test-Path -LiteralPath $STATUS_FILE) {
                $ageF = [int]([DateTime]::UtcNow - (Get-Item -LiteralPath $STATUS_FILE).LastWriteTimeUtc).TotalSeconds
                if ($ageF -gt $STATUS_STALE_SEC) { $doente = $true; $motivo = "status.json ilegivel/stale ha ${ageF}s" }
            }
            # sem status.json nenhum: pode ser 1o arranque (guardiao ainda nao anexado) - nao reinicia
        } elseif ($st.AgeSec -gt $STATUS_STALE_SEC) {
            $doente = $true; $motivo = "status.json stale ha $($st.AgeSec)s"
        } elseif (-not $st.Connected) {
            $doente = $true; $motivo = 'status.json com connected=false'
        }
        # Terminal recem-arrancado (logon, pos-reboot, subido pelo heartbeat segundos atras):
        # o status.json ainda e o de antes e o guardiao esta em aquecimento. Nao reiniciar.
        if ($doente) {
            $upMin = Get-Mt5UptimeMin
            if ($upMin -ge 0 -and ($upMin * 60) -lt $MT5_BOOT_GRACE_SEC) {
                Write-OpsLog ("rodando (PID {0}) ha {1:N0}s, ainda em arranque ({2}); nao reinicia antes de {3}s de vida" -f $pids, ($upMin * 60), $motivo, $MT5_BOOT_GRACE_SEC) $ORIGEM
                Write-Host ("Terminal arrancou ha {0:N0}s ({1}); aguardando o guardiao antes de julgar." -f ($upMin * 60), $motivo)
                exit 0
            }
        }
    }
    if (-not $doente) {
        Write-OpsLog "ja rodando (PID $pids) e saudavel; nada a fazer" $ORIGEM
        Write-Host "Terminal ja rodando (PID $pids)."
        exit 0
    }
    Write-OpsLog "rodando (PID $pids) mas doente: $motivo -> reiniciando" $ORIGEM
    Write-Host "Terminal rodando mas doente ($motivo): reiniciando."
    $Restart = $true
}

if ($procs.Count -gt 0 -and $Restart) {
    $pids = ($procs | ForEach-Object { $_.Id }) -join ','
    Write-OpsLog "restart solicitado: fechando PID $pids (gracioso, ate ${CloseGraceSec}s)" $ORIGEM
    foreach ($p in $procs) {
        try { [void]$p.CloseMainWindow() } catch { }
    }
    $deadline = [DateTime]::UtcNow.AddSeconds($CloseGraceSec)
    while ([DateTime]::UtcNow -lt $deadline) {
        Start-Sleep -Seconds 1
        if (@(Get-Mt5Process).Count -eq 0) { break }
    }
    $left = @(Get-Mt5Process)
    if ($left.Count -gt 0) {
        $pids2 = ($left | ForEach-Object { $_.Id }) -join ','
        Write-OpsLog "nao fechou graciosamente; Stop-Process -Force em PID $pids2" $ORIGEM
        foreach ($p in $left) {
            try { Stop-Process -Id $p.Id -Force -ErrorAction Stop } catch { Write-OpsLog "Stop-Process falhou em PID $($p.Id): $($_.Exception.Message)" $ORIGEM }
        }
        Start-Sleep -Seconds 5
    }
}

# --- Perfil de graficos: restaurar a copia integra do kit ------------
# O MT5 salva o perfil corrente ao sair; se o grafico do guardiao tiver sido fechado
# por engano, o proximo arranque subiria SEM guardiao. A copia em ops\profile\ (feita
# por save_profile.ps1) e restaurada antes de cada arranque. Sem a copia, nada muda.
if ($PROFILE_RESTORE -and (Test-Path -LiteralPath $PROFILE_SRC_DIR)) {
    $chr = @(Get-ChildItem -LiteralPath $PROFILE_SRC_DIR -File -ErrorAction SilentlyContinue)
    if ($chr.Count -gt 0) {
        try {
            Ensure-Dir $PROFILE_DST_DIR
            foreach ($old in @(Get-ChildItem -LiteralPath $PROFILE_DST_DIR -File -ErrorAction SilentlyContinue)) {
                Remove-Item -LiteralPath $old.FullName -Force -ErrorAction SilentlyContinue
            }
            Copy-Item -Path (Join-Path $PROFILE_SRC_DIR '*') -Destination $PROFILE_DST_DIR -Force
            $snap = ($chr | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1).LastWriteTimeUtc
            Write-OpsLog ("perfil '{0}' restaurado de {1} ({2} arquivo(s), snapshot de {3:yyyy-MM-dd HH:mm}Z)" -f $PROFILE_NAME, $PROFILE_SRC_DIR, $chr.Count, $snap) $ORIGEM
            Write-Host ("Perfil '{0}' restaurado do kit ({1} arquivo(s))." -f $PROFILE_NAME, $chr.Count)
        } catch {
            Write-OpsLog "AVISO: falha ao restaurar o perfil: $($_.Exception.Message)" $ORIGEM
            Write-Host "AVISO: falha ao restaurar o perfil: $($_.Exception.Message)"
        }
    }
} elseif ($PROFILE_RESTORE) {
    Write-OpsLog "AVISO: sem copia do perfil em $PROFILE_SRC_DIR (rode ops\save_profile.ps1 apos salvar o perfil no terminal); arranque com o perfil que o terminal tiver" $ORIGEM
}

# --- Laboratorio: a copia de tester nunca sobe antes do terminal ao vivo ---
# Um tester da copia ($LAB_DIR) rodando agora pegaria a porta 22346 do MCP antes do ao vivo e disputaria a RAM
# do arranque. Encerra so os processos da copia (pelo caminho, common.ps1); o lab.ps1 retoma o run depois.
try {
    $nLab = Stop-LabProcesses 'start_terminal: o terminal ao vivo vai subir' $ORIGEM
    if ($nLab -gt 0) { Write-Host "Laboratorio: $nLab processo(s) da copia de tester encerrado(s) antes do arranque." }
} catch { }

# --- Iniciar ---------------------------------------------------------
$mtArgs = @()
if ($MT5_PORTABLE) { $mtArgs += '/portable' }
if ($MT5_START_INI -and (Test-Path -LiteralPath $MT5_START_INI)) { $mtArgs += ('/config:"{0}"' -f $MT5_START_INI) }
Write-OpsLog ("iniciando: {0} {1}" -f $MT5_EXE, ($mtArgs -join ' ')) $ORIGEM
# FORA do job object da tarefa agendada (Start-Detached, common.ps1): dentro dele o
# terminal morreria quando a tarefa Heartbeat/Terminal estourasse o limite de tempo.
$newPid = Start-Detached -FilePath $MT5_EXE -Arguments ($mtArgs -join ' ') -WorkingDirectory $MT5_DIR
if ($newPid -le 0) {
    Write-OpsLog "ERRO ao iniciar: nenhum processo criado" $ORIGEM
    Write-Host "ERRO ao iniciar o terminal (ver ops.log)."
    exit 2
}

# Espera o processo estabilizar (o terminal pode reiniciar a si mesmo em update)
$deadline = [DateTime]::UtcNow.AddSeconds($WaitSec)
$ok = $false
while ([DateTime]::UtcNow -lt $deadline) {
    Start-Sleep -Seconds 3
    $now = @(Get-Mt5Process)
    if ($now.Count -gt 0) { $ok = $true; break }
}
if ($ok) {
    $pids = (@(Get-Mt5Process) | ForEach-Object { $_.Id }) -join ','
    Write-OpsLog "terminal em execucao (PID $pids)" $ORIGEM
    Write-Host "Terminal iniciado (PID $pids)."
    exit 0
}
Write-OpsLog "ERRO: processo nao apareceu em ${WaitSec}s" $ORIGEM
Write-Host "ERRO: terminal nao subiu em ${WaitSec}s."
exit 2
