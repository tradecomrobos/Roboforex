# Referência: caminhos, ferramentas MCP, magics e status.json (9 e 11)

Consulta. O formato do control.txt e quem pode cada comando ficam no CLAUDE.md (seção 10).

## 9. Ferramentas e caminhos

### 9.1 Caminhos no VPS

| O quê | Caminho |
|---|---|
| Workspace (este kit) | `C:\Sobrevivencia` |
| Regras, estado, diário, alertas, inbox | `C:\Sobrevivencia\CLAUDE.md`, `STATE.md`, `DIARIO.md`, `ALERTAS.md`, `INBOX.md` |
| Prompts das acordadas (o protocolo de cada uma) | `C:\Sobrevivencia\prompts\diario.md`, `semanal.md`, `incidente.md`, `preabertura.md`, `lab.md` |
| Módulos de regras | `C:\Sobrevivencia\regras\saude.md`, `inbox.md`, `incidente.md`, `desempenho.md`, `degrau.md`, `regime.md`, `revalidacao.md`, `laboratorio.md`, `referencia.md` (mapa: CLAUDE.md, seção 0; somente leitura para mim) |
| Scripts de operação | `C:\Sobrevivencia\ops\cmd.ps1` (escreve comando no control.txt), `checar.ps1` (as contas das regras, somente leitura; grava só o relatório em `ops\logs\checar_*.json`), `notify.ps1` (avisa o Henrique), `start_terminal.ps1` (reinício controlado do terminal), `status.ps1` (resumo somente leitura), `heartbeat.ps1` (vigia de 10 min, não sou eu), `analisar_alcance.ps1` (tabelas de alcance em R da 5.8; só lê os CSVs e grava o relatório em `campanha\regime\`), `lab.ps1` (laboratório, 5.9; eu só uso `-Acao status` e `-Acao parar`), `lab_instalar.ps1` (cria a cópia de tester; só do Henrique) |
| Logs do agente | `C:\Sobrevivencia\ops\logs\heartbeat.log` (uma linha a cada 10 min do vigia mais uma linha por acordada minha), `ops\logs\ops.log` (tudo o que os scripts fizeram: reinícios, comandos, incidentes disparados), `ops\logs\claude_<modo>_<ts>.log` (saída de cada acordada) |
| Campanha de backtest e gate | `C:\Sobrevivencia\campanha\RESULTADOS.md` (EAs aprovados, degraus, relatórios) |
| Laboratório: fila e notícias | `C:\Sobrevivencia\campanha\lab\fila\*.json` (eu escrevo pedidos; o lab move para `aceitos\` ou `rejeitados\`), `campanha\lab\news\*.csv` (eventos que eu acrescento, GMT) |
| Laboratório: lotes e registro | `C:\Sobrevivencia\campanha\lab\lotes\<id>\relatorio.md`, `analise.json`, `lote.json`, `reports\`, `propostas\*.set`; `lotes\registro.json` (candidatas e extras em quarentena). Somente leitura para mim. |
| Laboratório: cópia de tester | `C:\MT5_RF_Lab` (conta demo; não toco; o heartbeat a encerra fora da janela) |
| Fontes MQL5 do kit | `C:\Sobrevivencia\mql5\Experts` (Concorde_RF patched, SurvivalGuardian, RegimeLogger), `mql5\Include` (SurvivalGuard.mqh), `mql5\Presets` (os 4 .set: Concorde degraus A e B, guardião G35 e G45), `mql5\templates` (templates aprovados) |
| Snapshot do perfil | `C:\Sobrevivencia\ops\profile\sobrevivencia\*.chr` (restaurado pelo `start_terminal.ps1` em todo arranque; somente leitura para mim) |
| Documentação | `C:\Sobrevivencia\docs\ARQUITETURA.md` |
| Terminal MT5 (portable) | `C:\MT5_RoboForex\terminal64.exe` (rodar sempre com `/portable`) |
| Arquivos do guardião | `C:\MT5_RoboForex\MQL5\Files\survival\control.txt` (eu escrevo), `status.json` (guardião escreve, eu leio), `guardian.log` (guardião escreve) |
| Arquivos do RegimeLogger | `C:\MT5_RoboForex\MQL5\Files\survival\regime.csv` (uma linha por dia do servidor, 5.7), `alcance.csv` (E1 e E3 simuladas, duas linhas por dia) e `trades_mfe.csv` (trades reais fechados), estes dois só para a 5.8. RegimeLogger escreve; eu só leio. |
| Histórico de referência do alcance | `C:\Sobrevivencia\campanha\regime\alcance_hist.csv` (RegimeLogger v1.20 no tester; somente leitura para mim) |
| EAs compilados | `C:\MT5_RoboForex\MQL5\Experts\Sobrevivencia\*.ex5` (não toco) |
| Diários | `C:\MT5_RoboForex\MQL5\Logs\AAAAMMDD.log` (Experts), `C:\MT5_RoboForex\Logs\AAAAMMDD.log` (terminal). UTF-16. |
| Calendário CSV | pasta Common\Files do terminal (em modo portable conferir `TERMINAL_COMMONDATA_PATH` na linha "FILTRO NOTÍCIAS" do diário). Ao vivo o Concorde usa só o calendário nativo (o código não tem fallback para o CSV); o `news.csv` serve ao tester, e o laboratório gera dele o `news_lab_srv.csv` (5.9). |
| MCP nativo do terminal | `http://127.0.0.1:22346` (chave da aba MCP do próprio terminal, guardada na configuração do Claude Code, fora do workspace) |

### 9.2 Ferramentas MCP (`mt5-terminal`)

| Permitidas (somente leitura) | Uso |
|---|---|
| `get_workspace_info` | Obrigatória como primeira chamada da sessão (exigência do servidor). |
| `get_trading_account_info` | Equity, saldo, margem, permissão de trade, conexão. |
| `get_trading_open_positions` | Posições abertas, magic, flutuante. |
| `get_trading_history_positions`, `get_trading_history_orders` | P&L por magic e por período. |
| `get_expert_journal`, `get_terminal_journal` | Diário dos EAs e do terminal. |
| `list_open_charts` | Quais gráficos e EAs estão no ar. |
| `get_marketwatch_symbols`, `get_time_information` | Símbolos, hora do servidor/GMT. |
| `read_file`, `read_file_by_lines`, `list_directory`, `search_text` | status.json, guardian.log, control.txt, diários. |
| `economic_calendar_list_values`, `economic_calendar_list_values_last`, `economic_calendar_list_events_by_currency`, `economic_calendar_list_events_by_country`, `economic_calendar_list_countries`, `economic_calendar_get_event_by_id`, `economic_calendar_get_value_by_id` | Notícias de impacto da semana (pré-abertura, seção 7) e conferência do filtro de notícias. Horários do calendário em hora do servidor. |

| Única escrita permitida | Uso |
|---|---|
| `campanha\lab\fila\*.json` e `campanha\lab\news\*.csv` (Write, dentro do workspace), não uma ferramenta MCP | Pedidos de teste e eventos de notícias para o laboratório (5.9). |
| `ops\cmd.ps1` (PowerShell), não uma ferramenta MCP | Único caminho de escrita no `control.txt`. Fallback, só se o cmd.ps1 falhar: `Add-Content -Encoding Ascii` de uma linha `SEQ\|CMD\|ARG`, com SEQ maior que o `last_seq` do status.json. O `write_file` do MCP está bloqueado. |

Tudo o que não está nas duas tabelas é proibido (seção 2). Sem MCP, o mesmo trabalho é feito lendo os arquivos por caminho (status.json, guardian.log, MQL5\Logs) com PowerShell; a escrita continua sendo só o control.txt via `ops\cmd.ps1`.

### 9.3 Magics do portfólio

| EA | Estratégia | Magic | Gráfico | Estado |
|---|---|---|---|---|
| Concorde_RF v3.04 (v3.03 + guardião) | E1 range noturno + OCO | 202512 | XAUUSD M15 | **ativa** (0,4% por perna nos degraus A e B) |
| Concorde_RF | E2 intradiária M15 | 202605122 | XAUUSD M15 | **DESLIGADA** (`Estrategia2_Ativada=false`) |
| Concorde_RF | E3 breakout de Londres (2 pernas) | 202533 e 202534 | XAUUSD M15 | **ativa** (1,2% por perna no degrau A, 1,8% no B) |
| Concorde_RF | E4 RSI2 Connors H1 (EURUSD, USDCAD, USDJPY, AUDUSD) | 550555 | XAUUSD M15 (operaria os 4 pares) | **DESLIGADA** (`Estrategia4_Ativada=false`) |
| SurvivalGuardian | não opera; fecha posições herdando o magic delas | — | gráfico próprio | ativo |
| RegimeLogger | não opera: registrador do regime do ouro, grava `regime.csv` (5.7), `alcance.csv` e `trades_mfe.csv` (5.8) | — (sem magic) | XAUUSD D1 (gráfico próprio) | autorizado; ativo depois da instalação registrada em STATE.md |

Preset do Concorde em uso: o da linha "Degrau do preset" de STATE.md (hoje `Concorde_E13_A.set`, degrau A). **Magic 202605122 (E2) ou 550555 (E4) aparecendo ao vivo, em posição, ordem ou deal de entrada, é preset errado anexado: incidente CRITICO.** Mando `HALT` pelo `ops\cmd.ps1` e espero o Henrique (tabela da seção 6). Deals de um incidente já tratado não repetem o HALT: os de fechamento (inclusive os do guardião, que herdam o magic) não contam, e os de entrada que já constam de um alerta com HALT executado só recebem a referência a ele (regra completa na quinta pergunta de 4.3). A checagem é diária (4.3) e o `ops\heartbeat.ps1` também dispara incidente a cada 10 min se o `by_magic` do status.json mostrar posição com magic fora de 202512, 202533 e 202534. Posição com magic fora desta tabela é incidente ("EA desconhecido"). O RegimeLogger não envia ordens e não tem magic: posição, ordem ou deal com magic fora de 202512, 202533 e 202534 continua sendo EA desconhecido, venha de onde vier (inclusive de um gráfico com o nome RegimeLogger).

## 11. status.json (o que o guardião publica)

Campos (conferidos em 2026-09-22 contra `BuildStatusJson` de `SurvivalGuardian.mq5` v1.10; se divergir, vale o EA): `guardian_version`, `ts_server`, `ts_local`, `login`, `server`, `currency`, `margin_mode`, `connected`, `syncing`, `trade_allowed_terminal`, `trade_allowed_account`, `trade_allowed_expert`, `balance`, `credit`, `equity`, `margin_level`, `hwm`, `dd_pct`, `day_start`, `day_pnl_pct`, `day_stamp`, `positions`, `orders`, `by_magic`, `halt`, `daily_lock`, `day_override`, `risk_scale`, `risk_scale_manual` (true = FIXO por comando, false = AUTO), `last_seq`, `last_cmd` (`SEQ|CMD|ARG`), `last_cmd_result`, `state` (`OK` | `RISCO_REDUZIDO` | `LOCK_DIARIO` | `HALT` | `SYNC` | `DISCONNECTED`), `control_overflow`, `state_file_ok`, `retry_pending`, `uptime_s`, `cycle`, `poll_s`, `managed_magics`, `limit_daily_loss_pct`, `limit_dd_reduce_pct`, `limit_dd_hysteresis_pct`, `limit_dd_halt_pct`. Não existe campo de heartbeat: o heartbeat é a idade do próprio arquivo, reescrito de forma atômica a cada `poll_s` (5 s); mais de 3 minutos (180 s) sem atualização é incidente. `state` vira `DISCONNECTED` ou `SYNC` mesmo em HALT: para saber se há HALT, usar a chave `halt`. Contrato completo com exemplo em `SETUP_VPS.md`, Anexo A.
