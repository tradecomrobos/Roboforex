Acordada SEMANAL do Desafio Sobrevivência (sábado, 12:00 UTC, mercado fechado).

Você é o agente gestor no VPS. O diretório de trabalho é C:\Sobrevivencia e a constituição (C:\Sobrevivencia\CLAUDE.md) já está carregada; releia-a se tiver dúvida. Os números de seção citados (4.3, 5.6, seção 6...) estão no mapa da seção 0 dela. Não há humano nesta sessão: não peça confirmação, decida pelas regras.

Leia antes de começar: C:\Sobrevivencia\regras\saude.md, inbox.md, desempenho.md, regime.md, degrau.md e laboratorio.md (todos em C:\Sobrevivencia\regras\); também revalidacao.md se hoje é o primeiro sábado de janeiro, abril, julho ou outubro, e incidente.md se alguma checagem falhar.

1. Rodar os cálculos: `powershell -NoProfile -ExecutionPolicy Bypass -File C:\Sobrevivencia\ops\checar.ps1 -Acao semanal` (saúde, números, desempenho, regime e degrau). Para o critério 6 de subida, o CSV do `-Slippage` (regras\degrau.md).
2. Saúde e INBOX: ler o estado e o terminal e checar a saúde (4.1 a 4.3; qualquer "não" leva ao incidente, seção 6), e processar o INBOX (4.5).
3. Desempenho: revisão por magic (5.1), comparação com a referência e regras objetivas de pausa (5.2), conta como um todo (5.3). Pausa ou troca de EA só se uma regra objetiva disparou e todas as condições de 5.4 estão satisfeitas; faltando qualquer uma, AGUARDANDO OK DO HENRIQUE, sem improviso. Manutenção (5.5).
4. Regime do ouro (5.7), logo depois de 5.3 e antes do degrau, para um alerta de subida poder citar o regime.
5. Degrau (5.6): no degrau A, os 6 critérios de subida, com a tabela "critério | valor ao vivo | limite | ok?" no DIARIO.md; no degrau B, os gatilhos de descida; no preset A com o guardião G45 da descida, a vez do guardião; a conferência de um OK DEGRAU pendente; o `risk_scale_manual` (5.3 e 5.6). Aumento do risk_scale do guardião só com evidência escrita e nunca acima do "risk_scale esperado do guardião" de STATE.md.
6. Revalidação trimestral (5.8), se hoje é o primeiro sábado de janeiro, abril, julho ou outubro. Se o lote trimestral ainda roda, escreva no bloco "lote <id> em andamento".
7. Laboratório (5.9): `powershell -NoProfile -ExecutionPolicy Bypass -File C:\Sobrevivencia\ops\lab.ps1 -Acao status`. Registre no DIARIO.md a sonda da semana (ok ou o erro) e o estado dos lotes. Lote que não é sonda, concluído ou inválido, ainda não lido (STATE.md, seção "Laboratório") e sem acordada do modo lab registrada (linha "lab | <id>" no heartbeat.log): faça por ele o que prompts\lab.md pede.

Termine escrevendo: a tabela por magic na seção "Desempenho ao vivo" do STATE.md, a entrada semanal em DIARIO.md, alertas em ALERTAS.md mais ops\notify.ps1 se houver (seção 8), e uma linha em ops\logs\heartbeat.log no formato de 4.7 com o modo semanal.

Resposta final, uma linha só: "SEMANAL OK <equity USC> <DD%> <decisão: nenhuma | pausa EA | troca EA | alerta | recomenda degrau B | recomenda descida | recomenda redução por regime>" ou "SEMANAL ERRO <motivo>".
