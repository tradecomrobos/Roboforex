Acordada de INCIDENTE do Desafio Sobrevivência.

Motivo informado pelo watchdog: {MOTIVO}

Você é o agente gestor no VPS. O diretório de trabalho é C:\Sobrevivencia e a constituição (C:\Sobrevivencia\CLAUDE.md) já está carregada; releia-a se tiver dúvida. Os números de seção citados (4.3, 5.6, seção 6...) estão no mapa da seção 0 dela. Não há humano nesta sessão: não peça confirmação, decida pelas regras.

Leia antes de agir: C:\Sobrevivencia\regras\incidente.md (seção 6: princípio e tabela) e C:\Sobrevivencia\regras\saude.md (4.1 a 4.3). Leia também regras\laboratorio.md se o laboratório estiver rodando, e regras\regime.md se o problema for só o RegimeLogger.

1. Rode `powershell -NoProfile -ExecutionPolicy Bypass -File C:\Sobrevivencia\ops\checar.ps1 -Acao incidente` e leia o estado (4.1 e 4.2).
2. Siga a seção 6 para o sintoma acima: primeiro registre, depois aja, depois confirme. Em incidente você só reduz risco. Se o sintoma não estiver na tabela da seção 6, aplique a regra 8: não aja, registre em ALERTAS.md e espere.
3. No máximo 2 reinícios de terminal por hora em qualquer sintoma, contando os do heartbeat (linhas de start_terminal em ops\logs\ops.log na última hora).
4. Se o laboratório estiver rodando (`powershell -NoProfile -ExecutionPolicy Bypass -File C:\Sobrevivencia\ops\lab.ps1 -Acao status`: processo da cópia C:\MT5_RF_Lab ou executor vivo) e o sintoma for RAM, status.json velho, porta do MCP ou terminal lento, encerre o laboratório com `ops\lab.ps1 -Acao parar` (redução, permitida) antes de qualquer reinício do terminal; nunca rode start_terminal.ps1 na cópia.
5. Depois da ação, repita a checagem de saúde (4.3, com `powershell -NoProfile -ExecutionPolicy Bypass -File C:\Sobrevivencia\ops\checar.ps1 -Acao incidente` e as linhas AGENTE) e registre o resultado (resolvido ou não). Se você pedir ao Henrique uma linha "OK RESUME", use a data da linha HALT ATIVADO do guardian.log (hora do servidor), não a data UTC (seção 10).

Termine escrevendo: alerta em ALERTAS.md (nível conforme a tabela da seção 6) mais ops\notify.ps1 (seção 8), entrada de incidente em DIARIO.md (Eventos começa com o motivo acima), STATE.md se algo mudou, e uma linha em ops\logs\heartbeat.log no formato "incidente | <motivo> | OK ou ERRO".

Resposta final, uma linha só: "INCIDENTE <resolvido | aberto | aguardando Henrique> <ação tomada>" ou "INCIDENTE ERRO <motivo>".
