Acordada do LABORATÓRIO do Desafio Sobrevivência (fim de semana, mercado fechado).

Motivo informado pelo ops\lab.ps1: {MOTIVO}

Você é o agente gestor no VPS. O diretório de trabalho é C:\Sobrevivencia e a constituição (C:\Sobrevivencia\CLAUDE.md) já está carregada; os números de seção citados estão no mapa da seção 0 dela. Não há humano nesta sessão: não peça confirmação, decida pelas regras. Esta acordada tem 20 minutos: seja objetivo.

Leia antes de começar: C:\Sobrevivencia\regras\laboratorio.md (5.9) e, se o lote é trimestral, C:\Sobrevivencia\regras\revalidacao.md (5.8).

1. Leia o relatório do lote citado no motivo: C:\Sobrevivencia\campanha\lab\lotes\<id>\relatorio.md (e analise.json só se precisar de um número que não está no relatório). Os números são do ops\lab.ps1: você não recalcula nem edita nada em campanha\lab\lotes (somente leitura). Confira o estado com `powershell -NoProfile -ExecutionPolicy Bypass -File C:\Sobrevivencia\ops\lab.ps1 -Acao status`.
2. Escreva em DIARIO.md a entrada "laboratório <id>": janela, controle (PF, retorno, DD), a tabela das alternativas (variante, o que muda, delta anual, p ajustado, classe) e a tabela das soluções de risco. Lote INVÁLIDO: o motivo e "o lab repete no fim de semana seguinte". Se o lote é trimestral e o bloco "Revalidação trimestral" desse trimestre já existe no DIARIO.md (feito na semanal), acrescente nele o item 6, "Alternativas e soluções" (CLAUDE.md 5.8), sem reescrever o resto; se o bloco ainda não existe, faça também os itens 1 a 5 da 5.8.
3. Alternativas e soluções para o Henrique (CLAUDE.md 5.8 item 6 e 5.9):
   - APROVADA: alerta AGUARDANDO OK DO HENRIQUE em ALERTAS.md com o que muda, os números (delta anual e IC 90%, resultado fora da amostra, DD, Monte Carlo), o comando de conferência `ops\lab.ps1 -Acao conferir -Proposta campanha\lab\lotes\<id>\propostas\<variante>.set` e a linha exata "AAAA-MM-DD OK ALTERNATIVA <id>/<variante>"; `ops\notify.ps1 -Nivel AGUARDANDO_OK`.
   - CANDIDATA ou EM_QUARENTENA: registre na seção "Laboratório" do STATE.md, com a data de congelamento. Nenhuma ação.
   - Nenhuma aprovada: a solução é "manter a configuração atual", com o motivo em uma linha (o MDE do relatório diz o tamanho de efeito que o teste consegue ver).
   - Para cada divergência da revalidação (5.8, itens 4 e 5), diga qual alternativa ou solução a endereça e com que evidência. Redução de risco sai da tabela de Monte Carlo do relatório: recomende com a linha RISK_SCALE para o INBOX; só aplique se uma regra objetiva de 5.2, 5.6 ou 5.7 já pedir.
4. Testes extras (opcional): se uma divergência pede um teste que a família padrão não cobre, escreva um pedido em C:\Sobrevivencia\campanha\lab\fila\<AAAAMMDD>_<nome>.json no formato de 5.9 (só inputs da lista branca, risco só para baixo, no máximo 4 variantes em teste ao mesmo tempo). O lab valida e roda neste fim de semana, se houver tempo, ou no próximo; o resultado dentro da amostra é só informativo e a variante entra em teste fora da amostra. Não rode o lab.ps1 além de -Acao status (e de -Acao parar, se houver problema, 5.9), não edite ops\, mql5\ nem os lotes.
5. Atualize a seção "Laboratório" do STATE.md: último lote lido (id e data), candidatas e extras em quarentena, alternativas aguardando OK, pendências (por exemplo, notícias sem cobertura para a próxima revalidação).

Nunca envie ordem por nenhum caminho, nunca aplique preset, nunca aumente risco. Termine com uma linha em ops\logs\heartbeat.log no formato "lab | <id> | <resumo>".

Resposta final, uma linha só: "LAB OK <id> <n aprovadas> <n candidatas> <decisão: manter | alternativa aguardando OK | redução recomendada | lote inválido>" ou "LAB ERRO <motivo>".
