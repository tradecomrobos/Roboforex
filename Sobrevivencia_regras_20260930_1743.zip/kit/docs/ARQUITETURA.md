# Arquitetura do Desafio Sobrevivência

Conta RoboForex ProCent com depósito de 9.850 USC (98,50 USD), um VPS Windows (Hyonix HS-3), um terminal MT5, EAs que operam, um EA guardião que freia, um EA registrador do regime do ouro que não opera (RegimeLogger), um laboratório de backtests numa cópia separada do terminal, logada numa conta demo (`ops\lab.ps1`, só com o ouro fechado), um agente Claude Code que observa e decide devagar, e o Henrique no topo. Se a conta zerar, o agente morre. Este documento descreve as camadas, o fluxo de dados e o que acontece em cada falha. As regras de conduta do agente estão em `CLAUDE.md`; aqui está o porquê e o como. Portfólio e degrau em vigor: `CLAUDE.md` 3 e 5.6 e `campanha\RESULTADOS.md` 5 (Concorde só E1+E3, E2 e E4 desligadas; degrau A = preset `Concorde_E13_A.set`, E1 0,4% / E3 1,2% por perna, com o guardião G35; degrau B = `Concorde_E13_B.set`, E1 0,4% / E3 1,8%, com o G45, planejado, só por critério e com OK do Henrique).

## 1. Diagrama

```
                        +-----------------------------------+
                        |             HENRIQUE              |  RDP no VPS, dinheiro, OKs
                        |  escreve INBOX.md                 |
                        |  lê ALERTAS.md / DIARIO.md /      |
                        |  STATE.md, recebe notify.ps1      |
                        +----------------+------------------+
                     INBOX.md |                   ^ ALERTAS.md + notify.ps1
                              v                   |
                        +-----------------------------------+
   Task Scheduler ----> |   CLAUDE CODE  (claude -p)        |  acordadas: diária, semanal,
   (diária/semanal/     |   lê: CLAUDE.md, STATE.md, INBOX, |  pré-abertura, incidente
    pré-abertura/       |       status.json, guardian.log,  |
    incidente)          |       regime.csv, diários e       |
                        |       histórico via MCP           |
                        |   escreve: DIARIO.md, STATE.md,   |
                        |       ALERTAS.md, heartbeat.log,  |
                        |       control.txt (só isso)       |
                        +-------+-----------------+---------+
                MCP 127.0.0.1:22346 |             | ops\cmd.ps1  (append "SEQ|CMD|ARG")
                somente leitura     v             v
   +---------------------------------------------------------------------------+
   |   TERMINAL MT5 RoboForex   C:\MT5_RoboForex   (/portable, AutoTrading on)  |
   |                                                                           |
   |   +----------------------------+   GVs SURV_HALT / SURV_DAILY_LOCK /       |
   |   |  SurvivalGuardian (EA)     |   SURV_RISK_SCALE                         |
   |   |  gráfico próprio           | ----------------------------------+       |
   |   |  lê   control.txt          |                                   v       |
   |   |  grava status.json (5 s)   |                       +--------------------+
   |   |  grava guardian.log        |                       | Concorde_RF v3.04  |
   |   |  fecha posições (CTrade)   |                       | XAUUSD M15         |
   |   |  em LOCK / HALT / CLOSE_ALL|                       | E1 + E3 (E2/E4 OFF)|
   |   +-------------+--------------+                       | lê as GVs antes de |
   |                 |                                      | abrir e ao dimen-  |
   |   MQL5\Files\survival\                                 | sionar o lote      |
   |     control.txt  status.json  guardian.log             +---------+----------+
   |     regime.csv (grava o RegimeLogger)                            |
   |                                                                  |
   |   +----------------------------+                                 |
   |   |  RegimeLogger (EA)         |  não opera, sem magic           |
   |   |  XAUUSD D1, gráfico próprio|  1 linha por dia do             |
   |   |  grava regime.csv          |  servidor: amplitude,           |
   |   |  (sem spread, sem ticks)   |  ATR14, vol20 (%)               |
   |   +----------------------------+                                 |
   |                                                                  | ordens
   +------------------------------------------------------------------+---------+
                                                                       v
                                                        servidor RoboForex (ProCent)
                                                                       v
                                                                   MERCADO

   WATCHDOG (ops\heartbeat.ps1, PowerShell, Task Scheduler a cada 10 min, sem IA):
     terminal64.exe vivo?  status.json com menos de 3 min?  desconectado > 10 min?  HALT novo?
     equity < 50%?  conta certa?  magic fora do portfólio?  Windows reiniciou?
     -> ops\start_terminal.ps1   -> claude -p prompts\incidente.md ({MOTIVO})   -> ops\notify.ps1
     (falha de login do Claude: o proprio ops\run_claude.ps1 grava "ERRO auth" e notifica)
```

## 2. Camadas, de baixo para cima

| Camada | Componente | Função | Funciona sem a camada de cima? |
|---|---|---|---|
| 0 | EAs de trading (Concorde_RF v3.04 = v3.03 + patch do guardião) | Geram e gerenciam as ordens. Risco por perna nos inputs, multiplicado por `SURV_RISK_SCALE`. Stop diário próprio de 8% do equity (12% no degrau B; camada 1 do CLAUDE.md). Antes de abrir uma perna consultam `Surv_CanTrade()`; no sizing consultam `Surv_RiskScale()`. Sem as GVs (tester, guardião ausente), comportam-se exatamente como o original. | Sim. Sem guardião o EA opera como o original, com o seu próprio stop diário. |
| 1 | SurvivalGuardian (EA de proteção, agnóstico ao EA de trading) | Lê `control.txt`, publica `status.json` a cada 5 s e `guardian.log`. Limites duros por equity, G35 em vigor: lock diário 10%, DD 20% vs HWM -> escala 0,5 (volta a 1,0 abaixo de 10%), DD 35% -> HALT (grava a trava primeiro, depois fecha tudo, opcionalmente fecha os outros gráficos). No degrau B, G45: 15% / 25% (volta abaixo de 12%) / 45%. Fecha posições por CTrade herdando o magic. HALT só sai com `RESUME` (que não mexe na escala de risco). | Sim. É o freio que funciona com o Claude offline. Sobrevive a restart, kill forçado e queda do VPS porque cada escrita de GV é forçada a disco (`GlobalVariablesFlush`) e o estado é espelhado em `survival\state.txt`, restaurado no OnInit (HALT e `last_seq` nunca regridem). Só avalia limites depois de 3 ciclos com a conta carregada (estado `SYNC`), e zera o estado se o login mudar. |
| 2 | Heartbeat + watchdog (PowerShell, sem IA) | `status.json` é o heartbeat do guardião; `ops\logs\heartbeat.log` recebe uma linha do vigia a cada 10 min e uma por acordada do Claude. O watchdog checa processo, idade do status.json, desconexão, HALT novo, equity crítica, login esperado (se `$EXPECTED_LOGIN` estiver definido), posição com magic fora do portfólio (`by_magic` do status.json) e reinício do Windows; reinicia o terminal (`start_terminal.ps1`, nunca um terminal com menos de 10 min de vida), dispara a acordada de incidente (fora do seu job, com cooldown de 60 min) e avisa o Henrique. Erros de login do Claude são detectados e notificados pelo próprio `run_claude.ps1`. | Sim. Não depende do Claude nem do MCP. |
| 3 | Claude Code (acordadas headless) | Lê tudo, calcula P&L por magic, aplica regras objetivas (pausa/troca por evidência), escreve control.txt (só reduções em dia útil), registra DIARIO/STATE/ALERTAS, avisa o Henrique. Nunca envia ordens. | Não precisa: a conta sobrevive sem ele por dias. Ele existe para ver a deterioração antes do guardião. |
| 4 | Henrique | INBOX.md (OK RESUME, OK LIMITES, OK TROCA, OK DEGRAU B para a subida (preset B + G45), OK DEGRAU A para a descida (preset A + G35), ordens diretas), RDP para o que o Claude não pode (inputs do guardião, login, Windows). | — |

Fora das camadas: o **RegimeLogger** (EA no gráfico XAUUSD D1, sem magic, não envia ordens nem mexe em GV) só grava `survival\regime.csv`, uma linha por dia do servidor com a amplitude diária, o ATR14 e a mediana de 20 dias da amplitude (`vol20_pct`), para o Claude acompanhar o regime de volatilidade do ouro. O regime gera alerta e, no máximo, uma recomendação de redução ao Henrique (abaixo de 1,40% e de 1,20%, `CLAUDE.md` 5.7); nunca aumento de risco nem troca de parâmetro, porque a regra de volatilidade para ligar/desligar estratégias foi reprovada na pesquisa do seletor adaptativo (White p 0,93). Se ele parar, nada na conta muda: é ATENCAO, nunca HALT.

Princípio de desenho ("assimetria do freio"): cada camada só pode reduzir o risco da camada de baixo, nunca aumentar. O guardião pode parar o EA; o Claude pode parar o guardião (HALT) ou reduzir a escala; só o Henrique pode soltar (RESUME, UNLOCK fora de fim de semana, limites). Um erro em qualquer camada superior, incluindo um Claude confuso ou um prompt injetado por log, no pior caso para a conta; nunca a alavanca.

## 3. Fluxo de dados

### 3.1 control.txt (Claude -> guardião)
- Caminho: `C:\MT5_RoboForex\MQL5\Files\survival\control.txt`. Texto, uma linha por comando, sempre acrescentada: `SEQ|CMD|ARG`.
- Escrita: `ops\cmd.ps1 -Cmd <CMD> [-Arg <ARG>]` lê `last_seq` do status.json (ou o maior SEQ do arquivo), acrescenta a linha com SEQ+1 (ASCII sem BOM, CRLF, sob mutex) e espera até 20 s pela confirmação. Fallback sem cmd.ps1: **só append** ASCII (`Add-Content -LiteralPath control.txt -Value 'SEQ|CMD|ARG' -Encoding Ascii`); nunca reescrever o arquivo inteiro (o guardião lê a cada 5 s) nem usar `>>` (UTF-16, o guardião descarta).
- Leitura: o guardião, no OnTimer (5 s), lê o arquivo, ignora linhas com SEQ <= `last_seq` e a última linha sem terminador, executa as linhas novas em ordem (uma vez por SEQ) e publica `last_seq`, `last_cmd` (`SEQ|CMD|ARG`) e `last_cmd_result` (`OK ...`, `ERRO ...`, `PONG ...`) no status.json.
- Comandos: `HALT`, `RESUME`, `RISK_SCALE <0.25|0.5|0.67|1.0|AUTO>` (o `cmd.ps1` recusa aumento de segunda a sexta sem `-Force`), `CLOSE_ALL`, `LOCK_TODAY`, `UNLOCK_TODAY`, `SET_HWM <USC>`, `PING`. Quem pode mandar o quê está no CLAUDE.md, seção 10.
- Idempotência: SEQ crescente impede execução dupla depois de um restart; o guardião guarda `last_seq` em GV persistente (forçada a disco) e em `state.txt` (o maior dos dois vale no OnInit). SEQ repetido dentro da mesma leitura é ignorado com log; `cmd.ps1` usa um mutex para nunca gerar SEQ duplicado e só dá ACK se `last_cmd` começa por `SEQ|CMD|`. Se o guardião não está rodando quando a linha é gravada, ela **não** será executada quando ele subir do zero (o OnInit marca como processado tudo que já está no arquivo): `cmd.ps1` avisa; resolver o incidente e reenviar.
- Rotação: acima de 10.000 linhas o guardião não lê o resto do arquivo (e avisa no log/status `control_overflow`); `cmd.ps1` rotaciona sozinho acima de 5.000 linhas quando o status está fresco, guardando o último SEQ no cabeçalho do arquivo novo.

### 3.2 status.json (guardião -> Claude, watchdog, Henrique)
- Caminho: `C:\MT5_RoboForex\MQL5\Files\survival\status.json`, reescrito a cada 5 s (`poll_s`; arquivo temporário + rename, para nunca ser lido pela metade). Não há campo de heartbeat: o heartbeat é a idade do arquivo (stale acima de 180 s).
- Campos (v1.10, `BuildStatusJson`): `guardian_version`, `ts_server`, `ts_local`, `login`, `server`, `currency`, `connected`, `syncing`, `trade_allowed_*`, `balance`, `credit`, `equity`, `margin_level`, `hwm`, `dd_pct`, `day_start`, `day_pnl_pct`, `positions`, `orders`, `by_magic`, `halt`, `daily_lock`, `day_override`, `risk_scale`, `risk_scale_manual`, `last_seq`, `last_cmd`, `last_cmd_result`, `state` (OK | RISCO_REDUZIDO | LOCK_DIARIO | HALT | SYNC | DISCONNECTED), `control_overflow`, `state_file_ok`, `retry_pending`, `uptime_s`, `poll_s`, `managed_magics`, `limit_*`. Exemplo completo em `SETUP_VPS.md`, Anexo A; a fonte da verdade é o `SurvivalGuardian.mq5`.
- Uso: o Claude confere idade e estado antes de qualquer decisão (`halt` diz se há HALT mesmo com `state=DISCONNECTED`); o watchdog olha idade, `connected`, `halt`, `equity` e `login`.

### 3.3 Variáveis globais do terminal (guardião -> EAs)
- `SURV_HALT` (0/1, persistente), `SURV_DAILY_LOCK` (0/1), `SURV_RISK_SCALE` (0,05 a 1,0), `SURV_HEARTBEAT` (`TimeLocal` do último ciclo). Gravadas com `GlobalVariableSet` + `GlobalVariablesFlush` (o terminal sozinho só grava as GVs na saída graciosa) e espelhadas em `survival\state.txt`.
- O Concorde patched lê com `GlobalVariableCheck` antes de `GlobalVariableGet`: GV ausente = neutro (pode operar, `SURV_RISK_SCALE` 1,0). No tester ninguém cria as GVs, logo o backtest do patched é idêntico ao original. Fail-closed: se as GVs existem mas o heartbeat parou há mais de 15 min (guardião removido/gráfico fechado), `Surv_CanTrade()` devolve false até ele voltar; a gestão das posições abertas não passa por aí.
- Autocura do gráfico do guardião: `ops\start_terminal.ps1` restaura a cópia do perfil `sobrevivencia` guardada em `ops\profile\` antes de cada arranque (atualizada por `ops\save_profile.ps1`); sem essa cópia o MT5 recarregaria o último perfil salvo, possivelmente sem o guardião.
- Pontos de leitura no Concorde: E1_ProcessSession (antes de colocar pendentes; cancela pendentes se bloqueado), E2_CanOpenNewSetup, E3_ExecuteBreakout, E4_ProcessSymbol (bloqueio) e Concorde_LotsByRisk + E4_CalcLots (escala).

### 3.4 Registros do agente (Claude -> Henrique)
- `DIARIO.md`: uma entrada por acordada. `STATE.md`: estado atual, portfólio, referências, pendências, última leitura do INBOX. `ALERTAS.md`: alertas com nível e estado. `ops\logs\heartbeat.log`: uma linha por acordada (`data | tipo | OK/ERRO motivo`).
- `ops\notify.ps1`: push para o canal do Henrique; credencial no Credential Manager ou variável de ambiente, nunca no workspace.

### 3.5 INBOX.md (Henrique -> Claude)
- Linhas datadas, só acrescentadas pelo Henrique. O Claude lê as linhas depois da última marcada em STATE.md, executa o que as regras permitem, registra e marca a leitura. Nunca edita o arquivo.

### 3.6 regime.csv (RegimeLogger -> Claude)
- Caminho: `C:\MT5_RoboForex\MQL5\Files\survival\regime.csv` (dentro das pastas que o `run_claude.ps1` passa por `--add-dir`). Uma linha por dia de negociação do servidor, gravada ~2 min depois da meia-noite do servidor que fecha o dia (separador `;`, cabeçalho fixo): `data_servidor`, OHLC D1, `amplitude_usd`, `amplitude_pct` ((máxima - mínima) / fechamento da barra D1, em %), `atr14_pct`, `vol20_pct` (mediana de 20 dias da amplitude), as janelas da E1 (`e1_range_usd`, `e1_rompeu`, `e1_ext_usd`) e da E3 (`e3_caixa_usd`, `e3_rompeu`, `e3_ext_usd`, `e3_falso`), `tendencia` e `gerado_em`. No primeiro init o EA grava os últimos 180 dias de negociação (backfill); depois de uma parada, completa os dias que faltaram, sem duplicar (nem com dois gráficos dele: relê o fim do arquivo antes de gravar). Barra D1 residual de feriado é pulada e fica fora das médias; dia cujo M1 não bate com a D1 sai só com as colunas de amplitude (as das janelas vazias). Sem spread e sem ticks (decisão do Henrique: pesado demais).
- Uso: a diária só registra o `vol20_pct` da última linha em DIARIO.md; a semanal aplica os limiares (1,40%: ATENCAO; 1,20%: AGUARDANDO OK com recomendação de `RISK_SCALE 0.5`, aplicada só por linha do Henrique); a primeira semanal de cada trimestre compara PF e retorno ao vivo por estratégia com o esperado para a faixa de volatilidade vivida (`CLAUDE.md` 5.7 e 5.8). Somente leitura para o Claude.

### 3.7 alcance.csv e trades_mfe.csv (RegimeLogger v1.20 -> revalidação trimestral)
- **`alcance.csv`:** duas linhas por dia do servidor (E1 e E3). Simula no M1 a entrada que o Concorde faria no dia, com o preset A e o filtro de notícias:
  - notícias pelo calendário nativo ao vivo e pelo `news.csv` no tester;
  - bloqueio de entrada e fechamento 10 min antes da notícia.
  
  Mede em R quanto o preço andou a favor e contra antes do stop, com stops de 0,5x a 2,0x (`mfe_XXX` e `res_XXX`), mais `corte_noticia` e `fonte_noticias` (`cal`, `csv`, `sem`, `off`). Backfill de 180 dias na instalação.
- **`trades_mfe.csv`:** uma linha por posição real fechada da E1 ou da E3 desde 2026-09-22, com resultado, MFE e MAE em R. Atualizado a cada 10 min, só ao vivo.
- **Uso:** `ops\analisar_alcance.ps1` monta as tabelas VIVO x HIST (T1 a T7). O HIST vem de `campanha\regime\alcance_hist.csv` (RegimeLogger v1.20 no tester, jun/2024 a jun/2026). É lido só na revalidação trimestral (`CLAUDE.md` 5.8, item 5). O E[R] das tabelas é da entrada simulada sem breakeven, trailing nem TP dinâmico, portanto não é o resultado do EA. A grade SL x TP é informação para o Henrique; troca de parâmetro, só por alternativa APROVADA no laboratório (3.8) e OK dele.

### 3.8 Laboratório de testes (`ops\lab.ps1` -> `campanha\lab\lotes\` -> Claude)
- **O quê:** backtests do Concorde_RF numa cópia portátil separada (`C:\MT5_RF_Lab`, criada por `ops\lab_instalar.ps1`), logada numa conta DEMO RoboForex-Pro (`$LAB_LOGIN`), com o mesmo `.ex5` e os mesmos inputs do gráfico ao vivo (snapshot do perfil). Regras em `CLAUDE.md` 5.9.
- **Quando:** tarefa `Sobrevivencia-Lab` a cada 30 min; o executor só roda de sábado 04:30 a domingo 17:30 UTC. Todo sábado há uma sonda de 1 semana. No 1º fim de semana de cada trimestre roda o lote trimestral: controle, 8 variantes da família padrão e as variantes em quarentena, numa janela de 24 meses em segmentos de 6 meses, com o controle de novo no fim ("sanduíche"). Pedidos do agente pela fila (`campanha\lab\fila\*.json`).
- **Segurança:**
  - Job Object com limite de memória (2,5 GB), 2 núcleos, prioridade baixa e KILL_ON_JOB_CLOSE.
  - Checagens antes e durante cada run (status.json, terminal ao vivo, porta 22346, RAM, disco, reinício pendente, conta autorizada, MCP da cópia).
  - O heartbeat encerra a cópia fora da janela ou sem o executor vivo; o `start_terminal.ps1` a encerra antes de subir o terminal ao vivo.
  - O agente só pode `-Acao status` e `-Acao parar`.
- **Notícias:** `news_lab_srv.csv` (Common\Files) em hora do servidor por evento, com `News_SourceGMTOffset` do início de cada segmento. Isso corrige a defasagem de 1 h no inverno dos backtests da campanha. Cada run confere no log o fuso e o número de eventos.
- **Estatística:**
  - Séries diárias por dia do sinal e diferença variante - controle (mesma exposição).
  - StepM de Romano-Wolf com bootstrap estacionário (blocos 10/20/40), consistência nas duas metades, concentração mensal, relevância, gate de 5.2 e Monte Carlo pareado com o guardião do degrau.
  - CANDIDATA fica congelada e só vira APROVADA depois de 2 trimestres fora da amostra.
  - Validação na estação (29/09/2026):
    - parser idêntico ao `parse_reports.py` nos 21 relatórios da campanha, com casamento de saídas pelo nível de SL/TP (a atribuição E1/E3 do C22 passou a bater 100% com os runs isolados C15/C16);
    - Monte Carlo idêntico ao `montecarlo.py` dentro do erro de simulação;
    - tamanho do teste 5,2% a 7,1% sob o nulo com a correção de amostra finita.
- **Saída:** `relatorio.md` (tabela de alternativas e soluções de risco), `analise.json`, e `propostas\<variante>.set` só para APROVADA. O Henrique confere com `lab.ps1 -Acao conferir` antes de aplicar (`OK ALTERNATIVA`).

## 4. Acordadas (Task Scheduler)

| Tarefa | Quando | Comando | Prompt |
|---|---|---|---|
| Diária | seg-sex 22:30 UTC | `claude -p` com o conteúdo de `prompts\diario.md`, cwd `C:\Sobrevivencia` | seção 4 (`regras\saude.md`, `regras\inbox.md`) |
| Semanal | sábado 12:00 UTC | idem com `prompts\semanal.md` | seção 5 (`regras\desempenho.md`, `degrau.md`, `regime.md`, `revalidacao.md`, `laboratorio.md`) |
| Pré-abertura | domingo 18:00 UTC | idem com `prompts\preabertura.md` | seção 7 (no próprio prompt) |
| Incidente | disparada pelo watchdog | idem com `prompts\incidente.md`, `{MOTIVO}` substituído pelo watchdog | seção 6 (`regras\incidente.md`) |
| Laboratório (lab.ps1) | a cada 30 min; executor só sáb 04:30 a dom 17:30 UTC | PowerShell puro, executor destacado (`Start-Detached`) | — |
| Lab (agente) | chamada pelo `lab.ps1` ao fim de um lote (20 min) | `claude -p` com `prompts\lab.md` | 5.8 item 6 e 5.9 |
| Watchdog (heartbeat.ps1) | a cada 10 min | PowerShell puro (sem IA) | — |

**Organização das regras (desde 2026-10, item B5 da revisão de 2026-09-30).** O `CLAUDE.md`, carregado em toda acordada, ficou só com os princípios (missão, regras invioláveis, camadas de risco e definições, comunicação, control.txt): 23 KB contra os 91 KB de antes. O protocolo de cada acordada é o próprio prompt dela (`prompts\<modo>.md`), que diz os passos, os módulos a ler e o que escrever no fim, sem repetir regra. As regras de cada assunto estão em `regras\` (saude, inbox, incidente, desempenho, degrau, regime, revalidacao, laboratorio, referencia), cada uma num lugar só, com os números de seção antigos mantidos como nomes (o mapa está na seção 0 do `CLAUDE.md`). As contas das regras (checagem de saúde, números do dia, revisão por magic, critérios de degrau, regime, pré-abertura) são feitas pelo `ops\checar.ps1`, somente leitura, que imprime uma linha por checagem com PASSA, FALHA, ATENCAO, INFO, SEM_DADO ou AGENTE (o que o agente ainda faz pelo MCP). O script lê `status.json`, STATE.md, ALERTAS.md, o snapshot do perfil, o heartbeat.log, o guardian.log, o regime.csv e o `trades_mfe.csv`; é calculadora, não autoridade: vale a regra do módulo.

Cada acordada roda em processo próprio, sem estado entre elas: o estado vive em STATE.md, status.json e nas GVs. Acordadas nunca rodam em paralelo: cada tarefa tem "não iniciar nova instância" e `run_claude.ps1` usa um lock (`ops\logs\claude.lock`); a de incidente espera a anterior terminar (até 50 min), as agendadas saem com código 3 e o Task Scheduler tenta de novo em 15 min. Timeout de 45 min por acordada (`run_claude.ps1` mata o processo; a tarefa tem limite de 60 min). Processos longos iniciados por uma tarefa (terminal64, run_claude de incidente) são criados fora do job object da tarefa (WMI, `Start-Detached` em `ops\common.ps1`): senão o Task Scheduler os encerraria ao estourar o limite de tempo da tarefa.

## 5. O que acontece em cada falha

| Falha | Quem percebe | O que acontece automaticamente | O que o Claude faz | O que sobra para o Henrique |
|---|---|---|---|---|
| Terminal cai ou perde conexão | watchdog (processo/idade do status.json); Claude na acordada | watchdog reinicia via `start_terminal.ps1` (perfil de arranque com os gráficos, AutoTrading ligado); as GVs persistem, o guardião volta com o mesmo HWM, lock e HALT | acordada de incidente: confere saúde, registra; até 2 reinícios por hora, depois escala | se não voltou: RDP; conferir login, senha salva, rede |
| Guardião ausente (gráfico fechado, EA removido, terminal travado) | watchdog (status.json parado) | reinício do terminal; se o perfil de arranque estiver certo, o guardião volta | incidente CRITICO; se houver posições e o guardião não volta, o Claude não tem freio (não pode mandar ordens): notifica e espera; assim que o guardião voltar, HALT se o Henrique não respondeu | conferir o perfil de arranque; decidir HALT |
| EA de trading trava ou some | Claude (list_open_charts) | nada; as posições abertas ficam com SL do EA e sob os limites do guardião (que fecha tudo em lock/HALT) | não recria em dia útil; registra; se for EA desconhecido, HALT | recolocar o EA no fim de semana (ou o Claude, via template, 5.4) |
| Perda do dia >= 10% (15% no G45) | guardião | lock diário: fecha tudo, EAs não abrem até o próximo dia do servidor | registra (INFO); 3x na semana vira ATENCAO | nada |
| DD >= 20% vs HWM (25% no G45) | guardião | escala 0,5 até DD < 10% (12% no G45) | registra; se durar > 4 semanas, ATENCAO de portfólio | nada |
| DD >= 35% vs HWM (45% no G45) | guardião (grava a trava, fecha tudo, fecha os gráficos do Concorde e do RegimeLogger); heartbeat vê o HALT novo e dispara o incidente + notify | HALT: fecha tudo, trava persistente, fecha os outros gráficos; posições que a corretora recusa fechar (mercado fechado, gap de fim de semana) são tentadas de novo a cada ciclo | relatório em ALERTAS.md, AGUARDANDO OK DO HENRIQUE, nunca RESUME; na acordada de fim de semana em que lê o OK: `cmd.ps1 -Cmd RESUME` e, como o gráfico do Concorde foi fechado pelo HALT, `start_terminal.ps1 -Restart` para o perfil do kit recolocá-lo (confirma com `list_open_charts`) | decidir: `AAAA-MM-DD OK RESUME` em INBOX.md (data >= a do HALT; vale para um único RESUME; o Claude executa na semanal/pré-abertura; para RESUME imediato, rodar ele mesmo `ops\cmd.ps1 -Cmd RESUME` por RDP) ou encerrar. Antes do RESUME o fluxo é `OK SET_HWM` + `RISK_SCALE` menor se quiser: o RESUME mantém a escala que estiver em vigor |
| Equity < 50% do inicial | Claude | (o guardião já está em 0,5 desde 20% e em HALT em 35%; no G45, 0,5 desde 25% e HALT em 45%) | RISK_SCALE 0.25 se ainda maior; CRITICO; recomenda pausa | decidir |
| EA com desempenho ruim (DD acima do limite de pausa do degrau, 30,8% no A e 41,5% no B, ou 40+ trades PF < 0,8 em 60 d) | Claude (semanal) | nada | registra a evidência e AGUARDANDO OK; a troca física exige `chart_close`/`chart_open`/`chart_apply_template`, que `.claude\settings.json` nega (CLAUDE.md 5.4): enquanto o Henrique não liberar, ele faz a troca por RDP; em emergência o Claude reduz (`RISK_SCALE 0.25`, `HALT`) | validar e fazer a troca por RDP (ou liberar as três ferramentas no settings.json) |
| Claude sem autenticação | `run_claude.ps1` (mensagem de login no log da acordada) | linha `ERRO auth` em heartbeat.log + notify CRITICO na hora; o Task Scheduler ainda tenta 2 vezes (15 min) | nada: nem chega a rodar | `claude auth login` por RDP (ou `claude setup-token` + variável `CLAUDE_CODE_OAUTH_TOKEN` do usuário, para o token não expirar) |
| Claude confuso, prompt injetado por log, alucinação | regras do CLAUDE.md + o desenho | o pior caso é um HALT indevido: a conta para, não alavanca; ordens diretas são impossíveis por regra e o guardião ignora comandos fora do formato | — | ler ALERTAS.md e dar RESUME se foi indevido |
| RegimeLogger parado (regime.csv sem linha nova há mais de 2 dias úteis, gráfico ausente fora de HALT) | Claude (diária, semanal, pré-abertura) | nada: ele não opera nem protege; a conta segue igual | ATENCAO + notify, nunca HALT nem reinício do terminal por isso; a regra de regime fica "sem dado" | reanexar no gráfico XAUUSD D1 e salvar o perfil (SETUP_VPS 6.6) |
| MCP fora do ar | Claude | nada | usa os arquivos por caminho (status.json, guardian.log, MQL5\Logs); escreve control.txt por cmd.ps1 | conferir a chave do MCP e a porta |
| Disco cheio / Windows Update / reinício pendente | Claude (semanal, pré-abertura) | nada | registra e escala; não apaga nem reinicia o Windows | limpar logs, agendar reinício no fim de semana |
| Laboratório fora da janela, órfão, RAM ou status.json velho durante um run | lab.ps1 (a cada 15 s), heartbeat, start_terminal | o lab aborta o run; o heartbeat encerra a cópia (CRITICO); o Job Object mata a cópia se o lab.ps1 morrer | `ops\lab.ps1 -Acao parar` se ainda houver; registra | nada; se a sonda falhar por autorização, logar uma demo nova na cópia e atualizar `$LAB_LOGIN` |
| Servidor da corretora fora / feriado | heartbeat (`connected=false` > 10 min) e Claude | conexão cai e volta sozinha; o guardião continua vivo (`state=DISCONNECTED`, status fresco) e não pode fechar nada enquanto durar | incidente: `start_terminal.ps1` (que reinicia por `connected=false`); não mais de 2x/hora contando o `ops.log`; registra | nada |
| VPS reinicia (Windows Update de sábado 03:00, queda) | heartbeat (boot novo -> `POS_REBOOT` no heartbeat.log) | auto-logon -> tarefa `Sobrevivencia-Terminal` (+1 min) sobe o terminal com o perfil do kit e AutoTrading ligado; o guardião restaura HALT/lock/HWM/last_seq das GVs e do `state.txt`; o heartbeat zera os carimbos antigos e não reinicia um terminal com menos de 10 min de vida | registra na próxima acordada (diário do terminal, `ops.log`) | se o auto-logon falhou (senha trocada), RDP |
| Conta zera | guardião (HALT já aconteceu antes, aos 35%; 45% no G45) | — | escreve a última entrada do diário | fim do desafio |

## 6. Inventário do kit (o que vai para o VPS)

```
C:\Sobrevivencia\
  CLAUDE.md            princípios do agente e mapa das regras (só o Henrique edita)
  regras\              módulos de regras por assunto: saude, inbox, incidente, desempenho, degrau, regime, revalidacao, laboratorio, referencia
  STATE.md             estado atual, portfólio, referências, pendências
  DIARIO.md            uma entrada por acordada
  ALERTAS.md           alertas com nível e estado
  INBOX.md             instruções do Henrique (só ele escreve)
  prompts\             protocolo de cada acordada: diario.md, semanal.md, incidente.md, preabertura.md, lab.md
  ops\                 cmd.ps1, notify.ps1, start_terminal.ps1, checar.ps1 (contas das regras), watchdog e instalador das tarefas, logs\
  ops\profile\         snapshot do perfil "sobrevivencia" (restaurado em todo arranque)
  mql5\Experts\        Concorde_RF (original e patched v3.04), SurvivalGuardian, RegimeLogger (registrador, não opera)
  mql5\Include\        SurvivalGuard.mqh
  mql5\Presets\        4 .set: Concorde_E13_A (degrau A, em vigor), Concorde_E13_B (degrau B), SurvivalGuardian_G35 (em vigor), SurvivalGuardian_G45
  mql5\templates\      templates aprovados (EA + inputs) para a troca controlada
  campanha\            inis, relatórios e RESULTADOS.md (EAs aprovados no gate e a escada de degraus)
  campanha\lab\       laboratório: fila\ (pedidos do agente), news\ (eventos extras), lotes\ (relatórios, análise, propostas, registro)
  docs\                ARQUITETURA.md (este arquivo)

C:\MT5_RF_Lab\                        cópia só de tester do laboratório (conta demo; lab_instalar.ps1)
C:\MT5_RoboForex\                     terminal /portable (instalado pelo Henrique)
  MQL5\Experts\Sobrevivencia\*.ex5    EAs compilados
  MQL5\Files\survival\                control.txt, status.json, guardian.log, regime.csv
  MQL5\Logs\, Logs\                   diários (UTF-16)
```

## 7. Limites conhecidos e decisões de projeto

- O tester headless com `ShutdownTerminal=1` fecha o terminal ao terminar: no VPS nunca rodar backtest no terminal que opera. Backtests no VPS só pelo laboratório (3.8), na cópia `C:\MT5_RF_Lab`. Memória: um teste de 2 anos usa mais de 4 GB mesmo só com o ouro; por isso o laboratório roda segmentos de 6 meses dentro de um job de 2,5 GB, com o HS-3 de 8 GB.
- O guardião mede DD por equity contra um HWM que ele mesmo guarda em GV; depósitos e saques mudam o HWM só por `SET_HWM` (OK do Henrique).
- Na ProCent o lote mínimo 0,01 lote-cent (10 unidades) elimina o problema de piso de lote que existia com 100 USD numa conta padrão; ainda assim a campanha confere o lote médio real por escala.
- O Concorde ao vivo usa só o calendário nativo do MT5 para notícias (o código não cai para o CSV); `news.csv` serve ao tester. O terminal do VPS precisa do calendário habilitado.
- O MCP nativo do terminal é somente 127.0.0.1 e só uma instância por porta. A porta 22346 é do terminal ao vivo; a cópia do laboratório tem o MCP interno desligado, e o `lab.ps1` aborta se ela abrir o MCP, escutar 22345/22346 ou se a porta não estiver com o terminal ao vivo.
- O Claude não tem, por desenho, nenhuma ferramenta capaz de aumentar risco em dia útil. Se um dia parecer necessário, a resposta certa é uma linha no INBOX pelo Henrique, não uma exceção nas regras.
- Task Scheduler e processos longos: os filhos de uma tarefa ficam no job object dela; a tarefa continua "Running" enquanto eles vivem e, ao estourar o limite de tempo, a árvore inteira é encerrada. Por isso `start_terminal.ps1` (terminal64) e `heartbeat.ps1` (run_claude de incidente) criam esses processos via WMI (`Start-Detached`), fora do job. O checklist do SETUP confere que o terminal continua vivo mais de 10 min depois de subir por tarefa.
- `control.txt` cresce só por append; `cmd.ps1` rotaciona acima de 5.000 linhas (o guardião ignora comandos acima de 10.000). `guardian.log`, `ops.log` e `heartbeat.log` não rotacionam: limpeza mensal manual (SETUP, seção 11).
