# RESULTADOS da campanha Sobrevivência — Concorde_RF (RoboForex, depósito 10.000 = 10.000 USC)

> Campanha de 2026-09-22, concluída no mesmo dia (últimos relatórios: C22 e C23, o estudo de peso E1/E3 em `_peso\`; C14, C18 e V2 também rodaram). Build: **Concorde_RF v3.04** (v3.03 + SurvivalGuard; backtest idêntico ao original, ver `reports_sanidade`).
> Terminais: cópias portáteis `C:\RF_bt`, `C:\RF_bt2`, `C:\RF_bt3` da instalação RoboForex (build 6204), conta demo 52010215 em RoboForex-Pro, depósito 10.000 USD, `Leverage=1:1000` confirmado em todos os relatórios válidos. A validação fora da amostra (V1) rodou na cópia de backtest do terminal 4XC, com o ouro da Dukascopy (QDM).
> Ticks reais locais da RoboForex: 2025-09-22 a 2026-09-18. Nas rodadas de 2 anos o trecho anterior a 2025-09 usa **ticks gerados de M1** (inis `*_m1gen`). O campo "Qualidade do histórico" do .htm marca 100% nessas rodadas e não deve ser lido como "100% ticks reais".
>
> **Critério de escolha (mudou em 2026-09-22):** o objetivo do desafio passou a ser crescimento máximo sem morrer. O risco-alvo é o que maximiza o crescimento composto mediano em 12 meses mantendo a probabilidade de HALT dentro do teto da seção 5, com os limites do guardião ajustados junto, e é atingido em degraus confirmados ao vivo: começa no degrau A (E1 0,4% / E3 1,2% por perna, stops 8 / 6) + G35 e sobe para o degrau B (E1 0,4% / E3 1,8%, stops 12 / 9) + G45 só pelos critérios de 5.1 (motivo em 5, "Por que não começar direto no degrau B"). O gate antigo (PF >= 1,3, DD relativo <= 30%, >= 100 trades, lucro em cada janela de 12 meses) continua valendo para EAs **novos** entrarem no portfólio. A escada escolhida (E1+E3 com a E1 pela metade: C22 no degrau A, C23 no B) passa também no gate antigo. O plano da primeira versão da decisão (C11 na escala 1,0, C17 na 1,5) foi substituído no mesmo dia (seção 5).

## 1. Conferências pré-aceite (todas obrigatórias)

Fonte: `resultados.csv` (valores efetivos lidos do .htm), `inis\*.inputs.txt` e o veredito do tester em `rodar_paralelo.log`. Depósito 10.000 e `Panel_Mostrar=false` / `News_Enable=true` em todos os runs válidos.

| Run | Estratégias ligadas | Riscos E1/E2/E3/E4 (%) | Stops diários global / E3 (%) | Alavancagem | Qualidade (.htm) | Veredito do tester |
|---|---|---|---|---|---|---|
| C2 | E1+E2+E3+E4 | 0,4 / 0,4 / 0,6 / 1,0 | 8 / 6 | 1:1000 | 100% | successfully finished |
| C1 | E1+E2+E3+E4 | 0,8 / 0,8 / 1,2 / 2,0 | 8 / 6 | 1:1000 | 99% | successfully finished |
| C6 | E1+E2+E3+E4 | 1,2 / 1,2 / 1,8 / 3,0 | 12 / 9 | 1:1000 | 100% | successfully finished |
| C7 | E1+E2+E3+E4 | 1,6 / 1,6 / 2,4 / 4,0 | 16 / 12 | 1:1000 | 99% | successfully finished |
| C8 | E1+E2+E3+E4 | 1,6 / 1,6 / 2,4 / 4,0 | 8 / 6 | — | — | **inválido** ("some error after pass finished"); descartado |
| C4 | E1+E2+E3+E4 | 0,8 / 0,8 / 1,2 / 2,0 | 8 / 6 | 1:1000 | 100% (M1 antes de 2025-09) | successfully finished |
| C5 | E1+E2+E3+E4 | 1,6 / 1,6 / 2,4 / 4,0 | 16 / 12 | 1:1000 | 100% (M1 antes de 2025-09) | successfully finished |
| C9 | E1+E2+E3+E4 | 0,4 / 0,4 / 0,6 / 1,0 | 8 / 6 | — | — | **inválido** ("some error after pass finished"); descartado |
| C12 | E3+E4 | off / off / 1,2 / 2,0 | 8 / 6 | 1:1000 | 100% (M1 antes de 2025-09) | successfully finished |
| C11 | E1+E3 | 0,8 / off / 1,2 / off | 8 / 6 | 1:1000 | 100% (M1 antes de 2025-09) | successfully finished |
| C13 | E1+E3 | 0,4 / off / 0,6 / off | 8 / 6 | 1:1000 | 100% (M1 antes de 2025-09) | successfully finished |
| C15 | E3 | off / off / 1,2 / off | 8 / 6 | 1:1000 | 100% (M1 antes de 2025-09) | successfully finished |
| C16 | E1 | 0,8 / off / off / off | 8 / 6 | 1:1000 | 100% (M1 antes de 2025-09) | successfully finished |
| C17 | E1+E3 | 1,2 / off / 1,8 / off | 12 / 9 | 1:1000 | 100% (M1 antes de 2025-09) | successfully finished |
| C19 | E1+E3 | 0,8 / off / 1,2 / off | 8 / 6 | 1:1000 | 100% | successfully finished |
| C20 | E1+E2+E3+E4 | 0,8 / 0,8 / 1,2 / 2,0 | 8 / 6 | 1:1000 | 100% | successfully finished |
| C21 | E3 | off / off / 1,2 / off | 8 / 6 | 1:1000 | 100% | successfully finished |
| C14 | E1+E3 | 0,8 / off / 1,2 / off | 8 / 6 | 1:1000 | 100% (12 m de ticks reais) | successfully finished |
| C18 | E1+E3 | 1,6 / off / 2,4 / off | 16 / 12 | 1:1000 | 100% (M1 antes de 2025-09) | successfully finished |
| **C22** | **E1+E3 (degrau A)** | **0,4 / off / 1,2 / off** | **8 / 6** | 1:1000 | 100% (M1 antes de 2025-09) | successfully finished |
| **C23** | **E1+E3 (degrau B)** | **0,4 / off / 1,8 / off** | **12 / 9** | 1:1000 | 100% (M1 antes de 2025-09) | successfully finished |
| V1 | E1+E3 (só a E3 operou, ver 2.2) | 0,8 / off / 1,2 / off | 8 / 6 | 1:1000 | 98% | successfully finished (4XC) |
| V2 | E1+E2+E3+E4 (a E1 não operou, ver 2.2) | 0,8 / 0,8 / 1,2 / 2,0 | 8 / 6 | 1:1000 | 98% | successfully finished (4XC) |

Inis gerados e não rodados nesta campanha (sem relatório): C10, V3. C14 e C18 têm relatório em `reports\`, mas ainda não entraram no `resultados.csv` (números lidos do .htm com `parse_reports.py --somente`); C22 e C23 estão em `_peso\`, V2 em `_qdm\res.csv`.

## 2. Backtest por run (`resultados.csv`)

Escalas: o multiplicador incide sobre os riscos base (E1 0,8 · E2 0,8 · E3 1,2 · E4 2,0 por perna). Sufixo **s** = stops diários escalados junto; **f** = stops fixos em 8% e 6%. C22 e C23 usam multiplicadores diferentes por estratégia: E1 x0,5 (0,4%) nos dois, E3 x1,0 (1,2%) no C22 e x1,5 (1,8%) no C23. DD máx. = rebaixamento máximo de equity; DD rel. = rebaixamento relativo de equity (o do gate). Valores em USD do tester (= USC na ProCent).

| Run | Estratégias | Escala | Stops | Período | Lucro | Lucro % | PF | DD máx. equity % | DD rel. equity % | Trades | Sharpe | Janelas de 12 m | Gate antigo |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| C2 | 4 estratégias | 0,5 | 8 / 6 | 12 m | +12.113 | +121,1% | 1,21 | 11,66 | 16,62 | 2.056 | 3,21 | +12.113 | reprovado (PF) |
| C1 | 4 estratégias | 1,0 | 8 / 6 | 12 m | +41.167 | +411,7% | 1,19 | 21,61 | 31,64 | 2.053 | 3,23 | +41.167 | reprovado (PF, DD) |
| C6 | 4 estratégias | 1,5 | 12 / 9 | 12 m | +96.168 | +961,7% | 1,16 | 31,10 | 46,00 | 2.053 | 3,07 | +96.168 | reprovado (PF, DD) |
| C7 | 4 estratégias | 2,0 | 16 / 12 | 12 m | +187.409 | +1.874,1% | 1,13 | 39,65 | 56,58 | 2.053 | 2,90 | +187.409 | reprovado (PF, DD) |
| C4 | 4 estratégias | 1,0 | 8 / 6 | 2 a | +6.401 | +64,0% | 1,05 | **66,50** | 66,50 | 4.187 | 0,52 | **-6.423** / +12.824 | **reprovado** (PF, DD, janela negativa) |
| C5 | 4 estratégias | 2,0 | 16 / 12 | 2 a | +7.973 | +79,7% | 1,04 | 91,23 | 91,23 | 4.187 | 0,31 | -9.010 / +16.983 | reprovado (PF, DD, janela negativa) |
| C12 | E3+E4 | 1,0 | 8 / 6 | 2 a | +14.787 | +147,9% | 1,11 | 19,74 | 39,38 | 2.724 | 1,33 | **-710** / +15.497 | **reprovado** (PF, DD, janela negativa) |
| C11 | E1+E3 (plano anterior) | 1,0 | 8 / 6 | 2 a | +56.523 | +565,2% | 1,33 | 17,71 | 26,67 | 1.608 | 3,11 | +9.584 / +46.939 | APROVADO |
| C13 | E1+E3 | 0,5 | 8 / 6 | 2 a | +12.968 | +129,7% | 1,32 | 14,46 | 14,46 | 1.608 | 2,99 | +3.817 / +9.151 | APROVADO |
| C17 | E1+E3 (plano anterior) | 1,5 | 12 / 9 | 2 a | +145.507 | +1.455,1% | 1,29 | 25,91 | 38,83 | 1.608 | 2,96 | +16.964 / +128.542 | reprovado (PF 1,29, DD rel. 38,8%): foi a referência do degrau 1,5 do plano anterior |
| C15 | E3 | 1,0 | 8 / 6 | 2 a | +21.218 | +212,2% | 1,55 | 14,96 | 15,72 | 670 | 3,59 | +5.224 / +15.993 | APROVADO |
| C16 | E1 | 1,0 | 8 / 6 | 2 a | +10.083 | +100,8% | 1,22 | 17,33 | 23,71 | 938 | 2,56 | +2.741 / +7.342 | reprovado (PF) |
| C19 | E1+E3 | 1,0 | 8 / 6 | 60 d | +1.918 | +19,2% | 1,26 | 16,71 | 16,71 | 152 | 3,37 | — | amostra curta (só referência de ritmo) |
| C20 | 4 estratégias | 1,0 | 8 / 6 | 60 d | +2.188 | +21,9% | 1,13 | 21,05 | 21,05 | 382 | 2,06 | — | amostra curta |
| C21 | E3 | 1,0 | 8 / 6 | 60 d | +590 | +5,9% | 1,33 | 5,65 | 5,65 | 62 | 2,68 | — | amostra curta |
| C14 | E1+E3 | 1,0 | 8 / 6 | 12 m | +19.798 | +198,0% | 1,33 | 17,41 | 25,54 | 800 | 3,45 | +19.798 | APROVADO (uma janela só) |
| C18 | E1+E3 | 2,0 | 16 / 12 | 2 a | +312.352 | +3.123,5% | 1,26 | 33,24 | 48,63 | 1.608 | 2,81 | +25.458 / +286.893 | reprovado (PF, DD): a escala 2,0 do plano anterior pararia a conta |
| **C22** | **E1+E3 (degrau A)** | **E1 0,5 · E3 1,0** | **8 / 6** | **2 a** | **+34.849** | **+348,5%** | **1,40** | **20,51** | **20,51** | **1.608** | **3,32** | **+6.619 / +28.230** | **APROVADO** |
| **C23** | **E1+E3 (degrau B)** | **E1 0,5 · E3 1,5** | **12 / 9** | **2 a** | **+72.392** | **+723,9%** | **1,41** | **27,69** | **27,69** | **1.608** | **3,26** | **+11.328 / +61.063** | **APROVADO** |

Janelas de 12 meses dos runs de 2 anos: 2024-09-20 a 2025-09-20 e 2025-09-20 a 2026-09-19. Na conta de 10.000, a janela 1 do C11 é +95,8% e a janela 2 é +240% sobre o saldo do início dela (19.584). No C22: +66,2% e +169,9% (sobre 16.619); no C23: +113,3% e +286,3% (sobre 21.328).

### 2.1 Decomposição por estratégia (P&L exato por magic; "2024" = 20/09 a 31/12)

| Run | E1 | E2 | E3 | E4 | Por ano |
|---|---|---|---|---|---|
| C1 (4 estr., 12 m) | +12.549 | +6.729 | +16.404 | +5.485 | 2025: +1.317 · 2026: +39.850 |
| C7 (4 estr., 2,0, 12 m) | +53.591 | +39.779 | +89.489 | +4.550 | 2025: +1.737 · 2026: +185.672 |
| C4 (4 estr., 2 a) | +5.471 | **-3.999** | +6.059 | **-1.130** | 2024: -1.375 · 2025: -4.077 · 2026: +11.853 |
| C5 (4 estr., 2,0, 2 a) | +6.508 | **-5.023** | +9.759 | **-3.270** | 2024: -3.170 · 2025: -5.154 · 2026: +16.298 |
| C12 (E3+E4, 2 a) | — | — | +15.101 | **-314** | 2024: +2.650 · 2025: -1.287 · 2026: +13.424 |
| C11 (E1 0,8 + E3 1,2, 2 a) | +26.327 | — | +30.196 | — | 2024: +2.967 · 2025: +14.888 · 2026: +38.668 |
| C13 (E1+E3, 0,5, 2 a) | +8.120 | — | +4.848 | — | 2024: +1.240 · 2025: +5.089 · 2026: +6.639 |
| C17 (E1 1,2 + E3 1,8, plano anterior, 2 a) | +64.160 | — | +81.347 | — | 2024: +4.578 · 2025: +29.938 · 2026: +110.991 |
| C15 (E3, 2 a) | — | — | +21.218 | — | 2024: +2.975 · 2025: +10.271 · 2026: +7.972 |
| C16 (E1, 2 a) | +10.083 | — | — | — | 2024: -272 · 2025: +2.118 · 2026: +8.237 |
| C19 (E1+E3, 60 d) | +987 (90 trades, acerto 33%) | — | +931 (62 trades, acerto 58%) | — | 2026: +1.918 |
| C20 (4 estr., 60 d) | +1.039 (90) | +1.916 (54) | +768 (62) | **-1.535** (176) | 2026: +2.188 |
| C21 (E3, 60 d) | — | — | +590 (62) | — | 2026: +590 |
| C14 (E1 0,8 + E3 1,2, 12 m) | +8.187 (484) | — | +11.611 (316) | — | 2025: +3.371 · 2026: +16.426 |
| C18 (E1+E3, 2,0, 2 a) | +126.258 | — | +186.094 | — | 2024: +6.305 · 2025: +49.601 · 2026: +256.445 |
| **C22 (degrau A: E1 0,4 + E3 1,2, 2 a)** | **+11.810** | — | **+23.039** | — | **2024: +2.882 · 2025: +11.786 · 2026: +20.181** |
| **C23 (degrau B: E1 0,4 + E3 1,8, 2 a)** | **+15.065** | — | **+57.327** | — | **2024: +4.983 · 2025: +23.861 · 2026: +43.547** |
| V2 (4 estr., Dukascopy, 3 a) | não opera | **-18.725** (864) | +57.207 (946) | +131.177 (3.004) | 2023: +3.718 · 2024: +7.549 · 2025: +31.708 · 2026: +126.684 |

Leitura:
- **Na RoboForex, E2 e E4 perderam dinheiro em 2 anos** (C4: E2 -3.999, E4 -1.130; no C5, em dobro) e levaram o portfólio completo a DD de 66,5% e a primeira janela de 12 meses a -6.423 (-64%). Os runs de 12 meses (C1 a C7) não viam isso: a janela 2025-26 escondia o período ruim. **Leitura corrigida em 2.5:** "E2 e E4 perderam em 2024-25", sozinho, podia ser artefato dos ticks gerados de M1 desse trecho; o cruzamento com a Dukascopy (V2) e com os ticks reais (C1) mostra que a E2 é instável e perde em 2025 nas duas bases, e que a E4 depende da base.
- **E3 sozinha** é a melhor estratégia por qualidade: PF 1,55, DD 14,96%, lucrativa em cada ano, e validada em outra base (2.2).
- **E1 sozinha** tem PF 1,22 e 82% do lucro em 2026; o trecho de 2024 é levemente negativo. Somada à E3, o DD máximo fica praticamente igual ao da E1 sozinha (17,71% contra 17,33%) e o lucro de 2 anos sobe para +565%. Com a E1 pela metade (C22) o DD fica em 20,51% (máx. = relativo) e o lucro em +348,5%; com a E1 pela metade e a E3 a 1,8% (C23), +723,9% com DD 27,69%, praticamente o DD relativo do C11 (26,67%): ver 4.1.
- Nos últimos 60 dias a E2 foi positiva (+1.916) e a E4 negativa (-1.535). O portfólio completo ganhou um pouco mais que o E1+E3 (+21,9% contra +19,2%), com mais DD (21,05% contra 16,71%) e PF menor (1,13 contra 1,26). Isso não muda a decisão: a E2 perde em 2025 nas duas bases (2.5), e 60 dias não medem o risco que ela traz.
- C19 e C21 têm os mesmos 62 trades da E3; o P&L da E3 é maior no C19 (+931 contra +590) porque o saldo, engordado pela E1, aumenta o lote (risco em % do saldo).

### 2.2 Validação fora da amostra (V1, outra base de dados)

| Item | Valor |
|---|---|
| Base | ouro da Dukascopy via QDM, símbolo custom no terminal 4XC (cópia de backtest), período pedido 2023-07-03 a 2026-09-19, 98% ticks reais, fuso UTC. **Dados efetivos até 2026-07-15** (último trade em `trades\surv_V1_E13_x100_qdm3a.csv`; primeiro em 2023-07-21): a base termina em meados de julho, então a V1 não cobre os 60 dias de C19/C21 |
| Configuração | E1+E3 com E1 0,8% / E3 1,2% e stops 8 / 6 (os do C11). Como a E1 não operou, é na prática a E3 a 1,2% por perna com stops 8 / 6: a mesma E3 do degrau A |
| O que operou de fato | **só a E3** (938 trades). A E1 não abriu nenhuma ordem ("market closed"): o símbolo custom fecha a sessão à meia-noite e a E1 coloca as pendentes do range noturno às 00:00 GMT. **A V1 é, na prática, uma validação só da E3.** |
| Resultado | +32.382 (+323,8%), PF 1,56, DD máx. equity 11,42%, DD relativo de equity 34,87% (de saldo 32,13%: pico 11.620 -> 7.886 em maio/2024, com a conta ainda pequena), Sharpe 2,44 |
| Por ano | 2023 (2º semestre) +656 · 2024 +4.803 · 2025 +19.234 · 2026 (até 15/07) +7.688 |
| Janelas de 12 m (a partir de 2023-07-03) | +822 · +6.793 · +20.962: **todas positivas** (depois delas, mais 12 trades de 03/07 a 15/07/2026, +3.804) |
| Gate antigo | reprovado só pelo DD relativo (34,87% > 30%), concentrado no início, com a conta perto do depósito |

Leitura: a E3 repete a qualidade da base RoboForex em dados independentes (PF 1,56 contra 1,55 do C15), com lucro em todas as janelas. **A E1 não tem validação independente** (seção 5.4).

**Controle V2 (as 4 estratégias na mesma base Dukascopy):** mesmo período e mesma cópia de terminal da V1, com E1 0,8 / E2 0,8 / E3 1,2 / E4 2,0 e stops 8 / 6. A E1 também não opera aqui, então é, na prática, E2+E3+E4.

| Item | Valor |
|---|---|
| Resultado | +169.660 (+1.696,6%), PF 1,30, DD máx. equity 20,07%, DD relativo de equity 49,87%, 4.814 trades, Sharpe 2,11 |
| Por estratégia | E2 -18.725 (864 trades) · E3 +57.207 (946) · E4 +131.177 (3.004) |
| Por ano | 2023 (2º semestre) +3.718 · 2024 +7.549 · 2025 +31.708 · 2026 +126.684 |
| Janelas de 12 m (a partir de 2023-07-03) | -1.306 · +11.403 · +141.583 (e +17.980 depois de 03/07/2026) |
| Gate antigo | reprovado (DD relativo 49,87%, primeira janela negativa) |

Leitura: na Dukascopy, sem comissão e com spread mais estreito, a E4 é a maior fonte de lucro; na RoboForex ela perdeu (C4, C20). A E2 perde nas duas bases. Detalhe por ano em 2.5.

### 2.3 Últimos 60 dias (2026-07-20 a 2026-09-19, 100% ticks reais)

| Run | Estratégias | Lucro | PF | DD máx. equity | Trades | Trades por semana | Sharpe |
|---|---|---|---|---|---|---|---|
| C19 | E1 0,8 + E3 1,2 (plano anterior) | +1.918 (+19,2%) | 1,26 | 16,71% | 152 (E1 90, E3 62) | ~17 | 3,37 |
| C20 | quatro estratégias | +2.188 (+21,9%) | 1,13 | 21,05% | 382 | ~44 | 2,06 |
| C21 | só E3 | +590 (+5,9%) | 1,33 | 5,65% | 62 | ~7 | 2,68 |

Trecho equivalente dentro dos runs de 2 anos (os mesmos 152 trades de 2026-07-20 a 09-19; estimativa pelo saldo fechado, sem o flutuante; retorno sobre o saldo do início do trecho; calculado de `trades\` e `_peso\`): C11 +20,3%, PF 1,25, DD de saldo 14,96% (o C19 real deu +19,2%, DD de saldo 13,95% e de equity 16,71%: a estimativa bate); **C22 +15,2%, PF 1,32, DD de saldo 7,92%**; C23 +19,3%, PF 1,31, DD de saldo 8,77%. A E1 somou retorno mas triplicou o DD (C19 16,71% contra C21 5,65%): mais um motivo para reduzir o peso dela.

Custo de execução no tester (referência do critério 6 de subida): slippage adverso médio nas saídas por SL, em USD por onça. **C11 (2 anos, 527 saídas por SL): E1 0,124 (394 saídas), E3 0,568 (133), média 0,236 (mediana 0,05)**; só o trecho de ticks reais do C11 (desde 2025-09-22, 313 saídas): E1 0,164, E3 0,332, média 0,200. C19 (60 dias, 69 saídas): E1 0,06 (56), E3 0,44 (13), média 0,13 (mediana 0,06). A média depende da mistura E1/E3 (a E3 escorrega 4 a 7 vezes mais), por isso o limite ao vivo é ponderado pela mistura ao vivo com os números do C11, a maior amostra (5.1, critério 6). Os números valem para C22 e C23: mesmas estratégias e mesmos trades, e o slippage por onça não depende do lote. O tester não modela o slippage da corretora: esses números vêm só da granularidade dos ticks.

### 2.4 Regime dos últimos 60 dias do ouro (`regime\`, medianas dos últimos 44 pregões)

| Métrica | Valor |
|---|---|
| Variação | +5,5%; 20 dias de alta e 24 de baixa (rali em agosto, correção em setembro) |
| Range diário mediano / ATR14 D1 | 91 USD / 100 USD |
| Range 08-10 UTC (abertura de Londres, janela de rompimento da E3; a caixa é o range asiático 00-04 GMT) | 19,5 USD |
| Extensão depois de Londres | 35 USD |
| Dias de falso rompimento de Londres | 36% (contra 55% nos pregões anteriores da amostra): regime favorável ao breakout da E3 |
| Hora mais volátil | 12-14 UTC (abertura de NY) |

### 2.5 Análise cruzada por estratégia e ano (as duas bases)

Soma dos retornos percentuais por trade, em pontos percentuais (aproximação da contribuição de cada estratégia ao retorno composto do ano). V2 = Dukascopy, 4 estratégias, 2023-07 a 2026-07 (98% ticks reais; a E1 não opera nessa base); C4 = RoboForex, 4 estratégias, 2 anos ("2024" = 20/09 a 31/12; ticks gerados de M1 antes de 2025-09); C1 = RoboForex, 4 estratégias, 12 meses de ticks reais ("2025" = 4º trimestre).

| Estratégia | V2 2023 (2º sem.) | V2 2024 | V2 2025 | V2 2026 | C4 2024 | C4 2025 | C4 2026 | C1 4º tri 2025 | C1 2026 |
|---|---|---|---|---|---|---|---|---|---|
| E1 | — | — | — | — | -2,5 | +39,8 | +50,4 | -7,9 | +58,0 |
| E2 | +30,9 | +23,2 | **-8,9** | -9,4 | -32,0 | **-59,4** | +17,0 | +4,5 | +19,0 |
| E3 | +10,0 | +25,9 | +82,6 | +20,7 | +26,0 | +31,1 | +17,4 | +40,9 | +30,4 |
| E4 | -2,4 | +5,4 | +27,4 | +114,4 | -3,6 | **-66,2** | +51,2 | **-21,5** | +51,7 |

Leitura (corrige a justificativa antiga "E2 e E4 perderam em 2024-25", que podia ser artefato dos ticks gerados de M1):
- **E3:** positiva em todos os anos nas duas bases. É o núcleo robusto, e por isso passa a carregar o risco nos degraus A e B (5).
- **E2:** instável; negativa em 2025 nas DUAS bases, inclusive com ticks reais (a Dukascopy é de ticks reais). Fica desligada.
- **E4:** depende da base. Brilhou na Dukascopy, que não tem comissão e tem spread mais estreito, mas perdeu na RoboForex em 2025, inclusive no trimestre de ticks reais (C1). Por fazer milhares de trades pequenos (3.004 na V2) é a mais sensível ao custo da conta cent. Fica desligada; pode ser reavaliada se o spread medido ao vivo sair igual ou melhor que o do backtest.
- **E1:** só medida na RoboForex; negativa no trecho de 2024 (C4) e no 4º trimestre de 2025 de ticks reais (C1), forte depois. Sem validação independente: fica com metade do peso (4.1).

## 3. Monte Carlo de 12 meses do portfólio de quatro estratégias (`montecarlo.csv`; 5.000 caminhos, blocos de 20 trades)

Modo `guardiao` = G35 (DD 20% reduz o risco à metade, HALT em 35%). Critério antigo: P(HALT) <= 5%.

| Base | DD mediana % | DD p95 % | P(DD >= 20%) | P(HALT) | Retorno mediano | p5 | p95 | Critério |
|---|---|---|---|---|---|---|---|---|
| C2 (0,5, 12 m) | 14,6 | 22,2 | 14,0% | 0,02% | +120,0% | +33,7% | +259,5% | ok |
| C1 (1,0, 12 m) | 24,1 | 32,0 | 90,3% | 2,1% | +322,2% | +51,5% | +1.135% | ok |
| C6 (1,5, 12 m) | 30,7 | 35,4 | 99,98% | 23,2% | +477,6% | -7,4% | +2.873% | reprovado |
| C7 (2,0, 12 m) | 35,1 | 35,9 | 100% | 61,7% | +308,5% | -27,4% | +5.148% | reprovado |
| **C4 (1,0, 2 a)** | 32,3 | 35,3 | 99,7% | **37,0%** | +9,7% | -33,4% | +166,0% | **reprovado** |
| C5 (2,0, 2 a) | 35,3 | 36,0 | 100% | 95,2% | -6,5% | -35,0% | +243,5% | reprovado |

Leitura: com a base de 12 meses o portfólio completo em 1,0 parecia aceitável (P(HALT) 2,1%); com a base de 2 anos (C4) a probabilidade de HALT em 12 meses vai a 37%. Na curva de crescimento com a base C4 (`curva_kelly.csv`), k=1,0 G35 dá mediana x1,10, p5 x0,67 e P(HALT) 37%. Foi isso que levou à decomposição por estratégia (2.1) e ao portfólio E1+E3.

## 4. Curva de crescimento contra parada, E1+E3 (`curva_kelly_E13.csv` e simulação dos limites)

Esta seção mediu o plano anterior (base C11, E1 0,8% / E3 1,2%). O estudo que decidiu a escada A/B está em 4.1, com a mesma metodologia.

12 meses, bootstrap em blocos, 5.000 caminhos; o multiplicador k incide sobre os retornos do run-base. Guardiões: **G35** = o atual do kit (reduz a 0,5 com DD 20%, volta abaixo de 10%, HALT 35%); **G45** = reduz com DD 25%, volta abaixo de 12%, HALT 45%; G50 = reduz com 30%, volta abaixo de 15%, HALT 50% (só referência). HALT congela o caminho (conservador). O lock diário não entra no modelo (a simulação é por trade). As linhas G45 vêm da simulação dos limites rodada à parte com a mesma metodologia; o CSV guarda G35, G50 e "cru".

**Base C11 (plano anterior: RoboForex, 2 anos, E1 0,8 + E3 1,2; 806 trades por 12 meses)**

| k | Guardião | Múltiplo mediano | p5 | p95 | P(HALT) | DD p95 | P(prejuízo) |
|---|---|---|---|---|---|---|---|
| 0,5 | G35 | x1,62 | x1,16 | x2,26 | 0,0% | 17,3% | 1,0% |
| 1,0 | G35 | x2,47 | x1,20 | x4,93 | 0,1% | 26,4% | 1,7% |
| 1,5 | G35 | x3,33 | x1,17 | x9,66 | 3,2% | 33,4% | 2,6% |
| 1,5 | G45 | x3,55 | x1,26 | n/d | 0,1% | 35,4% | n/d |
| 1,5 | G50 | x3,79 | x1,30 | x10,58 | 0,08% | 37,6% | 1,9% |
| 2,0 | G35 | x4,15 | x0,93 | x17,09 | 15,5% | 35,4% | 6,0% |

**Base V1 (Dukascopy, 3 anos, só a E3 operou; 316 trades por 12 meses).** Como só a E3 a 1,2% operou, k=1,0 é a E3 do degrau A e k=1,5 a do degrau B.

| k | Guardião | Múltiplo mediano | p5 | P(HALT) | DD p95 | P(ano negativo) |
|---|---|---|---|---|---|---|
| **1,0** | **G35** | **x1,56** | **x0,91** | **0,4%** | 27,2% | **9,2%** |
| 1,5 | G35 | x1,82 | x0,87 | 4,5% | 34,5% | 10,5% |
| **1,5** | **G45** | **x1,88** | n/d | **0,6%** | **36,6%** | n/d |
| 2,0 | G35 | x2,06 | x0,77 | 16,0% | 35,5% | 13,3% |

Leitura:
- Em 1,5, trocar o G35 pelo G45 derruba P(HALT) de 3,2% para 0,1% (base C11) e de 4,5% para 0,6% (base V1), e ainda sobe a mediana: com o G35 apertado, um DD normal da escala 1,5 vira HALT e congela a conta. Escala e limites têm de subir juntos.
- Em 2,0, P(HALT) de 15,5% a 16% com o G35: fora de questão.
- Conferência da aproximação linear com os runs reais: C11 fez x1,96 e x3,40 nas duas janelas de 12 meses (mediana do modelo em k=1,0: x2,47); C17 fez x2,70 e x5,77 (modelo em k=1,5: x3,33 a x3,55). O DD máximo real do C17 (25,91%) cai dentro da faixa do modelo em 1,5.

### 4.1 Estudo de peso E1/E3 (`_peso\`: C22, C23 e a curva)

Pergunta: com a E3 validada fora da amostra e a E1 não, vale pôr menos risco na E1 e mais na E3? Os três runs têm os mesmos 1.608 trades (mesmos sinais; muda só o lote). Fonte: `_peso\res.csv` (C11 e C22) e `_peso\res23.csv` (C23), gerados por `parse_reports.py --out _peso/res.csv --trades-dir _peso`.

| Run | E1 / E3 (% por perna) | Stops | Lucro | PF | DD máx. equity | DD rel. equity | Sharpe | Recuperação | E1 | E3 | Janelas de 12 m | 2024 / 2025 / 2026 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| C11 (plano anterior) | 0,8 / 1,2 | 8 / 6 | +56.523 (+565,2%) | 1,33 | 17,71% | 26,67% | 3,11 | 4,11 | +26.327 | +30.196 | +9.584 / +46.939 | +2.967 / +14.888 / +38.668 |
| **C22 (degrau A)** | **0,4 / 1,2** | **8 / 6** | **+34.849 (+348,5%)** | **1,40** | **20,51%** | **20,51%** | **3,32** | **6,51** | +11.810 | +23.039 | +6.619 / +28.230 | +2.882 / +11.786 / +20.181 |
| **C23 (degrau B)** | **0,4 / 1,8** | **12 / 9** | **+72.392 (+723,9%)** | **1,41** | **27,69%** | **27,69%** | **3,26** | **6,19** | +15.065 | +57.327 | +11.328 / +61.063 | +4.983 / +23.861 / +43.547 |

Curva de 12 meses (bootstrap em blocos de 20 trades, 5.000 caminhos, mesma metodologia da seção 4; `_peso\curva.csv` guarda as bases C11 e C22 com G35, G50 e cru; as linhas da base C23 vêm da simulação à parte com a mesma metodologia):

| Base | k | Guardião | Múltiplo mediano | p5 | p95 | P(HALT) | DD mediana | DD p95 | P(prejuízo) |
|---|---|---|---|---|---|---|---|---|---|
| **C22 (degrau A)** | **1,0** | **G35** | **x2,11** | **x1,26** | x3,42 | **0,0%** | 14,0% | **21,7%** | 0,7% |
| C22 | 1,25 | G35 | x2,48 | x1,28 | x4,59 | 0,02% | 17,2% | 24,4% | 1,0% |
| C22 | 1,5 | G35 | x2,86 | x1,29 | x6,12 | 0,1% | 20,3% | 26,9% | 1,2% |
| C22 | 1,5 | G50 | x3,02 | x1,39 | x6,21 | 0,0% | 20,4% | 31,6% | 0,8% |
| C22 | 1,75 | G35 | x3,24 | x1,32 | x8,03 | 0,6% | 22,1% | 29,4% | 1,3% |
| C22 | 2,0 | G35 | x3,61 | x1,30 | x10,23 | 1,8% | 23,6% | 31,8% | 1,9% |
| C23 | 1,0 | G35 | x2,75 | x1,29 | n/d | 0,1% | n/d | 26,2% | n/d |
| **C23 (degrau B)** | **1,0** | **G45** | **x2,86** | **x1,34** | n/d | **0,0%** | n/d | **28,6%** | n/d |
| C23 (degrau C, não planejado) | 1,33 | G45 (lock diário teria de ir a >= 20%) | x3,71 | n/d | n/d | 0% | n/d | 33% | n/d |

Mesmo nível de risco, plano anterior contra mistura nova:

| Nível | Plano anterior (base C11) | Mistura nova (base C22) |
|---|---|---|
| DD p95 perto de 26-27% | k=1,0 G35: x2,47, p5 x1,20, P(HALT) 0,1%, DD p95 26,4% | k=1,5 G35: x2,86, p5 x1,29, P(HALT) 0,1%, DD p95 26,9% |
| Mais agressivo | k=1,5 G35: x3,33, P(HALT) 3,2% | k=2,0 G35: x3,61, P(HALT) 1,8% |

Leitura:
- A mistura com Londres pesada domina em todos os níveis: para o mesmo DD de cauda, mediana maior, p5 melhor e P(HALT) igual ou menor.
- C23 contra C11: mesmo DD (27,7% contra 26,7% de DD relativo), +28% de lucro, PF, Sharpe e fator de recuperação maiores, e 79% do lucro vindo da E3 (53% no C11), a única estratégia validada fora da amostra.
- C22 é o degrau de entrada: menos lucro que o C11 (+348,5% contra +565%), mas DD de cauda bem menor na curva (p95 21,7% contra 26,4%) e P(HALT) nula.
- Conferência da aproximação linear: o C22 fez x1,66 e x2,70 nas duas janelas de 12 meses (mediana do modelo x2,11); o C23, x2,13 e x3,86 (modelo x2,75 a x2,86).
- C18 (plano anterior na escala 2,0, stops 16 / 12, 2 anos): +312.352 (+3.124%), PF 1,26, DD máx. de equity 33,24% e DD relativo 48,63%, acima do HALT do G45: a escala 2,0 do plano anterior pararia a conta.
- C14 (plano anterior, só os 12 meses de ticks reais): +19.798 (+198%), PF 1,33, DD máx. de equity 17,41%, DD relativo 25,54%, 800 trades: confirma o C11 no trecho de ticks reais.
- Degrau C: projeção linear sobre o C23 (k=1,33 = E1 ~0,53% / E3 2,4%, stops 16 / 12) com G45; não planejado, exige backtest próprio e também um guardião com lock diário >= 20% (16 x 1,25): o G45 atual, com 15%, ficaria abaixo do stop diário de 16% do EA (seção 5, "Por que o lock diário vai a 15%"). A curva não pega isso porque não modela o lock diário (5.4, item 7).

## 5. Decisão (revisada em 2026-09-22: escada A/B)

Tomada pelo gestor (Claude) com o objetivo do Henrique: "ficar rico sem morrer". Esta versão substitui a primeira decisão do mesmo dia (escala 1,0 = E1 0,8% / E3 1,2% por perna, o C11; degrau 1,5 = E1 1,2% / E3 1,8%, o C17), trocada depois do estudo de peso E1/E3 (4.1) e da análise cruzada por estratégia (2.5). Os presets daquele plano foram apagados; C11 e C17 ficam neste arquivo só como histórico e comparação.

- **Teto de risco aceito:** P(HALT) <= 1% em 12 meses **nas duas bases**. Degrau A: 0,0% na base C22 (k=1,0, G35) e 0,4% na V1 (k=1,0, G35; a V1 é justamente a E3 a 1,2%). Degrau B: 0,0% na base C23 (k=1,0, G45; 0,1% com o G35) e 0,6% na V1 (k=1,5, G45: a E3 a 1,8%). Não passaria: a E3 a 1,8% com o G35 na V1 (4,5%).
- **Portfólio:** Concorde_RF v3.04 **só com E1** (range noturno, magic 202512) **e E3** (breakout de Londres, magics 202533 e 202534). **E2 (magic 202605122) e E4 (magic 550555) DESLIGADAS** (`Estrategia2_Ativada=false`, `Estrategia4_Ativada=false`). Motivo, corrigido pela análise cruzada (2.5): a E2 é instável e perde em 2025 nas duas bases, inclusive com ticks reais; a E4 depende da base (brilhou na Dukascopy, que não tem comissão e tem spread mais estreito, e perdeu na RoboForex em 2025, inclusive no trimestre de ticks reais) e, por fazer milhares de trades pequenos, é a mais sensível ao custo da conta cent. A E4 pode ser reavaliada se o spread medido ao vivo sair igual ou melhor que o do backtest.
- **Peso:** a E1 fica com metade do risco do plano anterior (0,4% por perna) nos dois degraus e a E3 carrega o risco. A E3 é positiva em todos os anos nas duas bases e é a única validada fora da amostra (V1); a E1 não tem validação independente e, nos últimos 60 dias, somou retorno mas triplicou o DD (2.3).
- **Degrau A (início):** preset `mql5\Presets\Concorde_E13_A.set` (gerado do ini do C22 por `gerar_set.py`): E1 0,4% / E3 1,2% por perna, stop diário global 8%, E3 6%. Guardião **G35** (`mql5\Presets\SurvivalGuardian_G35.set`, = defaults do fonte v1.10): lock diário 10%, DD 20% reduz o risco a 0,5 (volta abaixo de 10%), HALT 35%. Referência: **C22**, +34.849 (+348,5%), PF 1,40, DD 20,51% (máx. de equity = relativo; 5.353), 1.608 trades, Sharpe 3,32, janelas de 12 m +6.619 / +28.230, aprovado no gate. Curva de 12 meses (k=1,0, G35): mediana x2,11, p5 x1,26, P(HALT) 0,0%, P(prejuízo) 0,7%, DD mediana 14,0%, p95 21,7%. **Desde 2026-09-30 a referência de DD e PF do degrau A é o C22 corrigido** (as mesmas entradas, com as notícias na hora do servidor; 5.6): +36.697 (+367,0%), PF 1,42, DD 15,32% (relativo; o "DD máx." do relatório é 9,47%), 1.606 trades. A curva de 12 meses acima ainda é a do C22 original.
- **Degrau B (planejado, só pelos critérios de 5.1):** preset `Concorde_E13_B.set` (do ini do C23): E1 0,4% / E3 1,8% por perna, stops diários 12% / 9%. Guardião **G45** (`SurvivalGuardian_G45.set`: `Inp_DiarioMaxPerdaPct=15`, `Inp_DD_ReduzPct=25`, `Inp_DD_ReduzHisterese=12`, `Inp_DD_HaltPct=45`). Referência: **C23**, +72.392 (+723,9%), PF 1,41, DD 27,69% (máx. de equity = relativo), Sharpe 3,26, fator de recuperação 6,19, 1.608 trades, janelas +11.328 / +61.063, anos 2024 +4.983 / 2025 +23.861 / 2026 +43.547, E1 +15.065 e E3 +57.327; **aprovado no gate** (PF >= 1,3, DD <= 30%, >= 100 trades, lucro nas duas janelas). Curva (k=1,0, G45): mediana x2,86, p5 x1,34, P(HALT) 0,0%, DD p95 28,6%.
- **Degrau C (futuro, NÃO planejado):** E1 ~0,53% / E3 2,4% por perna, stops 16 / 12, com o G45 (o C23 com k=1,33). A curva projeta mediana x3,71 com P(HALT) 0% e DD p95 33%, mas é projeção linear sobre o C23: **exige backtest próprio** antes de qualquer uso, e **exige também um guardião com lock diário >= 20%** (16 x 1,25, a mesma folga dos degraus A e B): o G45 atual, com 15%, ficaria abaixo do stop diário de 16% do EA e dispararia antes dele em todo dia ruim. Nem o backtest nem a curva pegariam isso (o tester ignora o guardião; a curva não modela o lock diário). Só registrado como possibilidade.
- **Por que a escada nova e não a do plano anterior:** o C23 tem o mesmo DD do C11 (27,69% contra 26,67% de DD relativo) com +28% de lucro (+72.392 contra +56.523), PF (1,41 contra 1,33), Sharpe (3,26 contra 3,11) e fator de recuperação (6,19 contra 4,11) maiores, e o lucro passa a vir principalmente da E3 (79% no C23 contra 53% no C11), a única estratégia validada fora da amostra. Na curva, no mesmo nível de risco, a mistura com Londres pesada domina em todos os níveis (4.1). E a escala 2,0 do plano anterior (C18) chega a DD relativo de 48,63%: pararia a conta.
- **Por que o lock diário vai a 15% no degrau B:** o lock do guardião é a camada externa e tem de ficar **acima** do stop diário do próprio EA. No degrau A a relação é 10% contra 8% (1,25x). Com o preset B o stop do EA sobe para 12%; se o lock ficasse em 10%, o guardião dispararia antes do EA em todo dia ruim, fechando tudo num ponto que o C23 nunca testou (o tester ignora o guardião) e travando o dia inteiro. Com 15% (12 x 1,25) a ordem das camadas se mantém: primeiro o stop do EA (12%); o guardião só age se o EA falhar, se o slippage de várias pernas passar do stop ou se um reinício do EA rebasear o equity do dia. E 15% continua longe do HALT (45%). Somado à redução a 0,5 aos 20% do G35, que cortaria o risco no meio de quedas normais do degrau B (DD p95 de 26,2% com o G35 na curva do C23), é por isso que o preset B e o G45 só vão juntos.
- **Por que G45 e não G50 no degrau B:** o G50 aceita perder metade da conta antes do HALT, e depois de um HALT o que sobra é o capital para recomeçar. Com HALT a 45% sobram 55% da conta. Na curva o G50 rende pouco mais, com P(HALT) igualmente quase nula (na base C11 em k=1,5, x3,79 contra x3,55 do G45; na base C22 em k=1,5, x3,02 contra x2,86 do G35), e a diferença não paga os 5 pontos a mais de queda possível. Além disso, a base V1 não tem a linha G50.
- **Por que não começar direto no degrau B:** a mediana do B com G45 é maior (x2,86 contra x2,11) com P(HALT) também nula, mas a curva é feita sobre os mesmos dados em que as estratégias e o peso foram escolhidos (in-sample), a E1 não tem validação independente, o custo real de execução da conta cent é desconhecido e o DD p95 sobe de 21,7% para 28,6%. O degrau só vem depois que a conta ao vivo confirmar o backtest.
- **Por que E1+E3 e não só E3:** a E3 sozinha tem PF e DD melhores (1,55 / 14,96%, C15), mas a E1 pela metade soma lucro com DD moderado: o C22 (E1 0,4 + E3 1,2) faz +348,5% contra +212% do C15, com PF 1,40 e DD 20,51%, e passa no gate. Se a E1 falhar ao vivo, o recuo natural (a decidir com o Henrique) é só E3: C15 aprovado e V1 validando.

### 5.1 Critérios de subida do degrau A para o B (TODOS obrigatórios; avaliados pelo agente no protocolo semanal, CLAUDE.md 5.6)

| # | Critério | Limite | De onde vem |
|---|---|---|---|
| 1 | Trades ao vivo do Concorde (magics 202512, 202533, 202534) desde o início | >= 40 **e** >= 21 dias corridos (3 semanas completas) desde o "Início ao vivo do Concorde" | ritmo do C22: ~15 trades por semana (o mesmo nos dois degraus); 40 trades em menos de 3 semanas é ritmo anômalo (CLAUDE.md 4.4), não amostra maior |
| 2 | PF ao vivo | >= 1,10 | margem abaixo do PF do C22 (1,40) e do C19 (1,26) |
| 3 | DD ao vivo (queda da equity contra o pico, = `dd_pct`; CLAUDE.md 5.1): maior DD das últimas 8 semanas (ou desde o início do Concorde, se mais curto) e `dd_pct` atual | <= 15,3% nas 8 semanas e < 10% agora (até 2026-09-30: 20,5%) | DD do C22 corrigido (relativo = 15,32%, a mesma medida do `dd_pct`; 5.6) |
| 4 | HALT (automático ou de incidente) desde o início ao vivo do Concorde; HALT de ensaio anterior ao anexo não conta | nenhum | guardian.log, ALERTAS.md |
| 5 | Incidente de execução aberto em ALERTAS.md | nenhum | ALERTAS.md |
| 6 | Custo de execução (spread/slippage) ao vivo | <= 1,5x o do backtest, ponderado pela mistura ao vivo: slippage adverso médio nas saídas por SL <= 1,5 x (0,124 x nE1 + 0,568 x nE3) / (nE1 + nE3) USD por onça (só E1: 0,19; só E3: 0,85; mistura do C11: 0,35), com >= 10 saídas por SL da E1 e >= 5 da E3 | C11 (2.3), válido para C22 e C23 (mesmas estratégias e mesmos trades; o slippage por onça não depende do lote); histórico de ordens/posições |

**Quem executa:** o agente só RECOMENDA, em ALERTAS.md (nível AGUARDANDO OK DO HENRIQUE), com a tabela dos 6 critérios. O Henrique autoriza no INBOX com a linha `AAAA-MM-DD OK DEGRAU B` e aplica ele mesmo, por RDP e no fim de semana, os dois presets (`Concorde_E13_B.set` e `SurvivalGuardian_G45.set`; SETUP_VPS 6.5). Um preset sem o outro não vale (seção 5, "Por que o lock diário vai a 15%").

**Depois de uma descida conferida** (5.2), a contagem recomeça: os critérios 1 e 2 e o prazo de 21 dias contam da data da descida, e a subida exige também pelo menos 8 semanas no degrau A. Sem isso, o PF acumulado desde o início liberaria a subida de novo com o PF recente ainda < 1,0, e a conta oscilaria entre A e B.

### 5.2 Descida de volta para o degrau A

- **Gatilhos (qualquer um):** DD ao vivo (CLAUDE.md 5.1) acima de 25%, ou PF dos últimos 60 dias < 1,0 com >= 40 trades na janela.
- **Por que 25% e não o pré-alerta do degrau B (27,69%):** 25% = `Inp_DD_ReduzPct` do G45, o ponto em que o próprio guardião já corta o risco pela metade; a descida é recomendada de propósito antes do pré-alerta do C23. O C23 é in-sample e otimista por construção (5.4, item 1), e descer antes de 30% ainda permite trocar o Concorde e o guardião juntos. No caminho do próprio C23 (DD 27,69%) o degrau B teria sido desfeito uma vez: é aceito, porque descer é redução e a subida volta pelos critérios de 5.1. Para o degrau B, este gatilho prevalece sobre o "só registrar" do pré-alerta (5.3; CLAUDE.md 5.2). No plano anterior os dois números praticamente coincidiam (25% contra 25,91% do C17).
- O agente pode recomendar a descida a qualquer momento (ALERTAS.md, AGUARDANDO OK DO HENRIQUE). Como medida imediata, e só por ser redução, pode mandar `RISK_SCALE 0.67` no control.txt (E3 1,8 x 0,67 = 1,2, a do degrau A; a E1 cai para ~0,27%, redução a mais), desde que o `risk_scale` do guardião esteja em 1,0; se o guardião já reduziu para 0,5, mandar 0,67 seria aumento e não se manda nada. Depois da troca conferida, o agente devolve o controle com `RISK_SCALE AUTO` na acordada de fim de semana.
- A troca dos presets de volta é do Henrique, por RDP, no fim de semana, com a linha `OK DEGRAU A` no INBOX. Com `dd_pct` < 30%: `Concorde_E13_A.set` + `SurvivalGuardian_G35.set`. Com `dd_pct` >= 30%: só o Concorde; o guardião fica no G45 até o DD cair abaixo de 30% (a mesma linha cobre essa segunda troca), porque carregar o G35 com DD >= 35% dispara HALT na hora, no fundo do DD.
- Depois da descida, o DD acumulado no degrau B continua comparado com o C23 até a conta fazer HWM novo.

### 5.3 Referências para as regras semanais (CLAUDE.md 5.2)

| Degrau | Referência | DD de referência | Pré-alerta (a partir de) | Pausa (acima de, fixo) |
|---|---|---|---|---|
| A | C22 corrigido (desde 2026-09-30; antes, C22 com 20,51%) | 15,32% | 15,32% | 30,8% |
| B | C23 | 27,69% | 27,69% | 41,5% |

Os limites de pausa são 1,5x os DDs originais (20,51% e 27,69%) e ficaram fixos quando a referência do degrau A passou ao C22 corrigido (5.6): a pausa não ficou mais fácil de disparar por causa da correção. O C23 ainda tem as notícias atrasadas no inverno; será refeito antes de qualquer decisão sobre o degrau B.

Medida ao vivo: a definição única de DD de CLAUDE.md 5.1 (queda da equity contra o pico, em % do pico, = `dd_pct`), nunca em % do equity inicial. Em C22 e C23 o "DD máx." do MT5 e o DD relativo (a pior queda percentual, mesma medida do `dd_pct`) coincidem, então a referência está na mesma medida do número ao vivo. No C22 corrigido eles não coincidem (máx. 9,47%, relativo 15,32%): a referência é o relativo. (No plano anterior a referência era o DD máx. do C11, 17,71%, abaixo do DD relativo dele, 26,67%.) Se um dia houver mais de um EA na conta, a referência por EA passa a ser o DD relativo da curva de saldo fechado, recalculado dos trades (`_peso\`): C22 17,94% (C22 corrigido: 13,10%), C23 24,81%.

Ritmo esperado ao vivo no regime atual: ~15 trades por semana nos dois degraus (1.608 em 2 anos; cada sinal abre 2 pernas; muda só o lote). No C22 há no máximo um sinal por estratégia por dia e nunca mais de 8 posições fechadas em 24 h nem de 24 em 7 dias (mediana 16): acima de 8 em 24 h ou de 30 em 7 dias, o agente abre ATENCAO e checa duplicação e risco por perna (CLAUDE.md 4.4). Nos últimos 60 dias, o trecho equivalente do C22 fez +15,2% com DD de saldo fechado de 7,9% (2.3; estimativa sem o flutuante; no C22 corrigido, +14,3% e 8,2%): no degrau A, DD de 60 dias até ~10% é normal. O ritmo não muda com a correção das notícias: no C22 corrigido também são no máximo 8 posições fechadas em 24 h e 24 em 7 dias, mediana 16.

Magic de E2 (202605122) ou E4 (550555) aparecendo ao vivo = preset errado anexado = incidente CRITICO: o agente manda HALT e espera o Henrique.

### 5.4 Ressalvas honestas

1. **Seleção in-sample:** a escolha de E1+E3 (e o desligamento de E2 e E4) e o peso da E1 foram decididos olhando os mesmos dados que medem o resultado. O PF 1,40 e o DD 20,51% do C22 (1,42 e 15,32% no C22 corrigido) e o PF 1,41 e o DD 27,69% do C23 são, por construção, otimistas.
2. **A E1 não tem validação independente.** Na V1 e na V2 ela não operou (sessão do símbolo custom); só a E3 foi validada fora da RoboForex. A E1 sozinha tem PF 1,22, 2024 levemente negativo e 82% do lucro em 2026. Por isso ficou com metade do peso.
3. **2026 concentra a maior parte do lucro:** 58% do lucro de 2 anos no C22 (+20.181 de +34.849) e 60% no C23 (+43.547 de +72.392), em parte por juros compostos, mas também em %: no C23 a janela 2 rende +286% contra +113% da janela 1. O regime de 2026 (tendência e rompimentos limpos) pode não se repetir.
4. **Um único ativo (ouro).** E1 e E3 operam o mesmo XAUUSD M15: não há diversificação de ativo. Um regime ruim do ouro atinge as duas ao mesmo tempo.
5. **Ticks gerados de M1 antes de 2025-09** nas rodadas de 2 anos: o trecho 2024-25 (justamente a janela ruim) tem execução menos fiel que o trecho de ticks reais.
6. **O backtest não inclui o slippage real da conta cent**, nem requotes, nem diferenças de spread entre a conta Pro (demo dos testes) e a ProCent. O critério 6 de subida existe para medir isso ao vivo.
7. A curva de crescimento supõe que o lucro escala linearmente com o risco (ignora o piso do lote mínimo, a margem e o stop diário do EA) e não modela o lock diário. As linhas G45 e as da base C23 não estão no CSV (simulação à parte com a mesma metodologia). O degrau C é só projeção.
8. **Especificação do XAUUSD na ProCent conferida** pelo Henrique no VPS em 2026-09-22 (SETUP_VPS 6.0, concluída): contrato 100 XAU, volume mínimo e passo 0,01, margem ~436 por lote com 1:1000, o que prova o valor do tick padrão (1,00 por lote por 0,01). A conta cent se comporta numericamente como a conta de 10.000 do backtest. O spread na abertura de Londres ainda não foi anotado.

### 5.5 Próximo passo

Especificação do XAUUSD conferida (SETUP_VPS 6.0). Falta o ensaio HALT/RESUME sem posições (SETUP_VPS 8.6); depois, anexar o Concorde com `Concorde_E13_A.set`, confirmar o guardião com `SurvivalGuardian_G35.set`, salvar o perfil e começar a contar os critérios de 5.1 no protocolo semanal.

### 5.6 Correção das notícias no tester e referência nova do degrau A (2026-09-29/30)

**O defeito.** No tester, o Concorde converte o `news.csv` (em GMT) para a hora do servidor com um único offset, o do início do teste (`News_SourceGMTOffset`). O servidor da RoboForex é GMT+3 no horário de verão europeu e GMT+2 no inverno. Nas rodadas de 2 anos (C11, C22, C23), que começam no verão, as notícias de inverno ficavam 1 h atrasadas: 194 saídas da E3 aconteciam 50 min depois da notícia, em vez de 10 min antes. Ao vivo o EA usa o calendário nativo do terminal e sai na hora certa. O laboratório (CLAUDE.md 5.9) já roda com o `news_lab_srv.csv`, convertido evento a evento para a hora do servidor.

**O teste.** Mesmo ini do C22 (180 inputs), mesma cópia `C:\RF_bt`, conta demo, 2024-09-20 a 2026-09-19, rodado em 2026-09-29. As duas rodadas usam `E4_Use1..4=false`, neutro com a E4 desligada: com as notícias antigas, 1.608 trades como no C22 e só 4 saídas por horário da E1 1 s antes.

| Run | Notícias | Lucro | PF | DD relativo (equity) | DD máx. (MT5) | DD saldo fechado | Trades | Sharpe | Janelas de 12 m |
|---|---|---|---|---|---|---|---|---|---|
| C22 (original, 2026-09-22) | offset do início | +34.849 (+348,5%) | 1,40 | 20,51% | 20,51% | 17,94% | 1.608 | 3,32 | +6.619 / +28.230 |
| C22e (mesmos dados de 29/09) | offset do início | +34.938 (+349,4%) | 1,40 | 20,31% | 20,31% | 17,78% | 1.608 | 3,33 | +6.644 / +28.294 |
| **C22 corrigido** (C22n) | **hora do servidor por evento** | **+36.697 (+367,0%)** | **1,42** | **15,32%** | 9,47% | **13,10%** | **1.606** | **3,52** | **+6.413 / +30.284** |

O efeito da correção é a diferença entre C22e e C22n (mesmos dados de ticks): DD de 20,31% para 15,32%, PF de 1,40 para 1,42 e lucro 5% maior. Últimos 60 dias (2026-07-20 a 2026-09-19): +14,3% com DD de saldo fechado de 8,2% (C22: +15,2% e 7,9%). O ritmo é o mesmo (no máximo 8 posições fechadas em 24 h e 24 em 7 dias, mediana 16 por semana).

**O que mudou (decisão do Henrique, 2026-09-30):** a referência de DD e PF do degrau A passa a ser o C22 corrigido. Pré-alerta semanal a partir de 15,32% (era 20,51%); critério 3 de subida: DD das últimas 8 semanas <= 15,3% (era 20,5%); referência por EA de saldo fechado, 13,10% (era 17,94%).

**O que não mudou:** o limite de pausa do degrau A continua em 30,8% (fixo; 1,5 x 15,32% daria 22,98% se acompanhasse a correção, o que tornaria a pausa mais fácil de disparar; os gatilhos de pausa serão revistos à parte); o degrau B continua com o C23 (27,69%, pausa 41,5%), que tem o mesmo defeito e será refeito antes de qualquer decisão sobre o degrau B; a curva de 12 meses e o Monte Carlo do degrau A ainda são os do C22 original; as referências de slippage do critério 6 (C11) não dependem das notícias.

**Arquivos:** `reports\surv_C22n_E1h_E3x100_2a_newssrv.htm` (corrigido) e `reports\surv_C22e_E1h_E3x100_2a_e4off.htm` (mesmos dados, notícias antigas), trades em `trades\` e inis em `inis\` com os mesmos nomes. O `news_lab_srv.csv` sai do `news.csv` pela regra de horário de verão europeu (último domingo de março e de outubro, 01:00 UTC).

## 6. Anexos

`resultados.csv` · `montecarlo.csv` · `curva_kelly.csv` (base C4) · `curva_kelly_E13.csv` (bases C11 e V1) · `trades\*.csv` · `reports\*.htm` e `.png` · `inis\*.inputs.txt` e `inis_qdm\` · `regime\` (`analise_regime.py`, `regime_60d.csv`) · `rodar_paralelo.log` · `reports_sanidade\` (prova de que o patch não muda o resultado) · `reports_ref\` (relatórios de 20/09 com depósito 5.000, substituídos por esta campanha) · `_peso\` (estudo de peso: `res.csv` com C11 e C22, `res23.csv` com C23, `curva.csv` com as bases C11 e C22, trades dos três runs) · `_qdm\res.csv` (V2) · presets em `..\mql5\Presets\` (`Concorde_E13_A.set` do ini do C22, `Concorde_E13_B.set` do ini do C23, `SurvivalGuardian_G35.set`, `SurvivalGuardian_G45.set`; os presets do plano anterior foram apagados).
