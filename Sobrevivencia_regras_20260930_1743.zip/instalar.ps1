# instalar.ps1 - pacote de regras do Desafio Sobrevivencia (gerado na estacao em 20260930_1743):
#   laboratorio de testes (CLAUDE.md 5.9), referencia de DD corrigida (A3) e regras em modulos com ops\checar.ps1 (B5).
# Uso (console do VPS, usuario do auto-logon, FORA de uma acordada):
#   Expand-Archive <zip> -DestinationPath C:\Users\Public\regras_pkg -Force
#   powershell -NoProfile -ExecutionPolicy Bypass -File C:\Users\Public\regras_pkg\instalar.ps1
# Faz backup de cada arquivo substituido, confere SHA-256 antes e depois, faz no STATE.md so trocas pontuais
# (secao Laboratorio, pendencias, historico e as linhas da referencia de DD), roda as conferencias e grava o
# relatorio em ops\logs\instalar_regras_<ts>.txt. Nao mexe no terminal, no guardiao, no control.txt nem nas tarefas;
# nao liga o laboratorio ($LAB_LOGIN continua 0). Nao traz o ops\cmd.ps1.
$ErrorActionPreference = 'Stop'
$W = 'C:\Sobrevivencia'
$P = $PSScriptRoot
$ts = [DateTime]::UtcNow.ToString('yyyyMMdd_HHmmss')
$BK = "$W\ops\logs\backup_regras_$ts"
$REL = "$W\ops\logs\instalar_regras_$ts.txt"
$o = New-Object Collections.Generic.List[string]
function L([string]$m) { $o.Add($m); Write-Host $m }
if (($env:SURV_AGENTE -eq '1') -or [bool]$env:CLAUDECODE) { Write-Host 'RECUSADO: instalacao e do Henrique.'; exit 1 }
if (-not (Test-Path "$W\CLAUDE.md")) { Write-Host "ERRO: workspace $W nao encontrado"; exit 1 }
$lk = "$W\ops\logs\claude.lock"
if (Test-Path -LiteralPath $lk) {
    $lp = 0; [int]::TryParse("$((Get-Content -LiteralPath $lk -TotalCount 1))", [ref]$lp) | Out-Null
    if ($lp -gt 0 -and (Get-Process -Id $lp -ErrorAction SilentlyContinue)) { Write-Host "ABORTADO: ha uma acordada do Claude rodando (PID $lp). Rode de novo quando ela terminar."; exit 1 }
}
$man = @(Get-Content -LiteralPath "$P\manifest.txt" | Where-Object { $_ -match '\|' })
$falha = $false
foreach ($l in $man) {
    $r, $h = $l.Split('|')
    $src = Join-Path "$P\kit" $r
    if (-not (Test-Path -LiteralPath $src)) { L "FALTA no pacote: $r"; $falha = $true; continue }
    if ((Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash -ne $h) { L "HASH ERRADO no pacote: $r"; $falha = $true }
}
if ($falha) { L 'ABORTADO: pacote corrompido. Nada foi alterado.'; [IO.File]::WriteAllLines($REL, $o.ToArray()); exit 1 }
New-Item -ItemType Directory -Force -Path $BK | Out-Null
foreach ($l in $man) {
    $r, $h = $l.Split('|')
    $dst = Join-Path $W $r
    $antes = '(novo)'
    if (Test-Path -LiteralPath $dst) {
        $antes = (Get-FileHash -LiteralPath $dst -Algorithm MD5).Hash
        $bkArq = Join-Path $BK $r      # (nao usar $bk: e a mesma variavel que $BK no PowerShell)
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $bkArq) | Out-Null
        Copy-Item -LiteralPath $dst -Destination $bkArq -Force
    } else { New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null }
    Copy-Item -LiteralPath (Join-Path "$P\kit" $r) -Destination $dst -Force
    $depois = (Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash
    $ok = 'OK'; if ($depois -ne $h) { $ok = 'FALHOU'; $falha = $true }
    L ("{0,-6} {1,-26} antes md5={2} depois sha256={3}" -f $ok, $r, $antes, $depois.Substring(0, 16))
}
# ---------------- STATE.md: so trocas pontuais (o arquivo do VPS tem edicoes ao vivo)
$sf = "$W\STATE.md"
Copy-Item -LiteralPath $sf -Destination "$BK\STATE.md" -Force
$st = [IO.File]::ReadAllText($sf, [Text.Encoding]::UTF8)
$nl = "`n"; if ($st.Contains("`r`n")) { $nl = "`r`n" }
$pj = [IO.File]::ReadAllText("$P\state_patch.json", [Text.Encoding]::UTF8) | ConvertFrom-Json
function Contar([string]$T, [string]$S) { $n = 0; $i = $T.IndexOf($S, [StringComparison]::Ordinal); while ($i -ge 0) { $n++; $i = $T.IndexOf($S, $i + $S.Length, [StringComparison]::Ordinal) }; return $n }
$novasPend = @()
# (1) secao Laboratorio, pendencias e historico do laboratorio (se ainda nao existe)
if ($st -match '## Laborat') { L 'STATE.md: secao Laboratorio ja existe (nada feito nela)' }
else {
    $add = [IO.File]::ReadAllText("$P\state_lab.md", [Text.Encoding]::UTF8)
    $pH = $add -split '(?m)^@@HISTORICO@@\s*$'
    $histLab = ''; if ($pH.Count -gt 1) { $histLab = $pH[1].Trim() }
    $partes = $pH[0] -split '(?m)^@@PENDENCIAS@@\s*$'
    $secao = ($partes[0].TrimEnd() -replace "`r?`n", $nl) + $nl + $nl
    if ($partes.Count -gt 1) { $novasPend += @($partes[1].Trim() -split "`r?`n" | Where-Object { $_.Trim() }) }
    $i = $st.IndexOf('## Pend')
    if ($i -lt 0) { L 'ERRO: STATE.md sem "## Pendencias": secao Laboratorio NAO inserida'; $falha = $true }
    else { $st = $st.Substring(0, $i) + $secao + $st.Substring($i); L 'STATE.md: secao Laboratorio inserida antes de Pendencias' }
    if ($histLab) { $pj.historico = @($histLab) + @($pj.historico) }
}
# (2) trocas da referencia de DD (A3): cada uma so se o trecho existir exatamente uma vez
$k = 0
foreach ($t in $pj.trocas) {
    $k++
    $dep = ($t.depois -replace "`r?`n", $nl)
    $c = Contar $st $t.antes
    if ((Contar $st $dep) -ge 1) { L ("STATE.md A3 troca {0}: ja aplicada" -f $k) }
    elseif ($c -eq 1) { $st = $st.Replace($t.antes, $dep); L ("STATE.md A3 troca {0}: OK" -f $k) }
    else { L ("STATE.md A3 troca {0}: TRECHO NAO ENCONTRADO ({1}x) - conferir a mao: {2}" -f $k, $c, $t.antes.Substring(0, [Math]::Min(70, $t.antes.Length))) }
}
# (3) pendencias no fim da tabela (numeracao seguinte) e historico no fim da secao
$novasPend += @($pj.pendencias)
$lines = $st -split "`n"
$nums = @(); $ult = -1; $maxN = 0
for ($q = 0; $q -lt $lines.Count; $q++) { $mm = [regex]::Match($lines[$q], '^\|\s*(\d+)\s*\|'); if ($mm.Success) { $v = [int]$mm.Groups[1].Value; if ($v -ge $maxN) { $maxN = $v; $ult = $q } } }
if ($ult -lt 0) { L 'ERRO: tabela de pendencias nao encontrada no STATE.md'; $falha = $true }
else {
    $ins = @()
    foreach ($pl in $novasPend) {
        $txtP = "$pl" -replace '^\|\s*N\s*\|', ''
        if ($st.Contains($txtP.Substring(0, [Math]::Min(60, $txtP.Length)))) { L 'STATE.md: pendencia ja existe (pulada)'; continue }
        $maxN++; $ins += ('| ' + $maxN + ' |' + $txtP + ($(if ($nl -eq "`r`n") { "`r" } else { '' })))
    }
    $depoisL = @(); if ($ult -lt $lines.Count - 1) { $depoisL = @($lines[($ult + 1)..($lines.Count - 1)]) }
    $lines = @($lines[0..$ult]) + $ins + $depoisL
    L ("STATE.md: {0} pendencia(s) acrescentada(s)" -f $ins.Count)
}
$st = $lines -join "`n"
$j = $st.IndexOf('## Hist')
if ($j -lt 0) { L 'AVISO: STATE.md sem "## Historico": historico nao acrescentado' }
else {
    foreach ($hl in $pj.historico) {
        if ($st.Contains($hl.Substring(0, [Math]::Min(60, $hl.Length)))) { L 'STATE.md: linha de historico ja existe (pulada)'; continue }
        $prox = $st.IndexOf("`n## ", $j + 5)
        if ($prox -lt 0) { $st = $st.TrimEnd() + $nl + $hl + $nl }
        else { $st = $st.Substring(0, $prox).TrimEnd() + $nl + $hl + $nl + $st.Substring($prox) }
        L 'STATE.md: linha de historico acrescentada'
    }
}
[IO.File]::WriteAllText($sf, $st, (New-Object Text.UTF8Encoding($false)))
foreach ($d in 'campanha\lab\fila', 'campanha\lab\lotes', 'campanha\lab\news') { New-Item -ItemType Directory -Force -Path (Join-Path $W $d) | Out-Null }
# ---------------- conferencias
foreach ($s in 'ops\lab.ps1', 'ops\checar.ps1', 'ops\run_claude.ps1') {
    $e = $null; [void][System.Management.Automation.Language.Parser]::ParseFile((Join-Path $W $s), [ref]$null, [ref]$e)
    if ($e) { L "ERRO de sintaxe em ${s}: $($e[0].Message)"; $falha = $true } else { L "${s}: sintaxe ok" }
}
try { Add-Type -TypeDefinition ([IO.File]::ReadAllText("$W\ops\lab_core.cs")) -Language CSharp -ReferencedAssemblies System.Core; L 'lab_core.cs: compilou' } catch { L "ERRO ao compilar lab_core.cs: $($_.Exception.Message)"; $falha = $true }
L '--- checar.ps1 -Acao autoteste'
$out = & powershell -NoProfile -ExecutionPolicy Bypass -File "$W\ops\checar.ps1" -Acao autoteste -SemJson 2>&1
$out | ForEach-Object { L ("  " + $_) }
if (($out -join "`n") -notmatch 'RESULTADO autoteste: OK') { L 'ATENCAO: o autoteste nao saiu OK: conferir as linhas acima (rotulos do STATE.md)'; $falha = $true }
L '--- checar.ps1 -Acao diario (somente leitura; o veredito e so para conferir a instalacao)'
& powershell -NoProfile -ExecutionPolicy Bypass -File "$W\ops\checar.ps1" -Acao diario -SemJson 2>&1 | ForEach-Object { L ("  " + $_) }
L '--- lab.ps1 -Acao status'
try { & powershell -NoProfile -ExecutionPolicy Bypass -File "$W\ops\lab.ps1" -Acao status 2>&1 | ForEach-Object { L ("  " + $_) } } catch { L "lab.ps1 status falhou: $($_.Exception.Message)" }
L '--- run_claude.ps1 -Modo diario -DryRun'
& powershell -NoProfile -ExecutionPolicy Bypass -File "$W\ops\run_claude.ps1" -Modo diario -DryRun 2>&1 | ForEach-Object { L ("  " + $_) }
if ($falha) { L "INSTALACAO COM FALHA: backup em $BK (para voltar: copiar o backup por cima)" } else { L "INSTALACAO OK. Backup em $BK" }
L 'Proximo passo do laboratorio (Henrique): SETUP_VPS 6.7 (lab_instalar.ps1, demo na copia, MCP e Algo Trading desligados, $LAB_LOGIN, register_tasks -SoLab).'
[IO.File]::WriteAllLines($REL, $o.ToArray())
Write-Host "relatorio: $REL"
